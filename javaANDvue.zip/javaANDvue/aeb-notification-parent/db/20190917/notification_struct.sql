-----------------------------------------------------
-- Export file for user DHR_NOTIFICATION           --
-- Created by chunliucq on 17/09/2019, 10:22:25 AM --
-----------------------------------------------------

create table EMAIL_SEND_ATTACHMENT
(
  ID                NUMBER(19) not null,
  CREATED_DATE      TIMESTAMP(6) not null,
  CREATED_USER_OID  RAW(16) not null,
  DELETED           NUMBER(1) not null,
  MODIFIED_DATE     TIMESTAMP(6) not null,
  MODIFIED_USER_OID RAW(16) not null,
  OID               RAW(16),
  EMAIL_OID         RAW(16) not null,
  FILE_NAME         VARCHAR2(255 CHAR) not null,
  FILE_SIZE         NUMBER(19) not null,
  STORAGE_ADDRESS   VARCHAR2(255 CHAR) not null,
  SUFFIX            VARCHAR2(20 CHAR)
)
;
alter table EMAIL_SEND_ATTACHMENT
  add primary key (ID);
alter table EMAIL_SEND_ATTACHMENT
  add constraint UK_M4YY7TGUIC4OLH4FGU0BC69UP unique (OID);

prompt
prompt Creating table EMAIL_SEND_LOG
prompt =============================
prompt
create table EMAIL_SEND_LOG
(
  ID                NUMBER(19) not null,
  CREATED_DATE      TIMESTAMP(6) not null,
  CREATED_USER_OID  RAW(16) not null,
  DELETED           NUMBER(1) not null,
  MODIFIED_DATE     TIMESTAMP(6) not null,
  MODIFIED_USER_OID RAW(16) not null,
  OID               RAW(16),
  CONTENT           CLOB,
  COPY_TO           VARCHAR2(255 CHAR),
  RECEIVER          VARCHAR2(255 CHAR) not null,
  SUBJECT           VARCHAR2(255 CHAR) not null
)
;
alter table EMAIL_SEND_LOG
  add primary key (ID);
alter table EMAIL_SEND_LOG
  add constraint UK_AVOQGY9H7BA20LTFIYXNK71DQ unique (OID);


create table SMS_SEND_LOG
(
  ID                 NUMBER(19) not null,
  CREATED_DATE       TIMESTAMP(6) not null,
  CREATED_USER_OID   RAW(16) not null,
  DELETED            NUMBER(1) not null,
  MODIFIED_DATE      TIMESTAMP(6) not null,
  MODIFIED_USER_OID  RAW(16) not null,
  OID                RAW(16),
  BIZ_ID             VARCHAR2(30 CHAR) not null,
  OUT_ID             VARCHAR2(100 CHAR),
  RECEIVER           VARCHAR2(20 CHAR) not null,
  REQUEST_ID         VARCHAR2(36 CHAR) not null,
  SEND_TIME          TIMESTAMP(6) not null,
  SIGN_NAME          VARCHAR2(30 CHAR) not null,
  SMS_UP_EXTEND_CODE VARCHAR2(255 CHAR),
  TEMPLATE_CODE      VARCHAR2(20 CHAR) not null,
  TEMPLATE_PARAM     CLOB
)
;
alter table SMS_SEND_LOG
  add primary key (ID);
alter table SMS_SEND_LOG
  add constraint UK_8PK6F6TUC8R1S8NGW9G3TPLN0 unique (OID);


create sequence HIBERNATE_SEQUENCE
minvalue 1
maxvalue 9999999999999999999999999999
start with 41
increment by 1
cache 20;

