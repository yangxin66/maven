package com.deloitte.notification.provider.gateway.rest.v1;

import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.notification.provider.api.EmailRestInterface;
import com.deloitte.notification.provider.api.model.EmailParamDto;
import com.deloitte.notification.provider.service.EmailServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

/**
 * @author LiuChun
 */
@Api(tags = "邮件发送相关REST接口", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
@RestController
@RequestMapping(value = "/api/v1/email")
public class EmailRestController implements EmailRestInterface {
    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    EmailServiceImpl mailService;

    /**
     * 发送邮件
     * @param receivers 邮件接收人
     * @param copyTo 抄送
     * @param subject 主题
     * @param content 内容
     * @param attachments 附件信息
     * @return
     */
    @ApiOperation(value = "发送邮件", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiImplicitParams({
        @ApiImplicitParam(name = "receivers", value = "邮件接收人", required = true, dataType = "string"),
        @ApiImplicitParam(name = "copyTo", value = "抄送", required = false, dataType = "string"),
        @ApiImplicitParam(name = "subject", value = "主题", required = true, dataType = "string"),
        @ApiImplicitParam(name = "content", value = "内容", required = true, dataType = "string"),
        @ApiImplicitParam(name = "attachments", value = "附件", required = false,allowMultiple = true,dataType = "MultipartFile"),
    })
    @Override
    @PostMapping(value = "/send",consumes = MediaType.MULTIPART_FORM_DATA_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Response<String> sendEmail(@RequestParam(required = true,value = "receivers") String receivers,
                                      @RequestParam(required = false,value = "copyTo") String copyTo,
                                      @RequestParam(required = true,value = "subject") String subject,
                                      @RequestParam(required = true,value = "content") String content,
                                      @RequestPart(required = false,value = "attachments") MultipartFile[] attachments) {
        try {
            EmailParamDto emailParamDto = EmailParamDto.builder().build();
            emailParamDto.setReceivers(receivers);
            emailParamDto.setCopyTo(copyTo);
            emailParamDto.setSubject(subject);
            emailParamDto.setContent(content);
            mailService.sendMimeEmail(emailParamDto,attachments);
        }catch (BusinessException e){
            log.error("发送邮件异常",e);
            throw e;
        }
        return new Response<>(LanguageEnum.ZH_CN,Response.SUCCESS_CODE,"success",null);
    }

    @ApiOperation(value = "发送邮件", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,notes = "发送邮件,并且不能带有附件")
    @PostMapping(value = "/send_no_attachment", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiImplicitParam(name = "emailParamDto", value = "发送邮件信息,并且不能带有附件",
            required = true, dataType = "EmailParamDto")
    @Override
    public Response<String> sendEmailWithNoAttachment(@RequestBody EmailParamDto emailParamDto) {
        try {
            mailService.sendMimeEmail(emailParamDto,null);
        }catch (BusinessException e){
            log.error("发送邮件异常",e);
            throw e;
        }
        return new Response<>(LanguageEnum.ZH_CN,Response.SUCCESS_CODE,"success",null);
    }

    @ApiOperation(value = "发送邮件", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,notes = "批量发送邮件,并且不能带有附件")
    @PostMapping(value = "/send_no_attachment_batch", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @Override
    public Response<String> sendBatchEmailWithNoAttachment(@RequestBody List<EmailParamDto> emailParamDtoList) {
        try {
            Optional.of(emailParamDtoList).ifPresent(emailParamList -> {
                emailParamList.forEach(tmp -> {
                    mailService.sendMimeEmail(tmp,null);
                });
            });
        }catch (BusinessException e){
            log.error("发送邮件异常",e);
            throw e;
        }
        return new Response<>(LanguageEnum.getDefault(),Response.SUCCESS_CODE,null,null);
    }

}
