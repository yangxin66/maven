package com.deloitte.notification.provider.exception;

import lombok.Data;

/**
 * @author chunliucq
 * @since 02/09/2019 19:24
 */
public enum ExceptionEnum {
    SystemException("001-00-00001","系统异常，请联系管理员处理."),
    EMAIL_RECIEVER_NONE("001-00-00002","邮件接收者不能为空"),

    ;

    private String code;
    private String message;

    private ExceptionEnum(String code,String message){
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
