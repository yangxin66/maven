package com.deloitte.notification.provider.service;

import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.notification.provider.api.model.AliyunSmsDto;
import com.deloitte.notification.provider.exception.ExceptionEnum;
import com.deloitte.notification.provider.infrastructure.sms.configuration.properties.AliyunSmsInstanceProperties;
import com.deloitte.notification.provider.infrastructure.sms.model.AliyunSmsActionEnum;
import com.deloitte.notification.provider.infrastructure.sms.model.AliyunSmsResponse;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 基于阿里云短信服务的"短信发送器"
 *
 * @author xideng
 */
@Service
public class AliyunSmsServiceImpl implements AliyunSmsService {

    private static final Gson GSON = new Gson();

    private final IAcsClient client;
    @Autowired
    private final SmsSendLogService smsSendLogService;

    public AliyunSmsServiceImpl(IAcsClient client, SmsSendLogService smsSendLogService) {
        this.client = client;
        this.smsSendLogService = smsSendLogService;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public AliyunSmsDto sendSms(String phoneNumbers, String signName, String templateCode,
                                String templateParam, String smsUpExtendCode, String outId) throws ClientException {

        CommonRequest request = new CommonRequest();
        request.setMethod(MethodType.POST);
        request.setDomain(AliyunSmsInstanceProperties.DOMAIN);
        request.setVersion(AliyunSmsInstanceProperties.VERSION);
        request.setAction(AliyunSmsActionEnum.SEND_SMS.getValue());
        request.putQueryParameter("RegionId", AliyunSmsInstanceProperties.REGION_ID);
        request.putQueryParameter("PhoneNumbers", phoneNumbers);
        request.putQueryParameter("SignName", signName);
        request.putQueryParameter("TemplateCode", templateCode);
        if (null != templateParam && !templateParam.isEmpty()) {
            request.putQueryParameter("TemplateParam", templateParam);
        }
        if (null != smsUpExtendCode) {
            request.putQueryParameter("SmsUpExtendCode", smsUpExtendCode);
        }
        if (null != outId) {
            request.putQueryParameter("OutId", outId);
        }

        CommonResponse response = this.client.getCommonResponse(request);
        AliyunSmsResponse valueObject = GSON.fromJson(response.getData(), AliyunSmsResponse.class);
        if (valueObject.requestSuccessful()) {
            smsSendLogService.saveLogBySendTask(
                    phoneNumbers,signName, templateCode, templateParam, smsUpExtendCode, outId,
                    valueObject.getBizId(), valueObject.getRequestId());
            return valueObject.transfer();
        } else {
            throw new BusinessException(ExceptionEnum.SystemException.getCode(),valueObject.getMessage());
        }
    }
}
