package com.deloitte.notification.provider.repository.model;

import lombok.Builder;
import lombok.Data;

/**
 * 附件信息
 * @author chunliu
 */
@Data
public class Attachment {
    /**
     * 附件名称
     */
    private String fileName;
    /**
     * 附件后缀名
     */
    private String suffix;

    /**
     * 附件大小，单位KB
     */
    private Long size;

    /**
     * 附件存储地址
     */
    private String fileAddress;
}
