package com.deloitte.notification.provider.repository;

import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.notification.provider.repository.model.EmailSendAttachmentPo;
import org.springframework.stereotype.Repository;

@Repository
public interface EmailSendAttachmentRepoitory extends BaseRepository<EmailSendAttachmentPo> {
}
