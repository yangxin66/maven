package com.deloitte.notification.provider.service;

import com.deloitte.notification.provider.repository.model.Attachment;
import com.deloitte.notification.provider.api.model.EmailParamDto;
import com.deloitte.notification.provider.repository.EmailSendAttachmentRepoitory;
import com.deloitte.notification.provider.repository.EmailSendLogRepository;
import com.deloitte.notification.provider.repository.model.EmailSendAttachmentPo;
import com.deloitte.notification.provider.repository.model.EmailSendLogPo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmailSendLogServiceImpl implements EmailSendLogService {

    @Autowired
    private EmailSendLogRepository emailSendLogRepository;

    @Autowired
    private EmailSendAttachmentRepoitory emailSendAttachmentRepoitory;

    @Override
    @Transactional(rollbackFor = {Exception.class})
    public void saveSendLog(EmailParamDto paramDto,List<Attachment> attachmentList) {
        EmailSendLogPo emailSendLogPo = new EmailSendLogPo();
        emailSendLogPo.setReceiver(paramDto.getReceivers());
        emailSendLogPo.setCopyTo(paramDto.getCopyTo());
        emailSendLogPo.setSubject(paramDto.getSubject());
        emailSendLogPo.setContent(paramDto.getContent());

        EmailSendLogPo saveResult = emailSendLogRepository.save(emailSendLogPo);

        if (attachmentList != null && !attachmentList.isEmpty()){
            List<EmailSendAttachmentPo> emailSendAttachmentPoList = new ArrayList();
            for (Attachment attachment : attachmentList){
                EmailSendAttachmentPo po = new EmailSendAttachmentPo();
                po.setName(attachment.getFileName());
                po.setEmailOid(saveResult.getOid());
                po.setSuffix(attachment.getSuffix());
                po.setSize(attachment.getSize());
                po.setStorageAddress(attachment.getFileAddress());
                emailSendAttachmentPoList.add(po);
            }
            emailSendAttachmentRepoitory.saveAll(emailSendAttachmentPoList);
        }

    }
}
