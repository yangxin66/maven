package com.deloitte.notification.provider.infrastructure.sms.model;

import com.deloitte.notification.provider.api.model.AliyunSmsDto;
import com.google.gson.annotations.SerializedName;
import lombok.Data;

import java.io.Serializable;
import java.util.Objects;

/**
 * "阿里云短信服务响应"值对象
 *
 * @author xideng
 */
@Data
public class AliyunSmsResponse implements Serializable {

    private static final long serialVersionUID = 3550395866646222660L;

    private static final String SUCCESS_CODE = "OK";

    /**
     * 发送回执ID，可根据该ID在接口QuerySendDetails中查询具体的发送状态
     */
    @SerializedName("BizId")
    private final String bizId;

    /**
     * 请求状态码
     */
    @SerializedName("Code")
    private final String code;

    /**
     * 状态码的描述
     */
    @SerializedName("Message")
    private final String message;

    /**
     * 请求ID
     */
    @SerializedName("RequestId")
    private final String requestId;

    /**
     * 判断请求是否成功
     *
     * @return true -> 成功 | false -> 失败
     */
    public boolean requestSuccessful() {
        return Objects.equals(this.code, SUCCESS_CODE);
    }

    /**
     * 将请求对象转换为{@link AliyunSmsDto}对象，
     * 注意，只有请求成功时才会转换
     */
    public AliyunSmsDto transfer() {
        if (requestSuccessful()) {
            return new AliyunSmsDto(bizId, requestId);
        }
        return null;
    }
}
