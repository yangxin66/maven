package com.deloitte.notification.provider.service;

import com.aliyuncs.exceptions.ClientException;
import com.deloitte.notification.provider.api.model.AliyunSmsDto;

import java.util.Map;

/**
 * 阿里云短信服务接口
 *
 * @author xideng
 */
public interface AliyunSmsService {

    /**
     * 调用Aliyun Server发送短信
     *
     * @param phoneNumbers    接收方手机号码，多个以","隔开
     * @param signName        短信签名
     * @param templateCode    模板编码
     * @param templateParam   模板参数
     * @param smsUpExtendCode 上行短信扩展码
     * @param outId           外部流水扩展字段
     */
    AliyunSmsDto sendSms(String phoneNumbers,
                         String signName,
                         String templateCode,
                         String templateParam,
                         String smsUpExtendCode,
                         String outId) throws ClientException;
}
