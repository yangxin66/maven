package com.deloitte.notification.provider.service;

import com.deloitte.infrastructure.jpa.service.BaseService;
import com.deloitte.notification.provider.repository.model.SmsSendLogPo;

/**
 * 短信日志服务接口
 *
 * @author xideng
 */
public interface SmsSendLogService extends BaseService<SmsSendLogPo> {

    /**
     * 根据短信发送任务存储日志
     *
     * @param phoneNumbers    接收方手机号码，多个以","隔开
     * @param signName        短信签名
     * @param templateCode    模板编码
     * @param templateParam   模板参数
     * @param smsUpExtendCode 上行短信扩展码
     * @param outId           外部流水扩展字段
     * @param bizId           短信发送回执ID
     * @param requestId       请求ID
     */
    void saveLogBySendTask(String phoneNumbers,
                           String signName,
                           String templateCode,
                           String templateParam,
                           String smsUpExtendCode,
                           String outId,
                           String bizId,
                           String requestId);

}
