package com.deloitte.notification.provider.service;

import com.deloitte.notification.provider.api.model.EmailParamDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * 发关邮件服务接口
 */
public interface EmailService {

    /**
     * 发送Mime类型邮件
     */
    public void sendMimeEmail(EmailParamDto paramDto, MultipartFile[] files);
}
