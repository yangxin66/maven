package com.deloitte.notification.provider.repository.model;

import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * 短信发送日志模型
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "sms_send_log")
@Entity(name = "sms_send_log")
@SQLDelete(sql = "update sms_send_log set deleted = 1 where id = ?")
@Where(clause = "deleted = 0")
public class SmsSendLogPo extends BasePo {

    private static final long serialVersionUID = 3894747077779873605L;

    /**
     * 接受者电话号码
     */
    @Column(name = "receiver", length = 20, nullable = false, updatable = false)
    private String receiver;

    /**
     * 短信发送签名
     */
    @Column(name = "sign_name", length = 30, nullable = false, updatable = false)
    private String signName;

    /**
     * 模板id
     */
    @Column(name = "template_code", length = 20, nullable = false, updatable = false)
    private String templateCode;

    /**
     * 短信发送参数
     */
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "template_param", updatable = false)
    private String templateParam;


    /**
     * 上行短信扩展码
     */
    @Column(name = "sms_up_extend_code", updatable = false)
    private String smsUpExtendCode;

    /**
     * 外部流水扩展字段
     */
    @Column(name = "out_id", length = 100, updatable = false)
    private String outId;

    /**
     * 短信发送业务流水号id
     */
    @Column(name = "biz_id", nullable = false, updatable = false,length = 30)
    private String bizId;

    /**
     * 短信发送请求id
     */
    @Column(name = "request_id", nullable = false, updatable = false,length = 36)
    private String requestId;

    /**
     * 发送时间
     */
    @Column(name = "send_time", nullable = false, updatable = false)
    private LocalDateTime sendTime;
}
