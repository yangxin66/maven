package com.deloitte.notification.provider.service;

import com.deloitte.notification.provider.repository.model.Attachment;
import com.deloitte.notification.provider.api.model.EmailParamDto;

import java.util.List;

public interface EmailSendLogService {

    public void saveSendLog(EmailParamDto paramDto, List<Attachment> attachmentList);
}
