package com.deloitte.notification.provider.service;

import com.deloitte.infrastructure.jpa.service.BaseServiceImpl;
import com.deloitte.notification.provider.repository.SmsSendLogRepository;
import com.deloitte.notification.provider.repository.model.SmsSendLogPo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 短信发送日志服务层实现
 *
 * @author xideng
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class SmsSendLogServiceImpl extends BaseServiceImpl<SmsSendLogPo> implements SmsSendLogService {

    private static final String PHONE_NUMBERS_SEPARATOR = ",";

    private final SmsSendLogRepository repository;

    protected SmsSendLogServiceImpl(SmsSendLogRepository repository) {
        super(repository);
        this.repository = repository;
    }


    @Override
    public void saveLogBySendTask(
            String phoneNumbers, String signName, String templateCode, String templateParam,
            String smsUpExtendCode, String outId, String bizId, String requestId) {
        String[] numbers = phoneNumbers.split(PHONE_NUMBERS_SEPARATOR);
        LocalDateTime sendTime = LocalDateTime.now();
        List<SmsSendLogPo> logs = Stream.of(numbers)
                .map(number -> {
                    SmsSendLogPo smsSendLogPo = new SmsSendLogPo();
                    smsSendLogPo.setReceiver(number);
                    smsSendLogPo.setSignName(signName);
                    smsSendLogPo.setTemplateCode(templateCode);
                    smsSendLogPo.setTemplateParam(templateParam);
                    smsSendLogPo.setSmsUpExtendCode(smsUpExtendCode);
                    smsSendLogPo.setOutId(outId);
                    smsSendLogPo.setBizId(bizId);
                    smsSendLogPo.setRequestId(requestId);
                    smsSendLogPo.setSendTime(sendTime);
                    return smsSendLogPo;
                })
                .collect(Collectors.toList());
        repository.saveAll(logs);
    }
}
