package com.deloitte.notification.provider.repository.model;

import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.UUID;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "email_send_attachment")
@Entity(name = "email_send_attachment")
@SQLDelete(sql = "update email_send_attachment set deleted = 1 where id = ?")
@Where(clause = "deleted = 0")
public class EmailSendAttachmentPo extends BasePo {
    private static final long serialVersionUID = 3824747133739823625L;

    /**
     * 对应邮件发送记录oid
     */
    @Column(name = "email_oid", nullable = false, updatable = false,length = 16)
    private UUID emailOid;

    /**
     * 附件名称
     */
    @Column(name = "file_name", nullable = false, updatable = false,length = 255)
    private String name;

    /**
     * 附件名称
     */
    @Column(name = "suffix", nullable = true, updatable = false,length = 20)
    private String suffix;

    /**
     * 附件大小
     */
    @Column(name = "file_size", nullable = false, updatable = false)
    private Long size;

    /**
     * 附件大小
     */
    @Column(name = "storage_address", nullable = false, updatable = false,length = 255)
    private String storageAddress;
}
