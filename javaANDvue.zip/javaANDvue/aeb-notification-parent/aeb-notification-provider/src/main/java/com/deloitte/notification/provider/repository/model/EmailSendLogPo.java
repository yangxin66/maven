package com.deloitte.notification.provider.repository.model;


import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "email_send_log")
@Entity(name = "email_send_log")
@SQLDelete(sql = "update email_send_log set deleted = 1 where id = ?")
@Where(clause = "deleted = 0")
public class EmailSendLogPo extends BasePo {
    private static final long serialVersionUID = 3894747037779873625L;

    /**
     * 邮件接受者，多个以英文分号隔开
     */
    @Column(name = "receiver", length = 255, nullable = false, updatable = false)
    private String receiver;

    /**
     * 邮件抄送者，多个以英文分号隔开
     */
    @Column(name = "copy_to", length = 255, nullable = true, updatable = false)
    private String copyTo;

    /**
     * 邮件主题
     */
    @Column(name = "subject", length = 255, nullable = false, updatable = false)
    private String subject;

    /**
     * 邮件主题
     */
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "content",  nullable = true, updatable = false)
    private String content;
}
