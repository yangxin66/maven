package com.deloitte.notification.provider.gateway.rest.v1;

import com.aliyuncs.exceptions.ClientException;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.notification.provider.api.SmsRestInterface;
import com.deloitte.notification.provider.api.model.AliyunSmsDto;
import com.deloitte.notification.provider.api.model.AliyunSmsParamDto;
import com.deloitte.notification.provider.service.AliyunSmsServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 短信发送RESTful API
 *
 * @author xideng
 */
@Api(tags = "短信发送相关REST接口", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
@RestController
@RequestMapping(value = "/api/v1/sms")
public class SmsRestController implements SmsRestInterface {

    private final AliyunSmsServiceImpl sender;

    public SmsRestController(AliyunSmsServiceImpl sender) {
        this.sender = sender;
    }

    @ApiOperation(value = "发送短信", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiImplicitParam(name = "aliyunSmsParamDto", value = "短信发送参数聚合模型", dataType = "AliyunSmsParamDto", required = true)
    @PostMapping
    @Override
    public Response<AliyunSmsDto> sendSms(@Validated @RequestBody AliyunSmsParamDto aliyunSmsParamDto) {
        try {
            AliyunSmsDto aliyunSmsDto = sender.sendSms(
                    aliyunSmsParamDto.getPhoneNumbers(), aliyunSmsParamDto.getSignName(),
                    aliyunSmsParamDto.getTemplateCode(), aliyunSmsParamDto.getTemplateParam(),
                    aliyunSmsParamDto.getSmsUpExtendCode(), aliyunSmsParamDto.getOutId());
            return new Response<>(LanguageEnum.ZH_CN,Response.SUCCESS_CODE,"success",aliyunSmsDto);
        } catch (ClientException e) {
            e.printStackTrace();
            return null;
        }
    }
}
