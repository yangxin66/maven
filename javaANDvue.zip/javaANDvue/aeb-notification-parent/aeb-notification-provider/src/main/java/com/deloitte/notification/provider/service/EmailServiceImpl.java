package com.deloitte.notification.provider.service;

import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.notification.provider.exception.ExceptionEnum;
import com.deloitte.notification.provider.repository.model.Attachment;
import com.deloitte.notification.provider.api.model.EmailParamDto;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private EmailSendLogService emailSendLogService;

    @Value("${spring.mail.username}")
    private String from;

    @Value("${spring.mail.attachment-path}")
    private String attachBasePaht;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private JavaMailSender mailSender;

    private static String MULITY_SPLIT_CHAR = ";";

    /**
     * Mime类型邮件发送业务实现
     */
    @Override
    public void sendMimeEmail(EmailParamDto paramDto, MultipartFile[] files) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(from);
            if (StringUtils.isBlank(paramDto.getReceivers())){
                throw new BusinessException(ExceptionEnum.EMAIL_RECIEVER_NONE.getCode(),ExceptionEnum.EMAIL_RECIEVER_NONE.getMessage());
            }
            helper.setTo(paramDto.getReceivers().split(MULITY_SPLIT_CHAR));
            if (!StringUtils.isEmpty(paramDto.getCopyTo())){
                helper.setCc(paramDto.getCopyTo().split(MULITY_SPLIT_CHAR));
            }
            helper.setSubject(paramDto.getSubject());
            helper.setText(paramDto.getContent(), true);

            List<Attachment> attachmentList = new ArrayList();
            /**
             * 判断附件是否为空
             */
            if (files != null && files.length > 0) {
                /**
                 * 多附件处理
                 */
                for (MultipartFile file : files) {
                    try {
                        String storeFile = downdAttachFile(file);
                        helper.addAttachment(file.getOriginalFilename(), file);
                        Attachment po = new Attachment();
                        po.setFileName(file.getOriginalFilename());
                        String contentType = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1);
                        if (contentType.length() > 10){
                            contentType = contentType.substring(contentType.length() - 10);
                        }
                        po.setSuffix(contentType);
                        po.setSize(file.getSize());
                        po.setFileAddress(storeFile);
                        attachmentList.add(po);
                    } catch (Exception e) {
                        throw new BusinessException(ExceptionEnum.SystemException.getCode(),"邮件发送前，添加附件出现异常",e);
                    }
                }
            }
            // 发送邮件
            mailSender.send(message);

            // 保存邮件信息
            emailSendLogService.saveSendLog(paramDto,attachmentList);
        } catch (MessagingException e) {
            throw new BusinessException(ExceptionEnum.SystemException.getCode(),"发送邮件异常",e);
        }
    }

    /**
     * 保存文件
     * @param file 上传附件
     * @return 文件存储全地址
     */
    private String downdAttachFile(MultipartFile file){
        BufferedInputStream buf = null;
        BufferedOutputStream bos = null;

        String oriFile = file.getOriginalFilename();
        int doxIndex = oriFile.lastIndexOf(".");
        if (doxIndex < 0){
            doxIndex = oriFile.length();
        }
        String filePreName = oriFile.substring(0,doxIndex);
        String suffix = oriFile.substring(doxIndex + 1);
        String uuid = UUID.randomUUID().toString().replaceAll("-","");
        String storeFileName = filePreName + "_" + uuid + "." + suffix;
        String storePathFile = attachBasePaht + storeFileName;
        byte[] temp = new byte[1024];
        int len = -1;
        try {
            buf = new BufferedInputStream(file.getInputStream());
            bos = new BufferedOutputStream(new FileOutputStream(new File(storePathFile)));
            while ((len = buf.read(temp,0,temp.length)) >= 0){
                bos.write(temp,0,len);
                bos.flush();
            }
        }catch (Exception e){
            throw new BusinessException(ExceptionEnum.SystemException.getCode(),"保存附件异常",e);
        }finally {
            try {
                if (null != buf){
                    buf.close();
                }
                if (null != bos){
                    bos.close();
                }
            }catch (Exception e){
                throw new BusinessException(ExceptionEnum.SystemException.getCode(),"保存附件释放资源异常",e);
            }
        }
        return storePathFile;
    }
}