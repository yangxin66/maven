package com.deloitte.notification.provider.repository;

import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.notification.provider.repository.model.SmsSendLogPo;
import org.springframework.stereotype.Repository;

@Repository
public interface SmsSendLogRepository extends BaseRepository<SmsSendLogPo> {
}
