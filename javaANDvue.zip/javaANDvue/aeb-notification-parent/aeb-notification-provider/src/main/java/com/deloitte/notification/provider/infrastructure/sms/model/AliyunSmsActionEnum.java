package com.deloitte.notification.provider.infrastructure.sms.model;

import lombok.Getter;

public enum AliyunSmsActionEnum {

    SEND_SMS("SendSms"),

    SEND_BATCH_SMS("SendBatchSms"),

    QUERY_SEND_DETAILS("QuerySendDetails");

    @Getter
    private final String value;


    AliyunSmsActionEnum(String value) {
        this.value = value;
    }
}
