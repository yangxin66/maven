package com.deloitte.notification.provider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * 启动主类
 *
 * @author xideng
 */
@SpringBootApplication
@EnableJpaAuditing
public class NotificationProviderApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificationProviderApplication.class, args);
    }
}
