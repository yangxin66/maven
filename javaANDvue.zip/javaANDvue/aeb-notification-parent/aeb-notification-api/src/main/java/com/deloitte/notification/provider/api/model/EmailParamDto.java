package com.deloitte.notification.provider.api.model;

import lombok.Builder;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@Builder
public class EmailParamDto implements Serializable {
    /**
     * 邮件接收者，多个使用逗号分隔
     */
    @Length(max = 255,message = "邮件接收者长度不能超过255位")
    @NotBlank(message = "邮件接收者不能为空")
    private String receivers;
    /**
     * 邮件抄送者，多个使用逗号分隔
     */
    @Length(max = 255,message = "邮件抄送者长度不能超过255位")
    private String copyTo;
    /**
     * 邮件主题
     */
    @NotBlank(message = "邮件主题不能为空")
    private String subject;
    /**
     * 邮件内容
     */
    private String content;

}
