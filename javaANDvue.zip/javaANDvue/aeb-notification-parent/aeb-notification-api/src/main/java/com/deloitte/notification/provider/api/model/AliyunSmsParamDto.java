package com.deloitte.notification.provider.api.model;


import lombok.Builder;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 阿里云短信发送请求体
 *
 * @author xideng
 */
@Data
@Builder
public class AliyunSmsParamDto implements Serializable {

    private static final long serialVersionUID = 5437248633482865194L;

    /**
     * 手机号码，多个以","隔开
     */
    @NotNull(message = "手机号码不能为空")
    private final String phoneNumbers;

    /**
     * 短信签名
     */
    @NotNull(message = "短信签名不能为空")
    private final String signName;

    /**
     * 短信模板编码
     */
    @NotNull(message = "短信模板编码不能为空")
    private final String templateCode;

    /**
     * 短信模板参数，JSON字符串格式
     */
    private final String templateParam;

    /**
     * 上行短信扩展码
     */
    @Length(max = 255, message = "上行短信扩展码的长度不能超过255")
    private final String smsUpExtendCode;

    /**
     * 外部流水扩展字段
     */
    @Length(max = 100, message = "外部流水号的长度不能超过100")
    private final String outId;
}
