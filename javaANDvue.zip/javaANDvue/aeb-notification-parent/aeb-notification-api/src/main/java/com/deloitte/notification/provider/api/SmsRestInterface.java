package com.deloitte.notification.provider.api;

import com.deloitte.infrastructure.communication.Response;
import com.deloitte.notification.provider.api.model.AliyunSmsDto;
import com.deloitte.notification.provider.api.model.AliyunSmsParamDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient("AEB-NOTIFICATION")
public interface SmsRestInterface {

    @PostMapping(value = "/api/v1/sms")
    Response<AliyunSmsDto> sendSms(@RequestBody AliyunSmsParamDto aliyunSmsParamDto);
}
