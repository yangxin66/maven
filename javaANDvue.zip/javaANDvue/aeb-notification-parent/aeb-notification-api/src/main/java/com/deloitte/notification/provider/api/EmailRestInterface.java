package com.deloitte.notification.provider.api;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.notification.provider.api.configure.FeignMultipartSupportConfig;
import com.deloitte.notification.provider.api.model.EmailParamDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@FeignClient(name = "AEB-NOTIFICATION", configuration = FeignMultipartSupportConfig.class ,path = "/api/v1/email")
public interface EmailRestInterface {

    @PostMapping(value = "/send", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Response<String> sendEmail(@RequestParam String receivers,
                                      @RequestParam String copyTo,
                                      @RequestParam String subject,
                                      @RequestParam String content,
                                      @RequestPart MultipartFile[] files);

    @PostMapping(value = "/send_no_attachment", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Response<String> sendEmailWithNoAttachment(@RequestBody EmailParamDto emailParamDto);

    @PostMapping(value = "/send_no_attachment_batch", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Response<String> sendBatchEmailWithNoAttachment(@RequestBody List<EmailParamDto> emailParamDtoList);
}
;