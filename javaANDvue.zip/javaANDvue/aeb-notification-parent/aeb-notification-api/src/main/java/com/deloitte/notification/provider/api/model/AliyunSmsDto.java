package com.deloitte.notification.provider.api.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 阿里云短信
 *
 * @author xideng
 */
@Data
public class AliyunSmsDto implements Serializable {

    private static final long serialVersionUID = -8423487140862578815L;

    /**
     * 短信发送回执ID
     */
    private final String bizId;

    /**
     * 请求ID
     */
    private final String requestId;
}
