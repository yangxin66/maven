package com.deloitte.dhr.gateway.service.impl;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.utils.StreamUtil;
import com.deloitte.dhr.gateway.service.StaffInfoExportService;
import com.deloitte.dhr.hr.api.ExcelOutInterface;
import com.deloitte.dhr.hr.api.model.ExcelApplyExportDto;
import com.deloitte.dhr.hr.api.model.ExcelOutExprotDto;
import com.deloitte.dhr.hr.api.model.OutExportType;
import com.deloitte.dhr.hr.api.model.SearchTypeEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;

/**
 * <br/>29/08/2019 10:59
 *
 * @author lshao
 */
@Service
public class StaffInfoExportServiceImpl implements StaffInfoExportService {

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    ExcelOutInterface excelOutInterface;


//    @Override
    public void exportStaffInfoExcel(String data, HttpServletResponse httpServletResponse) {
        JavaType javaType = objectMapper.getTypeFactory().constructParametricType(Request.class, ExcelOutExprotDto.class);
        Request<ExcelOutExprotDto> excelOutExprotDtoRequest;
        try {
            excelOutExprotDtoRequest = objectMapper.readValue(data, javaType);
        } catch (IOException e) {
            throw new BusinessException(HRMateInfo.EXPORT_STAFF_INFO_TRANS_ERR.getCode(), HRMateInfo.EXPORT_STAFF_INFO_TRANS_ERR.getMessage(), e);
        }
        ExcelOutExprotDto excelOutExprotDto = excelOutExprotDtoRequest.getData();
        String filename = "员工信息";
        String outType = excelOutExprotDto.getOutType().name();
        if (excelOutExprotDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            filename = "未审核" + filename;
        } else {
            filename = "已审核" + filename;
        }
        if (outType.equals(OutExportType.BATCH_EXPORT.toString())) {
            filename = filename + "(部分名单)";
        }
        if (outType.equals(OutExportType.ALL_EXPORTS.toString())) {
            filename = filename + "(全部名单)";
        }
        InputStream inputStream = null;
//        try {
//            Response response =  excelOutInterface.getExceli(data);
//            inputStream = response.body().asInputStream();
//        } catch (IOException | ParseException e) {
//            throw new BusinessException(HRMateInfo.EXPORT_STAFF_INFO_ERR.getCode(), HRMateInfo.EXPORT_STAFF_INFO_ERR.getMessage(), e);
//        }
        filename = httpServletResponse.encodeURL(new String((filename + ".xls").getBytes(StandardCharsets.UTF_8), StandardCharsets.ISO_8859_1));
        httpServletResponse.setHeader("Content-Disposition", "attachment;filename=" + filename);
        StreamUtil.writeExcel(httpServletResponse, inputStream);
    }

}
