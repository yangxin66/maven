package com.deloitte.dhr.gateway.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author chunliucq
 * @since 27/09/2019 21:20
 */
@Data
public class Item {
    private String id;
    private String name;
    private String url;
    private List<Item> submenu = new ArrayList<>();
}
