package com.deloitte.dhr.gateway.service;

import com.deloitte.dhr.hr.api.model.AttachDTO;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 附件上传
 * <br/>29/08/2019 10:58
 *
 * @author lshao
 */
public interface AttachService {

    Response<AttachDTO> uploadAttch(MultipartFile file);

    void downLoad(AttachDTO dto, HttpServletResponse httpResponse);
}
