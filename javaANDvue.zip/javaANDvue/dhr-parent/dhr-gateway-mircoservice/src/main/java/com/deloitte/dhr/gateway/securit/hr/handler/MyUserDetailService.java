package com.deloitte.dhr.gateway.securit.hr.handler;

import com.deloitte.dhr.gateway.securit.hr.config.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Collections;

/**
 * @author chunliucq
 * @since 11/09/2019 22:52
 */
@Component
public class MyUserDetailService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        String token = userRepository.findTokenByUsername(username);
        return new User(username,token, Collections.emptyList());
    }
}
