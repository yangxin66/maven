package com.deloitte.dhr.gateway.securit.hr.filter;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.gateway.securit.hr.config.Oauth2ClientProperties;
import com.deloitte.dhr.gateway.securit.hr.model.AuthTokenInfo;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Base64;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * 用户权限访问过虑器，DHR无权限管理，需远程请求DUSER权限管理功能进行鉴权
 * @author chunliucq
 * @since 27/09/2019 10:50
 */
@Component
public class AccessAuthenticationFilter implements Filter {

    private RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private Oauth2ClientProperties oauth2ClientProperties;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest)servletRequest;
        String request = req.getRequestURI();

        boolean debug = true;

        if (debug){
            filterChain.doFilter(servletRequest,servletResponse);
            return;
        }

       String[] excluPath = {"/error"};
       for (String path : excluPath){
           if ((req.getContextPath() + path).equals(req.getRequestURI())){
               filterChain.doFilter(servletRequest,servletResponse);
               return;
           }
       }
        HttpHeaders headers = new HttpHeaders();
        String authHeaderName = "Authorization";

        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.add(authHeaderName,req.getHeader(authHeaderName));

        JSONObject jsonObject = ContextSession.getTokenPayload();

//        MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();
//        paramMap.add("staffNo", jsonObject.getString("staff_no"));
//        paramMap.add("clientId", jsonObject.getString("client_id"));
//        paramMap.add("requestUri", req.getRequestURI());
//        MultiValueMap<String, Object> dataMap = new LinkedMultiValueMap<>();
        Map<String,Object> dataMap = new HashMap<>();
        Map<String,Object> paramMap = new HashMap<>();
        paramMap.put("staffNo", jsonObject.getString("staff_no"));
        paramMap.put("clientId", jsonObject.getString("client_id"));
        paramMap.put("requestUri", req.getRequestURI());
        dataMap.put("data",paramMap);
        HttpEntity<Map<String,Object>> entity = new HttpEntity<>(dataMap, headers);

        ResponseEntity<Response> resp = restTemplate.postForEntity(oauth2ClientProperties.getAccessAuthUri(), entity, Response.class);
        if (resp.getStatusCode() != null && resp.getStatusCode().value() == 200) {
            filterChain.doFilter(servletRequest,servletResponse);
        }else {
            // 没有权限，直接返回
            Response<Void> respInfo = new Response<>(LanguageEnum.ZH_CN,
                    HRMateInfo.STAFF_NO_FORBIDDEN_EXCEPTION.getCode(),
                    HRMateInfo.STAFF_NO_FORBIDDEN_EXCEPTION.getMessage(),
                    null);
            servletResponse.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
            servletResponse.getWriter().write(SerializerUtils.serialize(respInfo));
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }
    @Override
    public void destroy() {

    }
}
