package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.hr.api.PositiveInterface;
import com.deloitte.dhr.hr.api.model.UnposotiveSearchDto;
import com.deloitte.dhr.hr.api.model.UnposotiveStaffInfoDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 转正接口
 *
 * @author chunliucq
 * @since 22/08/2019 11:25
 */
@RestController
@RequestMapping(value = "/api/v1/hr/positive", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class PositiveController{


    @Autowired
    PositiveInterface positiveInterface;


    @PostMapping("/staff_unpositive")
    public PaginationResponse<List<UnposotiveStaffInfoDto>> getUnPositiveStaff(@RequestBody PaginationRequest<UnposotiveSearchDto> request) {
        return positiveInterface.getUnPositiveStaff(request);
    }
}
