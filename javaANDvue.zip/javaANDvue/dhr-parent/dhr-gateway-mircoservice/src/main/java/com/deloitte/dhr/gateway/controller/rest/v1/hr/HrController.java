package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.HrInterface;
import com.deloitte.dhr.hr.api.model.SearchStaffCategoryInfoDto;
import com.deloitte.dhr.hr.api.model.SendStaffEmailDTO;
import com.deloitte.dhr.hr.api.model.VerifyStaffInfoDTO;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * hr填写信息
 * <br/>27/08/2019 11:32
 *
 * @author lshao
 */
@RestController
@RequestMapping(value = "/api/v1/hr", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class HrController {
    @Autowired
    private HrInterface hrInterface;

    @PostMapping(value = "/save")
    public Response<String> saveStaffInfo(@RequestBody Request<PageDataRequest> request) {
        return hrInterface.saveStaffInfo(request);
    }

    @PostMapping(value = "/sendStaffEmail")
    public Response<String> sendStaffEmail(@RequestBody Request<SendStaffEmailDTO> request) {

        return hrInterface.sendStaffEmail(request);
    }
    @PostMapping(value = "/verifyStaffInfo")
    public Response<String> verifyStaffInfo(@RequestBody Request<VerifyStaffInfoDTO> request) {
        return hrInterface.verifyStaffInfo(request);
    }
    @PostMapping(value = "/searchStaffCategoryInfo")
    public Response<JSONObject> searchStaffCategoryInfo(@RequestBody Request<SearchStaffCategoryInfoDto> request) {
        return hrInterface.searchStaffCategoryInfo(request);
    }

}
