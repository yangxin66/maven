package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.hr.api.StationRestInterface;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * 岗位相关的接口
 *
 * @author wgong
 */
@RestController
@RequestMapping(value = "/api/v1/hr/organizations", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class StationController {

    @Autowired
    private StationRestInterface stationRestInterface;

    /**
     * 根据岗位名称或岗位编码分页查询岗位数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @PostMapping("/stations/page")
    PaginationResponse<List<OrganizationSearchResDto>> getStationByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest){
        return stationRestInterface.getStationByPage(paginationRequest);
    }

    /**
     * 根据部门名称或部门编码分页查询部门数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @PostMapping("/departments/page")
    PaginationResponse<List<OrganizationSearchResDto>> getDepartmentByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest){
        return stationRestInterface.getDepartmentByPage(paginationRequest);
    }

    @PostMapping("/unit/page")
    public PaginationResponse<List<OrganizationSearchResDto>> getUnitByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest) {
        return stationRestInterface.getUnitByPage(paginationRequest);
    }

    /**
     * 根据上级组织编号和类型查找组织
     *
     * @param organizationQueryDtoRequest 查询参数传输实体
     */
    @PostMapping("/child")
    Response<List<OrganizationDto>> getOrganizationChild(@RequestBody Request<OrganizationQueryDto> organizationQueryDtoRequest){
        return stationRestInterface.getOrganizationChild(organizationQueryDtoRequest);
    }


}
