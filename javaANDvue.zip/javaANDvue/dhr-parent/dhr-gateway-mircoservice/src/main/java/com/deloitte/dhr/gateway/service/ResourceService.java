package com.deloitte.dhr.gateway.service;

import com.deloitte.dhr.gateway.model.Item;
import com.deloitte.dhr.gateway.model.ResourcesDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

/**
 * @author chunliucq
 * @since 07/10/2019 16:39
 */
public interface ResourceService {
    public static final String resource_type_api = "API";
    public static final String resource_type_menu = "MENU";

    /**
     * 获取资源列表 分菜单资源 和 API资源
     * @param staffNo
     * @param type 资源类型
     * @return
     */
    List<ResourcesDto> getResourceList(String staffNo, String type);
}
