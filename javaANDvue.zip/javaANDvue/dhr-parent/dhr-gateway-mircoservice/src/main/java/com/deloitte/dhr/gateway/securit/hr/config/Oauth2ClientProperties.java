package com.deloitte.dhr.gateway.securit.hr.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * @author chunliucq
 * @since 08/09/2019 21:24
 */

@Data
@Configuration
@ConfigurationProperties(prefix = "security.oauth2.client")
public class Oauth2ClientProperties {
    private String clientId;
    private String clientSecret;
    private String accessTokenUri;
    private String userAuthorizationUri;
    private String preEstablishedRedirectUri;
    private String checkTokenUri;
    private String logoutUri;
    private List<String> noneAuthPath;
    /**
     *  鉴权URI
     */
    private String accessAuthUri;
    /**
     * 查询用户角色URL
     */
    private String accessAuthQueryRoles;

    /**
     * 查询用户资源URL
     */
    private String accessAuthQueryResoures;
}
