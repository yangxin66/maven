package com.deloitte.dhr.gateway.constant;

/**
 * 公共的安全管理控制常量
 *
 * @author xideng
 */
public class CommonSecurityConstant {

    private CommonSecurityConstant() {
    }

    public static final String DETAILS_SESSION_NAME = "_LOGIN_USER_DETAILS";

    public static final String LOGOUT_URL = "/logout";

    public static final String SWAGGER_UI_URL = "/swagger-ui.html";
    public static final String SWAGGER_WEBJARS_URL = "/webjars/**";
    public static final String SWAGGER_RESOURCE_URL = "/swagger-resources/**";
    public static final String SWAGGER_API_DOCS_URL = "/v1/**";

    public static final String EMP_FILL_INFO = "/entry/fill/**";

    public static final String EMP_FILL_INFO_INIT = "/entry/add/init";

    public static final String TRANSFORM_USER = "/transform/user";

    public static final String TRANSFORM_ORGANIZATION = "/transform/organization";

    public static final String ACCESS_DENIED_MESSAGE = "权限不足，访问失败";

    public static final String ROLE_PREFIX = "ROLE_";
    
    public static final String DEFAULT_VALICODE_PROCESS_SESSION_KEY="processName";
        
    public static final String DEFAULT_VALICODE_PROCESS_NAME="ValicodeProcess";
    
    public static final String DEFAULT_VALICODE_COOKIE_KEY="ValicodeAuthentication";
    
    public static final String DEFAULT_SECURITY_AUTH_RESULT_KEY="authResult";
    
    public static final String DEFAULT_MFA_ENABLE="1"; 
    
    public static final Long DEFAULT_TOKEN_TIMEOUT=30 * 24 * 60 * 60 * 1000L;//30天
    
    public static final Integer DEFAULT_COOKIE_TIMEOUT=30 * 24 * 60 * 60;//30天
    
    public static final String VALICODE_TOKEN_USERID="userId";
    
    public static final String VALICODE_TOKEN_DATE="date";

    public static final String SMS_LOGIN = "sms_login";
    
    public static final String SMS_REGIST = "sms_regist";

    public static final String SMS_FORGET = "sms_forget";
    
    public static Long DEFAULT_SMS_TIMEOUT = 65L;
    
    public static int DEFAULT_SMS_CODE_SIZE = 6;
}
