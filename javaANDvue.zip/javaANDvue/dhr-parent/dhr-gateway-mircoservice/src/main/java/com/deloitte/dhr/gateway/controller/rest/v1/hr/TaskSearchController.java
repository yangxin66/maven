package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.hr.api.TaskSearchInterface;
import com.deloitte.dhr.hr.api.model.SearchDto;
import com.deloitte.dhr.hr.api.model.StaffInfoApplyDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 任务查询接口
 *
 * @author wgong
 * @since 22/08/2019 11:25
 */
@RestController
@RequestMapping(value = "/api/v1/hr/task", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class TaskSearchController {


    @Autowired
    TaskSearchInterface taskInterface;


    @PostMapping("/search")
    public PaginationResponse<List<StaffInfoApplyDto>> searchStaffInfoTask(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
        return taskInterface.searchStaffInfoTask(searchDtoPaginationRequest);
    }

    @PostMapping("/search/my_application")
    public PaginationResponse<List<StaffInfoApplyDto>> searchMyApplication(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
        return taskInterface.searchMyApplicationByPage(searchDtoPaginationRequest);
    }

}
