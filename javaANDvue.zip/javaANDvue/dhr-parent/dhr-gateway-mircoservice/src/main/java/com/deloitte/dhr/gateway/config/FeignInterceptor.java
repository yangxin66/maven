package com.deloitte.dhr.gateway.config;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.CommonConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.gateway.service.ContextSessionService;
import com.deloitte.infrastructure.ex.BusinessException;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Objects;


/**
 * @author amzheng
 * @disc
 * @type
 * @creatTime 26/04/2019
 */
@Component
public class FeignInterceptor implements RequestInterceptor {
    public static final String currentUserOid = "16bc38d0-5a39-4e03-bcb9-6abbe3304ccc";

    public static final String currentDepartmentOid = "22bc38d0-5a39-4e03-bcb9-6abbe3304ccc";

    @Autowired
    private ContextSessionService contextSessionService;

    // TODO: 03/09/2019 需要后续跟登录进行改造，现在登录用户信息写死
    @Override
    public void apply(RequestTemplate requestTemplate) {
        String jwtToken = ContextSession.getLoginUseToken();
        if (jwtToken == null){
            return;
        }

        requestTemplate.header(CommonConstant.TOKEN_JWT, jwtToken);
        String staffNo = ContextSession.getStaffFromJwt(jwtToken);
        CurrentLoginUserInfo loginUserInfo = contextSessionService.getUserInfoFromRedis(staffNo);
        if (Objects.isNull(loginUserInfo)){
            return;
        }
        // 资源信息 因数据太多，放在Header中可能会引起数据超过长度限制问题，去掉资源信息
        // 若后服务中需要时，可以重新缓存中获取
        loginUserInfo.setResourceList(null);
        String loginUserInfoJson = JSONObject.toJSONString(loginUserInfo);
        try{
            byte[] strBytes = loginUserInfoJson.getBytes("UTF-8");
            String loginUserInfoBase = Base64.getUrlEncoder().encodeToString(strBytes);
            requestTemplate.header(CommonConstant.LOGIN_USER_INFO, loginUserInfoBase);
        }catch (UnsupportedEncodingException e){
            throw new BusinessException(HRMateInfo.SYSTEM_EXCETION.getCode(),HRMateInfo.SYSTEM_EXCETION.getMessage(),e);
        }
    }



}
