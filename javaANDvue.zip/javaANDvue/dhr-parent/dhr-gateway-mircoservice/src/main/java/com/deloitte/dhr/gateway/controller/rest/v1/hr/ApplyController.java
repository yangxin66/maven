package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.hr.api.ApplyInterface;
import com.deloitte.dhr.hr.api.model.ApplyRecordDelDto;
import com.deloitte.dhr.hr.api.model.staff.ApplyNoAndTypeDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

/**
 * @author chunliucq
 * @since 12/10/2019 19:18
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/hr/apply",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class ApplyController {

    @Autowired
    private ApplyInterface applyInterface;

    /**
     * 保存各种申请 岗位变动、员工转正、兼岗等
     * @param applyRequest
     * @return
     */
    @PostMapping("/add/save")
    Response<Void> saveApply(@RequestBody Request<Map> applyRequest){
        return applyInterface.saveApply(applyRequest);
    }

    /**
     * 提交审批各种申请 岗位变动、员工转正、兼岗等
     * @param applyRequest
     * @return
     */
    @PostMapping("/add/submit")
    Response<Void> submitApply(@RequestBody Request<Map> applyRequest){
        return applyInterface.submitApply(applyRequest);
    }

    @PostMapping("/add/applydetail")
    Response<Void> appendRecord(@RequestBody Request<Map> requestData){
        return applyInterface.appendRecord(requestData);
    }

    @PostMapping("/del/applydetail")
    Response<Void> deleteRecord(@RequestBody Request<ApplyRecordDelDto> delDtoRequest){
        return applyInterface.deleteRecord(delDtoRequest);
    }

    @PostMapping("/query/applydetail/page")
    public PaginationResponse<List<Map>> queryApplyInfoByPageList(@RequestBody PaginationRequest<ApplyNoAndTypeDto> applyPaginationRequest){
        return applyInterface.queryApplyInfoByPageList(applyPaginationRequest);
    }

    @PostMapping("/query/applydetail/page/conf")
    public PaginationResponse<Map> queryApplyInfoByPageListForConf(@RequestBody PaginationRequest<ApplyNoAndTypeDto> applyPaginationRequest){
        return applyInterface.queryApplyInfoByPageListForConf(applyPaginationRequest);
    }

    @PostMapping("/query/applyinfo")
    Response<Map> queryApplyByApplyNo(@RequestBody Request<ApplyNoAndTypeDto> applyNoRequest){
        return applyInterface.queryApplyByApplyNo(applyNoRequest);
    }

    @PostMapping(value = "/save/apply/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    Response<Map> UploadApplyData(@RequestParam(required = false,value = "_APPLY_NO") String applyNo,
                                  @RequestParam(required = false,value = "_APPLY_SUB_TYPE") String busiType,
                                  @RequestPart(required = false,value = "attach") MultipartFile file){
        try {
            return applyInterface.UploadApplyData(applyNo,busiType,file);
        }catch (Exception e){
            log.error("upload file err",e);
        }
        return ResponseUtil.build().createBadResponse(HRMateInfo.SYSTEM_EXCETION.getCode(),HRMateInfo.SYSTEM_EXCETION.getMessage());
    }

}
