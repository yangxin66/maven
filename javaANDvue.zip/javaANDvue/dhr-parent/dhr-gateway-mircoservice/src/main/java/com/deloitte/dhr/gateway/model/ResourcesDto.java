package com.deloitte.dhr.gateway.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author chunliucq
 * @since 07/10/2019 16:49
 */
@Data
public class ResourcesDto {
    private Long id;
    private String orgId;
    private Long parentId;
    private String name;
    private String uri;
    private Integer level;
    private String code;
    private String type;
    private List<ResourcesDto> submenu = new ArrayList<>();
}
