package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.gateway.securit.hr.config.JwtProperties;
import com.deloitte.dhr.gateway.securit.hr.config.JwtTokenUtils;
import com.deloitte.dhr.gateway.securit.hr.config.Oauth2ClientProperties;
import com.deloitte.dhr.gateway.securit.hr.config.UserRepository;
import com.deloitte.dhr.gateway.securit.hr.model.RedirectResult;
import com.deloitte.infrastructure.communication.Response;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author chunliucq
 * @since 13/09/2019 0:46
 */
@Slf4j
@RestController
@RequestMapping(value={"/api/v1/oauth"}, produces={"application/json;charset=UTF-8"})
public class OauthController {

    @Autowired
    private Oauth2ClientProperties oauth2ClientProperties;

    @Autowired
    private JwtProperties jwtProperties;

    @Autowired
    private JwtTokenUtils jwtTokenUtils;

    @Autowired
    private UserRepository userRepository;

    @RequestMapping("/logout")
    public Response<RedirectResult> loginOut(HttpServletRequest request, HttpServletResponse resp){
        //先从url中取token
        boolean success = false;
        String authToken = null;
        String authHeader = request.getHeader(jwtProperties.getHeader());
        if (StringUtils.isNotBlank(authHeader) && authHeader.startsWith(jwtProperties.getTokenHead())) {
            //如果header中存在token，则覆盖掉url中的token
            // "Bearer "之后的内容
            authToken = authHeader.substring(jwtProperties.getTokenHead().length()).trim();
        }

        RedirectResult redirectResult = new RedirectResult(oauth2ClientProperties.getUserAuthorizationUri());
        Response<RedirectResult> result = ResponseUtil.build().createBadResponse("000-00-001", "退出登陆",redirectResult);
        if (StringUtils.isNotBlank(authToken)) {
            String username = jwtTokenUtils.getUsernameFromToken(authToken);
            log.info("checking authentication {}", username);
            log.info("request URL:{}", request.getRequestURI());
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                //从已有的user缓存中取了出user信息
                userRepository.remove(username);
                success = true;
            }
        }
        result = ResponseUtil.build().creatDeaultOkResponse(redirectResult);
        return result;
    }

}
