package com.deloitte.dhr.gateway.service;

import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;

/**
 * 员工信息缓存管理
 * @author chunliucq
 * @since 29/09/2019 10:14
 */
public interface ContextSessionService {

    /**
     * 查询用户信息并缓存，后续做登录后的鉴权使用
     * @param jwt 员工编号
     */
    CurrentLoginUserInfo saveUserInfoToRedis(String jwt);

    /**
     * 从缓存获取用户信息
     * @param staffNo
     * @return
     */
    CurrentLoginUserInfo getUserInfoFromRedis(String staffNo);
}
