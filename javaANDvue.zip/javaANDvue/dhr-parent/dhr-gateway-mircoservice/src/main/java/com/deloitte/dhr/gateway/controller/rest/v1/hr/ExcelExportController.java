package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.common.constant.ContentTypeConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.hr.api.ExcelOutDownLoadInterface;
import com.deloitte.dhr.hr.api.ExcelOutInterface;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.ex.BusinessException;
import feign.Response;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.Base64;
import java.util.Objects;

@RestController
@RequestMapping(value = "/api/v1/export")
public class ExcelExportController {

    @Autowired
    ExcelOutInterface excelOutInterface;

    @Autowired
    ExcelOutDownLoadInterface excelOutDownLoadInterface;

    @ApiOperation(value = "导出批量excel", notes = "导出excel")
    @PostMapping(value = "/excel/currency/batch")
    public void getInfoExcelCurrencyBatch(@RequestBody Request<ExcelOutExportCurrencyBatchDto> excelOutExportCurrencyBatchDtoRequest) throws IOException,
            ParseException{
        String filename="信息";
        feign.Response response = excelOutDownLoadInterface.getInfoExcelCurrencyBatch(excelOutExportCurrencyBatchDtoRequest);
        getfeignResponse(filename, response);


    }

    @ApiOperation(value = "导出全部excel", notes = "导出excel")
    @PostMapping(value = "/excel/currency/all")
    public void getInfoExcelCurrencyALL(@RequestBody Request<ExcelOutExportCurrencyALLDto> excelOutExportCurrencyALLDtoRequest) throws IOException,
            ParseException {
        String filename = "信息";
        feign.Response response = excelOutDownLoadInterface.getInfoExcelCurrencyALL(excelOutExportCurrencyALLDtoRequest);
        getfeignResponse(filename, response);
    }

    @PostMapping("/download/excel")
    @ApiOperation(value = "下载数据模板")
    public void downloadExcel(@RequestBody Request<String> request) throws IOException {
        String filename = "信息";
        feign.Response response =excelOutDownLoadInterface.downloadExcel(request);
        getfeignResponse(filename, response);
    }

    private void getfeignResponse(String filename, Response response) {
        HttpServletResponse httpResponse = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        httpResponse.setContentType(ContentTypeConstant.getContentType(".xls") + ";charset=UTF-8");
        try (InputStream is = response.body().asInputStream();
             OutputStream os = httpResponse.getOutputStream()) {
            httpResponse.setHeader("Content-Disposition", "attachment;fileName=" + URLEncoder.encode(filename + ".xls", "UTF-8"));
            byte[] bucket = new byte[1024 * 10];
            int i = 0;
            while ((i = is.read(bucket)) > -1) {
                os.write(bucket, 0, i);
            }
        } catch (Exception e) {
            throw new BusinessException(HRMateInfo.DOWNLOAD_ERR.getCode(), HRMateInfo.DOWNLOAD_ERR.getMessage(), e);
        }
    }

    @ApiOperation(value = "导出员工全部信息", notes = "导出员工全部信息到Excel中")
    @PostMapping(value = "/excel")
    public void getInfoExcel(HttpServletRequest request, @RequestBody Request<ExcelOutExprotDto> excelOutExprotDtoRequest) throws IOException,
            ParseException {
        String filename = "信息";
        ExcelOutExprotDto excelOutExprotDto = excelOutExprotDtoRequest.getData();
        OutExportType outType = excelOutExprotDto.getOutType();
        if (excelOutExprotDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            filename = "待办审核" + filename;
        } else {
            filename = "已审核" + filename;
        }
        if (outType.equals(OutExportType.BATCH_EXPORT.toString())) {
            filename = filename + "(选择名单)";
        }else {
            filename = filename + "(全部名单)";
        }
        String ua = request.getHeader("User-Agent");
        boolean IE_LT11 = ua.contains("MSIE"); // IE11以下版本
        boolean IE11 = ua.contains("rv:11.0) like Gecko"); // IE11
        boolean Edge = ua.contains("Edge"); // win10自带的Edge浏览器
        Base64.Encoder encoder = Base64.getEncoder();
        if (IE_LT11 || IE11 || Edge) {
            filename = URLEncoder.encode(filename, "UTF-8");
            // java的编码方式和浏览器有略微的不同：对于空格，java编码后的结果是加号，
            // 而浏览器的编码结果是%20，因此将+替换成%20, 这样浏览器才能正确解析空格
            filename = filename.replace("+", "%20");
        }else{
            filename = encoder.encodeToString(filename.getBytes("utf-8"));
            filename = "=?utf-8?B?" + filename + "?=";
        }
        feign.Response response =  excelOutDownLoadInterface.getInfoExcel(excelOutExprotDtoRequest);
        getfeignResponse(filename, response);


    }


    @ApiOperation(value = "导出申请信息", notes = "导出员工全部或部分申请信息到Excel中")
    @PostMapping(value = "/excel/apply/hr")
    @CrossOrigin("*")
    public void getApplyExcelHr(HttpServletRequest request,@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException {
        String filename = "信息";
        ExcelApplyExportDto excelApplyExportDto = excelApplyExportDtoRequest.getData();
        OutExportType outType = excelApplyExportDto.getOutType();
        if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            filename = "待办审核" + filename;
        } else if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.COMPLETE_TASK.toString())) {
            filename = "已审核" + filename;
        } else {
            filename = "进行中" + filename;
        }
        if (outType.equals(OutExportType.BATCH_EXPORT.toString())) {
            filename = filename + "(选择名单)";
        }else {
            filename = filename + "(全部名单)";
        }
        String ua = request.getHeader("User-Agent");
        boolean IE_LT11 = ua.contains("MSIE"); // IE11以下版本
        boolean IE11 = ua.contains("rv:11.0) like Gecko"); // IE11
        boolean Edge = ua.contains("Edge"); // win10自带的Edge浏览器
        Base64.Encoder encoder = Base64.getEncoder();
        if (IE_LT11 || IE11 || Edge) {
//            filename = URLEncoder.encode(filename, "UTF-8");
            // java的编码方式和浏览器有略微的不同：对于空格，java编码后的结果是加号，
            // 而浏览器的编码结果是%20，因此将+替换成%20, 这样浏览器才能正确解析空格
            filename = filename.replace("+", "%20");
        }else{
            filename = encoder.encodeToString(filename.getBytes("utf-8"));
            filename = "=?utf-8?B?" + filename + "?=";
        }
        feign.Response response =  excelOutDownLoadInterface.getApplyExcelHr(excelApplyExportDtoRequest);
        HttpServletResponse httpResponse = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        httpResponse.setContentType(ContentTypeConstant.getContentType(".xls") + ";charset=UTF-8");
        try (InputStream is = response.body().asInputStream();
             OutputStream os = httpResponse.getOutputStream()) {
            httpResponse.setHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode("导出.xls", "UTF-8"));
            byte[] bucket = new byte[1024 * 10];
            int i = 0;
            while ((i = is.read(bucket)) > -1) {
                os.write(bucket, 0, i);
            }
        } catch (Exception e) {
            throw new BusinessException(HRMateInfo.DOWNLOAD_ERR.getCode(), HRMateInfo.DOWNLOAD_ERR.getMessage(), e);
        }

    }
    @ApiOperation(value = "导出申请信息", notes = "导出员工全部或部分申请信息到Excel中")
    @PostMapping(value = "/excel/apply/staff")
    @CrossOrigin("*")
    public void getApplyExcelStaff(HttpServletRequest request,@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException {
        String filename = "信息";
        ExcelApplyExportDto excelApplyExportDto = excelApplyExportDtoRequest.getData();
        OutExportType outType = excelApplyExportDto.getOutType();
        if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            filename = "待办审核" + filename;
        } else if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.COMPLETE_TASK.toString())) {
            filename = "已审核" + filename;
        } else {
            filename = "进行中" + filename;
        }
        if (outType.equals(OutExportType.BATCH_EXPORT.toString())) {
            filename = filename + "(选择名单)";
        }else {
            filename = filename + "(全部名单)";
        }
        String ua = request.getHeader("User-Agent");
        boolean IE_LT11 = ua.contains("MSIE"); // IE11以下版本
        boolean IE11 = ua.contains("rv:11.0) like Gecko"); // IE11
        boolean Edge = ua.contains("Edge"); // win10自带的Edge浏览器
        Base64.Encoder encoder = Base64.getEncoder();
        if (IE_LT11 || IE11 || Edge) {
//            filename = URLEncoder.encode(filename, "UTF-8");
            // java的编码方式和浏览器有略微的不同：对于空格，java编码后的结果是加号，
            // 而浏览器的编码结果是%20，因此将+替换成%20, 这样浏览器才能正确解析空格
            filename = filename.replace("+", "%20");
        }else{
            filename = encoder.encodeToString(filename.getBytes("utf-8"));
            filename = "=?utf-8?B?" + filename + "?=";
        }
        feign.Response response =  excelOutDownLoadInterface.getApplyExcelStaff(excelApplyExportDtoRequest);
        HttpServletResponse httpResponse = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        httpResponse.setContentType(ContentTypeConstant.getContentType(".xls") + ";charset=UTF-8");
        try (InputStream is = response.body().asInputStream();
             OutputStream os = httpResponse.getOutputStream()) {
            httpResponse.setHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode("导出.xls", "UTF-8"));
            byte[] bucket = new byte[1024 * 10];
            int i = 0;
            while ((i = is.read(bucket)) > -1) {
                os.write(bucket, 0, i);
            }
        } catch (Exception e) {
            throw new BusinessException(HRMateInfo.DOWNLOAD_ERR.getCode(), HRMateInfo.DOWNLOAD_ERR.getMessage(), e);
        }
    }
    @ApiOperation(value = "个人信息审批查看信息导出excel", notes = "个人信息审批查看信息到Excel中")
    @PostMapping("/excel/apply/audit")
    @CrossOrigin("*")
    public void getApplyAuditExcel(HttpServletRequest request, @RequestBody Request<ExcelApplyDetailedDto> excelApplyDetailedDtoRequest) throws IOException,
            ParseException {
//        System.out.println(excelApplyDetailedDtoRequest);
        String ua = request.getHeader("User-Agent");
        boolean IE_LT11 = ua.contains("MSIE"); // IE11以下版本
        boolean IE11 = ua.contains("rv:11.0) like Gecko"); // IE11
        boolean Edge = ua.contains("Edge"); // win10自带的Edge浏览器
        Base64.Encoder encoder = Base64.getEncoder();
        String fileName="个人信息申请";
//        excelOutInterface.getApplyAuditExcel(excelApplyDetailedDtoRequest);
        ExcelApplyDetailedDto data = excelApplyDetailedDtoRequest.getData();
        OutExportType outType = data.getOutType();
        if (outType.equals(OutExportType.BATCH_EXPORT.toString())) {
            fileName = fileName + "(选择名单)";
        }else {
            fileName = fileName + "(全部名单)";
        }
        if (IE_LT11 || IE11 || Edge) {
            fileName = URLEncoder.encode(fileName, "UTF-8");
            // java的编码方式和浏览器有略微的不同：对于空格，java编码后的结果是加号，
            // 而浏览器的编码结果是%20，因此将+替换成%20, 这样浏览器才能正确解析空格
            fileName = fileName.replace("+", "%20");
        }else{
            fileName = encoder.encodeToString(fileName.getBytes("utf-8"));
            fileName = "=?utf-8?B?" + fileName + "?=";
        }

        feign.Response response =  excelOutDownLoadInterface.getApplyAuditExcel(excelApplyDetailedDtoRequest);
        HttpServletResponse httpResponse = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        httpResponse.setContentType(ContentTypeConstant.getContentType(".xls") + ";charset=UTF-8");
        try (InputStream is = response.body().asInputStream();
             OutputStream os = httpResponse.getOutputStream()) {
            httpResponse.setHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode("导出.xls", "UTF-8"));
            byte[] bucket = new byte[1024 * 10];
            int i = 0;
            while ((i = is.read(bucket)) > -1) {
                os.write(bucket, 0, i);
            }
        } catch (Exception e) {
            throw new BusinessException(HRMateInfo.DOWNLOAD_ERR.getCode(), HRMateInfo.DOWNLOAD_ERR.getMessage(), e);
        }
    }
}
