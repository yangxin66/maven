package com.deloitte.dhr.gateway.redis;


import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Repository
public class CommonRedisRepository {

    private final RedisTemplate<String, Object> redisTemplate;

    public CommonRedisRepository(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public Boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }

    public Object get(String key) {
        return redisTemplate.opsForValue().get(key);
    }

    public void set(String key, Object value) {
        redisTemplate.opsForValue().set(key, value);
    }

    public void set(String key, Object value, long time, TimeUnit unit) {
        redisTemplate.opsForValue().set(key, value, time, unit);
    }

    public void increment(String key, long step) {
        redisTemplate.opsForValue().increment(key, step);
    }

    public void increment(String key, long step, long time, TimeUnit unit) {
        if (!hasKey(key)) {
            redisTemplate.opsForValue().increment(key, step);
            redisTemplate.expire(key, time, unit);
        } else {
            redisTemplate.opsForValue().increment(key, step);
        }
    }

    public long getExpire(String key, TimeUnit unit) {
        Long expire = redisTemplate.getExpire(key, unit);
        return Objects.isNull(expire) ? 0 : expire;
    }

    public boolean expire(String key,Long time, TimeUnit unit){
        return redisTemplate.expire(key,time,unit);
    }

    public void remove(String... keys) {
        if (keys != null && keys.length > 0) {
            if (keys.length == 1) {
                redisTemplate.delete(keys[0]);
            } else {
                redisTemplate.delete(Arrays.asList(keys));
            }
        }
    }

    public void remove(String key) {
        redisTemplate.delete(key);
    }

}
