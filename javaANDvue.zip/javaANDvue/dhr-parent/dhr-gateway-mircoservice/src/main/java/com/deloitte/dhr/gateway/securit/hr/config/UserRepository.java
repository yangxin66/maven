package com.deloitte.dhr.gateway.securit.hr.config;

import com.deloitte.dhr.gateway.redis.CommonRedisRepository;
import com.deloitte.dhr.gateway.redis.RedisConstant;
import com.deloitte.dhr.gateway.securit.hr.model.JwtContent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

/**
 * @author chunliucq
 * @since 11/09/2019 13:55
 */
//@Component
    // 单机测试
    // todo 需用Redis保存
@Slf4j
@Repository
public class UserRepository {
    private final static Map<String,String> map = new HashMap<>();

    @Autowired
    private JwtTokenUtils jwtTokenUtils;
    @Autowired
    private CommonRedisRepository commonRedisRepository;

    public String findTokenByUsername(String username){
        return (String)commonRedisRepository.get(RedisConstant.USER_TOKEN_CHECK + username);
        //return map.get(RedisConstant.USER_TOKEN_CHECK + username);
    }

    public User insert(User user){
        JwtContent jwtContent = jwtTokenUtils.parseJwtToken(user.getPassword());
        Long expireTime = jwtContent.getPayload().getExp();
        Long expire = expireTime - System.currentTimeMillis()/1000L;
        commonRedisRepository.set(RedisConstant.USER_TOKEN_CHECK + user.getUsername(),user.getPassword(),expire, TimeUnit.SECONDS);
        //map.put(RedisConstant.USER_TOKEN_CHECK + user.getUsername(),user.getPassword());
        return user;
    }

    public void remove(String username){
        commonRedisRepository.remove(RedisConstant.USER_TOKEN_CHECK + username);
        //map.remove(RedisConstant.USER_TOKEN_CHECK + username);
    }
}
