package com.deloitte.dhr.gateway.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.CommonConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.common.utils.ValueGetTool;
import com.deloitte.dhr.gateway.redis.CommonRedisRepository;
import com.deloitte.dhr.gateway.securit.hr.config.Oauth2ClientProperties;
import com.deloitte.dhr.gateway.service.ContextSessionService;
import com.deloitte.dhr.hr.api.HrStaffInterface;
import com.deloitte.dhr.hr.api.model.staff.StaffNoDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.user.api.AuthorityUserResourcesInterface;
import com.deloitte.user.api.model.ResourcesByTypeAndPernr;
import com.deloitte.user.api.model.ResourcesDto;
import com.deloitte.user.api.model.RoleDtoOut;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author chunliucq
 * @since 29/09/2019 10:15
 */
@Service
public class ContextSessionServiceImpl implements ContextSessionService {

    @Autowired
    AuthorityUserResourcesInterface authorityUserResourcesInterface;

    @Autowired
    HrStaffInterface hrStaffInterface;

    @Autowired
    CommonRedisRepository commonRedisRepository;

    @Autowired
    private Oauth2ClientProperties oauth2ClientProperties;

    private RestTemplate restTemplate = new RestTemplate();



    /**
     * 查询用户信息并缓存，后续做登录后的鉴权使用
     * @param jwt
     */
    @Override
    public CurrentLoginUserInfo saveUserInfoToRedis(String jwt){
        String staffNo = ContextSession.getStaffFromJwt(jwt);
        CurrentLoginUserInfo loginUserInfo = new CurrentLoginUserInfo();
        // 登录信息
        JSONObject tokenPayload = ContextSession.getTokenPayload(jwt);
        String loginUserName = tokenPayload.getString("user_name");
        String clientId = tokenPayload.getString("client_id");
        loginUserInfo.setLoginUserName(loginUserName);
        loginUserInfo.setClientID(clientId);
        loginUserInfo.setStaffNo(staffNo);
        String loginTime = DateFormatUtils.format(new Date(),"yyyy-MM-dd HH:mm:ss:SSS");
        loginUserInfo.setLoginTime(loginTime);

        // 查询员工信息 姓名、部门等
        // TODO 需修改成重SAP查询
        StaffNoDto staffNoDto = new StaffNoDto();
        staffNoDto.setStaffNo(staffNo);
        Request<StaffNoDto> staffRquest = new Request<>(staffNoDto);
        Response<Map> staffInfoResponse = hrStaffInterface.queryStaffInfoByStaffNo(staffRquest);
        if (Response.SUCCESS_CODE.equals(staffInfoResponse.getCode())){
            Map<String,Object> staffInfoMap = staffInfoResponse.getData();
            if (!CollectionUtils.isEmpty(staffInfoMap)){
                String surName = ValueGetTool.getStringFromMap(staffInfoMap,"_DATA._BASE.NACHN");
                String name = ValueGetTool.getStringFromMap(staffInfoMap,"_DATA._BASE.ENAME");
                String deparName = ValueGetTool.getStringFromMap(staffInfoMap,"_DATA._BASE.DEPARTMENT");
                loginUserInfo.setPreName(name);
                loginUserInfo.setSurName(surName);
                loginUserInfo.setStaffName(String.format("%s %s",surName,name));
                loginUserInfo.setDepartmentName(deparName);
            }
        }else {
            throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_STAFF_INFO_ERR.getCode(),
                    HRMateInfo.STAFF_LOGIN_QUERY_STAFF_INFO_ERR.getMessage());
        }

        HttpHeaders headers = new HttpHeaders();
        String authHeaderName = "Authorization";

        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.add(authHeaderName, ContextSession.getHttpServletRequest().getHeader(authHeaderName));

        // 查询角色列表
        Map<String,Object> dataMap = new HashMap<>();
        Map<String,Object> paramMap = new HashMap<>();
        dataMap.put("data",staffNo);
        HttpEntity<Map<String,Object>> entity = new HttpEntity<>(dataMap, headers);
        ResponseEntity<Response> resp = restTemplate.postForEntity(oauth2ClientProperties.getAccessAuthQueryRoles(), entity, Response.class);
        if (resp != null && resp.getStatusCode().value()/100 == 2){
            Object obj = resp.getBody().getData();
            List<Map> roleListMap = (List<Map>)obj;
            if (!CollectionUtils.isEmpty(roleListMap)){
                List<CurrentLoginUserInfo.Role> roleList = roleListMap.stream().map(tmp -> {
                    CurrentLoginUserInfo.Role role = new CurrentLoginUserInfo.Role();
                    role.setId(Long.parseLong((String)tmp.get("id")));
                    role.setOrgId((String) tmp.get("orgId"));
                    role.setGrantOrgs((String) tmp.get("grantOrgs"));
                    role.setRoleName((String) tmp.get("roleName"));
                    role.setRoleCode((String) tmp.get("code"));
                    return role;
                }).collect(Collectors.toList());

                List<String> roleCodeList = roleList.stream()
                        .map(CurrentLoginUserInfo.Role::getRoleCode)
                        .collect(Collectors.toList());

                loginUserInfo.setRoleList(roleList);
                loginUserInfo.setRoleCodeList(roleCodeList);
            }

        }else {
            throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getCode(),
                    HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getMessage());
        }
//        if (Response.SUCCESS_CODE.equals(resp.getCode())){
//            List<RoleDtoOut> roleList = roleListResponse.getData();
//            if (!CollectionUtils.isEmpty(roleList)){
//                List<CurrentLoginUserInfo.Role> loginRoleList = roleList.stream().map(tmp -> {
//                    return convertRole(tmp);
//                }).collect(Collectors.toList());
//                loginUserInfo.setRoleList(loginRoleList);
//            }
//        }else {
//
//        }


       /* Request<String> request = new Request<>(staffNo);
        Response<List<RoleDtoOut>> roleListResponse = authorityUserResourcesInterface.queryUserRoleInfo(request);
        if (Response.SUCCESS_CODE.equals(roleListResponse.getCode())){
            List<RoleDtoOut> roleList = roleListResponse.getData();
            if (!CollectionUtils.isEmpty(roleList)){
                List<CurrentLoginUserInfo.Role> loginRoleList = roleList.stream().map(tmp -> {
                    return convertRole(tmp);
                }).collect(Collectors.toList());
                loginUserInfo.setRoleList(loginRoleList);
            }
        }else {
            throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getCode(),
                    HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getMessage());
        }*/

        // 查询资源列表
        ResourcesByTypeAndPernr rp = new ResourcesByTypeAndPernr();
        rp.setPernr(staffNo);
        rp.setType("API");
        Request<ResourcesByTypeAndPernr> requestInfo = new Request<>(rp);
        Response<List<ResourcesDto>> resourceListResponse = authorityUserResourcesInterface.queryUserResourcesInfoByPernrAndCode(requestInfo);
        if (resourceListResponse != null && resourceListResponse.getCode().startsWith("2")){
            List<ResourcesDto> resourcesDtoList = resourceListResponse.getData();
            if (!CollectionUtils.isEmpty(resourcesDtoList)){
                List<CurrentLoginUserInfo.Resource> loginResList = resourcesDtoList.stream().map(tmp -> {
                    return convertResource(tmp);
                }).collect(Collectors.toList());
                loginUserInfo.setResourceList(loginResList);
            }
        }/*else {
            throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_RESOURCES_ERR.getCode(),
                    HRMateInfo.STAFF_LOGIN_QUERY_RESOURCES_ERR.getMessage());
        }*/
        if (CollectionUtils.isEmpty(loginUserInfo.getRoleList())){
            loginUserInfo.setRoleList(new ArrayList<>());
        }
        if (CollectionUtils.isEmpty(loginUserInfo.getResourceList())){
            loginUserInfo.setResourceList(new ArrayList<>());
        }
        commonRedisRepository.set(CommonConstant.LOING_USER_REDIS_INFO_ID + staffNo,loginUserInfo,30, TimeUnit.MINUTES);
        return loginUserInfo;
    }

    @Override
    public CurrentLoginUserInfo getUserInfoFromRedis(String staffNo){
        String userInfoKey = CommonConstant.LOING_USER_REDIS_INFO_ID + staffNo;
        CurrentLoginUserInfo loginUserInfo = (CurrentLoginUserInfo)commonRedisRepository.get(userInfoKey);
        if (loginUserInfo != null){
            commonRedisRepository.expire(userInfoKey,30L,TimeUnit.MINUTES);
        }
        return loginUserInfo;
    }

    private CurrentLoginUserInfo.Role convertRole(RoleDtoOut roleDto){
        CurrentLoginUserInfo.Role role = new CurrentLoginUserInfo.Role();
        role.setId(roleDto.getId());
        role.setRoleName(role.getRoleName());
        role.setGrantOrgs(roleDto.getGrantOrgs());
        role.setOrgId(roleDto.getOrgId());
        role.setRoleCode(roleDto.getCode());
        return role;
    }

    private CurrentLoginUserInfo.Resource convertResource(ResourcesDto resourcesDto){
        CurrentLoginUserInfo.Resource resource = new CurrentLoginUserInfo.Resource();
        resource.setCode(resourcesDto.getCode());
        resource.setId(resourcesDto.getId());
        resource.setLevel(resourcesDto.getLevel());
        resource.setName(resourcesDto.getName());
        resource.setOrgId(resourcesDto.getOrgId());
        resource.setParentId(resourcesDto.getParentId());
        resource.setType(resourcesDto.getType());
        resource.setUri(resourcesDto.getUri());
        return resource;
    }
}
