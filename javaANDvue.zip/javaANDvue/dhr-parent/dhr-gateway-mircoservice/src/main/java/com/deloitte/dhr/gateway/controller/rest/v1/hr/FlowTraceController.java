package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.hr.api.FlowTraceRestInterface;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.api.model.FlowTraceLogDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 流程动态相关接口
 * date: 21/08/2019 15:58
 *
 * @author wgong
 * @since 0.0.1
 */
@RestController
@RequestMapping(value = "/api/v1/hr/flow_trace", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class FlowTraceController{

    @Autowired
    FlowTraceRestInterface flowTraceRestInterface;

    /**
     * 根据流程实例id查询流程节点信息
     *
     * @param request           查询参数传输实体
     */
    @PostMapping
    public Response<FlowTraceLogDto> getFlowTraceLogDetail(@RequestBody Request<String> request) {

        return flowTraceRestInterface.getFlowTraceLogDetail(request);
    }

    @PostMapping("/node_handler")
    public Response<Object> flowNodeHandler(@Validated @RequestBody Request<List<AuditHandlerDto>> request) {
        return flowTraceRestInterface.flowNodeHandler(request);
    }


}
