package com.deloitte.dhr.gateway.securit.hr.config;

import com.deloitte.dhr.gateway.securit.hr.filter.AccessAuthenticationFilter;
import com.deloitte.dhr.gateway.securit.hr.filter.JwtAuthenticationTokenFilter;
import com.deloitte.dhr.gateway.securit.hr.filter.LoginCallbackFilter;
import com.deloitte.dhr.gateway.securit.hr.handler.LinkToEntryPointHandler;
import com.deloitte.dhr.gateway.securit.hr.handler.LoginAuthticationProvider;
import com.deloitte.dhr.gateway.securit.hr.handler.LoginSuccessHandler;
import com.deloitte.dhr.gateway.securit.hr.handler.MyUserDetailService;
import com.deloitte.dhr.gateway.service.ContextSessionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.util.CollectionUtils;

/**
 * @author chunliucq
 * @since 11/09/2019 9:35
 */

@Slf4j
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(-1)
public class BrowerSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private JwtAuthenticationTokenFilter jwtAuthenticationTokenFilter;

    @Autowired
    private Oauth2ClientProperties oauth2ClientProperties;

    @Autowired
    private MyUserDetailService myUserDetailService;

    @Autowired
    private LoginAuthticationProvider loginAuthticationProvider;

    @Autowired
    private JwtProperties jwtProperties;

    @Autowired
    private JwtTokenUtils jwtTokenUtils;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SecurityWebProperties securityWebProperties;

    @Autowired
    private AccessAuthenticationFilter accessAuthenticationFilter;

    @Autowired
    private ContextSessionService contextSessionService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {

//        http.addFilterBefore(new CorsFilter(), SecurityContextPersistenceFilter.class);
//
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http.addFilterBefore(jwtAuthenticationTokenFilter, UsernamePasswordAuthenticationFilter.class);
        http.addFilterBefore(loginCallbackFilter(),JwtAuthenticationTokenFilter.class);
        http.addFilterAfter(accessAuthenticationFilter,UsernamePasswordAuthenticationFilter.class);
        http.exceptionHandling().authenticationEntryPoint(new LinkToEntryPointHandler(oauth2ClientProperties.getUserAuthorizationUri()));

        http.headers().frameOptions().disable();
        http.cors().disable();

        log.info("oauth2ClientProperties.getPreEstablishedRedirectUri:{}",oauth2ClientProperties.getPreEstablishedRedirectUri());
        String[] noneAuthPath = new String[]{"/favicon.ico"};
        if (!CollectionUtils.isEmpty(oauth2ClientProperties.getNoneAuthPath())){
            noneAuthPath = oauth2ClientProperties.getNoneAuthPath().toArray(new String[oauth2ClientProperties.getNoneAuthPath().size()]);
        }

        http.authorizeRequests()
                //访问"/"和"/home"路径的请求都允许
                .antMatchers(HttpMethod.OPTIONS, "/**").anonymous()
                .antMatchers(oauth2ClientProperties.getPreEstablishedRedirectUri()).permitAll()
                .antMatchers(noneAuthPath).permitAll()
                .antMatchers("/test/**").permitAll()
                .antMatchers("/error").permitAll()
                .antMatchers("/gateway/error").permitAll()
               // .antMatchers("/api/**").permitAll()
                .antMatchers("/**").permitAll()

                //而其他的请求都需要认证
                .anyRequest()
                .authenticated()
                .and()
//                修改Spring Security默认的登陆界面
                .formLogin()
//                .loginPage("/login")
                //.successHandler(loginSuccessHandler())
                .successHandler(loginSuccessHandler())
                .and()
                .logout()
                .permitAll();
        http.cors().and().csrf().disable();


    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //基于内存来存储用户信息
        auth.inMemoryAuthentication().passwordEncoder(new BCryptPasswordEncoder())
                .withUser("user").password(new BCryptPasswordEncoder().encode("123")).roles("USER").and()
                .withUser("admin").password(new BCryptPasswordEncoder().encode("456")).roles("USER","ADMIN");

        auth.authenticationProvider(loginAuthticationProvider);
        auth.userDetailsService(myUserDetailService).passwordEncoder(new BCryptPasswordEncoder());
    }


    public LoginSuccessHandler loginSuccessHandler(){
        return new LoginSuccessHandler(userRepository);
    }

    public LoginCallbackFilter loginCallbackFilter(){
        return new LoginCallbackFilter(oauth2ClientProperties.getPreEstablishedRedirectUri(),
                oauth2ClientProperties,
                userRepository,jwtTokenUtils,
                contextSessionService);
    }

}
