package com.deloitte.dhr.gateway.securit.hr.filter;

import com.deloitte.dhr.common.constant.CommonConstant;
import com.deloitte.dhr.common.constant.CommonStringConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.common.utils.ValueGetTool;
import com.deloitte.dhr.gateway.redis.CommonRedisRepository;
import com.deloitte.dhr.gateway.securit.hr.config.JwtTokenUtils;
import com.deloitte.dhr.gateway.securit.hr.config.Oauth2ClientProperties;
import com.deloitte.dhr.gateway.securit.hr.config.UserRepository;
import com.deloitte.dhr.gateway.securit.hr.model.AuthTokenInfo;
import com.deloitte.dhr.gateway.securit.hr.model.CodeDto;
import com.deloitte.dhr.gateway.service.ContextSessionService;
import com.deloitte.dhr.hr.api.HrStaffInterface;
import com.deloitte.dhr.hr.api.model.staff.StaffNoDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import com.deloitte.user.api.AuthorityUserResourcesInterface;
import com.deloitte.user.api.model.ResourcesByTypeAndPernr;
import com.deloitte.user.api.model.ResourcesDto;
import com.deloitte.user.api.model.RoleDtoOut;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 第三方登录成功后，回调地址coode处理
 * @author chunliucq
 * @since 11/09/2019 20:25
 */
@Slf4j
public class LoginCallbackFilter extends AbstractAuthenticationProcessingFilter {

    private Oauth2ClientProperties oauth2ClientProperties;

    private RestTemplate restTemplate = new RestTemplate();

    private UserRepository userRepository;

    private JwtTokenUtils jwtTokenUtils;

    private ContextSessionService contextSessionService;

    public LoginCallbackFilter(String defaultFilterProcessesUrl,
                               Oauth2ClientProperties oauth2ClientProperties,
                               UserRepository userRepository,
                               JwtTokenUtils jwtTokenUtils,
                               ContextSessionService contextSessionService) {
        super(defaultFilterProcessesUrl);
        this.oauth2ClientProperties = oauth2ClientProperties;
        this.userRepository = userRepository;
        this.jwtTokenUtils = jwtTokenUtils;
        this.contextSessionService = contextSessionService;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {
        String code = getData(request).getData().getCode();

        // todo 通过code获取jwt_token
        String jwtToken = code;

        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String base64UserMsgOri = oauth2ClientProperties.getClientId() + ":" + oauth2ClientProperties.getClientSecret();
        String base64UserMsg = Base64.getEncoder().encodeToString(base64UserMsgOri.getBytes());
        headers.add("Authorization", "Basic " + base64UserMsg);

        MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();
        paramMap.add("grant_type", "authorization_code");
        paramMap.add("code", code);
        paramMap.add("client_id", oauth2ClientProperties.getClientId());
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(paramMap, headers);

        ResponseEntity<AuthTokenInfo> resp = restTemplate.postForEntity(oauth2ClientProperties.getAccessTokenUri(), entity, AuthTokenInfo.class);
        if (resp.getStatusCode() != null && resp.getStatusCode().value() == 200) {
            AuthTokenInfo authTokenInfo = resp.getBody();
            /**
             * access_token：表示访问令牌，必选项。
             * token_type：表示令牌类型，该值大小写不敏感，必选项，可以是bearer类型或mac类型。
             * expires_in：表示过期时间，单位为秒。如果省略该参数，必须其他方式设置过期时间。
             * refresh_token：表示更新令牌，用来获取下一次的访问令牌，可选项。
             * scope：表示权限范围，如果与客户端申请的范围一致，此项可省略。
             */
            String access_token = authTokenInfo.getAccess_token();

            // todo 通过jwt_token获取username
            String username = jwtTokenUtils.getUsernameFromToken(access_token);
            if (username == null){
                throw new BusinessException(HRMateInfo.STAFF_NO_LOGIN_EXCEPTION.getCode(),HRMateInfo.STAFF_NO_LOGIN_EXCEPTION.getMessage());
            }

            User user = new User(username,access_token, Collections.emptyList());
            userRepository.insert(user);


            UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(user.getUsername(),
                    user.getPassword(),Collections.emptyList());
            return token;
        }
        log.debug("获取token失败,code:{}",code);
        return null;
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain
            chain, Authentication authResult) throws IOException, ServletException {

        String jwt = (String)authResult.getCredentials();
        CurrentLoginUserInfo userInfo = contextSessionService.saveUserInfoToRedis(jwt);
        // 资源信息不返回组前端
        userInfo.setResourceList(null);

        Map<String,Object> resultData = new HashMap<>();
        resultData.put("jwt",jwt);
        resultData.put("staffInfo",userInfo);

        Response<String> result = ResponseUtil.build().creatDeaultOkResponse(resultData);
        String responseData = SerializerUtils.serialize(result);
        response.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        response.getWriter().write(responseData);
    }


    /**
     * 解析请求 Request body 参数
     * @param request
     * @return
     */
    private Request<CodeDto> getData(HttpServletRequest request) {
        StringBuilder builder = new StringBuilder();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ServletInputStream is = request.getInputStream();
             BufferedInputStream bs = new BufferedInputStream(is)) {

            final String charset = "UTF-8";
            final byte[] buffer = new byte[1024];
            int read;

            while (-1 != (read = bs.read(buffer))) {
                baos.write(buffer, 0, read);
                builder.append(new String(buffer, 0, read, charset));
            }
            String requestStr = baos.toString(charset);
            ObjectMapper objectMapper = new ObjectMapper();
            JavaType javaType = objectMapper.getTypeFactory().constructParametricType(Request.class, CodeDto.class);
            Request<CodeDto> requestData = objectMapper.readValue(requestStr, javaType);
            return requestData;
        } catch (IOException e) {
            log.error("获取登录请求输入流失败");
            log.error(e.getMessage());
            throw new AuthenticationCredentialsNotFoundException("获取登录请求输入流失败");
        }
    }
}
