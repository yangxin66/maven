package com.deloitte.dhr.gateway.securit.hr.model;

import lombok.Data;

/**
 * @author chunliucq
 * @since 10/09/2019 14:53
 */
@Data
public class CodeDto {
    private String code;
}
