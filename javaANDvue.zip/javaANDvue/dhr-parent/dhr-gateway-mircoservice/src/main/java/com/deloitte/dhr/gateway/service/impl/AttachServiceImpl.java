package com.deloitte.dhr.gateway.service.impl;

import com.deloitte.dhr.common.constant.ContentTypeConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.file.api.FileDownloadInterface;
import com.deloitte.dhr.file.api.FileOperInterface;
import com.deloitte.dhr.file.api.dto.FileRequestDto;
import com.deloitte.dhr.file.api.dto.FileResponseDto;
import com.deloitte.dhr.gateway.service.AttachService;
import com.deloitte.dhr.hr.api.model.AttachDTO;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * <br/>29/08/2019 10:59
 *
 * @author lshao
 */
@Service
public class AttachServiceImpl implements AttachService {

    @Autowired
    FileOperInterface fileOper;

    @Autowired
    FileDownloadInterface fileDownload;

    @Override
    public Response<AttachDTO> uploadAttch(MultipartFile file){
        Response<FileResponseDto> fileResponse = null;
        if (file != null) {
            FileRequestDto fileRequestDto = new FileRequestDto();
            try {
                fileRequestDto.setFileBytes(file.getBytes());
            } catch (IOException e) {
                throw new BusinessException(HRMateInfo.UPLOAD_ERR.getCode(), HRMateInfo.UPLOAD_ERR.getMessage(), e);
            }
            fileRequestDto.setFileName(file.getOriginalFilename());
            fileResponse = fileOper.uploadFile(fileRequestDto);
            if (fileResponse.successful()) {
                AttachDTO attachDTO = new AttachDTO();
                attachDTO.setKey(fileResponse.getData().getUrl());
                attachDTO.setAttachType(AttachDTO.ATTACHTYPE_FILE);
                attachDTO.setAttachName(file.getOriginalFilename());
                return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, null, attachDTO);
            }
        }
        return new Response<>(LanguageEnum.getDefault(), HRMateInfo.UPLOAD_ERR.getCode(), HRMateInfo.UPLOAD_ERR.getMessage(), null);

    }

    @Override
    public void downLoad(AttachDTO dto, HttpServletResponse httpResponse){
//        ValidationServiceImpl.validate(dto);
        String url = dto.getKey();

        String prefix = url.substring(url.lastIndexOf("."));
        feign.Response response = fileDownload.download(dto.getKey());

        httpResponse.setContentType(ContentTypeConstant.getContentType(prefix.toLowerCase()) + ";charset=UTF-8");
        httpResponse.setCharacterEncoding("UTF-8");
//        httpResponse.setContentType("application/force-download");
        try (InputStream is = response.body().asInputStream();
             OutputStream os = httpResponse.getOutputStream()) {
            httpResponse.setHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode(dto.getAttachName(), "UTF-8"));
            byte[] bucket = new byte[1024 * 10];
            int i = 0;
            while ((i = is.read(bucket)) > -1) {
                os.write(bucket, 0, i);
            }
        } catch (Exception e) {
            throw new BusinessException(HRMateInfo.DOWNLOAD_ERR.getCode(), HRMateInfo.DOWNLOAD_ERR.getMessage(), e);
        }
    }
}
