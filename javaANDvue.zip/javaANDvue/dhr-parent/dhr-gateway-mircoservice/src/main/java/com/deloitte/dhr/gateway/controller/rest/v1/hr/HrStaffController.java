package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.hr.api.HrStaffInterface;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.api.model.staff.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;


/**
 * hr填写信息
 * <br/>27/08/2019 11:32
 *
 * @author lshao
 */
@RestController
@RequestMapping(value = "/api/v1/hr/staff", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class HrStaffController {
    @Autowired
    private HrStaffInterface hrStaffInterface;

    /**
     * 保存员工入职时，员工信息填写
     *
     * @param staffInfoJson
     * @return
     */
    @PostMapping(value = "/save")
    Response<Map> saveStaffInfo(@RequestBody Request<JSONObject> staffInfoJson) {
        return hrStaffInterface.saveStaffInfo(staffInfoJson);
    }

    /**
     * 员工填写信息提交
     *
     * @param staffInfoJson
     * @return
     */
    @PostMapping(value = "/submit")
    Response<Map> submitStaffInfo(@RequestBody Request<JSONObject> staffInfoJson) {
        return hrStaffInterface.submitStaffInfo(staffInfoJson);
    }

    /**
     * 检查员工身份
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/check/person")
    Response<String> staffPersonCheck(@RequestBody Request<StaffPersonCheckDto> request) {
        return hrStaffInterface.staffPersonCheck(request);
    }

    /**
     * 根据员工编号查询DHR员工信息
     *
     * @param staffNo
     * @return
     */
    @PostMapping(value = "/query/detail/dhr")
    Response<Map> queryStaffInfoByStaffNo(@RequestBody Request<StaffNoDto> staffNo) {
        return hrStaffInterface.queryStaffInfoByStaffNo(staffNo);
    }

    /**
     * 根据Token查询DHR员工信息
     *
     * @param tokenDtoRequest
     * @return
     */
    @PostMapping(value = "/query/detail/token")
    Response<Map> queryStaffInfoByToken(@RequestBody Request<TokenDto> tokenDtoRequest) {
        return hrStaffInterface.queryStaffInfoByToken(tokenDtoRequest);
    }

    /**
     * 根据查询条件查询员工入职信息
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
//    @PostMapping("/search")
//    PaginationResponse<List<StaffNodeDto>> searchEmployee(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
//        return hrStaffInterface.searchEmployee(searchDtoPaginationRequest);
//    }

    /**
     * 根据id查询员工入职对比信息
     *
     * @param idRequest 查询参数传输实体
     */
    @PostMapping("/detail/compare")
    Response<StaffDetailCompareDto> getStaffDetailCompare(@RequestBody Request<String> idRequest) {
        return hrStaffInterface.getStaffDetailCompare(idRequest);
    }


    /**
     * 审核通过
     *
     * @param listRequest 批量审核通过实体
     */
//    @PostMapping("/batch/approve")
//    Response<Object> approveStaffInfo(@Validated @RequestBody Request<List<ApproveStaffDto>> listRequest) {
//        return hrStaffInterface.approveStaffInfo(listRequest);
//    }

    /**
     * 根据查询条件查询待审批、已审批信息
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
//    @PostMapping("/search/modify_info_apply")
//    public PaginationResponse<List<StaffInfoApplyDto>> searchStaffInfoModifyFlow(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
//        return hrStaffInterface.searchStaffInfoModifyTask(searchDtoPaginationRequest);
//
//    }

//    @PostMapping("/search/my_application")
//    public PaginationResponse<List<StaffInfoApplyDto>> searchMyApplication(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
//        return hrStaffInterface.searchMyApplication(searchDtoPaginationRequest);
//    }

    /**
     * 通过员工编号,申请状态,申请模块查询
     * @param applyRequest   输入实体
     * @return
     */
    @PostMapping("/modinfo/applied")
    public Response<List<ApplyStatus>> queryApply (@Validated @RequestBody Request < StaffApplyDto > applyRequest) {
        return hrStaffInterface.queryApply(applyRequest);
    }

    /**
     * 通过申请编号查询申请信息
     * @param applyNo   申请编号
     * @return
     */
    @PostMapping("/modinfo/apply/query/applyno")
    public Response<Map> queryApplyByApplyNo (@RequestBody Request < ApplyNo > applyNo) {
        return hrStaffInterface.queryApplyByApplyNo(applyNo);
    }

    /**
     * 对申请记录进行分页
     * @param applyNoPaginationRequest  分页实体数据
     * @return
     */
    @PostMapping("/modinfo/apply/query/applypage")
    public PaginationResponse<List<Map>> queryApplyCompare(@RequestBody PaginationRequest < ApplyNo > applyNoPaginationRequest) {
        return hrStaffInterface.queryApplyCompare(applyNoPaginationRequest);
    }

    /**
     * 员工提效个人信息变更申请
     * @param applyRequest
     * @return
     */
    @PostMapping("/modinfo/apply")
    public Response<Void> applyModStaffInfo (@RequestBody Request < Map > applyRequest) {
        return hrStaffInterface.applyModStaffInfo(applyRequest);
    }


    @PostMapping("/modinfo/apply/querydetail")
    public Response<Map> queryUpdateDetailInfo (@RequestBody Request < ApplyRecord > applyRecordRequest) {
        return hrStaffInterface.queryUpdateDetailInfo(applyRecordRequest);
    }

    @PostMapping("/modinfo/apply/update/record")
    public Response<Void> updateApplyRecord(@RequestBody Request<Map> staffUpdateApplyRecordRequest) {
        return hrStaffInterface.updateApplyRecord(staffUpdateApplyRecordRequest);

    }

    @PostMapping("/search/staff_info")
    public Response<List<StaffInfoSearchDto>> searchStaffInfoByKeyword(@RequestBody Request<String> request) {
        return hrStaffInterface.searchStaffInfoByKeyword(request);

    }

    @PostMapping("/modify/staff_info/sap")
    public Response<String> modifyStaffInfoToSap(@Validated @RequestBody Request<StaffInfoModifyDto> request){
        return hrStaffInterface.modifyStaffInfoToSap(request);
    }
}
