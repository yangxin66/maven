package com.deloitte.dhr.gateway.securit.hr.config;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.gateway.securit.hr.model.Header;
import com.deloitte.dhr.gateway.securit.hr.model.JwtContent;
import com.deloitte.dhr.gateway.securit.hr.model.Payload;
import com.nimbusds.jwt.JWT;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.jwt.crypto.sign.MacSigner;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author chunliucq
 * @since 11/09/2019 14:04
 */
@Component
public class JwtTokenUtils {

    @Autowired
    private JwtProperties jwtProperties;

    public String getTokenFromRequest(HttpServletRequest request){
        String authToken = null;
        String authHeader = request.getHeader(jwtProperties.getHeader());
        if (StringUtils.isNotBlank(authHeader) && authHeader.startsWith(jwtProperties.getTokenHead())) {
            //如果header中存在token，则覆盖掉url中的token
            // "Bearer "之后的内容
            authToken = authHeader.substring(jwtProperties.getTokenHead().length()).trim();
        }
        return authToken;
    }

    public JwtContent parseJwtToken(String token){
        if (token == null){
            return null;
        }
        String[] jwtOriMsgArr = token.split("\\.");
        if (jwtOriMsgArr.length != 3){
            return null;
        }
        String headerBase = jwtOriMsgArr[0];
        String headerJson = new String(Base64.getUrlDecoder().decode(headerBase));

        String payloadBase = jwtOriMsgArr[1];
        String signature = jwtOriMsgArr[2];


        String payloadJson = new String(Base64.getUrlDecoder().decode(payloadBase));
        JwtContent jwtContent = new JwtContent();
        jwtContent.setHeader(JSONObject.parseObject(headerJson, Header.class));
        jwtContent.setPayload(JSONObject.parseObject(payloadJson, Payload.class));
        jwtContent.setSignature(signature);
        return jwtContent;
    }

    public String getUsernameFromToken(String token) {
        if (token == null){
            return null;
        }
        JwtContent jwtContent = parseJwtToken(token);
        if (jwtContent == null || jwtContent.getPayload() == null){
            return null;
        }
        return jwtContent.getPayload().getUser_name();
    }


    public boolean verifySignature(String token){
        //MacSigner macSigner = new MacSigner(jwtProperties.getSecret());
        //JwtContent jwtContent = parseJwtToken(token);
        //Base64.getUrlEncoder().encodeToString(jwtContent.getHeader())
        return false;
    }

    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }



    public Date getExpirationDateFromToken(String token) {
        Date expiration;
        try {
            final Claims claims = getClaimsFromToken(token);
            expiration = claims.getExpiration();
        } catch (Exception e) {
            expiration = null;
        }
        return expiration;
    }

    private Claims getClaimsFromToken(String token) {
        Claims claims;
        try {
            claims = Jwts.parser().setSigningKey(jwtProperties.getSecret()).parseClaimsJws(token).getBody();
        } catch (Exception e) {
            claims = null;
        }
        return claims;
    }

    private Date generateExpirationDate() {
        return new Date(System.currentTimeMillis() + jwtProperties.getExpiration() * 1000);
    }


    public Boolean canTokenBeRefreshed(String token) {
        return !isTokenExpired(token);
    }

}
