package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.hr.api.MessageInterface;
import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.model.MessageBatchAddDto;
import com.deloitte.dhr.hr.api.model.MessageCountDto;
import com.deloitte.dhr.hr.api.model.MessageDetailDto;
import com.deloitte.dhr.hr.api.model.MessageDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 消息相关的网关接口
 *
 * @author wgong
 * @since 22/08/2019 11:25
 */
@RestController
@RequestMapping(value = "/api/v1/hr/messages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class MessageController {


    @Autowired
    MessageInterface messageInterface;


    @PostMapping("/batch")
    public Response<Object> addMessage(@RequestBody @Validated Request<MessageBatchAddDto> messageAddDtoRequest) {
        return messageInterface.addMessage(messageAddDtoRequest);
    }

    @PostMapping
    public Response<Object> sendAllMessage(@RequestBody Request<MessageBatchAddDto> messageAddDtoRequest) {
        return messageInterface.sendAllMessage(messageAddDtoRequest);
    }

    @PostMapping("/page")
    public PaginationResponse<List<MessageDto>> findMessageByPage(@RequestBody PaginationRequest<MessageTypeEnum> messageType) {
        return messageInterface.findMessageByPage(messageType);
    }

    @PostMapping("/count")
    public Response<MessageCountDto> findMyAllMessageCount(@RequestBody Request<Object> request) {
        return messageInterface.findMyAllMessageCount(request);
    }

    @PostMapping("/{id}")
    public Response<MessageDetailDto> findById(@PathVariable("id") String id, @RequestBody Request<String> request) {
        return messageInterface.findById(id, request);
    }

    @PostMapping("/modify/{id}")
    public Response<Object> readMessage(@PathVariable("id")String id, @RequestBody Request<String> request) {
        return messageInterface.readMessage(id, request);
    }

    @PostMapping("/delete/{id}")
    public Response<Object> deleteMessage(@PathVariable("id")String id, @RequestBody Request<String> request) {
        return messageInterface.deleteMessage(id, request);
    }


}
