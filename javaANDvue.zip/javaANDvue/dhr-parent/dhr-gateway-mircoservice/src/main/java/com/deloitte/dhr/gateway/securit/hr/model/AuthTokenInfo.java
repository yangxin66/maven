package com.deloitte.dhr.gateway.securit.hr.model;

import lombok.Data;

/**
 * @author chunliucq
 * @since 09/09/2019 0:01
 */
@Data
public class AuthTokenInfo {
    private String access_token;
    private String token_type;
    private String refresh_token;
    private String expires_in;
    private String scope;

}
