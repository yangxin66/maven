package com.deloitte.dhr.gateway.securit.hr.handler;

import com.deloitte.dhr.gateway.securit.hr.model.RedirectResult;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * "重定向到登录页面"处理器
 *
 * @author xideng
 */
@Slf4j
public class LinkToEntryPointHandler implements AuthenticationEntryPoint {

    private final String loginPageUrl;

    public LinkToEntryPointHandler(String loginPageUrl) {
        this.loginPageUrl = loginPageUrl;
    }

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException {

        String requestURI = request.getRequestURI();
        if (!Objects.equals("/favicon.ico", requestURI)) {
            String requestUrl = this.buildRequestUrl(request);
            request.getSession().setAttribute("__REDIRECT_URL", requestUrl);
        }

        // FIXME 请求地址为授权地址时，应该响应重定向，而不是返回json
        if (Objects.equals(requestURI, "/oauth/authorize")) {
            response.sendRedirect(loginPageUrl);
        }
        
        log.info("用户未登录，无法访问[" + requestURI + "]重定向至登录页面[" + loginPageUrl + "]");
        Response<RedirectResult.Content> result = new RedirectResult(loginPageUrl);
        response.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
        response.getWriter().write(SerializerUtils.serialize(result));
    }

    private String buildRequestUrl(HttpServletRequest request) {
        String method = request.getMethod();
        if (!HttpMethod.GET.matches(method)) {
            return null;
        }
        StringBuffer requestURL = request.getRequestURL();
        Map<String, String[]> parameterMap = request.getParameterMap();
        if (null == parameterMap || parameterMap.isEmpty()) {
            return requestURL.toString();
        }

        StringBuilder builder = new StringBuilder(requestURL);
        builder.append("?");
        parameterMap.forEach((k, v) -> {
            String value = Stream.of(v).collect(Collectors.joining("," ,"", ""));
            builder.append(k).append("=").append(value).append("&");
        });
        builder.deleteCharAt(builder.length() - 1);
        return builder.toString();

    }
}
