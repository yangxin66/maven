package com.deloitte.dhr.gateway.securit.hr.filter;

import com.deloitte.dhr.gateway.securit.hr.config.JwtProperties;
import com.deloitte.dhr.gateway.securit.hr.config.JwtTokenUtils;
import com.deloitte.dhr.gateway.securit.hr.config.Oauth2ClientProperties;
import com.deloitte.dhr.gateway.securit.hr.config.UserRepository;
import com.deloitte.dhr.gateway.securit.hr.model.RedirectResult;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.annotation.Resource;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author chunliucq
 * @since 11/09/2019 14:03
 */
@Slf4j
@Component
public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {

    @Autowired
    private JwtProperties jwtProperties;


    @Autowired
    private Oauth2ClientProperties oauth2ClientProperties;

    @Resource
    private UserDetailsService userDetailsService;
   // @Resource
    //private JwtTokenUtils jwtTokenUtils;
//    @Resource
//    private UserRepository userRepository;

    @Autowired
    private JwtTokenUtils jwtTokenUtils;

    @Autowired
    private UserRepository userRepository;

    private String tokenHeader = "Authorization";

    private String tokenHead = "Bearer ";

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain) throws ServletException, IOException {
        boolean checkTokenResult = true;
        //先从request中取token
        String authToken = jwtTokenUtils.getTokenFromRequest(request);

        if (StringUtils.isNotBlank(authToken)) {
            String username = jwtTokenUtils.getUsernameFromToken(authToken);
            log.info("checking authentication {}", username);
            log.info("request URL:{}",request.getRequestURI());
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                //从已有的user缓存中取了出user信息
                String token = userRepository.findTokenByUsername(username);

                // todo 检查token是否有效
//                if (jwtTokenUtils.validateToken(authToken, user)) {
//                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
//
//                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

//                }
                if (authToken.equals(token) && username != null){
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(username, authToken);
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    checkTokenResult = true;
                }
            }
        }
        if (checkTokenResult){
            // token 校验通过
            chain.doFilter(request, response);
        }else {
            String requestURI = request.getRequestURI();
            log.debug("用户未登录或会话已过期，无法访问[" + requestURI + "]重定向至登录页面[" + oauth2ClientProperties.getUserAuthorizationUri() + "]");
            Response<RedirectResult.Content> result = new RedirectResult(oauth2ClientProperties.getUserAuthorizationUri());
            response.setContentType(MediaType.APPLICATION_JSON_UTF8_VALUE);
            response.getWriter().write(SerializerUtils.serialize(result));
        }

    }
}
