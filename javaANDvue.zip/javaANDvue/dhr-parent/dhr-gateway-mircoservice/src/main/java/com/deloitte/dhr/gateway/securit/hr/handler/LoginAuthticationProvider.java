package com.deloitte.dhr.gateway.securit.hr.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

/**
 * @author chunliucq
 * @since 11/09/2019 23:38
 */
@Component
public class LoginAuthticationProvider implements AuthenticationProvider {

    @Autowired
    private MyUserDetailService myUserDetailService;

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String username = (String)authentication.getPrincipal();

        UserDetails userDetails = myUserDetailService.loadUserByUsername(username);

        if (userDetails != null){
            UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(
                    username, userDetails.getPassword(),
                    new NullAuthoritiesMapper().mapAuthorities(userDetails.getAuthorities()));
            result.setDetails(authentication.getDetails());
            return result;
        }
        return null;
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
