package com.deloitte.dhr.gateway.securit.hr.model;

import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import lombok.Getter;

/**
 * 表示重定向的{@link Response}
 *
 * @author xideng
 */
public class RedirectResult extends Response<RedirectResult.Content> {

    private static final long serialVersionUID = -1413323828370862678L;

    private static final int REDIRECT_CODE = 302;


    public RedirectResult(String url) {
        super(LanguageEnum.ZH_CN,String.valueOf(REDIRECT_CODE),null,new Content(url));
    }

    public static final class Content {

        @Getter
        private final String location;

        private Content(String location) {
            this.location = location;
        }
    }
}
