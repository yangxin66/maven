package com.deloitte.dhr.gateway.securit.hr.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * @author chunliucq
 * @since 22/09/2019 23:22
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "security.web")
public class SecurityWebProperties {
    /**
     * 无需校验路径
     */
    private List<String> noneAuthPaht;
}
