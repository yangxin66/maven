package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.gateway.model.Item;
import com.deloitte.dhr.gateway.model.ResourcesDto;
import com.deloitte.dhr.gateway.service.ResourceService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.user.api.AuthorityUserResourcesInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 菜单管理
 *
 * @author chunliucq
 * @since 06/09/2019 16:03
 */
@RestController
@RequestMapping(value = "/api/v1/menu", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class MenuController {

    @Autowired
    AuthorityUserResourcesInterface authorityUserResourcesInterface;

    @Autowired
    private ResourceService resourceService;

    /**
     * 获取菜单，返回菜单树
     *
     * @param request
     * @return
     */
    @PostMapping("/get")
    public Response<List<Item>> getMenu(@RequestBody Request<String> request) {

        List<ResourcesDto> resourcesList = resourceService.getResourceList(request.getData(),
                ResourceService.resource_type_menu);
        List<ResourcesDto> collect = resourcesList.stream().sorted((o1, o2) -> {
            return o1.getLevel() - o2.getLevel();
        }).collect(Collectors.toList());

        List<Item> menuList = convertResourceToItem(collect);
        return ResponseUtil.build().creatDeaultOkResponse(menuList);
    }

    private List<Item> convertResourceToItem(List<ResourcesDto> resourcesList) {
        List<Item> treeList = new ArrayList<>();
        for (ResourcesDto res : resourcesList) {
            if (res.getParentId() == null || res.getParentId() <= 0) {
                Item item = convertResToItem(res);
                treeList.add(item);
            }
        }
        for (ResourcesDto tmpRes : resourcesList) {
            appendSubItem(treeList, tmpRes);
        }
        //return treedByRoots(resourcesList, treeList);
        return  treeList;
    }

    private List<ResourcesDto> treedByRoots(List<ResourcesDto> resourcesList, List<Item> treeList) {
        Map<Long, ResourcesDto> map = new HashMap<>();
        resourcesList.stream()
                // 根据Level排序
                .sorted((d1, d2) -> {
                    int source = d1.getLevel();
                    int target = d2.getLevel();
                    int compare = Integer.compare(source, target);
                    if (compare != 0) {
                        return compare;
                    }
                    return Integer.compare(d1.getId().intValue(), d2.getId().intValue());
                })
                .forEach(resourcesDto -> {
                    Long parent = resourcesDto.getParentId();
                    if (0 != parent) {
                        ResourcesDto item = map.get(parent);
                        if (null != item) {
                            List<ResourcesDto> children = item.getSubmenu();
                            children.add(resourcesDto);
                        }
                    }
                    map.put(resourcesDto.getId(), resourcesDto);
                });
        List<ResourcesDto> finalRes = new ArrayList<>(treeList.size());
        treeList.forEach(tree -> finalRes.add(map.get((Long.parseLong(tree.getId())))));
        return finalRes;
    }

    private void appendSubItem(List<Item> itemList, ResourcesDto res) {
        if (CollectionUtils.isEmpty(itemList)) {
            return;
        }
        for (Item item : itemList) {
            if (item.getId().equals(String.valueOf(res.getParentId()))) {
                Item item1 = convertResToItem(res);
                if (CollectionUtils.isEmpty(item.getSubmenu())) {
                    item.setSubmenu(new ArrayList<>());
                }
                List<Item> items = new ArrayList<>();
                item.getSubmenu().add(item1);
                return;
            } else {
                appendSubItem(item.getSubmenu(), res);
            }
        }
    }

    private Item convertResToItem(ResourcesDto res) {
        Item item = new Item();
        item.setId(String.valueOf(res.getId()));
        item.setName(res.getName());
        item.setUrl(res.getUri());
        return item;
    }

}

