package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.hr.api.TaskSearchInterface;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author chunliucq
 * @since 06/09/2019 16:03
 */
@RestController
@RequestMapping(value = "/test",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class TestController {

    private TaskSearchInterface taskInterface;

    @Autowired
    private List<TaskSearchInterface> taskSearchInterfaceList;

    @GetMapping("/hello")
    public Response<String> test(String s){

        return ResponseUtil.build().creatDeaultOkResponse("hello");
    }

    @GetMapping("/visit")
    public Response<String> visit(String s){

        return ResponseUtil.build().creatDeaultOkResponse("visit");
    }

    @GetMapping("/err")
    public Response<String> err(String s){
        return ResponseUtil.build().creatDeaultOkResponse("err");
    }
}
