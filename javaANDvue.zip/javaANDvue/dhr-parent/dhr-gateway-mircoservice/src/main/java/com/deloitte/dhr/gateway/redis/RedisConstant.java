package com.deloitte.dhr.gateway.redis;

/**
 * redis的键的常量类
 * <br/>28/08/2019 16:32
 *
 * @author lshao
 */
public class RedisConstant {

    public static final String USER_TOKEN_CHECK = "LOGIN:STAFF:VERIFY:JWTTOKEN:";
}
