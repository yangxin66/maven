package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.hr.api.HrNotificationInterface;
import com.deloitte.dhr.hr.api.model.RejectStaffDto;
import com.deloitte.dhr.hr.api.model.staff.StaffListDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author chunliucq
 * @since 22/08/2019 13:49
 */
@RestController
@RequestMapping(value = "/api/v1/hr/notification", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class HrNotificationController {

    @Autowired
    private HrNotificationInterface hrNotificationInterface;

    /**
     * 驳回 --》重新发送邮件
     *
     * @param request 查询参数传输实体
     */
    @PostMapping("/reject_entry_email")
    Response<Object> sendRejectEmail(@Validated @RequestBody Request<RejectStaffDto> request){
        return hrNotificationInterface.sendRejectEmail(request);
    }

    @PostMapping(value = "/send_entry_email")
    Response<Object> sendEmail(@RequestBody Request<List<String>> applyNoListReq){
        return hrNotificationInterface.sendEmail(applyNoListReq);
    }
}
