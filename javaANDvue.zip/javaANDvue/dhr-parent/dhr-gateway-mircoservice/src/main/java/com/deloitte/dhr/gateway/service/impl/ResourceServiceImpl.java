package com.deloitte.dhr.gateway.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.gateway.model.ResourcesDto;
import com.deloitte.dhr.gateway.securit.hr.config.Oauth2ClientProperties;
import com.deloitte.dhr.gateway.service.ResourceService;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author chunliucq
 * @since 07/10/2019 16:44
 */
@Service
public class ResourceServiceImpl implements ResourceService {

    private RestTemplate restTemplate = new RestTemplate();

    @Autowired
    private Oauth2ClientProperties oauth2ClientProperties;


    @Override
    public List<ResourcesDto> getResourceList(String staffNo, String type) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        Map<String,Object> dataMap = new HashMap<>();
        Map<String,Object> paramMap = new HashMap<>();
        dataMap.put("data",paramMap);
        paramMap.put("pernr",staffNo);
        paramMap.put("type",type);
        HttpEntity<Map<String,Object>> entity = new HttpEntity<>(dataMap, headers);
        ResponseEntity<Response> resp = restTemplate.postForEntity(oauth2ClientProperties.getAccessAuthQueryResoures(), entity, Response.class);
        if (resp != null && resp.getStatusCode().value()/100 == 2){
            Object obj = resp.getBody().getData();
            List<Map> roleListMap = (List<Map>)obj;
            if (!CollectionUtils.isEmpty(roleListMap)){
                List<ResourcesDto> resourceList = roleListMap.stream().map(tmp -> {
                    String resJson = JSONObject.toJSONString(tmp);
                    ResourcesDto res = JSONObject.parseObject(resJson,ResourcesDto.class);
                    return res;
                }).collect(Collectors.toList());
                return resourceList;
            }
        }else {
            throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getCode(),
                    HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getMessage());
        }
        return new ArrayList<>();
    }
}
