package com.deloitte.dhr.gateway.web.i18n;

import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.i18n.config.SpringMessageLocator;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * date: 06/09/2019 16:11
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
@Aspect
public class MessageAspect {

    @Pointcut("@within(org.springframework.stereotype.Controller) || @within(org.springframework.web.bind.annotation.RestController)")
    public void pointcut() {
    }

    /**
     * 返回通知
     *
     * @param proceedingJoinPoint proceedingJoinPoint
     */
    @Around(value = "pointcut()")
    public Object doAround(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object result = proceedingJoinPoint.proceed();
        if (result instanceof PaginationResponse) {
            PaginationResponse response = (PaginationResponse) result;
            LanguageEnum language = response.getLanguage();
            language = language == null ? LanguageEnum.ZH_CN : language;
            Locale locale = new Locale(language.name());
            String code = response.getCode();
            String message = SpringMessageLocator.getMessage(code, locale);
            return new PaginationResponse<>(language,response.getPage(),response.getSize(),response.getTotal(),
                    response.getSortBy(), code, message, response.getData());
        } else if (result instanceof Response) {
            Response response = (Response) result;
            LanguageEnum language = response.getLanguage();
            language = language == null ? LanguageEnum.ZH_CN : language;
            Locale locale = new Locale(language.name());
            String code = response.getCode();
            String message = SpringMessageLocator.getMessage(code, locale);
            return new Response<>(language, code, message, response.getData());
        }
        return result;
    }
}
