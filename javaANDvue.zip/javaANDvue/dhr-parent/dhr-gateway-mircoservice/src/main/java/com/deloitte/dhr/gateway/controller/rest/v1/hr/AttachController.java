package com.deloitte.dhr.gateway.controller.rest.v1.hr;

import com.deloitte.dhr.gateway.service.AttachService;
import com.deloitte.dhr.hr.api.model.AttachDTO;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * 附件操作
 * <br/>29/08/2019 11:28
 *
 * @author lshao
 */
@RestController
@RequestMapping(value = "/api/v1/hr/attach", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class AttachController {

    @Autowired
    private AttachService attachService;

    /**
     * 上传
     */
    @PostMapping("/upload")
    Response<AttachDTO> upload(@RequestParam("attach") MultipartFile file) {
        return attachService.uploadAttch(file);
    }

    @GetMapping("/download")
    void download(AttachDTO dto, HttpServletResponse response) {
        attachService.downLoad(dto, response);
    }
}
