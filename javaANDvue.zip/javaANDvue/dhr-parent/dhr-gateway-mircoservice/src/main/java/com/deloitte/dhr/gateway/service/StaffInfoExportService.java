package com.deloitte.dhr.gateway.service;

import com.deloitte.dhr.hr.api.model.AttachDTO;
import com.deloitte.dhr.hr.api.model.ExcelApplyExportDto;
import com.deloitte.dhr.hr.api.model.ExcelOutExprotDto;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * 员工信息导出
 * <br/>29/08/2019 10:58
 *
 * @author wgong
 */
public interface StaffInfoExportService {

    void exportStaffInfoExcel(String data, HttpServletResponse httpResponse);

}
