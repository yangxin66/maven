-----------------------------------------------------
-- Export file for user DHR_HR                     --
-- Created by chunliucq on 17/09/2019, 10:28:29 AM --
-----------------------------------------------------

create table DHR_BUSINESS_ENUM
(
  ID                NUMBER(19) default '' not null,
  CREATED_DATE      TIMESTAMP(6) not null,
  CREATED_USER_OID  RAW(16) not null,
  DELETED           NUMBER(1) not null,
  MODIFIED_DATE     TIMESTAMP(6) not null,
  MODIFIED_USER_OID RAW(16) not null,
  OID               RAW(16),
  CODE              VARCHAR2(20 CHAR),
  CODE_NAME         VARCHAR2(50 CHAR),
  COMPANY_ID        VARCHAR2(50 CHAR)
)
;
alter table DHR_BUSINESS_ENUM
  add primary key (ID);
alter table DHR_BUSINESS_ENUM
  add constraint UK_CTTT8OGNI131T94984UGHI7FI unique (OID);

prompt
prompt Creating table DHR_BUSINESS_ENUM_ITEM
prompt =====================================
prompt
create table DHR_BUSINESS_ENUM_ITEM
(
  ID                NUMBER(19) not null,
  CREATED_DATE      TIMESTAMP(6) not null,
  CREATED_USER_OID  RAW(16) not null,
  DELETED           NUMBER(1) not null,
  MODIFIED_DATE     TIMESTAMP(6) not null,
  MODIFIED_USER_OID RAW(16) not null,
  OID               RAW(16),
  CODE              VARCHAR2(20 CHAR),
  ITEM_DES          VARCHAR2(254 CHAR),
  ENUM_ID           NUMBER(19),
  ITEM_CODE         VARCHAR2(50 CHAR),
  ITEM_LEVEL        NUMBER(10),
  ITEM_PATH         VARCHAR2(254 CHAR),
  ITEM_VALUE        VARCHAR2(254 CHAR),
  PID               VARCHAR2(20 CHAR)
)
;
alter table DHR_BUSINESS_ENUM_ITEM
  add primary key (ID);
alter table DHR_BUSINESS_ENUM_ITEM
  add constraint UK_ORT1U8M3OXC94W5LHVVN0XTFL unique (OID);
alter table DHR_BUSINESS_ENUM_ITEM
  add constraint FKT3UV7HJ4SJLRJY2MFSK85XBG4 foreign key (ENUM_ID)
  references DHR_BUSINESS_ENUM (ID);


create sequence HIBERNATE_SEQUENCE
minvalue 1
maxvalue 9999999999999999999999999999
start with 47
increment by 1
cache 20;

