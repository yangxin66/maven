package com.deloitte.dhr.hr;

import com.deloitte.dhr.hr.provider.DhrHRApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

/**
 * date: 04/09/2019 19:59
 *
 * @author wgong
 * @since 0.0.1
 */
@SpringBootTest(classes = DhrHRApplication.class)
@RunWith(SpringRunner.class)
public class MongodbTest {

    @Autowired
    MongoTemplate mongoTemplate;

    @Test
    public void testMong(){
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("businessId").is("1567132768310")),
                Aggregation.lookup("staff_info", "businessId", "_BUSINESSID", "staffInfoList"),
                Aggregation.match(Criteria.where("staffInfoList").exists(true).andOperator(Criteria.where("staffInfoList._DATA._BASE.NACHN").is("王")))
        );
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, "staff_email_status", Map.class);
//        AggregationResults<StaffInfoEmailStatusRelDto> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, "staff_email_status", StaffInfoEmailStatusRelDto.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
        System.out.println(mappedResults);
    }
}
