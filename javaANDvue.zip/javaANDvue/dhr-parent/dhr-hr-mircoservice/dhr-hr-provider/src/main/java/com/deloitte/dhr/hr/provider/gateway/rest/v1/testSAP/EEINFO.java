package com.deloitte.dhr.hr.provider.gateway.rest.v1.testSAP;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * <br/>22/08/2019 15:32
 *
 * @author lshao
 */
@Data
public class EEINFO {
    @JsonProperty("PERSKTX")
    private String persktx;

    @JsonProperty("PERNR")
    private String pernr;
}
