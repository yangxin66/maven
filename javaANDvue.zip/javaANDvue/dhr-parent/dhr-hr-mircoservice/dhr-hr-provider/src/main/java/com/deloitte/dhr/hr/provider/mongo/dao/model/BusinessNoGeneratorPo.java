package com.deloitte.dhr.hr.provider.mongo.dao.model;

import lombok.Data;

/**
 * 业务生成编号规则生成器po
 * @author chunliucq
 * @since 04/09/2019 20:27
 */
@Data
public class BusinessNoGeneratorPo {
    /**
     * 业务编号key
     */
    private String key;
    /**
     * 业务生成规则
     */
    private BusinessNoRule rule;
}
