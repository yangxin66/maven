package com.deloitte.dhr.hr.provider.gateway.rest.v1.testSAP;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.sap.bean.parameter.ImportParameter;
import com.deloitte.dhr.extension.sap.service.JCOService;
import com.deloitte.dhr.extension.sap.service.SapService;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <br/>22/08/2019 11:28
 *
 * @author lshao
 */
@RestController
@RequestMapping("/sap")
public class SapTestController {
    @Autowired
    private SapService sapService;
    @Autowired
    private JCOService jcoService;
    @Data
    @AllArgsConstructor
    private class Param{
        @JsonProperty("I_PERNR")
        private String pernr;
        @JsonProperty("TTT")
        private String ttt;
    }
    @Data
    @AllArgsConstructor
    private class MetaDataParam{
        @JsonProperty("I_FUNNM")
        private String funnm;
    }

    @RequestMapping("/test")
    public Object test(){
        Param p = new Param("00000423","22");
        JSONObject j = sapService.call(new ImportParameter("ZFM_PA_BASICINFO",p));
        TestExports e = sapService.getExports(j,TestExports.class);
        System.out.println(e);
        return j;
    }

    @RequestMapping("/metadata")
    public Object testJSON(@RequestParam("rfc") String rfcStr){
        MetaDataParam p =new MetaDataParam(rfcStr);
        JSONObject metaJSON = this.sapService.call(new ImportParameter("YFM_DTT01",p));
        System.out.println(metaJSON.toJSONString());
        return metaJSON;
    }


    @RequestMapping("/testJSON")
    public Object testJSON(){
        JSONObject result = this.jcoService.call2JSON("YFM_DTT01",new JSONObject());
        System.out.println(result.toJSONString());
        return result;
    }

    @RequestMapping("/testTable")
    public Object testTable(){
        Param p = new Param("00000423","22");
        JSONObject j = sapService.call(new ImportParameter("ZFM_PA_READPHOTO",p));
        TestTables t = sapService.getTables(j,TestTables.class);
        TestExports e = sapService.getExports(j,TestExports.class);
        System.out.println(j);
        System.out.println(e);
        return j;
    }
}
