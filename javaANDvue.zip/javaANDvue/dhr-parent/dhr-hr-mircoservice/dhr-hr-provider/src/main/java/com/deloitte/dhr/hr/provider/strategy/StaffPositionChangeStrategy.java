package com.deloitte.dhr.hr.provider.strategy;

import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.dhr.hr.provider.service.TaskNodeHandlerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * 岗位变动流程节点相关处理
 * date: 15/10/2019 9:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class StaffPositionChangeStrategy implements Strategy {

    @Autowired
    private TaskNodeHandlerService taskNodeHandlerService;


    @Autowired
    HrNotificationService hrNotificationService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean nodeHandler(AuditHandlerDto auditHandlerDto, String staffId,
                               String applyNo) {
        boolean ended = taskNodeHandlerService.commonFlowNodeHandler(auditHandlerDto);
        // TODO 可能需要将临时数据需要修改为正式数据
        if (ended) {
            if (SubtypeEnum.STAFF_POSITION_CHANGE == auditHandlerDto.getSubtypeEnum()) {
                // 员工岗位变动审批完后的操作
                positionChangeApprovedHandler(staffId);
            } else if (SubtypeEnum.LEADER_POSITION_CHANGE == auditHandlerDto.getSubtypeEnum()) {
                leaderChangeApprovedHandler(applyNo);
            }

        }
        return ended;
    }

    @Override
    public ManagementTypeEnum getManagementType() {
        return ManagementTypeEnum.POSITION_CHANGE;
    }

    /**
     * 岗位变动审批通过后的操作
     *
     * @param applyNo 业务编号
     */
    private void positionChangeApprovedHandler(String applyNo) {
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_POSITION_CHANGE_DETAIL);
        // TODO 需要调用SAP的接口 更新岗位信息

    }

    /**
     * 岗位变动审批通过后的操作
     *
     * @param applyNo 业务编号
     */
    private void leaderChangeApprovedHandler(String applyNo) {
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_POSITION_CHANGE_DETAIL);
        // TODO 需要调用SAP的接口 更新岗位信息
    }
}
