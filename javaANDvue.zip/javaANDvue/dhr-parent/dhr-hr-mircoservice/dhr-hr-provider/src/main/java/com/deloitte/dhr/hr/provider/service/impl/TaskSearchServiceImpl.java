package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApplyPartEnum;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.dhr.hr.provider.utils.PaginationUtils;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.constant.ConditionRelType;
import com.deloitte.workflow.api.model.dto.TaskDto;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

/**
 * date: 21/08/2019 16:13
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class TaskSearchServiceImpl implements TaskSearchService {

    private final PlatformTransactionManager dataSourceTransactionManager;

    private final TransactionDefinition transactionDefinition;

    private final WfTaskApi wfTaskApi;


    private final MongoTemplate mongoTemplate;


    @Autowired
    CommonService commonService;

    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;

    @Autowired
    BussniessNoGeneratorService bussniessNoGeneratorService;

    @Autowired
    AuditNodeService auditNodeService;

    @Autowired
    StaffInfoDao staffInfoDao;

    public TaskSearchServiceImpl(PlatformTransactionManager dataSourceTransactionManager, TransactionDefinition transactionDefinition,
                                 WfTaskApi wfTaskApi, MongoTemplate mongoTemplate) {
        this.dataSourceTransactionManager = dataSourceTransactionManager;
        this.transactionDefinition = transactionDefinition;
        this.wfTaskApi = wfTaskApi;
        this.mongoTemplate = mongoTemplate;
    }


    private Criteria createStaffInfoCriteria(List<FieldCustomDto> firstFieldCustoms, List<FieldCustomDto> secondFieldCustoms, String prefix) {

        Criteria criteria = createCriteria(firstFieldCustoms, SearchRelationEnum.AND, prefix + ".");
        // 关联staff_info的员工信息要存在
        Criteria criteriaStaffInfoList = Criteria.where(prefix).exists(true);
        // 添加员工信息查询条件
        if (secondFieldCustoms != null && secondFieldCustoms.size() != 0) {
            Criteria criteria2 = createCriteria(secondFieldCustoms, SearchRelationEnum.OR, prefix + ".");
            criteriaStaffInfoList.andOperator(criteria, criteria2);
        } else {
            criteriaStaffInfoList.andOperator(criteria);
        }
        return criteriaStaffInfoList;

    }

    private Criteria createCriteria(List<FieldCustomDto> fieldCustomList, SearchRelationEnum searchRelationEnum, String prefix) {
        prefix = (prefix == null ? "" : prefix);
        List<Criteria> criteriaList = new ArrayList<>();
        Criteria criteria = new Criteria();
        for (FieldCustomDto f : fieldCustomList) {
            if (StringUtils.isNotBlank(f.getKey()) && StringUtils.isNotBlank(f.getValue())) {
                if (SearchConditionEnum.eq.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).is(f.getValue()));
                } else if (SearchConditionEnum.like.equals(f.getCondition())) {
                    String value = dealSpecialStr(f.getValue());
                    criteriaList.add(Criteria.where(prefix + f.getKey()).regex(".*?" + value + ".*"));
                } else if (SearchConditionEnum.lt.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).lt(f.getValue()));
                } else if (SearchConditionEnum.gt.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).gt(f.getValue()));
                } else if (SearchConditionEnum.ne.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).ne(f.getValue()));
                } else if (SearchConditionEnum.lte.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).lte(f.getValue()));
                } else if (SearchConditionEnum.gte.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).gte(f.getValue()));
                }
            }
        }
        if (criteriaList.size() > 0) {
            Criteria[] criteriaArr = new Criteria[criteriaList.size()];
            for (int i = 0; i < criteriaList.size(); i++) {
                criteriaArr[i] = criteriaList.get(i);
            }
            if (SearchRelationEnum.AND.name().equals(searchRelationEnum.name())) {
                criteria.andOperator(criteriaArr);
            } else if (SearchRelationEnum.OR.name().equals(searchRelationEnum.name())) {
                criteria.orOperator(criteriaArr);
            } else {
                throw new IllegalStateException("暂不支持该关系");
            }
        }

        return criteria;
    }

    /**
     * 处理正则表达式的特殊字符
     *
     * @param value 原字符
     */
    private String dealSpecialStr(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        if (value.contains(".") || value.contains("\\") || value.contains("?") || value.contains("<") || value.contains(">")
                || value.contains("^")) {
            return "\\" + value;
        }

        return value;
    }


    /**
     * 根据查询条件分页查询信息修改的待审批、已审批信息
     *
     * @param searchDtoRequest 搜索参数
     */
    @Override
    public PaginationResponse<List<StaffInfoApplyDto>> searchTaskByPage(PaginationRequest<SearchDto> searchDtoRequest) {
        //TODO 加入登录后用户信息需要改造
        SearchDto searchDto = searchDtoRequest.getData();
        SearchTypeEnum type = searchDto.getType();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        if (firstFieldCustoms == null || firstFieldCustoms.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getMessage());
        }
        validateSearchCondition(firstFieldCustoms);
        ManagementTypeEnum managementTypeEnum = searchDto.getManagementType();
        PaginationRequest<SearchDto> searchDtoPaginationRequest;
        addCondition(managementTypeEnum, firstFieldCustoms, false);
        searchDto.setFirstFieldCustoms(firstFieldCustoms);
        searchDtoPaginationRequest = new PaginationRequest<>(searchDto, searchDtoRequest.getPage(), searchDtoRequest.getSize(), searchDtoRequest.getSortPairs());

        if (SearchTypeEnum.COMPLETE_TASK == type) {
            return getTaskByPageFromFlow(searchDtoPaginationRequest, true);
        } else if (SearchTypeEnum.UNCOMPLETE_TASK == type) {
            return getTaskByPageFromFlow(searchDtoPaginationRequest, false);
        } else {
            throw new BusinessException(HRMateInfo.SEARCH_TYPE_IS_UNSUPPORT_ERR.getCode(), HRMateInfo.SEARCH_TYPE_IS_UNSUPPORT_ERR.getMessage());
        }
    }

    private void validateSearchCondition(List<FieldCustomDto> firstFieldCustoms){
        int gteNum = 0;
        Instant start = null;
        Instant end = Instant.now();
        for (FieldCustomDto fieldCustomDto : firstFieldCustoms) {
            if ("_APPLY_TIME".equals(fieldCustomDto.getKey()) && SearchConditionEnum.gte.equals(fieldCustomDto.getCondition())
                    && StringUtils.isNotBlank(fieldCustomDto.getValue())) {
                gteNum += 1;
                String value = fieldCustomDto.getValue();
                try {
                    start = Instant.parse(value);
                } catch (Exception e) {
                    throw new BusinessException(HRMateInfo.TIME_TRANS_ERR.getCode(), HRMateInfo.TIME_TRANS_ERR.getMessage());
                }
            } else if("_APPLY_TIME".equals(fieldCustomDto.getKey()) && SearchConditionEnum.lte.equals(fieldCustomDto.getCondition())
                    && StringUtils.isNotBlank(fieldCustomDto.getValue())) {
                String value = fieldCustomDto.getValue();
                try {
                    end = Instant.parse(value);
                } catch (Exception e) {
                    throw new BusinessException(HRMateInfo.TIME_TRANS_ERR.getCode(), HRMateInfo.TIME_TRANS_ERR.getMessage());
                }
            }
        }
        // 如果没有申请时间
        if (gteNum != 1 || start == null) {
            throw new BusinessException(HRMateInfo.SEARCH_CONDITION_ERR.getCode(), HRMateInfo.SEARCH_CONDITION_ERR.getMessage());
        }
        Instant endinstant = end.truncatedTo(ChronoUnit.DAYS);
        Instant startInstant = start.truncatedTo(ChronoUnit.DAYS);
        Duration between =Duration.between(startInstant,endinstant);
        long l = between.getSeconds() / (60 * 60 * 24);
        if (l > 366) {
            throw new BusinessException(HRMateInfo.SEARCH_CONDITION_ERR.getCode(), HRMateInfo.SEARCH_CONDITION_ERR.getMessage());
        }

    }

    @Override
    public PaginationResponse<List<StaffInfoApplyDto>> searchMyApplicationByPage(PaginationRequest<SearchDto> searchDtoRequest) {
        //TODO 加入登录后用户信息需要改造
        SearchDto searchDto = searchDtoRequest.getData();
        SearchTypeEnum type = searchDto.getType();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        if (firstFieldCustoms == null || firstFieldCustoms.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getMessage());
        }
        validateSearchCondition(firstFieldCustoms);
        PaginationRequest<SearchDto> searchDtoPaginationRequest;
        ManagementTypeEnum managementTypeEnum = searchDto.getManagementType();
        addCondition(managementTypeEnum, firstFieldCustoms, true);
        searchDto.setFirstFieldCustoms(firstFieldCustoms);
        searchDtoPaginationRequest = new PaginationRequest<>(searchDto, searchDtoRequest.getPage(), searchDtoRequest.getSize(), searchDtoRequest.getSortPairs());

        if (SearchTypeEnum.PROCESSING == type) {
            // 查询正则进行中的任务
            return getMyApplicationProcessingTasksByPage(searchDtoPaginationRequest);
        } else if (SearchTypeEnum.COMPLETE_TASK == type) {
            return getMyApplicationCompleteApplyByPage(searchDtoPaginationRequest);
        } else {
            return getTaskByPageFromFlow(searchDtoPaginationRequest, false);
        }

    }

    /**
     * 给待办已办的一级搜索项添加一些条件
     *
     * @param managementTypeEnum 管理类型枚举 比如岗位变动、兼职管理等
     * @param firstFieldCustoms  待办已办的一级搜索项
     * @param isMyApplication    是否是个人申请
     */
    private void addCondition(ManagementTypeEnum managementTypeEnum, List<FieldCustomDto> firstFieldCustoms, boolean isMyApplication) {
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        if (managementTypeEnum != null) {
            FieldCustomDto fieldCustomDto = new FieldCustomDto();
            fieldCustomDto.setKey("_APPLY_TYPE");
            fieldCustomDto.setValue(managementTypeEnum.name());
            fieldCustomDto.setCondition(SearchConditionEnum.eq);
            firstFieldCustoms.add(fieldCustomDto);
        }
        if (isMyApplication) {
            // 设置查询我的个人申请的条件
            FieldCustomDto fieldCustomDto = new FieldCustomDto();
            fieldCustomDto.setKey("_IS_MY_APPLICATION");
            fieldCustomDto.setValue("1");
            fieldCustomDto.setCondition(SearchConditionEnum.eq);
            firstFieldCustoms.add(fieldCustomDto);
            // 设置发起人必须是自己
            FieldCustomDto fieldCustomDto1 = new FieldCustomDto();
            fieldCustomDto1.setKey("_APPLICANT_ID");
            fieldCustomDto1.setValue(staffNo);
            fieldCustomDto1.setCondition(SearchConditionEnum.eq);
            firstFieldCustoms.add(fieldCustomDto1);
        }
//        else {
//            // 设置查询非我的个人申请的条件
//            FieldCustomDto fieldCustomDto = new FieldCustomDto();
//            fieldCustomDto.setKey("_IS_MY_APPLICATION");
//            fieldCustomDto.setValue("0");
//            fieldCustomDto.setCondition(SearchConditionEnum.EQUALS);
//            firstFieldCustoms.add(fieldCustomDto);
//        }

    }

    /**
     * 获取我的申请 已完成任务列表
     *
     * @param searchDtoRequest
     * @return
     */
    private PaginationResponse<List<StaffInfoApplyDto>> getMyApplicationCompleteApplyByPage(PaginationRequest<SearchDto> searchDtoRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoRequest.getPage(), searchDtoRequest.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Criteria completeCriteria = Criteria.where("_AUDIT_TIME").exists(true);
        Criteria staffNoCriteria = Criteria.where("_APPLICANT_ID").is(staffNo);
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(completeCriteria);
        criteriaList.add(staffNoCriteria);
        Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

        Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_AUDIT_TIME"));
        List<Map> list = mongoTemplate.find(query.skip((long) page * size).limit(size),
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        int total = mongoTemplate.find(query,
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY).size();

        List<StaffInfoApplyDto> staffInfoModifyFlowDtoList = new ArrayList<>();
        list.forEach(m -> {
            StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
            staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
            String type1 = staffInfoApplyDto.getType();
            if (type1 != null) {
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
            }
            if (staffInfoApplyDto.getApplyType() != null) {
                staffInfoApplyDto.setApplyTypeName(ManagementTypeEnum.valueOf(staffInfoApplyDto.getApplyType()).getValue());
            }
            if (staffInfoApplyDto.getApplySubType() != null) {
                staffInfoApplyDto.setApplySubTypeName(SubtypeEnum.valueOf(staffInfoApplyDto.getApplySubType()).getValue());
            }
            // 如果是查询待审核的任务 应该设置状态为待审核  因为HRCollection.HR_STAFF_UPDATE_APPLY集合中存储的状态是针对表单状态：已提交、审核中、
            staffInfoModifyFlowDtoList.add(staffInfoApplyDto);
        });
        return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                page,
                size,
                total,
                searchDtoRequest.getSortPairs(), staffInfoModifyFlowDtoList);

    }

    /**
     * 获取我的申请 未完成任务列表
     *
     * @param searchDtoRequest
     * @return
     */
    private PaginationResponse<List<StaffInfoApplyDto>> getTaskByPageFromFlow(PaginationRequest<SearchDto> searchDtoRequest, boolean complete) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoRequest.getPage(), searchDtoRequest.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();


        String status = getStatusByfirstFieldCustoms(firstFieldCustoms);
//        List<String> flowTaskIds = taskDtos.stream().map(TaskDto::getTaskId).collect(Collectors.toList());
        Criteria searchStaffInfoApplyCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffApplyList");
        Sort sort;
        Criteria taskNodeCriteria ;
        Criteria staffApplyCriteria;
        List<Criteria> criteriaList = new ArrayList<>();
        if (!complete) {
            List<TaskDto> taskDtos = findTaskByManagentType(searchDto.getManagementType(),Boolean.FALSE);
            if (taskDtos == null || taskDtos.size() == 0) {
                return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                        page,
                        size,
                        0,
                        searchDtoRequest.getSortPairs(), null);
            }
            List<String> flowTaskIds = taskDtos.stream().map(TaskDto::getTaskId).collect(Collectors.toList());
            taskNodeCriteria = Criteria.where("taskId").in(flowTaskIds);
            staffApplyCriteria = searchStaffInfoApplyCriteria;
            sort = Sort.by(Sort.Direction.DESC, "staffApplyList._APPLY_TIME");
        } else {
//            List<AuditNodePo> completeTask = auditNodeService.findCompleteTask();
//            List<String> flowTaskIds = completeTask.stream().map(AuditNodePo::getTaskId).collect(Collectors.toList());
            CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
            String currentStaffNo = currentLoginUserInfo.getStaffNo();
            taskNodeCriteria = Criteria.where("auditorId").is(currentStaffNo);

            criteriaList.add(Criteria.where("auditTime").exists(true));
            criteriaList.add(Criteria.where("status").ne(ApproveStatusEnum.APPROVAL_PENDING.name()));
            criteriaList.add(Criteria.where("status").ne(ApproveStatusEnum.PRE_SUBMIT.name()));
            criteriaList.add(Criteria.where("status").ne(ApproveStatusEnum.CLOSE.name()));

            Criteria criteria = Criteria.where("auditTime").exists(true).andOperator(
                    new Criteria().orOperator(
                            Criteria.where("staffApplyList._IS_MY_APPLICATION").is("0")
                                    .andOperator(new Criteria().orOperator(
                                            Criteria.where("status").is(ApproveStatusEnum.SUBMITTED.name()),
                                            Criteria.where("status").is(ApproveStatusEnum.APPROVED.name()),
                                            Criteria.where("status").is(ApproveStatusEnum.REJECT.name()),
                                            Criteria.where("status").is(ApproveStatusEnum.UNAPPROVED.name())))
                    ,Criteria.where("status").ne(ApproveStatusEnum.SUBMITTED.name()).andOperator(
                            Criteria.where("staffApplyList._IS_MY_APPLICATION").is("1")))
            );
            staffApplyCriteria = Criteria.where("auditTime").exists(true).andOperator(criteria, searchStaffInfoApplyCriteria);
            sort = Sort.by(Sort.Direction.DESC, "auditTime");
        }
        if (status != null) {
            criteriaList.add(Criteria.where("status").is(status));
//            taskNodeCriteria.andOperator(Criteria.where("status").is(status));
        }
        if (criteriaList.size() != 0) {
            Criteria[] criteriaArr = new Criteria[criteriaList.size()];
            for (int i = 0; i < criteriaList.size(); i++) {
                criteriaArr[i] = criteriaList.get(i);
            }
            taskNodeCriteria.andOperator(criteriaArr);
        }
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(taskNodeCriteria),
                Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                Aggregation.match(staffApplyCriteria),
                Aggregation.sort(sort),
                Aggregation.skip((long) page * size),
                Aggregation.limit(size)
        );
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, HRCollection.HR_TASK_AUDIT_NODE, Map.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
        List<StaffInfoApplyDto> staffInfoApplyDtos = new ArrayList<>();
        mappedResults.forEach(m -> {
            TaskAuditNodeStaffInfoApplyRelDto nodeStaffInfoApplyRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), TaskAuditNodeStaffInfoApplyRelDto.class);
            List<StaffInfoApplyDto> staffApplyList = nodeStaffInfoApplyRelDto.getStaffApplyList();
            if (staffApplyList != null && staffApplyList.size() > 0) {
                StaffInfoApplyDto staffInfoApplyDto = staffApplyList.get(0);
                staffInfoApplyDto.setTaskStatus(nodeStaffInfoApplyRelDto.getStatus());
                staffInfoApplyDto.setTaskStatusName(ApproveStatusEnum.valueOf(nodeStaffInfoApplyRelDto.getStatus()).getValue());
                staffInfoApplyDto.setAuditTime(nodeStaffInfoApplyRelDto.getAuditTime());
                staffInfoApplyDto.setTaskId(nodeStaffInfoApplyRelDto.getTaskId());
//                staffInfoApplyDto.setStatus(nodeStaffInfoApplyRelDto.getStatus());
//                staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(nodeStaffInfoApplyRelDto.getStatus()).getValue());
                staffInfoApplyDto.setAuditId(nodeStaffInfoApplyRelDto.getAuditorId());
                staffInfoApplyDto.setAuditName(nodeStaffInfoApplyRelDto.getAuditorName());
                // 员工信息修改类型
                String type1 = staffInfoApplyDto.getType();
                if (type1 != null) {
                    staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
                }
                if (staffInfoApplyDto.getApplyType() != null) {
                    staffInfoApplyDto.setApplyTypeName(ManagementTypeEnum.valueOf(staffInfoApplyDto.getApplyType()).getValue());
                }
                if (staffInfoApplyDto.getApplySubType() != null) {
                    staffInfoApplyDto.setApplySubTypeName(SubtypeEnum.valueOf(staffInfoApplyDto.getApplySubType()).getValue());
                }
                staffInfoApplyDtos.add(staffInfoApplyDto);
            }
        });

        Aggregation aggregationTotal = Aggregation.newAggregation(
                Aggregation.match(taskNodeCriteria),
                Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                Aggregation.match(staffApplyCriteria),
                Aggregation.match(Criteria.where("auditTime").exists(true))
        );
        int total = mongoTemplate.aggregate(aggregationTotal, HRCollection.HR_TASK_AUDIT_NODE, Map.class).getMappedResults().size();
        return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                page,
                size,
                total,
                searchDtoRequest.getSortPairs(), staffInfoApplyDtos);

    }

    private String getStatusByfirstFieldCustoms(List<FieldCustomDto> firstFieldCustoms) {
        Iterator<FieldCustomDto> it = firstFieldCustoms.iterator();
        while (it.hasNext()) {
            FieldCustomDto firstFieldCustom = it.next();
            if ("_APPLY_STATUS".equals(firstFieldCustom.getKey())) {
                String value = firstFieldCustom.getValue();
                if (value == null || StringUtils.isBlank(value)) {
                    return null;
                }
                it.remove();
                return value;
            }
        }
        return null;
    }

    private PaginationResponse<List<StaffInfoApplyDto>> getMyApplicationProcessingTasksByPage(PaginationRequest<SearchDto> searchDtoRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoRequest.getPage(), searchDtoRequest.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Criteria criteria1 = Criteria.where("_APPLICANT_ID").is(staffNo);
        Criteria c1 = Criteria.where("_AUDIT_TIME").exists(false);
        Criteria c2 = Criteria.where("_APPLY_STATUS").ne("REJECT");
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(c1);
        criteriaList.add(c2);
        criteriaList.add(criteria1);
        Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

        Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_APPLY_TIME"));
        List<Map> list = mongoTemplate.find(query.skip((long) page * size).limit(size),
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        int total = mongoTemplate.find(query,
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY).size();

        List<StaffInfoApplyDto> staffInfoModifyFlowDtoList = new ArrayList<>();
        list.forEach(m -> {
            StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
            staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
            String type1 = staffInfoApplyDto.getType();
            if (type1 != null) {
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
            }
            if (staffInfoApplyDto.getApplyType() != null) {
                staffInfoApplyDto.setApplyTypeName(ManagementTypeEnum.valueOf(staffInfoApplyDto.getApplyType()).getValue());
            }
            if (staffInfoApplyDto.getApplySubType() != null) {
                staffInfoApplyDto.setApplySubTypeName(SubtypeEnum.valueOf(staffInfoApplyDto.getApplySubType()).getValue());
            }
            // 如果是查询待审核的任务 应该设置状态为待审核  因为HRCollection.HR_STAFF_UPDATE_APPLY集合中存储的状态是针对表单状态：已提交、审核中、
            staffInfoModifyFlowDtoList.add(staffInfoApplyDto);
        });
        return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                page,
                size,
                total,
                searchDtoRequest.getSortPairs(), staffInfoModifyFlowDtoList);
    }


    /**
     * 查询已完成或未完成的员工信息修改任务
     *
     * @param complete 是否完成
     */
    private List<TaskDto> findTaskByManagentType(ManagementTypeEnum managementTypeEnum, boolean complete) {
        TaskDto taskDto = new TaskDto();
        Response<List<TaskDto>> response;
        Map<String, Object> map = new HashMap<>(1);
        // 如果是员工入职
        if (ManagementTypeEnum.CREATE_STAFF == managementTypeEnum) {
            map.put("instanceType", ManagementTypeEnum.CREATE_STAFF.name());
            taskDto.setProcessVariables(map);
        } else if (ManagementTypeEnum.STAFF_INFO_MODIFY == managementTypeEnum) {
            map.put("instanceType", ManagementTypeEnum.STAFF_INFO_MODIFY.name());
            taskDto.setProcessVariables(map);
        } else if (ManagementTypeEnum.DECREASE_BOOK == managementTypeEnum) {
            map.put("instanceType", ManagementTypeEnum.DECREASE_BOOK.name());
            taskDto.setProcessVariables(map);
        }

        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        taskDto.setCompleted(complete);
        if (!complete) {
            taskDto.setCandidateGroups(ContextSession.getCurrentLoginUserRoleCodes());
            taskDto.setConditionRelType(ConditionRelType.OR);
            taskDto.setAssignee(staffNo);
            taskDto.setCandidate(staffNo);
            Request<TaskDto> request = new Request<>(taskDto);
            response = wfTaskApi.list(request);
        } else {
            taskDto.setAssignee(staffNo);
            Request<TaskDto> request = new Request<>(taskDto);
            response = wfTaskApi.historyTaskList(request);
        }

        if (!response.successful()) {
            throw new BusinessException(response.getCode(), response.getMessage());
        }
        return response.getData();
    }

    private Criteria createStaffInfoModifyCriteria(List<FieldCustomDto> firstFieldCustoms,
                                                   List<FieldCustomDto> secondFieldCustoms,
                                                   List<Criteria> criteriaStaffInfoList) {
        Criteria criteria = createCriteria(firstFieldCustoms, SearchRelationEnum.AND, "");
        criteriaStaffInfoList.add(criteria);
        Criteria criteria1 = new Criteria();
        // 添加员工信息更改查询条件
        if (secondFieldCustoms != null && secondFieldCustoms.size() != 0) {
            Criteria criteria2 = createCriteria(secondFieldCustoms, SearchRelationEnum.OR, "");
            criteriaStaffInfoList.add(criteria2);
        }
        if (criteriaStaffInfoList.size() > 0) {
            Criteria[] criteriaArr = new Criteria[criteriaStaffInfoList.size()];
            for (int i = 0; i < criteriaStaffInfoList.size(); i++) {
                criteriaArr[i] = criteriaStaffInfoList.get(i);
            }
            criteria1.andOperator(criteriaArr);
        }
        return criteria1;

    }


}
