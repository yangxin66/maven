package com.deloitte.dhr.hr.provider.mongo.dao.model;

import lombok.Builder;
import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * 审核节点
 * date: 17/09/2019 11:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@Builder
@Document(collection = "task_audit_node")
public class AuditNodePo{

    @Id
    private ObjectId id;

    private String processInstanceId;

    private String applyNo;

    private String taskId;

    private String lastTaskId;

    private String lastAuditorId;

    private String lastAuditorName;

    private String taskName;

    private String auditorId;

    private String auditorName;

    private Instant auditTime;

    private String imgUrl;

    private String status;

    private String statusName;

    private String remark;

}
