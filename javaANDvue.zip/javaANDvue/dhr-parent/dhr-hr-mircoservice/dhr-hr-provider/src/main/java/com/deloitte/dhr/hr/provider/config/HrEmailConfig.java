package com.deloitte.dhr.hr.provider.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author chunliucq
 * @since 29/08/2019 14:34
 */
@Data
@Component
@ConfigurationProperties(prefix = "dhr.test")
public class HrEmailConfig {
    /**
     * 系统域名
     */
    private String domain;

    /**
     * 邮件通知Token有效期
     */
    private Integer emailValid = 15;

    /**
     * 测试公司名称
     */
    private String companyName = "";
}
