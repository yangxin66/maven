package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.provider.mongo.dao.model.AuditNodePo;
import com.deloitte.workflow.api.model.dto.TaskNodeDto;

import java.util.List;

/**
 * @author chunliucq
 * @since 30/08/2019 17:06
 */
public interface AuditNodeService {

    void addNextTaskNode(List<TaskNodeDto> taskNodes, String applyNo, String status,
                         String lastTaskId, String lastAuditorId, String lastAuditorName);

    AuditNodePo findByProcessInstanceIdEqualsAndTaskIdEquals(String processInstaceId, String taskId);

    List<AuditNodePo> findCompleteTaskByProcessInstanceId(String processInstantId);

    List<AuditNodePo> findByTaskIdAndStatus(List<String> taskIds, String status);

    List<AuditNodePo> findByTaskIdAndStatusAndApplyNo(List<String> taskIds, List<String> applyNo, String status);

    void saveAndUpdate(AuditNodePo auditNodePo);

    List<AuditNodePo> findCompleteTask();
}
