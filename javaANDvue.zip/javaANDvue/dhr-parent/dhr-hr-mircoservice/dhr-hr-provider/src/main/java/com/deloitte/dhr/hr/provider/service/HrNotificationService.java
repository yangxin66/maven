package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.model.RejectStaffDto;

import java.util.List;

/**
 * date: 29/08/2019 14:44
 *
 * @author wgong
 * @since 0.0.1
 */
public interface HrNotificationService {

    /**
     * 发送驳回邮件
     *
     * @param rejectStaffDto 驳回实体
     */
    void sendRejectStaffInfoEmail(RejectStaffDto rejectStaffDto);

    /**
     * 批量发送审批通过邮件
     * @param pageDataRequests 员工集合信息
     */
    void batchSendApproveEmail(List<PageDataRequest> pageDataRequests);

    /**
     * 员工入职邮件发送
     * @param staffNoList
     */
    void doCommingInSendMail(List<String> staffNoList);

    /**
     * 发送入职审批通过邮件
     * @param pageDataRequest 员工集合信息
     */
    void sendCreateStaffApproveEmail(PageDataRequest pageDataRequest);
}
