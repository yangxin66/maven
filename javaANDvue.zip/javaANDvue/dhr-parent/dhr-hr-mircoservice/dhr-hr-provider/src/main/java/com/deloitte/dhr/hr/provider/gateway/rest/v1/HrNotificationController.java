package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.hr.api.HrNotificationInterface;
import com.deloitte.dhr.hr.api.model.RejectStaffDto;
import com.deloitte.dhr.hr.api.model.staff.StaffListDto;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 员工通知信息Controler
 * 包括发送邮件、短信通知等
 * @author chunliucq
 * @since 20/08/2019 10:52
 */
@RestController
@RequestMapping(value = "/api/v1/hr/notification",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class HrNotificationController implements HrNotificationInterface {

    @Autowired
    private HrNotificationService hrNotificationService;

    /**
     * 入职邮件通知
     * @param applyNosReq 业务编码集合
     * @return
     */
    @ApiOperation(value = "入职邮件通知",notes = "Hr新建员工入职时,邮件通知")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "applyNosReq",value="待发送邮件员工编号列表",required = true,dataType = "Request«List«string»»" )
    })
    @PostMapping(value = "/send_entry_email")
    @Override
    public Response<Object> sendEmail(@RequestBody Request<List<String>> applyNosReq){

        List<String> applyNoList =  applyNosReq.getData();
        if (CollectionUtils.isEmpty(applyNoList)){
            throw new BusinessException(HRMateInfo.STAFF_INFO_NONE_ERR.getCode(),HRMateInfo.STAFF_INFO_NONE_ERR.getMessage());
        }

        hrNotificationService.doCommingInSendMail(applyNoList);
        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "Success", null);
    }

    /**
     * 根据id从SAP中查询员工入职信息
     *
     * @param request 查询参数传输实体
     */
    @Override
    @PostMapping("/reject_entry_email")
    @ApiOperation(value = "驳回通过员工入职信息")
    @ApiImplicitParam(name = "request", value = "驳回传输实体", required = true, dataType = "Request«RejectStaffDto»")
    public Response<Object> sendRejectEmail(@Validated @RequestBody Request<RejectStaffDto> request) {
        // 任务id
        RejectStaffDto rejectStaffDto = request.getData();
        if (rejectStaffDto == null) {
            return new Response<>(request.getLanguage(),
                    HRMateInfo.SEND_REJECT_EMAIL_IS_EMPTY_ERR.getCode(), HRMateInfo.SEND_REJECT_EMAIL_IS_EMPTY_ERR.getMessage(), null);
        }
        hrNotificationService.sendRejectStaffInfoEmail(rejectStaffDto);
        return new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, "", null);
    }
}
