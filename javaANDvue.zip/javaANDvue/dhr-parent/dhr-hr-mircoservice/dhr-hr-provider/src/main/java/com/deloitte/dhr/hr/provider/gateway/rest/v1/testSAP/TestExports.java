package com.deloitte.dhr.hr.provider.gateway.rest.v1.testSAP;

import com.deloitte.dhr.extension.sap.bean.parameter.Exports;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * <br/>22/08/2019 15:29
 *
 * @author lshao
 */
@Data
public class TestExports extends Exports {
    @JsonProperty("E_EEINFO")
    private EEINFO eeinfo;
    @JsonProperty("E_EXTENSION")
    private String extension;
}