package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.hr.api.HrStaffInterface;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.api.model.staff.*;
import com.deloitte.dhr.hr.provider.redis.CommonRedisRepository;
import com.deloitte.dhr.hr.provider.redis.RedisConstant;
import com.deloitte.dhr.hr.provider.service.StaffApplyAlterService;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import com.deloitte.dhr.hr.provider.service.BussniessNoGeneratorService;
import com.deloitte.dhr.hr.provider.service.StaffInfoService;
import com.deloitte.dhr.hr.provider.service.HrStaffService;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.ex.BusinessException;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * 员工入职操作入口
 * 1、员工填写个人信息
 * 2、员工提交个人信息
 *
 * @author chunliucq
 * @since 22/08/2019 11:25
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/hr/staff", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class HrStaffController implements HrStaffInterface {

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    private CommonRedisRepository commonRedisRepository;

    @Autowired
    private StaffApplyAlterService staffApplyAlterService;

    @Autowired
    private BaseMongoService baseMongoService;

    @Autowired
    private BussniessNoGeneratorService bussniessNoGeneratorService;

    private static String STAFF_INFO_BUSINESSID = "_BUSINESSID";

    /**
     * 员工token Key prefix
     */
    private static final String STAFF_COMING_IN_SEND_EMAIL = "staff_coming_in_send_mail_";


    @Autowired
    HrStaffService hrStaffService;

    /**
     * 员工填写个人信息
     *
     * @param staffInfoJson
     * @return
     */
    @Override
    @ApiOperation(value = "员工填写个人信息", notes = "员工填写个人信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "staffInfoJson", value = "员工信息", required = true, dataType = "Request«JSONObject»")
    })
    @PostMapping(value = "/save")
    public Response<Map> saveStaffInfo(@RequestBody Request<JSONObject> staffInfoJson) {

        // todo check

        // save
        staffInfoService.savePartStaffInfo(staffInfoJson.getData());
        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "success", null);
    }

    /**
     * 员工填写信息提交
     *
     * @param staffInfoJson
     * @return
     */
    @ApiOperation(value = "员工提交个人信息", notes = "员工提交个人信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "staffInfoJson", value = "员工信息", required = true, dataType = "JSONObject")
    })
    @Override
    @PostMapping(value = "/submit")
    public Response<Map> submitStaffInfo(@RequestBody Request<JSONObject> staffInfoJson) {

        // 人员编号
        String staffNo = staffInfoJson.getData().getString(STAFF_INFO_BUSINESSID);

        // 保存
        staffInfoService.savePartStaffInfo(staffInfoJson.getData());

        // 校验
        boolean isComplete = staffInfoService.isAllFillInComplete(staffNo);

        if (!isComplete) {
            throw new BusinessException(HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getCode(), HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getMessage());
        }

        // 提效控制修改
        // TODO

        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "success", null);

    }


    @Override
    @PostMapping(value = "/check/person")
    public Response<String> staffPersonCheck(@RequestBody Request<StaffPersonCheckDto> request) {

        //JSONObject staffInfo = staffInfoService.queryStaffInfoByStaffNo(request.getData().getToken());

        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "success", null);
    }

    @ApiOperation(value = "查询员工信息", notes = "根据员工编号查询员工信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "staffNo", value = "员工编号", required = true, dataType = "Request«StaffNoDto»")
    })

    @PostMapping(value = "/query/detail/dhr")
    @Override
    public Response<Map> queryStaffInfoByStaffNo(@RequestBody Request<StaffNoDto> staffNo) {


        String resultJson = staffInfoService.queryStaffInfoByStaffNo(staffNo.getData().getStaffNo());
        Map mpa = JSONObject.parseObject(resultJson, Map.class);
        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "success", mpa);
    }

    @ApiOperation(value = "查询员工信息", notes = "根据Token查询员工信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "token", value = "Token", required = true, dataType = "Request«TokenDto»")
    })

    @PostMapping(value = "/query/detail/token")
    @Override
    public Response<Map> queryStaffInfoByToken(@RequestBody Request<TokenDto> tokenDtoRequest) {
        String staffNo = getTokenStaffNo(tokenDtoRequest.getData().getToken());
        if (staffNo == null) {
            return new Response<Map>(LanguageEnum.getDefault(), "1100233882", "Token已过期", null);
        }
        String resultJson = staffInfoService.queryStaffInfoByStaffNo(staffNo);
        Map mpa = JSONObject.parseObject(resultJson, Map.class);
        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "success", mpa);
    }

    /**
     * 根据查询条件查询员工入职信息
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
//    @Override
//    @ApiOperation(value = "搜索员工信息", notes = "搜索员工信息")
//    @ApiImplicitParams({
//            @ApiImplicitParam(name = "searchDtoPaginationRequest", value = "搜索项", required = true, dataType = "PaginationRequest«SearchDto»")
//    })
//    @PostMapping("/search")
//    public PaginationResponse<List<StaffNodeDto>> searchEmployee(@RequestBody @Valid PaginationRequest<SearchDto> searchDtoPaginationRequest) {
//        return hrStaffService.searchEmployeeByPage(searchDtoPaginationRequest);
//    }

    /**
     * 根据员工编号查询员工入职信息
     *
     * @param idRequest 查询参数传输实体
     */
    @Override
    @PostMapping("/detail/compare")
    @ApiOperation(value = "根据员工编号查询DHR和SAP中的员工入职信息")
    @ApiImplicitParam(name = "idRequest", value = "包含员工编号的搜索项", required = true, dataType = "Request«string»")
    public Response<StaffDetailCompareDto> getStaffDetailCompare(@RequestBody Request<String> idRequest) {
        String id = idRequest.getData();
        if (id == null || StringUtils.isBlank(id)) {
            return new Response<>(idRequest.getLanguage(),
                    HRMateInfo.STAFF_CODE_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_CODE_IS_EMPTY_ERR.getMessage(), null);
        }
        StaffDetailCompareDto staffDetailCompareDto = hrStaffService.getStaffDetailCompare(id);
        return new Response<>(idRequest.getLanguage(),
                Response.SUCCESS_CODE, null, staffDetailCompareDto);
    }

    /**
     * 批量审核通过员工入职信息
     *
     * @param approveStaffDtoListRequest 查询参数传输实体
     */
//    @Override
//    @PostMapping("/batch/approve")
//    @ApiOperation(value = "批量审核通过员工入职信息")
//    @ApiImplicitParam(name = "approveStaffDtoListRequest", value = "审核查询实体", required = true, dataType = "Request«List«ApproveStaffDto»»")
//    public Response<Object> approveStaffInfo(@Validated @RequestBody Request<List<ApproveStaffDto>> approveStaffDtoListRequest) {
//        // 任务id
//        List<ApproveStaffDto> data = approveStaffDtoListRequest.getData();
//        if (data == null || data.size() == 0) {
//            return new Response<>(approveStaffDtoListRequest.getLanguage(),
//                    HRMateInfo.HR_BATCH_APPROVE_RNTRY_DATA_IS_EMPTY_ERR.getCode(),
//                    HRMateInfo.HR_BATCH_APPROVE_RNTRY_DATA_IS_EMPTY_ERR.getMessage(), null);
//        }
//        hrStaffService.approveStaffInfo(data);
//        return new Response<>(approveStaffDtoListRequest.getLanguage(),
//                Response.SUCCESS_CODE, "", null);
//    }
//
//    @Override
//    @PostMapping("/search/modify_info_apply")
//    @ApiOperation(value = "搜索员工修改信息申请")
//    @ApiImplicitParam(name = "searchDtoPaginationRequest", value = "员工修改信息申请查询实体", required = true, dataType = "PaginationRequest«SearchDto»")
//    public PaginationResponse<List<StaffInfoApplyDto>> searchStaffInfoModifyTask(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
//        return hrStaffService.searchStaffInfoModifyTask(searchDtoPaginationRequest);
//    }

//    @Override
//    @PostMapping("/search/my_application")
//    @ApiOperation(value = "搜索我的申请")
//    @ApiImplicitParam(name = "searchDtoPaginationRequest", value = "员工修改信息申请查询实体", required = true, dataType = "PaginationRequest«SearchDto»")
//    public PaginationResponse<List<StaffInfoApplyDto>> searchMyApplication(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
//        return hrStaffService.searchMyApplication(searchDtoPaginationRequest);
//    }

    /**
     * 通过员工编号,申请状态,申请模块查询
     *
     * @param applyRequest 输入实体
     * @return
     */
    @Override
    @PostMapping("/modinfo/applied")
    @ApiOperation(value = "查询申请记录")
    @ApiImplicitParam(name = "applyRequest", value = "员工编号,模块名称,申请状态",
            required = true, dataType = "Request«StaffApplyDto»")
    public Response<List<ApplyStatus>> queryApply(@Validated @RequestBody Request<StaffApplyDto> applyRequest) {
        List<ApplyStatus> applyStatuses =
                staffApplyAlterService.queryApplyAlter(applyRequest);
        return ResponseUtil.build().creatDeaultOkResponse(applyStatuses);
    }

    /**
     * 通过申请编号查询申请信息
     *
     * @param applyNo 申请编号
     * @return
     */
    @Override
    @PostMapping("/modinfo/apply/query/applyno")
    @ApiOperation(value = "查询申请记录根据申请编号")
    @ApiImplicitParam(name = "applyNo", value = "申请编号",
            required = true, dataType = "Request«ApplyNo»")
    public Response<Map> queryApplyByApplyNo(@RequestBody Request<ApplyNo> applyNo) {
        JSONObject ApplyRecord =
                staffApplyAlterService.queryApplyAlterByApply(applyNo.getData().getApplyNo());
        return new Response<>(applyNo.getLanguage(),
                Response.SUCCESS_CODE, null, ApplyRecord);
    }

    /**
     * 对申请记录进行分页
     *
     * @param applyNoPaginationRequest 分页实体数据
     * @return
     */
    @Override
    @PostMapping("/modinfo/apply/query/applypage")
    @ApiOperation(value = "根据申请编号分页")
    @ApiImplicitParam(name = "applyNoPaginationRequest", value = "申请编号",
            required = true, dataType = "PaginationRequest«ApplyNo»")
    public PaginationResponse<List<Map>> queryApplyCompare(@RequestBody PaginationRequest<ApplyNo> applyNoPaginationRequest) {
        return staffApplyAlterService.ApplyPage(applyNoPaginationRequest);
    }


    private String getTokenStaffNo(String token) {
        String staffNo = (String) commonRedisRepository.get(RedisConstant.EMAIL_STAFF_VERIFY_TOKEN + token);
        return staffNo;
    }

    /**
     * 员工提效个人信息变更申请
     *
     * @param applyRequest
     * @return
     */
    @Override
    @PostMapping("/modinfo/apply")
    @ApiOperation(value = "员工提交个人信息变更申请")
    @ApiImplicitParam(name = "applyRequest", value = "申请信息", required = true, dataType = "Request«Map»",
            examples = @Example({@ExampleProperty(mediaType = "_BUSINESSID", value = "00000000"), @ExampleProperty(mediaType = "AA", value = "00000000")}))
    public Response<Void> applyModStaffInfo(@RequestBody Request<Map> applyRequest) {
        return staffInfoService.applyModStaffInfo(applyRequest);
    }

    @Override
    @PostMapping("/modify/staff_info/sap")
    @ApiOperation(value = "修改SAP中的员工信息")
    @ApiImplicitParam(name = "request", value = "员工信息修改传输实体",  required = true, dataType = "Request«StaffInfoModifyDto»")
    public Response<String> modifyStaffInfoToSap(@Validated @RequestBody Request<StaffInfoModifyDto> request){
        StaffInfoModifyDto data = request.getData();
        if (data == null) {
            throw new BusinessException(HRMateInfo.STAFF_INFO_MODIFY_DATA_IS_EMPTY_ERR.getCode(),
                    HRMateInfo.STAFF_INFO_MODIFY_DATA_IS_EMPTY_ERR.getMessage());
        }

        return new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, null, hrStaffService.modifyStaffInfoToSap(request.getData()));
    }

    @Override
    @PostMapping("/modinfo/apply/querydetail")
    @ApiOperation(value = "查询员工信息修改申请中变更记录详细信息")
    public Response<Map> queryUpdateDetailInfo(@RequestBody Request<ApplyRecord> applyRecordRequest) {
        ApplyRecord applyRecord = applyRecordRequest.getData();
        return staffInfoService.queryUpdateDetailInfo(applyRecord.getApplyNo(), applyRecord.getRid());
    }

    /**
     * @param staffUpdateApplyRecordRequest
     * @return
     */
    @Override
    @PostMapping("/modinfo/apply/update/record")
    public Response<Void> updateApplyRecord(@RequestBody Request<Map> staffUpdateApplyRecordRequest) {
        staffInfoService.queryDetailInfoUpdate(staffUpdateApplyRecordRequest);
        return new Response<>(staffUpdateApplyRecordRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    /**
     * 根据关键字搜索员工信息
     * @param request 含关键字的传输实体
     * @return
     */
    @Override
    @PostMapping("/search/staff_info")
    @ApiOperation(value = "根据关键字搜索员工信息")
    @ApiImplicitParam(name = "request", value = "关键字", required = true, dataType = "Request«string»")
    public Response<List<StaffInfoSearchDto>> searchStaffInfoByKeyword(@RequestBody Request<String> request) {
        String keyword = request.getData();
        if (keyword == null || StringUtils.isBlank(keyword)) {
            throw new BusinessException(HRMateInfo.SEARCH_STAFF_INFO_KEYWORD_IS_EMPTY.getCode(), HRMateInfo.SEARCH_STAFF_INFO_KEYWORD_IS_EMPTY.getMessage());
        }
        List<StaffInfoSearchDto> staffInfoSearchDtos = hrStaffService.searchStaffInfoByKeyword(keyword);
        return ResponseUtil.build().creatDeaultOkResponse(request.getLanguage(), staffInfoSearchDtos);
    }

}
