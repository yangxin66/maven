package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.hr.api.MessageInterface;
import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.model.MessageBatchAddDto;
import com.deloitte.dhr.hr.api.model.MessageCountDto;
import com.deloitte.dhr.hr.api.model.MessageDetailDto;
import com.deloitte.dhr.hr.api.model.MessageDto;
import com.deloitte.dhr.hr.provider.service.MessageService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.ex.BusinessException;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 任务查询接口
 *
 * @author chunliucq
 * @since 22/08/2019 11:25
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/hr/messages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class MessageController implements MessageInterface {


    @Autowired
    MessageService messageService;


    @Override
    @PostMapping("/batch")
    @ApiOperation(value = "发送消息")
    @ApiImplicitParam(name = "messageAddDtoRequest", value = "员工修改信息申请查询实体", required = true, dataType = "Request«MessageBatchAddDto»")
    public Response<Object> addMessage(@RequestBody @Validated Request<MessageBatchAddDto> messageAddDtoRequest) {
        MessageBatchAddDto messageAddDto = messageAddDtoRequest.getData();
        if (messageAddDto == null || messageAddDto.getStaffNos() == null || messageAddDto.getStaffNos().size() == 0) {
            throw new BusinessException(HRMateInfo.ADD_MESSAGE_DATA_IS_NULL_ERR.getCode(), HRMateInfo.ADD_MESSAGE_DATA_IS_NULL_ERR.getMessage());
        }
        messageService.addMessage(messageAddDto);
        return new Response<>(messageAddDtoRequest.getLanguage(), Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping
    public Response<Object> sendAllMessage(@RequestBody Request<MessageBatchAddDto> messageAddDtoRequest) {
        MessageBatchAddDto messageAddDto = messageAddDtoRequest.getData();
        if (messageAddDto == null) {
            throw new BusinessException(HRMateInfo.ADD_MESSAGE_DATA_IS_NULL_ERR.getCode(), HRMateInfo.ADD_MESSAGE_DATA_IS_NULL_ERR.getMessage());
        }
        messageService.sendAllMessage(messageAddDto);
        return new Response<>(messageAddDtoRequest.getLanguage(), Response.SUCCESS_CODE, null, null);

    }

    @Override
    @PostMapping("/page")
    @ApiOperation(value = "根据消息类型分页获取消息")
    @ApiImplicitParam(name = "messageType", value = "消息类型", required = true, dataType = "PaginationRequest«messageTypeEnum»")
    public PaginationResponse<List<MessageDto>> findMessageByPage(@RequestBody PaginationRequest<MessageTypeEnum> messageType) {
        MessageTypeEnum data = messageType.getData();
        if (data == null) {
            throw new BusinessException(HRMateInfo.QUERY_MESSAGE_TYPE_IS_ERR.getCode(), HRMateInfo.QUERY_MESSAGE_TYPE_IS_ERR.getMessage());
        }
        return messageService.findMessageByTypeAndPage(messageType);
    }

    @Override
    @PostMapping("/count")
    @ApiOperation(value = "获取当前用户的所有消息")
    @ApiImplicitParam(name = "request", value = "请求", required = true, dataType = "Request«Object»")
    public Response<MessageCountDto> findMyAllMessageCount(@RequestBody Request<Object> request) {
        MessageCountDto myAllMessageNum = messageService.getMyAllMessageNum();
        return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, myAllMessageNum);
    }

    @Override
    @PostMapping("/{id}")
    @ApiOperation(value = "根据id查看消息详细信息")
    @ApiImplicitParam(name = "request", value = "请求", required = true, dataType = "Request«string»")
    public Response<MessageDetailDto> findById(@PathVariable("id") String id, @RequestBody Request<String> request) {
        MessageDetailDto messageDto = messageService.findById(id);
        return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, messageDto);
    }

    @Override
    @PostMapping("/modify/{id}")
    @ApiOperation(value = "标记为已读")
    @ApiImplicitParam(name = "request", value = "请求", required = true, dataType = "Request«string»")
    public Response<Object> readMessage(@PathVariable("id")String id, @RequestBody Request<String> request) {
        messageService.readMessage(id);
        return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/delete/{id}")
    @ApiOperation(value = "根据id删除消息")
    @ApiImplicitParam(name = "request", value = "请求", required = true, dataType = "Request«string»")
    public Response<Object> deleteMessage(@PathVariable("id")String id, @RequestBody Request<String> request) {
        messageService.deleteMessage(id);
        return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, null);
    }


}
