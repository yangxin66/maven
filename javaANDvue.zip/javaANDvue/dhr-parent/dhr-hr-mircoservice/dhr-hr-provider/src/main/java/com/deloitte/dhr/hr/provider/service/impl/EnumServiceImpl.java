package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.hr.api.model.EnumCombox;
import com.deloitte.dhr.hr.api.model.EnumItem;
import com.deloitte.dhr.hr.api.model.EnumResult;
import com.deloitte.dhr.hr.provider.repository.EnumRepository;
import com.deloitte.dhr.hr.provider.repository.model.EnumItemPo;
import com.deloitte.dhr.hr.provider.repository.model.EnumPo;
import com.deloitte.dhr.hr.provider.service.EnumItemService;
import com.deloitte.dhr.hr.provider.service.EnumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * 查询枚举对象Service
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class EnumServiceImpl implements EnumService {

    @Autowired
    private EnumRepository enumRepository;

    @Autowired
    private EnumItemService enumItemService;

    @Override
    public EnumResult queryEnumInfo(List<String> keyList){
        List<EnumPo> enumPoList = new ArrayList<>();

        for(String key : keyList){
            EnumPo byCode = enumRepository.findByCode(key);
            if (byCode != null){
                enumPoList.add(byCode);
            }
        }
        return convertEnumPoToDto(enumPoList);
    }

    private EnumResult convertEnumPoToDto(List<EnumPo> poList) {
        EnumResult result = new EnumResult();
        Map<String, List<EnumItem>> map = new HashMap<>();
        for (EnumPo e:poList) {
            if(!map.containsKey(e.getCode())) {
                // 创建List<EnumCom.box>
                List<EnumItem> enumItems =new ArrayList<>();
                // 对list赋值
                // List<EnumItemPo> enumItemPos=e.getEnumItemPoList();
                List<EnumItemPo> enumItemPos= enumItemService.queryEnum(e.getCode());
                if(enumItemPos==null) {
                    continue;
                }
                for (EnumItemPo ei:enumItemPos) {
                    EnumItem enumItem = new EnumItem();
                    enumItem.setValue(ei.getItemValue());
                    enumItem.setDescription(ei.getDescription());
                    enumItem.setItemId(ei.getItemCode());
                    enumItems.add(enumItem);
                }
                map.put(e.getCode(),enumItems);
            }else {
                // 直接获取map的List<EnumCombox>
                List<EnumItem> enumItemList =new ArrayList<>();
                // 对list赋值
                for (EnumItemPo ei : e.getEnumItemPoList()) {
                    EnumItem enumItem = new EnumItem();
                    enumItem.setValue(ei.getItemValue());
                    enumItem.setDescription(ei.getDescription());
                    enumItem.setItemId(ei.getItemCode());
                    enumItemList.add(enumItem);
                }
                map.put(e.getCode(),enumItemList);
            }
            // 遍历map集合并赋值给result
            List<EnumCombox> enumComboxes = new ArrayList<>();
            result.setResultList(enumComboxes);
            for (Map.Entry<String,List<EnumItem>> entry:map.entrySet()) {
                EnumCombox enumCombox = new EnumCombox();
                enumCombox.setKey(entry.getKey());
                enumCombox.setEnumItemList(entry.getValue());
                enumComboxes.add(enumCombox);
            }
            for (EnumCombox tempBox : enumComboxes){
                String code = tempBox.getKey();
                for (EnumPo temp : poList){
                    if (code.equals(temp.getCode())){
                        tempBox.setKeyName(temp.getCodeName());
                    }
                }
            }
        }
        return result;
    }
}
