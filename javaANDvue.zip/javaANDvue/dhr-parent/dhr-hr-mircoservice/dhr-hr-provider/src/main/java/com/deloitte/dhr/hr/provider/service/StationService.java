package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.OrganizationDto;
import com.deloitte.dhr.hr.api.model.OrganizationQueryDto;
import com.deloitte.dhr.hr.api.model.OrganizationSearchDto;
import com.deloitte.dhr.hr.api.model.OrganizationSearchResDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.util.List;

/**
 * 岗位相关服务接口
 * date: 21/08/2019 16:02
 *
 * @author wgong
 * @since 0.0.1
 */
public interface StationService {

    /**
     * 根据岗位名称或岗位编码分页查询岗位数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    PaginationResponse<List<OrganizationSearchResDto>> getStationByPage(PaginationRequest<OrganizationSearchDto> paginationRequest);

    /**
     * 根据部门名称或部门编码分页查询部门数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    PaginationResponse<List<OrganizationSearchResDto>> getDepartmentByPage(PaginationRequest<OrganizationSearchDto> paginationRequest);

    /**
     * 根据单位名称或单位编码分页查询部门数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    PaginationResponse<List<OrganizationSearchResDto>> getUnitByPage(PaginationRequest<OrganizationSearchDto> paginationRequest);

    /**
     * 根据上级组织编号和类型查找组织
     * @param organizationQueryDto 组织查询传输实体
     */
    List<OrganizationDto> getOrganizationChild(OrganizationQueryDto organizationQueryDto);
}
