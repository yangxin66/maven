package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.common.utils.ValueGetTool;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.extension.sap.bean.RFC;
import com.deloitte.dhr.extension.sap.bean.parameter.ImportParameter;
import com.deloitte.dhr.extension.sap.service.SapService;
import com.deloitte.dhr.extension.sap.utils.ParameterConvert;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.ProcessInstanceTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.api.model.SearchStaffCategoryInfoDto;
import com.deloitte.dhr.hr.api.model.SendStaffEmailDTO;
import com.deloitte.dhr.hr.api.model.VerifyStaffInfoDTO;
import com.deloitte.dhr.hr.provider.config.HrUserConfig;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoApplyDao;
import com.deloitte.dhr.hr.provider.redis.CommonRedisRepository;
import com.deloitte.dhr.hr.provider.redis.RedisConstant;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.workflow.api.WfProcessApi;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.model.dto.ProcessInstanceDto;
import com.deloitte.workflow.api.model.dto.ProcessStartDto;
import com.deloitte.workflow.api.model.dto.TaskCandidateGroupDto;
import com.deloitte.workflow.api.model.dto.TaskNodeDto;
import com.mongodb.MongoClient;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <br/>27/08/2019 11:45
 *
 * @author lshao
 */
@Component
@Transactional(rollbackFor = Exception.class)
public class HrServiceImpl implements HrService {
    @Autowired
    MongoTemplate template;
    @Autowired
    private SapService sapService;
    @Autowired
    private WfProcessApi wfProcessApi;
    @Autowired
    private WfTaskApi wfTaskApi;
    @Autowired
    private CommonRedisRepository redisService;

    @Autowired
    private PlatformTransactionManager dataSourceTransactionManager;

    @Autowired
    MongoClient mongoClient;

    @Autowired
    private HrUserConfig hrUserConfig;

    @Autowired
    private BussniessNoGeneratorService bussniessNoGeneratorService;

    @Autowired
    private BaseMongoService baseMongoService;

    @Autowired
    private AuditNodeService auditNodeService;

    @Autowired
    StaffInfoApplyDao staffInfoApplyDao;

    @Autowired
    private FlowTraceService flowTraceService;

//    @Autowired
//    ClientSessionOptions options;

    @Override
    public Response<String> save(Request<PageDataRequest> request) {
        long businessId = System.currentTimeMillis();
        PageDataRequest dataRequest = request.getData();
        dataRequest.setBusinessId(businessId + "");
        LocalDateTime now = LocalDateTime.now();
        dataRequest.setOptionTime(now);
        //HARDCODE
        JSONObject data = dataRequest.getData();
        Map _base = (Map) data.get("_BASE");
        _base.put("PERNR", businessId + "");
        data.put("_BASE", _base);
        //保存到sap
        ImportParameter ip = ParameterConvert.convert(dataRequest.getData(), RFC.ZFM_PA_HIRE_BASIC);
//        JSONObject jsonObject = sapService.call(ip);
//        Exports export = sapService.getExports(jsonObject, Exports.class);
//        if (!StringUtils.equals(export.getSubrc(), Constants.E_SUBRC_S)) {
//            return new Response<>(request.getLanguage(), RemoteMateInfo.SAP_INVOKE_ERR.getCode(), export.getMessage(), null);
//        }
        //保存员工信息到mongo
        template.save(JSONObject.toJSON(dataRequest), HRCollection.HR_STAFF_INFO);

        //  添加申请信息数据到表中
        Map<String, Object> reqData = new HashMap<>();
        String applyNo = bussniessNoGeneratorService.getNewBussniessNo(SubtypeEnum.CREATE_STAFF.getAutoNoPrefix());
        reqData.put("_APPLY_NO", applyNo);
        reqData.put("_APPLY_TIME", Instant.now().toString());
        reqData.put("_APPLY_STATUS", ApproveStatusEnum.APPROVAL_PENDING);
        reqData.put("_APPLY_TYPE", ManagementTypeEnum.CREATE_STAFF.name());
        reqData.put("_APPLY_SUB_TYPE", SubtypeEnum.CREATE_STAFF.name());
        reqData.put("_SEND_EMAIL_NUM", 0);
        // 设置员工相关信息
        reqData.put("_NAME", (String)_base.get("NACHN") + _base.get("ENAME"));
        reqData.put("NACHN", _base.get("NACHN"));
        reqData.put("ENAME", _base.get("ENAME"));
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        reqData.put("_APPLICANT_ID", currentLoginUserInfo.getStaffNo());
        reqData.put("_DEPARTMENT_ID", currentLoginUserInfo.getDepartmentId());
        reqData.put("_DEPARTMENT_NAME", currentLoginUserInfo.getDepartmentName());
        reqData.put("_APPLICANT_NAME", currentLoginUserInfo.getStaffName());
        reqData.put("_BUSINESSID", businessId);
        reqData.put("_OPTIONTIME", now.toString());
        reqData.put("_REASON", "新员工入职申请");
        reqData.put("DHRSFZH", _base.get("DHRSFZH"));
        reqData.put("_IS_MY_APPLICATION", "0");
        baseMongoService.save(JSONObject.toJSONString(reqData), HRCollection.HR_STAFF_UPDATE_APPLY);


        //启动流程引擎
        ProcessStartDto processStartDto = new ProcessStartDto();
        //HARDCODE
        processStartDto.setKey(ProcessInstanceTypeEnum.NEW_STAFF.getKey());
        Map<String, Object> parmaeter = new HashMap<>();
        parmaeter.put("instanceType", ManagementTypeEnum.CREATE_STAFF.name());
//        parmaeter.put("staffId", businessId);
        processStartDto.setVariables(parmaeter);
        Response<ProcessInstanceDto> wfResonse = wfProcessApi.start(new Request<>(processStartDto));

        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        Update update = new Update();
        update.set("_PROCESS_INSTANCE_ID", wfResonse.getData().getId());
        baseMongoService.updateAndFlush(query, update, HRCollection.HR_STAFF_UPDATE_APPLY);

        ProcessInstanceDto processInstanceDto = wfResonse.getData();
        List<TaskNodeDto> taskList = processInstanceDto.getTaskNodes();
//        List<TaskCandidateGroupDto> taskCandidateGroupList = new ArrayList<>();
//        taskList.forEach(taskNodeDto -> {
//            // TODO 分配者需要修改
//            List<String> currentLoginUserRoleCodes = Collections.singletonList(HrStaffServiceImpl.hrRoleId);
//            List<TaskCandidateGroupDto> taskCandidateGroupDtos = currentLoginUserRoleCodes.stream().map(roleCode -> new TaskCandidateGroupDto(taskNodeDto.getTaskId(), roleCode)).collect(Collectors.toList());
//            taskCandidateGroupList.addAll(taskCandidateGroupDtos);
//        });
//        Response<Object> response = wfTaskApi.addCandidateGroup(new Request<>(taskCandidateGroupList));
//        if (!response.successful()) {
//            throw new BusinessException(response.getCode(), response.getMessage());
//        }
//        auditNodeService.addNextTaskNode(taskList, applyNo, ApproveStatusEnum.APPROVAL_PENDING.name());

        auditNodeService.addNextTaskNode(taskList, applyNo, ApproveStatusEnum.PRE_SUBMIT.name(), null, null, null);
        taskList.forEach(tmp -> {
            AuditHandlerDto auditHandlerDto = new AuditHandlerDto();
            auditHandlerDto.setProcessInstantId(wfResonse.getData().getId());
//            auditHandlerDto.setRemark("提交申请");
            auditHandlerDto.setTaskId(tmp.getTaskId());
            auditHandlerDto.setApplicationStatusEnum(ApplicationStatusEnum.SUBMITTED);
            auditHandlerDto.setSubtypeEnum(SubtypeEnum.CREATE_STAFF);
            Request<List<AuditHandlerDto>> flowNodeHanderReq = new Request<>(Collections.singletonList(auditHandlerDto));
            flowTraceService.flowNodeHandler(flowNodeHanderReq);
        });



        // 保存数据后需要添加是否发送邮件数据
//        StaffEmailPo po = new StaffEmailPo();
//        po.setSendFlag(false);
//        po.setBusinessId("" + businessId);
//        po.setOwner(ContextSession.getStaffNoFromJwt());
//        saveSendStaffEmail(po);


        // 新建员工注册用户
        String mobile = ValueGetTool.getStringFromJsonByKey(data,"_CONTACT.CELL");
        String email = ValueGetTool.getStringFromJsonByKey(data,"_CONTACT.EMAIL");
        registerDhrUser(mobile,email,String.valueOf(businessId));

        return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, applyNo);
    }

    @Override
    public void choiceSendStaffEmail(SendStaffEmailDTO requestDTO) {
        if (requestDTO.getSendFlag()) {
            staffInfoApplyDao.updateCreateStaffSendEmailNum(requestDTO.getApplyNo());
        }

//        StaffEmailPo po;
//        List<StaffEmailPo> staffEmailPos = template.find(Query.query(Criteria.where("businessId").is(requestDTO.getApplyNo())), StaffEmailPo.class);
//        if (staffEmailPos.size() != 0) {
//            po = staffEmailPos.get(0);
//            po.setSendFlag(requestDTO.getSendFlag());
//        } else {
//            Boolean sendFlag = requestDTO.getSendFlag();
//            String businessId = requestDTO.getBusinessId();
//            po = new StaffEmailPo();
//            po.setBusinessId(businessId);
//            po.setSendFlag(sendFlag);
//            po.setOwner(ContextSession.getStaffNoFromJwt());
//        }
//        saveSendStaffEmail(po);
    }

    private void registerDhrUser(String mobile,String email,String staffNo){
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        //MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();
        Map<String,Object> paramMap = new HashMap<>();
        paramMap.put("mobile", mobile);
        paramMap.put("email", email);
        paramMap.put("staffNo", staffNo);
        paramMap.put("password",staffNo);
        Map<String,Object> requestMap = new HashMap<>();
        requestMap.put("data",paramMap);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestMap, headers);

        ResponseEntity<Response> resp = restTemplate.postForEntity(hrUserConfig.getRegisterUrl(), entity, Response.class);
        if (resp.getStatusCode() != null && resp.getStatusCode().value() == 200) {
            if (resp.getBody() == null || !Response.SUCCESS_CODE.equals(resp.getBody().getCode())){
                throw new BusinessException(HRMateInfo.STAFF_INFO_REGISTER_USER_ERR.getCode(),HRMateInfo.STAFF_INFO_REGISTER_USER_ERR.getMessage());
            }
        }else {
            throw new BusinessException(HRMateInfo.STAFF_INFO_REGISTER_USER_ERR.getCode(),HRMateInfo.STAFF_INFO_REGISTER_USER_ERR.getMessage());
        }
    }

//    public void saveSendStaffEmail(StaffEmailPo po) {
//        template.save(po);
//        //如果为true，则立即向员工发送入职填报邮件
//        if (po.getSendFlag()) {
//            hrNotificationService.doCommingInSendMail(Collections.singletonList(po.getBusinessId()));
//        }
//
//    }

    @Override
    public Response<String> verifyStaffInfo(Request<VerifyStaffInfoDTO> request) {
        VerifyStaffInfoDTO verifyStaffInfoDTO = request.getData();
        ValidationServiceImpl.validate(verifyStaffInfoDTO);
        //HARDCODE

        //1.姓名、身份证从sap获取到对应用户的数据
        String sapStaffNo = "";
        //2.将token从redis获取人员编号与sap数据编号进行匹配
        String cacheStaffNo = (String) redisService.get(RedisConstant.EMAIL_STAFF_VERIFY_TOKEN + verifyStaffInfoDTO.getToken());
        if (StringUtils.equals(verifyStaffInfoDTO.getName(), "张三") && StringUtils.equals(verifyStaffInfoDTO.getCard(), "500107199211111111")) {
            return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, cacheStaffNo);
        }
        return new Response<>(request.getLanguage(), HRMateInfo.VERIFY_UNKNOW_ERR.getCode(), HRMateInfo.VERIFY_UNKNOW_ERR.getMessage(), null);
    }


    /**
     * 将员工修改信息同步到SAP中
     *
     * @param staffInfo
     * @return
     */
    @Override
    public Response<Void> updateStaffInfoByHr(JSONObject staffInfo){
        // todo liuchun 需SAP提供修改接口，将员工信息同步修改到SAP

        return null;
    }

    @Override
    public JSONObject searchStaffCategoryInfo(SearchStaffCategoryInfoDto dto) {
        // TODO: lshao 需要sap提供分类历史信息的条件搜索，并且带有分页的功能
        Object resultJSON = null;
       switch (dto.getCategory()){
           case "_EDUCATION":
               String result = "{\"_EDUCATION\":[{\"_OP\":\"\",\"PERNR\":\"00000423\",\"BEGDA\":\"1994-01-15\",\"ENDDA\":\"1994-01-15\",\"INSTI\":\"院校/培训机构\",\"ZZSXZY\":\"所学专业\",\"ZZXLLX\":\"学历类型\",\"SLABS\":\"学位\",\"ZZSFZGXL\":\"是否最高学历\",\"ZZSFZGXW\":\"是否最高学位\",\"AUSBI\":\"受教育形式\",\"XUELI\":{\"data\":{\"value\":{\"attachtype\":\"file\",\"value\":{\"PENER\":\"员工编号\",\"CODE\":\"附件唯一标识\"}}}},\"XUEWEI\":{\"data\":{\"value\":{\"attachtype\":\"file\",\"value\":{\"PENER\":\"员工编号\",\"CODE\":\"附件唯一标识\"}}}}},{\"_OP\":\"\",\"PERNR\":\"00000423\",\"BEGDA\":\"1992-01-15\",\"ENDDA\":\"1992-01-15\",\"INSTI\":\"院校/培训机构22\",\"ZZSXZY\":\"所学专业22\",\"ZZXLLX\":\"学历类型22\",\"SLABS\":\"学位\",\"ZZSFZGXL\":\"是否最高学历\",\"ZZSFZGXW\":\"是否最高学位\",\"AUSBI\":\"受教育形式\",\"XUELI\":{\"data\":{\"value\":{\"attachtype\":\"file\",\"value\":{\"PENER\":\"员工编号\",\"CODE\":\"附件唯一标识\"}}}},\"XUEWEI\":{\"data\":{\"value\":{\"attachtype\":\"file\",\"value\":{\"PENER\":\"员工编号\",\"CODE\":\"附件唯一标识\"}}}}}]}";
               resultJSON = JSONObject.parse(result);
               break;
           case "_PARTY":
               String result2 = "{\"_PARTY\":[{\"_OP\":\"\",\"PERNR\":\"00000423\",\"INFTY\":\"01\",\"BEGDA\":\"1994-01-15\",\"ENDDA\":\"1994-01-15\",\"JOINU\":\"XXX公司\"}]}";
               resultJSON = JSONObject.parse(result2);
           break;
       }
        return (JSONObject)resultJSON;
    }
}
