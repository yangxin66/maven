package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.QueryApplyUploadDto;
import com.deloitte.dhr.hr.api.model.staff.StaffNoDto;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface MockService {


    Response<Map> queryUploadEstimate(String staffNo);

    PaginationResponse<Map<String, Object>> queryUploadApplyData(PaginationRequest<QueryApplyUploadDto> request,Boolean type);

    Response<List> queryApplyStaffInfo(String staffNo);

    PaginationResponse<List> queryConcurrentPost(PaginationRequest<StaffNoDto> request);

    void downloadExcel(SubtypeEnum subtypeEnum) throws IOException;
}
