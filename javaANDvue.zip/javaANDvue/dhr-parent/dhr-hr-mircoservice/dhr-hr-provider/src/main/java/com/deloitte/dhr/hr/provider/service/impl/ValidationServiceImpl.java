package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.infrastructure.ex.BusinessException;
import org.hibernate.validator.HibernateValidator;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.util.Set;

/**
 * <br/>28/08/2019 17:10
 *
 * @author lshao
 */
public class ValidationServiceImpl {

    /**
     * 使用hibernate的注解来进行验证
     */
    private static Validator validator = Validation
            .byProvider(HibernateValidator.class).configure().failFast(true).buildValidatorFactory().getValidator();

    /**
     * 功能描述: <br>
     * 〈注解验证参数〉
     *
     * @param obj
     */
    public static <T> void validate(T obj) {
        Set<ConstraintViolation<T>> constraintViolations = validator.validate(obj);
        // 抛出检验异常
        if (constraintViolations.size() > 0) {
            throw new BusinessException(HRMateInfo.VERIFY_PARAMETER_ERR.getCode(), String.format(constraintViolations.iterator().next().getMessage()));
        }
    }
}
