package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.EnumResult;

import java.util.List;

/**
 * @author chunliucq
 * @since 30/08/2019 17:06
 */
public interface EnumService {
    /**
     * 查询枚举对象
     * @param keyList
     * @return
     */
    EnumResult queryEnumInfo(List<String> keyList);
}
