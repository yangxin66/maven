package com.deloitte.dhr.hr.provider.strategy;

import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.dhr.hr.provider.service.TaskNodeHandlerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 合同管理流程节点相关处理
 * date: 15/10/2019 9:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class ContractStrategy implements Strategy {

    @Autowired
    private TaskNodeHandlerService taskNodeHandlerService;


    @Autowired
    HrNotificationService hrNotificationService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public boolean nodeHandler(AuditHandlerDto auditHandlerDto, String staffId,
                               String applyNo) {
        boolean ended = taskNodeHandlerService.commonFlowNodeHandler(auditHandlerDto);
        // TODO 可能需要将临时数据需要修改为正式数据
        if (ended) {
            if (SubtypeEnum.START_CONTRACT == auditHandlerDto.getSubtypeEnum()) {
                // 发起合同审批完后的操作
                startContractApprovedHandler(applyNo);
            } else if (SubtypeEnum.EXTEND_CONTRACT == auditHandlerDto.getSubtypeEnum()) {
                // 续签合同审批完后的操作
                extendContractApprovedHandler(applyNo);
            } else if (SubtypeEnum.END_CONTRACT == auditHandlerDto.getSubtypeEnum()) {
                // 终止合同审批完后的操作
                endAndpostApprovedHandler(staffId);
            }

        }
        return ended;
    }

    @Override
    public ManagementTypeEnum getManagementType() {
        return ManagementTypeEnum.CONTRACT_MANAGEMENT;
    }

    /**
     * 发起合同审批通过后的操作
     *
     * @param applyNo 业务编号
     */
    private void startContractApprovedHandler(String applyNo) {
        // TODO 需要调用SAP的接口 添加发起合同信息
        // 业务数据
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_START_CONTRACT_DETAIL);

    }

    /**
     * 续签合同审批通过后的操作
     *
     * @param applyNo 业务编号
     */
    private void extendContractApprovedHandler(String applyNo) {
        // TODO 需要调用SAP的接口 添加结束合同信息
        // 业务数据
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_EXTEND_CONTRACT_DETAIL);

    }

    /**
     * 结束合同审批通过后的操作
     *
     * @param applyNo 业务编号
     */
    private void endAndpostApprovedHandler(String applyNo) {
        // TODO 需要调用SAP的接口 添加结束合同信息
        // 业务数据
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_END_CONTRACT_DETAIL);

    }

}
