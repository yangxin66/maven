package com.deloitte.dhr.hr.provider.mongo.dao;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.infrastructure.ex.BusinessException;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

/**
 * @author chunliucq
 * @since 29/08/2019 11:10
 */
@Repository
public class StaffInfoCheckDao extends BaseSimpleMongoDao {

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 员工编号字段
     */
    private static String Staff_NO_KEY = "_BUSINESSID";

    /**
     * 根据员工编号查询员工信息填写校验结果表
     * @param staffNo
     * @return
     */
    public Document queryStaffInfoCheckListByStaffNo(String staffNo){
        Query query = new Query();
        query.addCriteria(Criteria.where(Staff_NO_KEY).is(staffNo));
        Document document = mongoTemplate.findOne(query, Document.class, HRCollection.HR_STAFF_INFO_CHECK);
        return document;
    }
}
