package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.hr.api.StationRestInterface;
import com.deloitte.dhr.hr.api.model.OrganizationSearchDto;
import com.deloitte.dhr.hr.api.model.OrganizationDto;
import com.deloitte.dhr.hr.api.model.OrganizationQueryDto;
import com.deloitte.dhr.hr.api.model.OrganizationSearchResDto;
import com.deloitte.dhr.hr.provider.service.StationService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * date: 21/08/2019 15:58
 *
 * @author wgong
 * @since 0.0.1
 */
@RestController
@RequestMapping(value = "/api/v1/hr/organizations", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
@Api(value = "组织相关API", tags = {"OrganizationApi"}, produces = MediaType.APPLICATION_JSON_VALUE)
public class StationRestController implements StationRestInterface {

    @Autowired
    StationService stationService;

    /**
     * 根据岗位名称或岗位编码分页查询岗位数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @Override
    @PostMapping("/stations/page")
    @ApiOperation("根据岗位名称或岗位编号分页查询岗位")
    @ApiImplicitParam(name = "paginationRequest", value = "分页查询岗位实体", required = true, dataType = "PaginationRequest«OrganizationSearchDto»")
    public PaginationResponse<List<OrganizationSearchResDto>> getStationByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest) {
        return stationService.getStationByPage(paginationRequest);
    }

    /**
     * 根据部门名称或部门编码分页查询部门数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @Override
    @PostMapping("/departments/page")
    @ApiOperation("根据部门名称或部门编号分页查询岗位")
    @ApiImplicitParam(name = "paginationRequest", value = "分页查询岗位实体", required = true, dataType = "PaginationRequest«OrganizationSearchDto»")
    public PaginationResponse<List<OrganizationSearchResDto>> getDepartmentByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest) {
        return stationService.getDepartmentByPage(paginationRequest);
    }

    @Override
    @PostMapping("/unit/page")
    @ApiOperation("根据单位名称或单位编号分页查询岗位")
    @ApiImplicitParam(name = "paginationRequest", value = "分页查询岗位实体", required = true, dataType = "PaginationRequest«OrganizationSearchDto»")
    public PaginationResponse<List<OrganizationSearchResDto>> getUnitByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest) {
        return stationService.getUnitByPage(paginationRequest);
    }

    /**
     * 根据上级组织编号和类型查找组织
     *
     * @param organizationQueryDtoRequest 查询参数传输实体
     */
    @Override
    @PostMapping("/child")
    @ApiOperation("根据上级组织编号和类型查找组织")
    @ApiImplicitParam(name = "organizationQueryDtoRequest", value = "岗位名称或岗位编号查询实体", required = true, dataType = "Request«OrganizationQueryDto»")
    public Response<List<OrganizationDto>> getOrganizationChild(@RequestBody Request<OrganizationQueryDto> organizationQueryDtoRequest) {
        return new Response<>(organizationQueryDtoRequest.getLanguage(),
                "OK", "查询成功", stationService.getOrganizationChild(organizationQueryDtoRequest.getData()));
    }



}
