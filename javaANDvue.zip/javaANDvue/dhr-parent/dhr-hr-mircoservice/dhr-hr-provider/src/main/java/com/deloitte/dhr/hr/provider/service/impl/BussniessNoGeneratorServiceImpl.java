package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.common.constant.CommonStringConstant;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.provider.mongo.dao.BusnissNoGeneratorDao;
import com.deloitte.dhr.hr.provider.mongo.dao.model.BusinessNoGeneratorPo;
import com.deloitte.dhr.hr.provider.mongo.dao.model.BusinessNoRule;
import com.deloitte.dhr.hr.provider.service.BussniessNoGeneratorService;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author chunliucq
 * @since 04/09/2019 20:40
 */
@Service
public class BussniessNoGeneratorServiceImpl implements BussniessNoGeneratorService {

    @Autowired
    private BusnissNoGeneratorDao busnissNoGeneratorDao;

    private Pattern ptn = Pattern.compile("\\{( |%|:|\\w)+\\}");

    @Override
    public String getNewBussniessNo(String key){
        BusinessNoGeneratorPo po = busnissNoGeneratorDao.queryGeneratorRuleByKey(key);
        if (po == null){
            po = new BusinessNoGeneratorPo();
            po.setKey(key);
            BusinessNoRule rule = createDefaultRule();
            po.setRule(rule);
            busnissNoGeneratorDao.save(po, HRCollection.HR_BUSNISS_NO);
        }
        BusinessNoRule rule = po.getRule();
        String result = parsePattern(rule);
        busnissNoGeneratorDao.updateGeneratorRule(po);
        return result;
    }

    @Override
    public String getNewBussniessNo(SubtypeEnum subtypeEnum) {
        String key = CommonStringConstant.BUSINESSNO_APPLY_KEY + "_" + subtypeEnum.getAutoNoPrefix();
        BusinessNoGeneratorPo po = busnissNoGeneratorDao.queryGeneratorRuleByKey(key);
        if (po == null){
            po = new BusinessNoGeneratorPo();
            po.setKey(key);
            BusinessNoRule rule = createDefaultRule(subtypeEnum);
            po.setRule(rule);
            busnissNoGeneratorDao.save(po, HRCollection.HR_BUSNISS_NO);
        }
        BusinessNoRule rule = po.getRule();
        String result = parsePattern(rule);
        busnissNoGeneratorDao.updateGeneratorRule(po);
        return result;
    }

    private String parsePattern(BusinessNoRule rule) {
        StringBuffer sb = new StringBuffer();
        Matcher m = ptn.matcher(rule.getPattern().trim());
        while (m.find()) {
            String tempParam = m.group();
            String keyStr = tempParam.substring(1, tempParam.length() - 1);
            String parsedStr = parseParams(keyStr, rule);
            m.appendReplacement(sb, parsedStr);
        }
        return sb.toString();
    }

    private String parseParams(String param,BusinessNoRule rule){
        String[] paramSplit = param.split(":");
        String prefix = paramSplit[0].toString();
        String surfix = paramSplit[1].toString();

        if ("%d".equalsIgnoreCase(prefix)){
            // 日期时间转换
            String dateStr = DateFormatUtils.format(new Date(),surfix);
            return dateStr;
        }
        if ("%rand".equalsIgnoreCase(prefix)){
            int len = Integer.parseInt(surfix);
            return randNumStr(len);
        }
        if ("%seq".equalsIgnoreCase(prefix)){
            int len = Integer.parseInt(surfix);
            return generSeq(len,rule);
        }
        return null;
    }

    private synchronized String randNumStr(int num){
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < num ; i++){
            int rd = random.nextInt(10);
            sb.append(rd);
        }
        return sb.toString();
    }

    private String generSeq(int len,BusinessNoRule rule){
        Long step = rule.getStep();
        Long index = rule.getIndex();
        Long start = rule.getStart();
        StringBuffer sb = new StringBuffer();
        if(start == null){
            start = 0L;
        }
        if (index == null){
            index = start;
        }
        if (step == null){
            step = 1L;
        }

        String curDateStr = DateFormatUtils.format(new Date(),"yyyyMMdd");
        if (curDateStr.compareTo(rule.getDate()) > 0){
            index = 0L;
            rule.setDate(curDateStr);
        }

        index = index + step;
        rule.setIndex(index);
        sb.append(index);
        if (sb.length() < len){
            for (int i = 0; i < len - sb.length() ; i++){
                sb.insert(0,"0");
            }
        }
        return sb.toString();
    }

    private BusinessNoRule createDefaultRule(){
        BusinessNoRule rule = new BusinessNoRule();
        rule.setPattern("{%rand:2}{%d:yyyyMMddHHmmss}{%rand:2}{%seq:5}");
        rule.setIndex(0L);
        rule.setStep(1L);
        rule.setStart(0L);
        rule.setDate(DateFormatUtils.format(new Date(),"yyyyMMdd"));
        return rule;
    }

    private BusinessNoRule createDefaultRule(SubtypeEnum subtypeEnum){
        BusinessNoRule rule = new BusinessNoRule();
        rule.setPattern(subtypeEnum.getAutoNoPrefix() + "{%d:yyyyMMddHHmmss}{%rand:2}{%seq:5}");
        rule.setIndex(0L);
        rule.setStep(1L);
        rule.setStart(0L);
        rule.setDate(DateFormatUtils.format(new Date(),"yyyyMMdd"));
        return rule;
    }

}
