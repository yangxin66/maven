package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;

import java.util.List;

/**
 * 流程节点信息相关服务接口
 * date: 21/08/2019 16:02
 *
 * @author wgong
 * @since 0.0.1
 */
public interface FlowTraceService {

    /**
     * 根根据流程实例id查询流程节点信息
     *
     */
    Response<FlowTraceLogDto> getStaffInfoModifyFlowTraceLogDetail(Request<String> request);


    /**
     * 流程节点处理
     *
     * @param request 流程节点处理传输实体
     */
    void flowNodeHandler(Request<List<AuditHandlerDto>> request);
}
