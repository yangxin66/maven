package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApplyPartEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.export.ExcelExportImpl;
import com.deloitte.dhr.common.export.model.ExportTitle;
import com.deloitte.dhr.common.export.model.SheetList;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.ExcelExportService;
import com.deloitte.dhr.hr.provider.service.HrStaffService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.ex.BusinessException;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;

@Service
@Transactional(rollbackFor = Exception.class)
public class ExcelExportServiceImpl implements ExcelExportService {

    @Autowired
    HrStaffService hrStaffService;

    ExcelExportImpl excelExport = new ExcelExportImpl();

    private RestTemplate restTemplate = new RestTemplate();

    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;

    @Autowired
    StaffInfoDao staffInfoDao;


    @Override
    public void ExcelOutExport(HttpServletResponse response, ExcelOutExprotDto excelOutExprotDto) throws IOException, ParseException {
        String filename = "信息";

        //是否发送邮件
        List<Boolean> sendFlags = new ArrayList<>();

        if (excelOutExprotDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            filename = "待办审核" + filename;
        } else {
            filename = "已审核" + filename;
        }
        List<ExportTitle> title = excelOutExprotDto.getTitle();
        String outType = excelOutExprotDto.getOutType().name();
        SearchDto searchDto = excelOutExprotDto.getSearchDto();
        List<String> staffNoList = excelOutExprotDto.getStaffListDto().getStaffNoList();
        List<SheetList> sheetLists = new ArrayList<>();
        SheetList sheetList = new SheetList();
        sheetLists.add(sheetList);
        sheetList.setSheetName("工作表一");
        sheetList.setTitle(title);
        JSONArray data2 = new JSONArray();

        //批量导出
        if (outType.equals(OutExportType.BATCH_EXPORT.toString())) {
            List<StaffInfoStatus> staffInfoStatusList = hrStaffService.getEmployJsonObjectListFromStaffIds(staffNoList);
            getExcelData(sendFlags, data2, staffInfoStatusList);
            filename = filename + "(选择名单)";
        }
        //全部导出
        if (outType.equals(OutExportType.ALL_EXPORTS.toString())) {

            Request<SearchDto> searchDtoRequest = new Request<>(searchDto);
            //查询数据
            List<StaffInfoStatus> staffInfoStatusList = hrStaffService.exportJsonObjects(searchDtoRequest);
            getExcelData(sendFlags, data2, staffInfoStatusList);
            filename = filename + "(全部名单)";
        }
        sheetList.setData(data2);
        sheetList.setSendFlags(sendFlags);
        excelExport.generateDoucmentSheets(response, sheetLists, filename);

    }

    /**
     * 批量导出数据
     * @param response
     * @param excelOutExportCurrencyBatchDto  导出数据的参数
     * @throws IOException
     * @throws ParseException
     */
    @Override
    public void ExcelOutExportCurrencyBatch(HttpServletResponse response, ExcelOutExportCurrencyBatchDto excelOutExportCurrencyBatchDto) throws IOException,
            ParseException {
        String filename = "信息";
        //获取表头数据
        List<ExportTitle> title = excelOutExportCurrencyBatchDto.getTitle();
        //获取导出数据的url
        String url = excelOutExportCurrencyBatchDto.getUrl();
        //数据的获取报文
        JSONObject data = excelOutExportCurrencyBatchDto.getData();
        String status = excelOutExportCurrencyBatchDto.getStatus();
        List<PageAndSize> pageAndSizeList = excelOutExportCurrencyBatchDto.getPageAndSizeList();
        //勾选的唯一字段的名称
        String name = excelOutExportCurrencyBatchDto.getName();
        List<SheetList> sheetLists = new ArrayList<>();
        SheetList sheetList = new SheetList();
        sheetLists.add(sheetList);
        JSONArray applyData = new JSONArray();
        sheetList.setSheetName("工作表一");
        sheetList.setTitle(title);
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Enumeration headerNames = request.getHeaderNames();
        HttpHeaders headers = new HttpHeaders();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            headers.set(key, value);
        }
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        //上传文件是导出错误信息
        if (!status.isEmpty()) {
            int page = 1;
            data.put("page", page);
            data.put("size", 100);
            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(data, headers);
            SimpleClientHttpRequestFactory sf = new SimpleClientHttpRequestFactory();
            sf.setConnectTimeout(20000);
            sf.setReadTimeout(1000 * 60);
            restTemplate.setRequestFactory(sf);
            //模拟访问接口
            ResponseEntity<Map> resp = restTemplate.postForEntity(url, entity, Map.class);
            if (resp != null && resp.getStatusCode().value() / 100 == 2) {
                Map map = resp.getBody();
                int total = Integer.parseInt((String) map.get("total"));
                int num = total / 100;
                if (num > 1) {
                    while (num > 0) {
                        data.put("page", page + 1);
                        resp = restTemplate.postForEntity(url, entity, Map.class);
                        if (resp != null && resp.getStatusCode().value() / 100 == 2) {
                            //对返回的数据进行处理
                            map = resp.getBody();
                            Object obj = map.get("data");
                            List<Map> roleListMap = (List<Map>) obj;
                            if (!CollectionUtils.isEmpty(roleListMap)) {
                                int k = roleListMap.size();
                                for (int n = 0; n < k; n++) {
                                    applyData.add(roleListMap.get(n));
                                }
                            }
                        }
                        num--;
                    }
                } else {
                    Object obj = map.get("data");
                    List<Map> roleListMap = null;
                    if (obj instanceof List) {
                        roleListMap = (List<Map>) obj;
                    } else if (obj instanceof Map) {
                        Map map1 = (Map) obj;
                        roleListMap = (List<Map>) map1.get("data");
                    }
                    if (!CollectionUtils.isEmpty(roleListMap)) {
                        int k = roleListMap.size();
                        for (int n = 0; n < k; n++) {
                            Map map1 = roleListMap.get(n);
                            if (map1.get("UPLOAD_STATUS").toString().equals("false")) {
                                applyData.add(roleListMap.get(n));
                            }
                        }
                    }
                    sheetList.setData(applyData);
                }
            }
        }else {
            //批量导出

            for (PageAndSize pageAndSize : pageAndSizeList) {
                Integer page = pageAndSize.getPage();
                List<String> idList = pageAndSize.getIdList();
                data.put("page", page);
                Integer size = (Integer) data.get("size");
                data.put("size", page * size);
                HttpEntity<Map<String, Object>> entity = new HttpEntity<>(data, headers);
                SimpleClientHttpRequestFactory sf = new SimpleClientHttpRequestFactory();
                sf.setConnectTimeout(20000);
                sf.setReadTimeout(1000 * 60);
                restTemplate.setRequestFactory(sf);
                ResponseEntity<Map> resp = restTemplate.postForEntity(url, entity, Map.class);
                if (resp != null && resp.getStatusCode().value() / 100 == 2) {
                    Map map = resp.getBody();
                    List<Map> roleListMap = null;
                    if (map instanceof List) {
                        roleListMap = (List<Map>) map;
                    } else {
                        Object obj = map.get("data");
                        roleListMap = (List<Map>) obj;
                    }
                    if (!CollectionUtils.isEmpty(roleListMap)) {
                        int k = roleListMap.size();
                        for (int n = 0; n < k; n++) {
                            Map map1 = roleListMap.get(n);
                            String id = (String) map1.get(name);
                            if (idList.contains(id)) {
                                applyData.add(roleListMap.get(n));
                            }
                        }
                        sheetList.setData(applyData);
                    }
                } else {
                    throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getCode(),
                            HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getMessage());
                }
            }
        }
        excelExport.generateDoucmentSheets(response, sheetLists, filename);
    }

    /**
     * 全部导出
     * @param response
     * @param excelOutExportCurrencyALLDto
     * @throws IOException
     * @throws ParseException
     */
    @Override
    public void ExcelOutExportCurrencyAll(HttpServletResponse response, ExcelOutExportCurrencyALLDto excelOutExportCurrencyALLDto) throws IOException, ParseException {
        String filename = "信息";
        //获取表头数据
        List<ExportTitle> title = excelOutExportCurrencyALLDto.getTitle();
        //获取导出数据的url
        String url = excelOutExportCurrencyALLDto.getUrl();
        //数据的获取报文
        JSONObject data = excelOutExportCurrencyALLDto.getData();
        List<Boolean> sendFlags= new ArrayList<>();
        List<SheetList> sheetLists = new ArrayList<>();
        JSONArray data2 = new JSONArray();
        SheetList sheetList = new SheetList();
        sheetList.setData(data2);
        sheetLists.add(sheetList);
        sheetList.setSheetName("工作表一");
        sheetList.setTitle(title);
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Enumeration headerNames = request.getHeaderNames();
        HttpHeaders headers = new HttpHeaders();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            headers.set(key, value);
        }
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        int page = 1;
        data.put("page", page);
        data.put("size", 100);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(data, headers);
        SimpleClientHttpRequestFactory sf = new SimpleClientHttpRequestFactory();
        sf.setConnectTimeout(20000);
        sf.setReadTimeout(1000 * 60);
        restTemplate.setRequestFactory(sf);
        //模拟数据访问接口
        ResponseEntity<Map> resp = restTemplate.postForEntity(url, entity, Map.class);
        if (resp != null && resp.getStatusCode().value() / 100 == 2) {
            Map map = resp.getBody();
            int total = Integer.parseInt((String) map.get("total"));
            int num = total / 100;
            if (num > 1) {
                while (num > 0) {
                    data.put("page", page + 1);
                    resp = restTemplate.postForEntity(url, entity, Map.class);
                    if (resp != null && resp.getStatusCode().value() / 100 == 2) {
                        map = resp.getBody();
                        Object obj = map.get("data");
                        List<Map> roleListMap = (List<Map>) obj;
                        if (!CollectionUtils.isEmpty(roleListMap)) {
                            int k = roleListMap.size();
                            for (int n = 0; n < k; n++) {
                                data2.add(roleListMap.get(n));
                            }

                        }
                    }
                    num--;
                }
            } else {
                Object obj = map.get("data");
                List<Map> roleListMap = null;
                if (obj instanceof List) {
                    roleListMap = (List<Map>) obj;
                } else if (obj instanceof Map) {
                    Map map1 = (Map) obj;
                    roleListMap = (List<Map>) map1.get("data");
                }
                if (!CollectionUtils.isEmpty(roleListMap)) {
                    int k = roleListMap.size();
                    for (int n = 0; n < k; n++) {
                        data2.add(roleListMap.get(n));
                    }
                }
            }
        } else {
            throw new BusinessException(HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getCode(),
                    HRMateInfo.STAFF_LOGIN_QUERY_ROLE_ERR.getMessage());
        }

        excelExport.generateDoucmentSheets(response, sheetLists, filename);
    }

    @Override
    public void ExcelAPPlyOutExport(HttpServletResponse response, ExcelApplyExportDto excelApplyExportDto) throws IOException, ParseException {
        SearchDto searchDto = excelApplyExportDto.getSearchDto();
        OutExportType outType = excelApplyExportDto.getOutType();
        List<ExportTitle> title = excelApplyExportDto.getTitle();
        List<String> applyNoList = excelApplyExportDto.getApplyNoList();
        List<SheetList> sheetLists = new ArrayList<>();
        SheetList sheetList = new SheetList();
        sheetLists.add(sheetList);
        sheetList.setSheetName("工作表一");
        sheetList.setTitle(title);
        String fileName = "申请记录";
        if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            fileName = "待办审核" + fileName;
        } else if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.COMPLETE_TASK.toString())) {
            fileName = "已审核" + fileName;
        } else {
            fileName = "进行中" + fileName;
        }
        JSONArray applyData = new JSONArray();
        if (outType.equals(OutExportType.BATCH_EXPORT)) {
            ApplySearchDto applySearchDto = new ApplySearchDto();
            applySearchDto.setApplyNoList(applyNoList);
            applySearchDto.setSearchDto(searchDto);
            List<Map> mapList = hrStaffService.ExportApplyMapFormApplyNoHr(applySearchDto);

            if (mapList == null || mapList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            int k = mapList.size();
            for (int i = 0; i < k; i++) {
                applyData.add(mapList.get(i));
            }
            sheetList.setData(applyData);
            fileName = fileName + "（选择数据）";
        } else {
            Request<SearchDto> searchDtoRequest = new Request<>(searchDto);
            List<Map> mapList = hrStaffService.ExportApplyMap(searchDtoRequest);
            if (mapList == null || mapList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            int k = mapList.size();
            for (int i = 0; i < k; i++) {
                applyData.add(mapList.get(i));
            }
            sheetList.setData(applyData);
            fileName = fileName + "（全部数据）";
        }
        excelExport.generateDoucmentSheets(response, sheetLists, fileName);

    }

    @Override
    public void ExcelAPPlyOutExportMy(HttpServletResponse response, ExcelApplyExportDto excelApplyExportDto) throws IOException, ParseException {
        SearchDto searchDto = excelApplyExportDto.getSearchDto();
        OutExportType outType = excelApplyExportDto.getOutType();
        List<ExportTitle> title = excelApplyExportDto.getTitle();
        List<String> applyNoList = excelApplyExportDto.getApplyNoList();
        List<SheetList> sheetLists = new ArrayList<>();
        SheetList sheetList = new SheetList();
        sheetLists.add(sheetList);
        sheetList.setSheetName("工作表一");
        sheetList.setTitle(title);
        String fileName = "申请记录";
        if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.UNCOMPLETE_TASK.toString())) {
            fileName = "待办审核" + fileName;
        } else if (excelApplyExportDto.getSearchDto().getType().toString().equals(SearchTypeEnum.COMPLETE_TASK.toString())) {
            fileName = "已审核" + fileName;
        } else {
            fileName = "进行中" + fileName;
        }
        JSONArray applyData = new JSONArray();
        if (outType.equals(OutExportType.BATCH_EXPORT)) {
            ApplySearchDto applySearchDto = new ApplySearchDto();
            applySearchDto.setApplyNoList(applyNoList);
            applySearchDto.setSearchDto(searchDto);
            List<Map> mapList = hrStaffService.ExportApplyMapFormApplyNoStaff(applySearchDto);
            if (mapList == null || mapList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            int k = mapList.size();
            for (int i = 0; i < k; i++) {
                applyData.add(mapList.get(i));
            }
            sheetList.setData(applyData);
            fileName = fileName + "（选择数据）";
        } else {
            Request<SearchDto> searchDtoRequest = new Request<>(searchDto);
            List<Map> mapList = hrStaffService.ExportApplyMyApplication(searchDtoRequest);
            if (mapList == null || mapList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            int k = mapList.size();
            for (int i = 0; i < k; i++) {
                applyData.add(mapList.get(i));
            }
            sheetList.setData(applyData);
            fileName = fileName + "（全部数据）";
        }
        excelExport.generateDoucmentSheets(response, sheetLists, fileName);

    }

    @Override
    public void ExcelAPPlyAuditOutExport(HttpServletResponse response, ExcelApplyDetailedDto excelApplyDetailedDto) throws IOException, ParseException {
        String fileName = "个人信息";
        OutExportType outType = excelApplyDetailedDto.getOutType();
        List<ApplyList> applyLists = excelApplyDetailedDto.getApplyList();
        List<ExportTitle> title = excelApplyDetailedDto.getTitle();
        String part = excelApplyDetailedDto.getPart();
        String value = ApplyPartEnum.valueOf(part).getValue();
        List<String> ridList = excelApplyDetailedDto.getRidList();
        fileName = fileName + value;
        String staffNo = excelApplyDetailedDto.getStaffNo();
        List<SheetList> sheetLists = new ArrayList<>();
        SheetList sheetList = new SheetList();
        sheetLists.add(sheetList);
        sheetList.setSheetName("工作表一");
        sheetList.setTitle(title);
        JSONArray applyData = new JSONArray();
        String s = staffInfoDao.queryStaffInfoByStaffNo(staffNo);
        JSONObject jsonObject = JSONObject.parseObject(s);
//        Document document = staffInfoCheckDao.queryStaffInfoCheckListByStaffNo(staffNo);
        if (outType.equals(OutExportType.BATCH_EXPORT)) {
            List<Document> documentList = staffApplyAlterDao.QueryApplyDetail(applyLists);
            if (documentList == null || documentList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            for (Document map : documentList) {
                map.putAll(jsonObject);
                applyData.add(map);
            }
            sheetList.setData(applyData);
            fileName = fileName + "（选择数据）";
        } else {
            List<Document> documentList = staffApplyAlterDao.QueryApplyAlter(staffNo, part);
            if (documentList == null || documentList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            List<String> applyList = new ArrayList<>();
            for (Document d : documentList) {
                String applyNo = d.getString("_APPLY_NO");
                applyList.add(applyNo);
            }
            List<Document> mapList = staffApplyAlterDao.ExcelByApplyNoAndRid(applyList, ridList);
            if (mapList == null || mapList.size() == 0) {
                throw new BusinessException(HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
            }
            int k = mapList.size();
            for (int i = 0; i < k; i++) {
                mapList.get(i).putAll(jsonObject);
                applyData.add(mapList.get(i));
            }
            sheetList.setData(applyData);
            fileName = fileName + "（全部数据）";
        }
        excelExport.generateDoucmentSheets(response, sheetLists, fileName);
    }

    private void getExcelData(List<Boolean> sendFlags, JSONArray data2, List<StaffInfoStatus> staffInfoStatusList) {
        if (staffInfoStatusList == null || staffInfoStatusList.size() == 0) {
            throw new BusinessException(HRMateInfo.DOWNLOAD_IS_NULL_IS_EMPTY_ERR.getCode(), HRMateInfo.DATA_NONULL_IS_EMPTY_ERR.getMessage());
        }
        for (int k = staffInfoStatusList.size() - 1; 0 <= k; k--) {
            Boolean sendFlag = staffInfoStatusList.get(k).isSendFlag();
            sendFlags.add(sendFlag);
            data2.add(staffInfoStatusList.get(k).getData());
        }
    }
}
