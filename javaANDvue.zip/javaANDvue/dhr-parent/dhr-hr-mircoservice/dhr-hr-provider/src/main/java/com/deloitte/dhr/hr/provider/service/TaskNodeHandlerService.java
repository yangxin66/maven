package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.AuditHandlerDto;

/**
 * date: 15/10/2019 9:29
 *
 * @author wgong
 * @since 0.0.1
 */
public interface TaskNodeHandlerService {

    /**
     * 通用的任务节点处理
     * @param auditHandlerDto
     * @return
     */
    boolean commonFlowNodeHandler(AuditHandlerDto auditHandlerDto);
}
