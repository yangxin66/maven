package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.UnposotiveSearchDto;
import com.deloitte.dhr.hr.api.model.UnposotiveStaffInfoDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.util.List;

/**
 * date: 12/10/2019 15:03
 *
 * @author wgong
 * @since 0.0.1
 */
public interface PositiveService {

    PaginationResponse<List<UnposotiveStaffInfoDto>> getUnPositiveStaffInfoByPage(PaginationRequest<UnposotiveSearchDto> request);

    List<String > getUnPositiveStaffInfoNos();
}
