package com.deloitte.dhr.hr.provider.service;

/**
 * @author chunliucq
 * @since 17/09/2019 16:13
 */
public class StaffUpdateApplyService {

}
