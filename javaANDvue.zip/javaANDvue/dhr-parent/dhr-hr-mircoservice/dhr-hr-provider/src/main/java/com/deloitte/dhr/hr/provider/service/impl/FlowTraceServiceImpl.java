package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.config.ApplyProcessEnum;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoApplyDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.mongo.dao.model.AuditNodePo;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.dhr.hr.provider.strategy.StrategyManagement;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.workflow.api.WfProcessApi;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.model.dto.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * date: 21/08/2019 16:13
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class FlowTraceServiceImpl implements FlowTraceService {


    @Autowired
    WfProcessApi wfProcessApi;

    @Autowired
    StaffInfoService staffInfoService;

    @Autowired
    AuditNodeService auditNodeService;

    @Autowired
    WfTaskApi wfTaskApi;

    @Autowired
    BaseMongoService baseMongoService;

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    StaffInfoApplyDao staffInfoApplyDao;

    @Autowired
    StrategyManagement strategyManagement;

    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;

    @Autowired
    CommonService commonService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    HrNotificationService hrNotificationService;


    /**
     * 根根据流程实例id查询流程节点信息
     *
     * @param request 含有实例id的请求参数
     */
    @Override
    public Response<FlowTraceLogDto> getStaffInfoModifyFlowTraceLogDetail(Request<String> request) {
        // 查询已完成的任务
        String processInstanceId = request.getData();
        List<AuditNodePo> completeTasks = auditNodeService.findCompleteTaskByProcessInstanceId(processInstanceId);
        List<AuditNodeDto> completeAuditNodeDtos = new ArrayList<>();
        List<AuditNodeDto> flowLogDetail = new ArrayList<>();
        if (completeTasks != null && completeTasks.size() != 0) {
            completeAuditNodeDtos = handleCompleteTaskNodeDto(completeTasks);
            flowLogDetail.addAll(completeAuditNodeDtos);
        }

        // 查询下一步未完成的任务
        List<AuditNodeDto> completeTaskAndNextUncompleteTask = null;
        List<AuditNodeDto> nextUncompleteTaskAuditNodeDtos;
        Response<ProcessInstanceDto> processInstanceDtoResponse = wfProcessApi.findInstanceByIdWhetherFinished(new Request<>(null), processInstanceId);
        if (!processInstanceDtoResponse.successful()) {
            throw new BusinessException(processInstanceDtoResponse.getCode(), processInstanceDtoResponse.getMessage());
        }
        ProcessInstanceDto processInstanceDto = processInstanceDtoResponse.getData();
        if (processInstanceDto != null) {
            // 有未完成的任务代表该流程还没有结束
            if (processInstanceDto.getTaskNodes() != null && processInstanceDto.getTaskNodes().size() != 0) {
                nextUncompleteTaskAuditNodeDtos = getNextUncompleteTask(processInstanceDto.getTaskNodes());
                // 如果有未完成的任务
                if (nextUncompleteTaskAuditNodeDtos != null && nextUncompleteTaskAuditNodeDtos.size() > 0) {
                    // 组装完成和和下一步未完成的状态
                    completeTaskAndNextUncompleteTask = new ArrayList<>();
                    completeTaskAndNextUncompleteTask.addAll(completeAuditNodeDtos);
                    completeTaskAndNextUncompleteTask.addAll(nextUncompleteTaskAuditNodeDtos);
                } else {
                    // 没有未完成的任务代表该流程结束了 需要单独添加流程end节点
                    AuditNodeDto endNode = getEndNode(processInstanceDto);
                    if (endNode != null && flowLogDetail.size() > 0) {
                        AuditNodeDto auditNodeDto = flowLogDetail.get(flowLogDetail.size() - 1);
                        endNode.setImgUrl(auditNodeDto.getImgUrl());
                        endNode.setAuditTime(auditNodeDto.getAuditTime());
                        endNode.setAuditorName(auditNodeDto.getAuditorName());
                    }
//                    endNode.setTaskName("系统写入完成");
                    // 给流程动态添加end节点 并加在最前面  因为流程动态是倒序展示
                    flowLogDetail.add(endNode);
                    // 流程动态需要反序展示
                    Collections.reverse(flowLogDetail);
                    // 给流程步骤添加end节点
                    completeTaskAndNextUncompleteTask = new ArrayList<>(1);
                    completeTaskAndNextUncompleteTask.addAll(completeAuditNodeDtos);
                    completeTaskAndNextUncompleteTask.add(endNode);
                }

            }
        } else {
            // 根据流程id没有找到相应的流程信息 则查出来的未完成任务为空
            completeTaskAndNextUncompleteTask = completeAuditNodeDtos;
        }

        FlowTraceLogDto flowTraceLogDto = FlowTraceLogDto.builder()
                .flowSteps(completeTaskAndNextUncompleteTask)
                .flowLogDetail(flowLogDetail)
                .build();
        return ResponseUtil.build().creatDeaultOkResponse(request.getLanguage(), flowTraceLogDto);
    }

    /**
     * 获取end节点
     *
     * @param processInstanceDto 流程信息
     */
    private AuditNodeDto getEndNode(ProcessInstanceDto processInstanceDto) {
        AuditNodeDto auditNodeDto = new AuditNodeDto();
        auditNodeDto.setCompleted(Boolean.TRUE);

        StaffInfoApplyDto staffInfoApplyDto = staffInfoApplyDao.queryStaffInfoByProcessInstantId(processInstanceDto.getId());
        if (staffInfoApplyDto != null) {
            if (ApproveStatusEnum.CLOSE.name().equals(staffInfoApplyDto.getStatus())) {
                auditNodeDto.setTaskName("流程已关闭");
                return auditNodeDto;
            }
        }
        List<TaskNodeDto> taskNodes = processInstanceDto.getTaskNodes();
        for (TaskNodeDto taskNode : taskNodes) {
            if (TaskNodeType.endEvent.equals(taskNode.getNodeType())) {
                if (StringUtils.isBlank(taskNode.getName())) {
                    auditNodeDto.setTaskName("系统写入成功");
                    return auditNodeDto;
                } else {
                    auditNodeDto.setTaskName(taskNode.getName());
                    return auditNodeDto;
                }
            }
        }
        return null;

    }

    /**
     * 处理已完成任务AuditNodePo 转成FlowTraceLogNodeDto类型
     *
     * @param auditNodePos 任务节点
     */
    private List<AuditNodeDto> handleCompleteTaskNodeDto(List<AuditNodePo> auditNodePos) {
        List<AuditNodeDto> flowTraceLogNodeDtos = new ArrayList<>();
        for (AuditNodePo auditNodePo : auditNodePos) {
            AuditNodeDto auditNodeDto = new AuditNodeDto();
            // 设置分配者
            auditNodeDto.setAuditorName(auditNodePo.getAuditorName());
            // 设置处理时间
            auditNodeDto.setAuditTime(auditNodePo.getAuditTime());
            // 设置备注
            auditNodeDto.setRemark(auditNodePo.getRemark());
            // 设置流程状态名称
            String statusName = (auditNodePo.getStatus() == null ? null : (ApproveStatusEnum.valueOf(auditNodePo.getStatus()).getValue()));
            auditNodeDto.setStatusName(statusName);
            // 设置任务名称
            auditNodeDto.setTaskName(auditNodePo.getTaskName());
            // 设置是否完成
            auditNodeDto.setCompleted(true);
            // 设置用户头像
            auditNodeDto.setImgUrl(auditNodePo.getImgUrl());
            flowTraceLogNodeDtos.add(auditNodeDto);
        }
        return flowTraceLogNodeDtos;
    }

    /**
     * 处理任务TaskNodeDto 转成FlowTraceLogNodeDto类型
     *
     * @param taskNodeDtos 流程实例下的已完成任务和下个未完成的任务
     */
    private List<AuditNodeDto> getNextUncompleteTask(List<TaskNodeDto> taskNodeDtos) {

        // 获取任务列表
        List<TaskNodeDto> uncompleteTasks = new ArrayList<>();
        taskNodeDtos.forEach(taskNodeDto -> {
            if (!taskNodeDto.getCompleted()) {
                uncompleteTasks.add(taskNodeDto);
            }
        });
        // 转换未完成任务集合
        List<AuditNodeDto> auditNodeDtos = new ArrayList<>();
        for (TaskNodeDto taskNodeDto : uncompleteTasks) {
            AuditNodeDto auditNodeDto = new AuditNodeDto();
            // 设置任务名称
            auditNodeDto.setTaskName(taskNodeDto.getName());
            // 设置是否完成
            auditNodeDto.setCompleted(false);
            auditNodeDtos.add(auditNodeDto);
        }
        return auditNodeDtos;
    }

    /**
     * 流程节点处理
     *
     * @param request 流程节点处理传输实体
     */
    @Override
    public void flowNodeHandler(Request<List<AuditHandlerDto>> request) {

        List<AuditHandlerDto> auditHandlerDtos = request.getData();
        List<String> staffIds = new ArrayList<>();
        List<String> applyNos = new ArrayList<>();
        if (auditHandlerDtos.size() != 0){
            auditHandlerDtos.forEach(auditHandlerDto -> {
                ManagementTypeEnum managementType = getTypeBySubType(auditHandlerDto.getSubtypeEnum());

                StaffInfoApplyDto staffInfoApplyDto = staffInfoApplyDao.queryStaffInfoByProcessInstantId(auditHandlerDto.getProcessInstantId());
                if (staffInfoApplyDto == null) {
                    throw new BusinessException(HRMateInfo.AUDIT_PARAMETER_APPLYNO_ERR.getCode(), HRMateInfo.AUDIT_PARAMETER_APPLYNO_ERR.getMessage());
                }
                String staffId = staffInfoApplyDto.getStaffId();
                String applyNo = staffInfoApplyDto.getApplyNo();
                String processInstantId = staffInfoApplyDto.getProcessInstanceId();
                // 如果是删除流程 跟任务无关  所以需要单独判断
                if (ApplicationStatusEnum.DELETE == auditHandlerDto.getApplicationStatusEnum()) {
                    if (processInstantId != null) {
                        Response<Object> response = wfProcessApi.deleteProcessInstanceById(processInstantId, new Request<>(null));
                        if (response.successful()) {
                            // 删除流程成功后 更新apply表中的数据
                            staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.DELETE.name(), true);
                        } else {
                            throw new BusinessException(response.getCode(), response.getMessage());
                        }
                    }
                } else {
                    // 如果是对任务进行操作 根据不同的类型调用不同的处理节点的方法
                    // 这里的员工编号需要注意：对于那种业务数据有员工编号的（多条员工信息）员工编号需要根据业务编号去各个业务的detail表里面去查 此时的staffId是空的
                    // 对于那种业务数据中没有员工编号（只针对一个员工进行处理） 员工编号在apply表中 也就是当前的staffId
                    boolean ended = strategyManagement.create(managementType).nodeHandler(auditHandlerDto, staffId, applyNo);
                    if (ended) {
                        staffIds.add(staffId);
                        applyNos.add(applyNo);
                    }
                }
            });
            // 处理批量发送邮件
            AuditHandlerDto auditHandlerDto = auditHandlerDtos.get(0);
            SubtypeEnum subtypeEnum = auditHandlerDto.getSubtypeEnum();
            ManagementTypeEnum managementType = getTypeBySubType(auditHandlerDto.getSubtypeEnum());
            if (subtypeEnum != null) {
                // 入职成功需要发送邮件 邮件是另外一个服务所以批量发送邮件效率会高一点
                if (staffIds.size() != 0 && applyNos.size() != 0) {
                    strategyManagement.create(managementType).batchSendEmail(staffIds);
                }
            }

        }



    }

    public ManagementTypeEnum getTypeBySubType(SubtypeEnum subtypeEnum){
        ApplyProcessEnum applyProcessEnum = ApplyProcessEnum.getByBusiType(subtypeEnum);
        if (applyProcessEnum == null){
            throw new BusinessException(HRMateInfo.BUSINESS_TYPE_IS_ERR.getCode(), HRMateInfo.BUSINESS_TYPE_IS_ERR.getMessage());
        }
        return applyProcessEnum.getIntanceType();
    }



//    /**
//     * 将完成的状态更新到申请表中
//     *
//     * @param applyNo 业务编码
//     * @param status  流程状态
//     */
//    private void updateStaffUpdateApplyStatus(String applyNo, String status, boolean ended) {
//        Query query = new Query();
//        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
//        List<Map> staffUpdateApplys = baseMongoService.queryOneForMapList(query, HRCollection.HR_STAFF_UPDATE_APPLY);
//        if (staffUpdateApplys == null || staffUpdateApplys.size() == 0) {
//            throw new BusinessException(HRMateInfo.STAFF_UPDATE_APPLY_NO_IS_ERR.getCode(), HRMateInfo.STAFF_UPDATE_APPLY_NO_IS_ERR.getMessage());
//        }
//        Update update = new Update();
//        update.set("_APPLY_STATUS", status);
//        if (ended) {
//            // TODO 加入登录后需要修改
//            update.set("_AUDIT_ID", ContextSession.getStaffNoFromJwt());
//            update.set("_AUDIT_NAME", ContextSession.getCurrentLoginUserInfo().getStaffName());
//            update.set("_AUDIT_TIME", Instant.now().toString());
//        }
//        baseMongoService.updateAndFlush(query, update, HRCollection.HR_STAFF_UPDATE_APPLY);
//    }



    private String getTaskName(String processInstantId, String taskId) {
        Response<ProcessInstanceDto> processInstanceDtoResponse = wfProcessApi.findInstanceByIdWhetherFinished(new Request<>(Boolean.FALSE), processInstantId);
        if (!processInstanceDtoResponse.successful()) {
            throw new BusinessException(processInstanceDtoResponse.getCode(), processInstanceDtoResponse.getMessage());
        }
        ProcessInstanceDto data = processInstanceDtoResponse.getData();
        if (data == null || data.getTaskNodes() == null || data.getTaskNodes().size() == 0) {
            throw new BusinessException(HRMateInfo.AUDIT_PARAMETER_INSTANT_ID_IS_ERR.getCode(), HRMateInfo.AUDIT_PARAMETER_INSTANT_ID_IS_ERR.getMessage());
        }
        List<TaskNodeDto> taskNodes = data.getTaskNodes();
        for (TaskNodeDto taskNode : taskNodes) {
            if (taskId.equals(taskNode.getTaskId())) {
                return taskNode.getName();
            }
        }
        throw new BusinessException(HRMateInfo.AUDIT_PARAMETER_INSTANT_ID_IS_ERR.getCode(), HRMateInfo.AUDIT_PARAMETER_INSTANT_ID_IS_ERR.getMessage());
    }

}
