package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.hr.api.model.UnposotiveSearchDto;
import com.deloitte.dhr.hr.api.model.UnposotiveStaffInfoDto;
import com.deloitte.dhr.hr.provider.service.PositiveService;
import com.deloitte.dhr.hr.provider.utils.PaginationUtils;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * date: 12/10/2019 15:03
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class PositiveServiceImpl implements PositiveService {

    @Override
    public PaginationResponse<List<UnposotiveStaffInfoDto>> getUnPositiveStaffInfoByPage(PaginationRequest<UnposotiveSearchDto> request) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(request.getPage(), request.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        List<String> staffNos = mockStaffNos();
        List<UnposotiveStaffInfoDto> unposotiveStaffInfoDtos= new ArrayList<>(6);
        for (int i = 0; i < 6; i++) {
            UnposotiveStaffInfoDto unposotiveStaffInfoDto = new UnposotiveStaffInfoDto();
            unposotiveStaffInfoDto.setName("张三" + (i + 1));
            unposotiveStaffInfoDto.setEntryTime(Instant.now());
            unposotiveStaffInfoDto.setReason("社会招聘");
            unposotiveStaffInfoDto.setRemainingDays(i + 1);
            unposotiveStaffInfoDto.setStaffNo(staffNos.get(i));
            unposotiveStaffInfoDto.setStatusName("未转正");
            unposotiveStaffInfoDto.setUnit("集团公司");
            unposotiveStaffInfoDto.setSendMessageNum(0);
            unposotiveStaffInfoDtos.add(unposotiveStaffInfoDto);
        }
        return new PaginationResponse<>(request.getLanguage(), page, size, 6, request.getSortPairs(), Response.SUCCESS_CODE, null, unposotiveStaffInfoDtos);
    }

    @Override
    public List<String> getUnPositiveStaffInfoNos() {
        return mockStaffNos();
    }

    private List<String> mockStaffNos() {
        List<String> staffNos = new ArrayList<>(6);
        staffNos.add("1569325685456");
        staffNos.add("1569582477626");
        staffNos.add("1567075668286");
        staffNos.add("1567075786770");
        staffNos.add("1567075931892");
        staffNos.add("1567075949546");
        return staffNos;

    }
}
