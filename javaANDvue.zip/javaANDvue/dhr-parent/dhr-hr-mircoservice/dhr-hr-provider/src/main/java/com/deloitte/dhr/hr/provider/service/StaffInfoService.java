package com.deloitte.dhr.hr.provider.service;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.bson.Document;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

/**
 * @author chunliucq
 * @since 23/08/2019 11:04
 */
public interface StaffInfoService {

    /**
     * 保存部份员工信息，其中一个模块的信息
     * @param staffInfoJson
     * @return
     */
    public abstract JSONObject savePartStaffInfo(JSONObject staffInfoJson);

    /**
     * 通过员工编号查询mongodb中员工信息
     * @param staffNo
     * @return
     */
    public String queryStaffInfoByStaffNo(String staffNo);


    /**
     * 发送邮件通知
     * @param staffNo
     */
    public void doSendMail(String staffNo,String msgTemplate,String... msgParams);

    /**
     * 员工提效个人信息变更申请
     * @param applyRequest
     * @return
     */
    public Response<Void> applyModStaffInfo(@RequestBody Request<Map> applyRequest);

    /**
     * 更新员工信息填写检查点
     * @param staffNo 员工编号
     * @param staffInfoPartNode 填写信息模块节点
     */
    public void updateStaffInfoCheckPart(String staffNo,String staffInfoPartNode,boolean checkResult);


    /**
     * 判断员工信息是否填写完成
     * @param staffNo
     * @return
     */
    boolean isAllFillInComplete(String staffNo);


    /**
     * 查询员工信息修改申请记录中指定变化详细信息
     * @param applyNo
     * @param rid
     * @return
     */
    public Response<Map> queryUpdateDetailInfo(String applyNo, String rid);

    public Boolean queryDetailInfoUpdate(Request<Map> staffUpdateApplyRecordRequest);
}
