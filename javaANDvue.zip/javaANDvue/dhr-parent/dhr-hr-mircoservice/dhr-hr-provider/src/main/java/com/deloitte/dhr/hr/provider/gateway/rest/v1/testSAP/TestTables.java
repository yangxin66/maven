package com.deloitte.dhr.hr.provider.gateway.rest.v1.testSAP;

import com.deloitte.dhr.extension.sap.bean.parameter.Exports;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * <br/>22/08/2019 15:29
 *
 * @author lshao
 */
@Data
public class TestTables {
    @JsonProperty("T_EEPICTURE")
    private List<Epicture> epicture;
}