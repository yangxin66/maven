package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.api.model.staff.ApplyNo;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;


import java.util.List;
import java.util.Map;

/**
 * @author chunliucq
 * @since 22/08/2019 15:03
 */
public interface HrStaffService {

    PageDataRequest getStaffInfoDetail(String staffId);

    StaffDetailCompareDto getStaffDetailCompare(String staffId);

    void approveStaffInfo(List<ApproveStaffDto> approveStaffDtoList);

    List<StaffInfoStatus> exportJsonObjects(Request<SearchDto> searchDtoRequest);

    List<StaffInfoStatus> getEmployJsonObjectListFromStaffIds(List<String> ids);

    List<Map> ExportApplyMap(Request<SearchDto> searchDtoRequest);

    List<Map> ExportApplyMyApplication(Request<SearchDto> searchDtoRequest);

    List<Map> ExportApplyMapFormApplyNoHr(ApplySearchDto applySearchDto);

    List<Map> ExportApplyMapFormApplyNoStaff(ApplySearchDto applySearchDto);

    List<StaffInfoSearchDto> searchStaffInfoByKeyword(String keyword);

    String modifyStaffInfoToSap(StaffInfoModifyDto request);
}
