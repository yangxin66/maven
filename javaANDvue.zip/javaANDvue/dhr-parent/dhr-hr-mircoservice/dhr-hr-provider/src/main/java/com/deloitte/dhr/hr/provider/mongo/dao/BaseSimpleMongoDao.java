package com.deloitte.dhr.hr.provider.mongo.dao;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.client.result.DeleteResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.bson.Document;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

/**
 * @author chunliucq
 * @since 27/08/2019 13:45
 */
@Component
public class BaseSimpleMongoDao {

    @Autowired
    private MongoTemplate mongoTemplate;

    public void save(String jsonData,String collection){
        mongoTemplate.save(jsonData,collection);
    }

    public void updateAndFlush(JSONObject queryJson, Map<String,JSON> updateJson, String collection){
        Query query = new Query();

        for (String key : queryJson.keySet()){
            String queryParam = queryJson.getString(key);
            query.addCriteria(Criteria.where(key).is(queryParam));
        }
        Update update = new Update();
        for (String key : updateJson.keySet()){
            BasicDBObject bdb = null;

            JSON tempJsonData = updateJson.get(key);
            if (tempJsonData instanceof JSONObject){
                JSONObject updateData = (JSONObject)tempJsonData;
                bdb =  BasicDBObject.parse(updateData.toJSONString());
                update.set(key,bdb);
            }
            if (tempJsonData instanceof JSONArray){
                JSONArray updateData = (JSONArray)tempJsonData;
                BasicDBList bdl = new BasicDBList();
                for (Object obj : updateData.toArray()){
                    bdb =  BasicDBObject.parse(JSONObject.toJSONString(obj));
                    bdl.add(bdb);
                }
                //BasicDBList columns = (BasicDBList) JSON.parse(param);
                update.set(key,bdl);
            }
        }
        mongoTemplate.upsert(query,update,collection);
    }

    public void updateAndFlush(Query query, Update update, String collection){
        mongoTemplate.upsert(query,update,collection);
    }

    public void removeAndFlush(Query query, String collection){
        mongoTemplate.remove(query,collection);
    }

    public void save(Object obj,String collectionName){
        mongoTemplate.save(obj,collectionName);
    }

    public void save(List objList,String collectionName){
        //mongoTemplate.save(objList,collectionName);
        if (!CollectionUtils.isEmpty(objList)){
            for (Object obj : objList){
                mongoTemplate.save(obj,collectionName);
            }
        }
    }

    public void insert(List objList,String collectionName){
        mongoTemplate.insert(objList,collectionName);
    }

    public Document queryOneForDocument(Query query, String collectionName){
        return mongoTemplate.findOne(query,Document.class,collectionName);
    }

    public List<Document> queryForDocument(Query query, String collectionName){
        return mongoTemplate.find(query,Document.class,collectionName);
    }

    public long count(Query query,String collectionName){
        return mongoTemplate.count(query,collectionName);
    }

    public boolean remove(Query query,String collectionName){
        DeleteResult deleteResult = mongoTemplate.remove(query,collectionName);
        return deleteResult.getDeletedCount() > 0;
    }
}
