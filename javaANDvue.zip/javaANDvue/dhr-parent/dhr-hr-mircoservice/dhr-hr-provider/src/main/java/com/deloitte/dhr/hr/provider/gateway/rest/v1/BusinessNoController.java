package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.hr.api.BusinessNoInterface;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.provider.service.BussniessNoGeneratorService;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * 业务编号生成器
 * @author chunliucq
 * @since 05/09/2019 16:32
 */
@RestController
@RequestMapping(value = "/api/v1/hr/business",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class BusinessNoController implements BusinessNoInterface {

    @Autowired
    private BussniessNoGeneratorService bussniessNoGeneratorService;

    @ApiOperation(value = "生成业务编号")
    @ApiImplicitParam(name = "request",value="生成业务编号的KEY",required = true,dataType = "Request«string»")
    @PostMapping(value = "/generatorNo")
    @Override
    public Response<String> generatorBusinessNo(@RequestBody Request<String> request){
        String key = request.getData();
        String businessNo = bussniessNoGeneratorService.getNewBussniessNo(key);
        return new Response<String>(LanguageEnum.ZH_CN,Response.SUCCESS_CODE,"success",businessNo);
    }

    @ApiOperation(value = "生成业务编号")
    @ApiImplicitParam(name = "request",value="生成业务编号的业务类型",required = true,dataType = "Request«string»")
    @PostMapping(value = "/generatorNoByBusiType")
    @Override
    public Response<String> generatorBusinessNoByBusiType(@RequestBody Request<String> request){
        SubtypeEnum subtypeEnum = SubtypeEnum.valueOf(request.getData());
        String businessNo = bussniessNoGeneratorService.getNewBussniessNo(subtypeEnum);
        return new Response<String>(LanguageEnum.ZH_CN,Response.SUCCESS_CODE,"success",businessNo);

    }
}
