package com.deloitte.dhr.hr.provider.gateway.rest.v1.demo;

import com.deloitte.dhr.metadata.component.context.OptionContext;
import com.deloitte.dhr.metadata.component.element.form.field.Option;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;

/**
 * TODO
 *
 * @author xideng
 */
@RestController
@RequestMapping(value = "/api/v1/options")
public class OptionRestController {

    @GetMapping
    public Response<List<Option>> getOptions(@RequestParam("option") String option) {
        if (StringUtils.isEmpty(option)) {//人事范围
            return new Response<>(null, Response.SUCCESS_CODE, null, OptionContext.RESOURCES.get("WERKS"));
        }
        return new Response<>(null, Response.SUCCESS_CODE, null, OptionContext.RESOURCES.get(option));
    }
}
