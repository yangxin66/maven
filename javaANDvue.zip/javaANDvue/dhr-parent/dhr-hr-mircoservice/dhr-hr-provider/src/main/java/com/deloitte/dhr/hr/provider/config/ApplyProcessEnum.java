package com.deloitte.dhr.hr.provider.config;

import com.deloitte.dhr.hr.api.constant.ApplyModeEnum;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.ProcessInstanceTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;

import java.util.Arrays;
import java.util.List;

/**
 * 流程管理关联信息  流程关联业务类型、流程实例、业务主类型、业务处理模式
 * @author chunliucq
 * @since 10/10/2019 10:20
 */
public enum ApplyProcessEnum {

    /**
     * 员工新建入职
     */
    CREATE_STAFF(SubtypeEnum.CREATE_STAFF, ProcessInstanceTypeEnum.NEW_STAFF, ManagementTypeEnum.CREATE_STAFF, ApplyModeEnum.MINGLE),
    /**
     * 员工信息修改
     */
    STAFF_INFO_MODIFY(SubtypeEnum.STAFF_INFO_MODIFY, ProcessInstanceTypeEnum.STAFF_INFO_MODIFY, ManagementTypeEnum.STAFF_INFO_MODIFY, ApplyModeEnum.MINGLE),

    /**
     * 离职
     */
    DIMISSION(SubtypeEnum.DIMISSION, ProcessInstanceTypeEnum.STAFF_DIMISSION, ManagementTypeEnum.DECREASE_BOOK, ApplyModeEnum.MULTIPLE),
    /**
     * 领导岗位变动
     */
    LEADER_POSITION_CHANGE(SubtypeEnum.LEADER_POSITION_CHANGE,ProcessInstanceTypeEnum.LEADER_POSITION_CHANGE,ManagementTypeEnum.POSITION_CHANGE,ApplyModeEnum.MULTIPLE),
    /**
     * 员工岗位变动
     */
    STAFF_POSITION_CHANGE(SubtypeEnum.STAFF_POSITION_CHANGE,ProcessInstanceTypeEnum.STAFF_POSITION_CHANGE,ManagementTypeEnum.POSITION_CHANGE,ApplyModeEnum.MULTIPLE),

    /**
     * 转正
     */
    POSITIVE(SubtypeEnum.POSITIVE,ProcessInstanceTypeEnum.POSITIVE,ManagementTypeEnum.POSITIVE,ApplyModeEnum.SINGLE),
    /**
     * 开始兼岗
     */
    START_AND_POST(SubtypeEnum.START_AND_POST,ProcessInstanceTypeEnum.START_AND_POST,ManagementTypeEnum.AND_POST,ApplyModeEnum.MULTIPLE),
    /**
     * 结束兼岗
     */
    END_AND_POST(SubtypeEnum.END_AND_POST,ProcessInstanceTypeEnum.END_AND_POST,ManagementTypeEnum.AND_POST,ApplyModeEnum.MULTIPLE),
    /**
     * 员工自离
     */
    DIMISSION_FROM_EMPLOYEES(SubtypeEnum.DIMISSION_FROM_EMPLOYEES,ProcessInstanceTypeEnum.DIMISSION_FROM_EMPLOYEES,ManagementTypeEnum.DECREASE_BOOK,ApplyModeEnum.MULTIPLE),
    /**
     * 违纪解除合同
     */
    TERMINATE_THE_CONTRACT_FROM_DISCIPLINE(SubtypeEnum.TERMINATE_THE_CONTRACT_FROM_DISCIPLINE,ProcessInstanceTypeEnum.TERMINATE_THE_CONTRACT_FROM_DISCIPLINE,ManagementTypeEnum.DECREASE_BOOK,ApplyModeEnum.MULTIPLE),
    /**
     * 协议解除合同
     */
    TERMINATE_THE_CONTRACT_FROM_PROTOCOL(SubtypeEnum.TERMINATE_THE_CONTRACT_FROM_PROTOCOL,ProcessInstanceTypeEnum.TERMINATE_THE_CONTRACT_FROM_PROTOCOL,ManagementTypeEnum.DECREASE_BOOK,ApplyModeEnum.MULTIPLE),
    /**
     * 身故
     */
    STAFF_DECEASE(SubtypeEnum.STAFF_DECEASE,ProcessInstanceTypeEnum.STAFF_DECEASE,ManagementTypeEnum.DECREASE_BOOK,ApplyModeEnum.MULTIPLE),
    /**
     * 退休
     */
    RETIRE(SubtypeEnum.RETIRE,ProcessInstanceTypeEnum.RETIRE,ManagementTypeEnum.DECREASE_BOOK,ApplyModeEnum.MULTIPLE),
    /**
     * 发起合同
     */
    START_CONTRACT(SubtypeEnum.START_CONTRACT,ProcessInstanceTypeEnum.START_CONTRACT,ManagementTypeEnum.CONTRACT_MANAGEMENT,ApplyModeEnum.MULTIPLE),
    /**
     * 续签合同
     */
    EXTEND_CONTRACT(SubtypeEnum.EXTEND_CONTRACT,ProcessInstanceTypeEnum.EXTEND_CONTRACT,ManagementTypeEnum.CONTRACT_MANAGEMENT,ApplyModeEnum.MULTIPLE),
    /**
     * 终止合同
     */
    END_CONTRACT(SubtypeEnum.END_CONTRACT,ProcessInstanceTypeEnum.END_CONTRACT,ManagementTypeEnum.CONTRACT_MANAGEMENT,ApplyModeEnum.MULTIPLE),







    ;

    /**
     * 业务子类型
     */
    private SubtypeEnum busiType;
    /**
     * 流程实例KEY
     */
    private ProcessInstanceTypeEnum processKey;
    /**
     * 业务主类型
     */
    private ManagementTypeEnum intanceType;

    /**
     * 业务处理模式
     */
    private ApplyModeEnum applyModeEnum;

    /**
     * 业务模型
     * @param subtypeEnum
     * @param processKey
     * @param intanceType
     */


    ApplyProcessEnum(SubtypeEnum subtypeEnum, ProcessInstanceTypeEnum processKey, ManagementTypeEnum intanceType,ApplyModeEnum applyModeEnum){
        this.busiType = subtypeEnum;
        this.processKey = processKey;
        this.intanceType = intanceType;
        this.applyModeEnum = applyModeEnum;
    }

    public SubtypeEnum getBusiType() {
        return busiType;
    }

    public ProcessInstanceTypeEnum getProcessKey() {
        return processKey;
    }

    public ApplyModeEnum getApplyModeEnum() {
        return applyModeEnum;
    }

    public ManagementTypeEnum getIntanceType() {
        return intanceType;
    }

    public static ApplyProcessEnum getByBusiType(SubtypeEnum subtypeEnum){
        for (ApplyProcessEnum cfg : values()){
            if (cfg.getBusiType() == subtypeEnum){
                return cfg;
            }
        }
        return null;
    }

    public static List<ApplyProcessEnum> getList(){
        return Arrays.asList(values());
    }
}
