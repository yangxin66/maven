package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;

public interface ExcelExportService {

    void ExcelOutExport(HttpServletResponse response, ExcelOutExprotDto excelOutExprotDto) throws IOException, ParseException;

    void ExcelOutExportCurrencyBatch(HttpServletResponse response, ExcelOutExportCurrencyBatchDto excelOutExportCurrencyBatchDto) throws IOException,
            ParseException;

    void ExcelOutExportCurrencyAll(HttpServletResponse response, ExcelOutExportCurrencyALLDto excelOutExportCurrencyALLDto) throws IOException,
            ParseException;

    void ExcelAPPlyOutExport(HttpServletResponse response, ExcelApplyExportDto excelApplyExportDto) throws IOException, ParseException;

    void ExcelAPPlyOutExportMy(HttpServletResponse response, ExcelApplyExportDto excelApplyExportDto) throws IOException, ParseException;

    void ExcelAPPlyAuditOutExport(HttpServletResponse response, ExcelApplyDetailedDto excelApplyDetailedDto) throws IOException, ParseException;


}
