package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.hr.api.model.ApplyRecordDelDto;
import com.deloitte.dhr.hr.api.model.FileApplyRequestDto;
import com.deloitte.dhr.hr.api.model.staff.ApplyNoAndTypeDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.util.List;
import java.util.Map;

/**
 * 申请管理，主要包括，岗位变动申请，减册申请、合同申请、兼岗申请、转正申请等的 提交申请、
 * 保存业务数据、提效审核、申请信息查询等功能
 * @author chunliucq
 * @since 08/10/2019 16:30
 */
public interface ApplyService {

    /**
     * 保存申请信息
     * @param applyRequest
     * @return
     */
    Response<Void> saveApplyInfo(Request<Map> applyRequest, ApproveStatusEnum applyStatus);

    /**
     * 保存申请-业务数据 信息  批量保存
     * @param busiType
     * @param applyNo
     * @param applyRequestMapList
     * @return
     */
    Response<Void> saveApplyDetailRecord(String busiType, String applyNo, List<Map> applyRequestMapList,Boolean isOfficalData,boolean isCleardata);

    /**
     * 保存申请-业务数据 信息  批量保存
     * 修改申请信息-业务数据  注：上传业务数据字优根据"_RID"字段判定是否修改
     * @param applyRequest
     * @return
     */
    Response<Void> saveApplyDetailRecord(Request<Map> applyRequest,boolean isOfficalData,boolean isClearData);

    /**
     * 删除单条业务数据
     * @param applyRecordDelDto
     * @return
     */
    Response<Void> delApplyDetailRecord(ApplyRecordDelDto applyRecordDelDto);

    /**
     * 查询申请详情   若请求无申请编号，则新生成申请的初始数据
     * @param applyNo
     * @return
     */
    Response<Map> queryApplyInfoOrInitNewApply(ApplyNoAndTypeDto applyNo);

    /**
     * 分页查询申请信息的业务数据
     * @param applyNoPaginationRequest
     * @return
     */
    PaginationResponse<List<Map>> queryApplyInfoByPageList(PaginationRequest<ApplyNoAndTypeDto> applyNoPaginationRequest);

    /**
     * 上传批量数据excel数据
     * @param fileApplyRequestDto
     * @return
     */
    Response<Map> uploadApplyData(FileApplyRequestDto fileApplyRequestDto);


}
