package com.deloitte.dhr.hr.provider.mongo.dao;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.provider.mongo.dao.model.AuditNodePo;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * 审核节点持久化仓库接口
 *
 * @author wgong
 */
@Component
public class AuditNodeDao {

    @Autowired
    MongoTemplate mongoTemplate;
    /**
     * 根据流程id查询审核状态节点 按照审批时间升序
     *
     * @param processInstantId 流程id
     */
    public List<AuditNodePo> findByProcessInstanceIdEqualsAndAuditTimeIsNotNullOrderByAuditTimeAsc(String processInstantId){
        Query query = new Query(Criteria.where("processInstanceId").is(processInstantId).andOperator(
                Criteria.where("auditTime").exists(true)
        ));
        List<Map> list = mongoTemplate.find(query.with(Sort.by(Sort.Direction.ASC, "auditTime")),
                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
        return list.stream().map(po -> SerializerUtils.deserialize(JSONObject.toJSONString(po), AuditNodePo.class)).collect(Collectors.toList());
    }

    /**
     * 根据任务集合查询审批节点
     *
     * @param taskIds 任务集合
     */

    public List<AuditNodePo> findByTaskIdIn(List<String> taskIds){
        Query query = new Query(Criteria.where("taskId").in(taskIds));
        List<Map> list = mongoTemplate.find(query,
                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
        return list.stream().map(po -> SerializerUtils.deserialize(JSONObject.toJSONString(po), AuditNodePo.class)).collect(Collectors.toList());

    }
//
//    public List<AuditNodePo> findByTaskIdInAndApplyNo(List<String> taskIds,String applyNo){
//        Query query = new Query(Criteria.where("taskId").in(taskIds).andOperator(
//                Criteria.where("applyNo").is(applyNo)
//        ));
//        List<Map> list = mongoTemplate.find(query,
//                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
//        return list.stream().map(po -> SerializerUtils.deserialize(JSONObject.toJSONString(po), AuditNodePo.class)).collect(Collectors.toList());
//
//    }

    public List<AuditNodePo> findCompleteTask(){
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String currentStaffNo = currentLoginUserInfo.getStaffNo();
        Query query = new Query(Criteria.where("auditorId").is(currentStaffNo).andOperator(
                Criteria.where("auditTime").exists(true),
                Criteria.where("status").ne(ApproveStatusEnum.SUBMITTED.name()),
                Criteria.where("status").ne(ApproveStatusEnum.APPROVAL_PENDING.name()),
                Criteria.where("status").ne("PRE_SUBMIT"),
                Criteria.where("status").ne(ApproveStatusEnum.CLOSE.name())
        ));
        List<Map> list = mongoTemplate.find(query,
                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
        return list.stream().map(po -> SerializerUtils.deserialize(JSONObject.toJSONString(po), AuditNodePo.class)).collect(Collectors.toList());

    }

    public List<AuditNodePo> findByTaskIdInAndStatusEquals(List<String> taskIds, String status){
        Query query = new Query(Criteria.where("taskId").in(taskIds).andOperator(
                Criteria.where("status").is(status)
        ));
        List<Map> list = mongoTemplate.find(query,
                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
        return list.stream().map(po -> SerializerUtils.deserialize(JSONObject.toJSONString(po), AuditNodePo.class)).collect(Collectors.toList());

    }

    public List<AuditNodePo> findByTaskIdInAndApplyNoAndStatusEquals(List<String> taskIds,List<String> applyNos, String status){
        Query query;
        if (status == null || StringUtils.isBlank(status)) {
            query = new Query(Criteria.where("taskId").in(taskIds).andOperator(
                    Criteria.where("applyNo").in(applyNos)
            ));
        } else {
            query = new Query(Criteria.where("taskId").in(taskIds).andOperator(
                    Criteria.where("applyNo").in(applyNos), Criteria.where("status").is(status)
            ));
        }

        List<Map> list = mongoTemplate.find(query,
                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
        return list.stream().map(po -> SerializerUtils.deserialize(JSONObject.toJSONString(po), AuditNodePo.class)).collect(Collectors.toList());

    }

    public AuditNodePo findByProcessInstanceIdEqualsAndTaskIdEquals(String processInstanceId, String taskId){
        Query query = new Query(Criteria.where("processInstanceId").is(processInstanceId).andOperator(
                Criteria.where("taskId").is(taskId)
        ));
        List<Map> list = mongoTemplate.find(query,
                Map.class, HRCollection.HR_TASK_AUDIT_NODE);
        if (list.size() == 0) {
            return null;
        }
        return SerializerUtils.deserialize(JSONObject.toJSONString(list.get(0)), AuditNodePo.class);

    }
}
