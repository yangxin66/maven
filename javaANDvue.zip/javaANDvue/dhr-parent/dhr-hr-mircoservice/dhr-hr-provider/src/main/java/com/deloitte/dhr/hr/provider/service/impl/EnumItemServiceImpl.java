package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.hr.provider.repository.EnumItemRepository;
import com.deloitte.dhr.hr.provider.repository.model.EnumItemPo;
import com.deloitte.dhr.hr.provider.service.EnumItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 枚举项Service
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class EnumItemServiceImpl implements EnumItemService {

    @Autowired
    EnumItemRepository enumItemRepository;

    @Override
    public List<EnumItemPo> queryEnum(String code){
        List<EnumItemPo> enumItemPoList = enumItemRepository.findByCode(code);
        return enumItemPoList;
    }
}
