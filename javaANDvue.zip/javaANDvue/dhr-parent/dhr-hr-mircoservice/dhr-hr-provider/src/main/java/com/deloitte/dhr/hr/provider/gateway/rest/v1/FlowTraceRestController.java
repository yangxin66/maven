package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.hr.api.FlowTraceRestInterface;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.service.FlowTraceService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * date: 21/08/2019 15:58
 *
 * @author wgong
 * @since 0.0.1
 */
@RestController
@RequestMapping(value = "/api/v1/hr/flow_trace", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
@Api(value = "流程路径相关API", tags = {"FlowTraceApi"}, produces = MediaType.APPLICATION_JSON_VALUE)
public class FlowTraceRestController implements FlowTraceRestInterface {

    @Autowired
    FlowTraceService flowTraceService;

    /**
     * 根据流程实例id查询流程节点信息
     *
     * @param request           查询参数传输实体
     */
    @Override
    @PostMapping
    @ApiOperation("根据流程实例id查询流程节点信息")
    @ApiImplicitParam(name = "request", value = "实体", required = true, dataType = "Request«string»")
    public Response<FlowTraceLogDto> getFlowTraceLogDetail(@RequestBody Request<String> request) {
        String processInstanceId = request.getData();
        if (processInstanceId == null || StringUtils.isBlank(processInstanceId)) {
            throw  new BusinessException(HRMateInfo.PROCESSINSTANCE_ID_ISNULL_ERR.getCode(), HRMateInfo.PROCESSINSTANCE_ID_ISNULL_ERR.getMessage());
        }
        return flowTraceService.getStaffInfoModifyFlowTraceLogDetail(request);
    }

    /**
     * 流程节点处理
     *
     * @param request 查询参数传输实体
     */
    @Override
    @PostMapping("/node_handler")
    @ApiOperation("流程节点处理方法")
    @ApiImplicitParam(name = "request", value = "流程节点处理实体", required = true, dataType = "Request«List«AuditHandlerDto»»")
    public Response<Object> flowNodeHandler(@Validated @RequestBody Request<List<AuditHandlerDto>> request) {
        flowTraceService.flowNodeHandler(request);
        return ResponseUtil.build().creatDeaultOkResponse(request.getLanguage(), null);
    }


}
