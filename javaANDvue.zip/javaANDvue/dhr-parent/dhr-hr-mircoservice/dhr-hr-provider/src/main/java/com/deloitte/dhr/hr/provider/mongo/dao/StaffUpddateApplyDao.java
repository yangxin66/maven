package com.deloitte.dhr.hr.provider.mongo.dao;

import org.springframework.stereotype.Repository;

/**
 * @author chunliucq
 * @since 17/09/2019 16:12
 */
@Repository
public class StaffUpddateApplyDao extends BaseSimpleMongoDao {

}
