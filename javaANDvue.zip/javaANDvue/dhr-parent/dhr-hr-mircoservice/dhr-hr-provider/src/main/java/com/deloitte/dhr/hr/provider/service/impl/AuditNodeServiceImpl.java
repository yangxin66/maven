package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.provider.mongo.dao.AuditNodeDao;
import com.deloitte.dhr.hr.provider.mongo.dao.model.AuditNodePo;
import com.deloitte.dhr.hr.provider.service.AuditNodeService;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import com.deloitte.workflow.api.model.dto.TaskNodeDto;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

/**
 * 查询枚举对象Service
 * @author wgong
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class AuditNodeServiceImpl implements AuditNodeService {

    @Autowired
    private AuditNodeDao auditNodeDao;

    @Autowired
    private BaseMongoService baseMongoService;

    @Override
    public void addNextTaskNode(List<TaskNodeDto> taskNodes, String applyNo, String status,
                                String lastTaskId, String lastAuditorId, String lastAuditorName) {
        taskNodes.forEach(task ->
        {
            AuditNodePo auditNodePo = AuditNodePo.builder()
                    .processInstanceId(task.getProcessInstanceId())
                    .taskId(task.getTaskId())
                    .lastTaskId(lastTaskId)
                    .lastAuditorId(lastAuditorId)
                    .lastAuditorName(lastAuditorName)
                    .taskName(task.getName())
                    .status(status)
                    .applyNo(applyNo)
                    .build();
            // 将审核状态保存在表中
            saveAndUpdate(auditNodePo);
        });
    }

    @Override
    public AuditNodePo findByProcessInstanceIdEqualsAndTaskIdEquals(String processInstaceId, String taskId) {
        if (processInstaceId == null || taskId == null) {
            return null;
        }
        return auditNodeDao.findByProcessInstanceIdEqualsAndTaskIdEquals(processInstaceId, taskId);
    }

    @Override
    public List<AuditNodePo> findCompleteTaskByProcessInstanceId(String processInstantId) {
        if (processInstantId == null ) {
            return null;
        }
        return auditNodeDao.findByProcessInstanceIdEqualsAndAuditTimeIsNotNullOrderByAuditTimeAsc(processInstantId);
    }

    @Override
    public List<AuditNodePo> findByTaskIdAndStatus(List<String> taskIds, String status) {
        if (taskIds == null || taskIds.size() ==0) {
            return null;
        }
        if (StringUtils.isNotBlank(status)) {
            return auditNodeDao.findByTaskIdInAndStatusEquals(taskIds, status);
        }
        return auditNodeDao.findByTaskIdIn(taskIds);

    }

    @Override
    public List<AuditNodePo> findByTaskIdAndStatusAndApplyNo(List<String> taskIds,List<String> applyNos, String status) {
        if (taskIds == null || taskIds.size() ==0) {
            return null;
        }
        return auditNodeDao.findByTaskIdInAndApplyNoAndStatusEquals(taskIds,applyNos,status);
    }

    @Override
    public void saveAndUpdate(AuditNodePo auditNodePo) {
        Query query = new Query();
        query.addCriteria(Criteria.where("applyNo").is(auditNodePo.getApplyNo())
                .andOperator(Criteria.where("processInstanceId").is(auditNodePo.getProcessInstanceId()), Criteria.where("taskId").is(auditNodePo.getTaskId())));
        Update update = new Update();
        update.set("processInstanceId", auditNodePo.getProcessInstanceId());
        update.set("applyNo", auditNodePo.getApplyNo());
        update.set("taskId", auditNodePo.getTaskId());
        update.set("taskName", auditNodePo.getTaskName());
        update.set("auditorId", auditNodePo.getAuditorId());
        update.set("auditorName", auditNodePo.getAuditorName());
        Instant auditTime = auditNodePo.getAuditTime();
        if (auditTime != null) {
            update.set("auditTime", auditTime.toString());
        }
        update.set("imgUrl", auditNodePo.getImgUrl());
        update.set("status", auditNodePo.getStatus());
        update.set("statusName", auditNodePo.getStatusName());
        update.set("remark", auditNodePo.getRemark());
        update.set("lastTaskId", auditNodePo.getLastTaskId());
        update.set("lastAuditorId", auditNodePo.getLastAuditorId());
        update.set("lastAuditorName", auditNodePo.getLastAuditorName());
        baseMongoService.updateAndFlush(query, update, HRCollection.HR_TASK_AUDIT_NODE);
    }

    @Override
    public List<AuditNodePo> findCompleteTask() {
        return auditNodeDao.findCompleteTask();
    }


}
