package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.constant.CommonStringConstant;
import com.deloitte.dhr.common.exception.FileMateInfo;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.common.utils.ValueGetTool;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.constant.ApplyModeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.api.model.UploadApplyDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffUpddateApplyDao;
import com.deloitte.dhr.hr.api.model.staff.ApplyNoAndTypeDto;
import com.deloitte.dhr.hr.provider.config.ApplyProcessEnum;
import com.deloitte.dhr.hr.provider.repository.BusiDataRepository;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.workflow.api.WfProcessApi;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.model.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author chunliucq
 * @since 08/10/2019 16:32
 */
@Slf4j
@Service
public class ApplyServiceImpl implements  ApplyService {

    @Autowired
    private BussniessNoGeneratorService bussniessNoGeneratorService;

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    private BaseMongoService baseMongoService;

    @Autowired
    private WfProcessApi wfProcessApi;

    @Autowired
    private AuditNodeService auditNodeService;

    @Autowired
    private FlowTraceService flowTraceService;

    @Autowired
    private WfTaskApi wfTaskApi;

    @Autowired
    private StaffUpddateApplyDao staffUpddateApplyDao;

    @Autowired
    private MockService mockService;

    @Autowired
    private BusiDataRepository busiDataRepository;

    private static final String APPLY_KEY = "_APPLYINFO";
    private static final String ATTACHMENTS_KEY = "_ATTACHMENTS";

    @Override
    public Response<Void> saveApplyInfo(Request<Map> applyRequest,ApproveStatusEnum applyStatus) {



        Map<String,Object> reqDataMap = applyRequest.getData();
        String applyNo = ValueGetTool.getStringFromMap(reqDataMap,"_APPLYINFO._APPLY_NO.value");
        String applySubType = ValueGetTool.getStringFromMap(reqDataMap,"_APPLYINFO._APPLY_SUB_TYPE.value");
        String reason = ValueGetTool.getStringFromMap(reqDataMap,"_APPLYINFO._REASON.value");
        SubtypeEnum busiType = SubtypeEnum.valueOf(applySubType);


        String processInstanceId = null;
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        Map map = baseMongoService.queryOneForMap(query, HRCollection.HR_STAFF_UPDATE_APPLY);
        if (map == null) {
            saveAppendApplyInfo(applyRequest,true);
        } else {
            saveAppendApplyInfo(applyRequest,false);
            processInstanceId = (String) map.get("_PROCESS_INSTANCE_ID");
            //updateAppendApplyInfo(applyRequest);

        }

        ApplyProcessEnum applyProcessEnum = ApplyProcessEnum.getByBusiType(busiType);
        if (applyProcessEnum.getApplyModeEnum() == ApplyModeEnum.MULTIPLE){
            // 多条业务数据时，不保存业务数据

        }else if (applyProcessEnum.getApplyModeEnum() == ApplyModeEnum.SINGLE){
            // 单条业务数据时，前 申请信息 与 业务数据 一起  该情况有且仅有一条业务数据记录
            //  每次保存申请时，修改业务数据记录
            saveOrupdateSingleModeBusiData(applyRequest.getData());
        }else if (applyProcessEnum.getApplyModeEnum() == ApplyModeEnum.MINGLE){
            // 其它模式 业务数据与申请数据一起上传，并且每次保存申请时，清理之前的业务数据记录
            saveApplyDetailRecord(applyRequest, Boolean.TRUE, Boolean.TRUE);
        }


        // 统计记录条条数
        String collectionName = busiType.getTableName();
        long num = baseMongoService.count(query,collectionName);


        // 修改申请中变化记录条数
        Update updateRecordNum = new Update();
        updateRecordNum.set("_MOD_NUM", String.valueOf(num));
        baseMongoService.updateAndFlush(query, updateRecordNum, HRCollection.HR_STAFF_UPDATE_APPLY);

        // 修改临时数据状态
        updateBusiDataOffical(busiType,applyNo);

        if (processInstanceId == null) {
            //启动流程引擎
            ProcessStartDto processStartDto = new ProcessStartDto();
            //HARDCODE

            ApplyProcessEnum applyProcessConfig = ApplyProcessEnum.getByBusiType(busiType);
            processStartDto.setKey(applyProcessConfig.getProcessKey().getKey());
            Map<String, Object> parmaeter = new HashMap<>();
            parmaeter.put("instanceType", applyProcessConfig.getIntanceType().name());
            // todo 修改变化员工编号
            processStartDto.setVariables(parmaeter);
            Response<ProcessInstanceDto> wfResonse = wfProcessApi.start(new Request<>(processStartDto));
            ProcessInstanceDto processInstanceDto = wfResonse.getData();
            List<TaskNodeDto> taskList = processInstanceDto.getTaskNodes();
            if (CollectionUtils.isEmpty(taskList)){
                return ResponseUtil.build().createBadResponse(HRMateInfo.APPLY_START_PROCESS_ERR.getCode(),HRMateInfo.APPLY_START_PROCESS_ERR.getMessage());
            }

            List<TaskCandidateGroupDto> taskCandidateGroupList = new ArrayList<>();
            taskList.forEach(taskNodeDto -> {
                // TODO 分配者需要修改
                List<String> currentLoginUserRoleCodes = ContextSession.getCurrentLoginUserRoleCodes();
                List<TaskCandidateGroupDto> taskCandidateGroupDtos = currentLoginUserRoleCodes.stream().map(roleCode -> new TaskCandidateGroupDto(taskNodeDto.getTaskId(), roleCode)).collect(Collectors.toList());
                taskCandidateGroupList.addAll(taskCandidateGroupDtos);
            });
            wfTaskApi.addCandidateGroup(new Request<>(taskCandidateGroupList));
            auditNodeService.addNextTaskNode(taskList, applyNo, ApproveStatusEnum.PRE_SUBMIT.name(), null, null, null);

            Update update = new Update();
            update.set("_PROCESS_INSTANCE_ID", wfResonse.getData().getId());
            baseMongoService.updateAndFlush(query, update, HRCollection.HR_STAFF_UPDATE_APPLY);

            processInstanceId = wfResonse.getData().getId();
        }

        // 提交审批  审批操作
        if (applyStatus == ApproveStatusEnum.SUBMITTED){
            doApplySubmit(busiType,processInstanceId,reason);
        }
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    private void doApplySubmit(SubtypeEnum busiType,String processInstanceId,String reason){
        TaskDto taskDto = new TaskDto();
        taskDto.setProcessInstanceId(processInstanceId);
        taskDto.setCompleted(false);
        Request<TaskDto> taskDtoRequest = new Request<>(taskDto);
        Response<List<TaskDto>>  taksResp = wfTaskApi.list(taskDtoRequest);
        if (Response.SUCCESS_CODE.equals(taksResp.getCode())){
            List<TaskDto> taskDtoList = taksResp.getData();
            if (! CollectionUtils.isEmpty(taskDtoList)){
                taskDtoList.forEach(tmp -> {
                    AuditHandlerDto auditHandlerDto = new AuditHandlerDto();
                    auditHandlerDto.setProcessInstantId(processInstanceId);
                    auditHandlerDto.setRemark(reason);
                    auditHandlerDto.setTaskId(tmp.getTaskId());
                    auditHandlerDto.setApplicationStatusEnum(ApplicationStatusEnum.SUBMITTED);
                    auditHandlerDto.setSubtypeEnum(busiType);
                    Request<List<AuditHandlerDto>> flowNodeHanderReq = new Request<>(Collections.singletonList(auditHandlerDto));
                    flowTraceService.flowNodeHandler(flowNodeHanderReq);
                });
            }else {
            }
        }else {

        }
    }

    @Override
    public Response<Void> saveApplyDetailRecord(Request<Map> applyRequest,boolean isOfficalData,boolean isClearData){
        Map<String,Object> reqDataMap = (Map<String,Object>)applyRequest.getData().get("_APPLYINFO");

        String staffNo = ValueGetTool.getStringFromMap(reqDataMap,"_BUSINESSID.value");
        String applyType = ValueGetTool.getStringFromMap(reqDataMap,"_APPLY_TYPE.value");
        String applySubType = ValueGetTool.getStringFromMap(reqDataMap,"_APPLY_SUB_TYPE.value");
        String applyNo = ValueGetTool.getStringFromMap(reqDataMap,"_APPLY_NO.value");

        List<Map> paramDataList = null;
        Object data = applyRequest.getData().get("_BUSI_DATA");
        if (data == null){
            return ResponseUtil.build().creatDeaultOkResponse(null);
        }
        if (data instanceof  List){
            paramDataList = (List<Map>)data;
        }else {
            Map<String,Object> paramData = (Map<String,Object>)data;
            paramDataList = Collections.singletonList(paramData);
        }
        return saveApplyDetailRecord(applySubType,applyNo,paramDataList,isOfficalData,isClearData);
    }

    @Override
    public Response<Void> delApplyDetailRecord(ApplyRecordDelDto applyRecordDelDto){

        List<String> ridList = applyRecordDelDto.getRidList();
        if (!CollectionUtils.isEmpty(ridList)){
            for (String rid : ridList){
                Query query = new Query();
                Criteria criteria = Criteria.where("_APPLY_NO").is(applyRecordDelDto.getApplyNo())
                        .and("_RID").is(rid);
                query.addCriteria(criteria);
                SubtypeEnum busiTypeEnum = SubtypeEnum.valueOf(applyRecordDelDto.getBusiType());
                baseMongoService.remove(query,busiTypeEnum.getTableName());
            }
        }
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @Override
    @Transactional(propagation=Propagation.REQUIRED)
    public Response<Void> saveApplyDetailRecord(String busiType,String applyNo,List<Map> applyRequestMapList,Boolean isOfficalData,boolean isCleardata){

        if (CollectionUtils.isEmpty(applyRequestMapList)){
            return ResponseUtil.build().createBadResponse(HRMateInfo.VERIFY_PARAMETER_ERR.getCode(),HRMateInfo.VERIFY_PARAMETER_ERR.getMessage());
        }

        SubtypeEnum busiTypeEnum = SubtypeEnum.valueOf(busiType);
        if (isCleardata){
            // 保存业务数据之前是否清除之前的业务数据
            Query query = new Query();
            query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));


            baseMongoService.remove(query,busiTypeEnum.getTableName());
        }

        final Map<String,JSONObject> cacheMap = new HashMap<>();

        List<Map<String, Object>> recordList = new ArrayList<>();
        for (Map tmp : applyRequestMapList){
                    Map recordMap =  new HashMap(tmp);
                    // 判断是保存 还是 修改    有"_RID" 参数时为修改
                    String rid_key = "_RID";
                    String isOfficalKey = "_IS_OFFICAL_DATA";

                    String rid = ValueGetTool.getStringFromMap(tmp,rid_key);
                    if (StringUtils.isEmpty(rid)){
                        rid = bussniessNoGeneratorService.getNewBussniessNo(CommonStringConstant.BUSINESSNO_RID_KEY);
                        // 当前新增数据是否为正式数据， 有可能为临时数据
                        recordMap.put(isOfficalKey,isOfficalData);
                    }else {
                        Map busiData = busiDataRepository.queryOneBusiData(applyNo,rid,busiTypeEnum);
                        if (CollectionUtils.isEmpty(busiData)){
                            return ResponseUtil.build().createBadResponse(HRMateInfo.APPLY_MODIFY_BUSIDATA_ERR.getCode(),
                                    HRMateInfo.APPLY_MODIFY_BUSIDATA_ERR.getMessage() + ",rid:" + rid);
                        }
                        String idKey = "_id";
                        Object id = busiData.get(idKey);
                        recordMap.put(idKey,id);
                        recordMap.put(isOfficalKey,busiData.get(isOfficalKey));
                    }
                    String staffNo = ValueGetTool.getStringFromMap(recordMap,"_BUSINESSID.value");
                    recordMap.put("_APPLY_NO", applyNo);
                    recordMap.put("_CREATE_TIME", createMapValue(Instant.now().toString()));
                    recordMap.put("_APPLY_SUB_TYPE", busiType);
                    recordMap.put("_APPLY_SUB_TYPE_NAME", busiTypeEnum.getValue());


                    recordMap.put(rid_key, rid);
                    recordList.add(recordMap);
                }
        SubtypeEnum subtypeEnum = SubtypeEnum.valueOf(busiType);
        String collectionName = subtypeEnum.getTableName();
        baseMongoService.save(recordList, collectionName);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    // TODO
    public void saveAppendApplyInfo(Request<Map> applyRequest,boolean isNew){

        Map reqData = ValueGetTool.getSubMapFromMap(applyRequest.getData(),"_APPLYINFO");
        String applyNo = ValueGetTool.getStringFromMap(reqData,"_APPLY_NO.value");
        if (CollectionUtils.isEmpty(reqData)){
            return;
        }

        // 将Value包装去掉
        for (Map.Entry<String,Object> entry : (Set<Map.Entry<String,Object>>)reqData.entrySet()){
            String key = entry.getKey();
            Object obj = entry.getValue();
            if (obj != null && obj instanceof Map){
                Map resMap = (Map)obj;
                if (resMap.containsKey("value")){
                    Object value = resMap.get("value");
                    reqData.put(key,value);
                }
            }
        }


        if (isNew){
            reqData.put("_APPLY_TIME", Instant.now());
            reqData.put("_APPLY_STATUS", ApproveStatusEnum.PRE_SUBMIT);
        }else {
            reqData.remove("_APPLY_STATUS");
            reqData.remove("_APPLY_STATUS_NAME");
        }


        String applyType = ValueGetTool.getStringFromMap(reqData,"_APPLY_TYPE");
        String applySubType = ValueGetTool.getStringFromMap(reqData,"_APPLY_SUB_TYPE");
        //reqData.put("_APPLY_TYPE_DESC", ManagementTypeEnum.valueOf(applyType).getValue());
        //reqData.put("_APPLY_SUB_TYPE_DESC",SubtypeEnum.valueOf(applySubType).getValue());

        String staffNo = ValueGetTool.getStringFromMap(reqData,"_BUSINESSID.value");
        String reason = ValueGetTool.getStringFromMap(reqData,"_REASON.value");
        if (reason != null && reason.length() > 100) {
            throw new BusinessException(HRMateInfo.APPLY_REMARK_LONG_OVER_LONG_ERR.getCode(), HRMateInfo.APPLY_REMARK_LONG_OVER_LONG_ERR.getMessage());
        }


        reqData.put(ATTACHMENTS_KEY,applyRequest.getData().get(ATTACHMENTS_KEY));
//        reqData.put("_DATA_PART", dataPart);
//        String partName = ApplyPartEnum.valueOf(dataPart).getValue();
//        reqData.put("_DATA_PART_MAME", partName);
        reqData.put("_MOD_NUM", String.valueOf(0));


        // 设置员工相关信息
        // todo 从SAP获取
        /*****************************************/
        JSONObject staffInfoJson = null;
        String staffJsonStr = staffInfoService.queryStaffInfoByStaffNo(staffNo);
        staffInfoJson = JSONObject.parseObject(staffJsonStr);
        reqData.put("_NAME", ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.NACHN")
                + ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.ENAME"));
        reqData.put("_APPLICANT_ID", ContextSession.getCurrentLoginUserInfo().getStaffNo());
        reqData.put("_APPLICANT_NAME", ContextSession.getCurrentLoginUserInfo().getStaffName());
        reqData.put("_DEPARTMENT_NAME", ContextSession.getCurrentLoginUserInfo().getDepartmentName());
        reqData.put("_BUSINESSID", ContextSession.getCurrentLoginUserInfo().getStaffNo());

        // 新增是否是个人申请字段，用于判断是否是个人申请,个人提交是1   非个人提交是0
        // 当前流程中个有申请业务只有员工转正申请
        String isPersionalApply = SubtypeEnum.valueOf(applySubType) == SubtypeEnum.POSITIVE ? "1":"0";
        reqData.put("_IS_MY_APPLICATION", isPersionalApply);


        // 附件处理
        Object obj =  applyRequest.getData().get("_ATTACHMENTS");
        if (obj != null){
            reqData.put(ATTACHMENTS_KEY,obj);
        }

        if (isNew){
            baseMongoService.save(JSONObject.toJSONString(reqData), HRCollection.HR_STAFF_UPDATE_APPLY);
        }else {
            Query query = new Query();
            query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));

            Update update = new Update();
            for (Map.Entry<String,Object> entry : (Set<Map.Entry<String,Object>>)reqData.entrySet()){
                String key = entry.getKey();
                Object value = entry.getValue();
                update.set(key,value);
            }
            baseMongoService.updateAndFlush(query,update,HRCollection.HR_STAFF_UPDATE_APPLY);
        }

    }

    /**
     * 修改申请信息   注意，修改前已确认申请信息已存在
     * @param applyRequest
     */
    public void updateAppendApplyInfo(Request<Map> applyRequest){

        Map requestDataMap = applyRequest.getData();
        String applyNo = ValueGetTool.getStringFromMap(requestDataMap,"_APPLYINFO._APPLY_NO");
        String busiTypeStr = ValueGetTool.getStringFromMap(requestDataMap,"_APPLYINFO._APPLY_SUB_TYPE");
        Map applyMap = ValueGetTool.getSubMapFromMap(requestDataMap,"_DATA");

        SubtypeEnum busiType = SubtypeEnum.valueOf(busiTypeStr);

        Update update = new Update();
        for (Map.Entry<String,Object> entry : (Set<Map.Entry<String,Object>>) applyMap.entrySet()){
            String key = entry.getKey();
            Object value = entry.getValue();
            update.set(key,value);
        }

        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        baseMongoService.updateAndFlush(query,update,busiType.getTableName());
    }

    /**
     * 查询申请信息 或获取初始化信息
     * 1、有申请编号时，查询对应申请编号的申请信息，未查询到时返回 未查询申请信息
     * 2、无申请编号，生成申请时的初始数据，如业务编号，申请时间、创建人
     * @param applyNo
     * @return
     */
    @Override
    public Response<Map> queryApplyInfoOrInitNewApply(ApplyNoAndTypeDto applyNo){
        String applyNoStr = applyNo.getApplyNo();
        String busiType = applyNo.getBusiType();

        Map applyInfoMap = null;
        if (!StringUtils.isEmpty(applyNoStr)){
            Query query = new Query();
            query.addCriteria(Criteria.where("_APPLY_NO").is(applyNoStr));
            applyInfoMap = baseMongoService.queryOneForMap(query, HRCollection.HR_STAFF_UPDATE_APPLY);
        }
        Map result = new HashMap();
        if (applyInfoMap != null){
            List<Map> attatch = (List<Map>)applyInfoMap.remove(ATTACHMENTS_KEY);
            applyInfoMap.remove("_id");
            convertApplyMap(applyInfoMap);
            result.put("_APPLYINFO",applyInfoMap);
            result.put(ATTACHMENTS_KEY,attatch);


            SubtypeEnum subtypeEnum = SubtypeEnum.valueOf(busiType);
            if (subtypeEnum == SubtypeEnum.POSITIVE){
                //  转正申请时，特殊处理，还原界面申请信息数据结构
                Map busiDataMap = null;
                if (!StringUtils.isEmpty(applyNoStr)){
                    Query query = new Query();
                    query.addCriteria(Criteria.where("_APPLY_NO").is(applyNoStr));
                    busiDataMap = baseMongoService.queryOneForMap(query, subtypeEnum.getTableName());
                }

                if (!CollectionUtils.isEmpty(busiDataMap)){
                    // 去掉固定后增加字段
                    busiDataMap.remove(APPLY_KEY);
                    busiDataMap.remove("_RID");
                    busiDataMap.remove("_IS_OFFICAL_DATA");
                    busiDataMap.remove("_id");
                    result.putAll(busiDataMap);
                }
            }
        }else {
            // 无申请信息时，根据业务类型初始化申请相关的基本信息
            SubtypeEnum subtypeEnum = SubtypeEnum.valueOf(busiType);
            String newApplyNo = bussniessNoGeneratorService.getNewBussniessNo(subtypeEnum);
            Map initApplyInfoMap = new HashMap();
            initApplyInfoMap.put("_APPLY_NO",newApplyNo);
            initApplyInfoMap.put("_APPLY_TIME", Instant.now());
            initApplyInfoMap.put("_APPLY_STATUS",ApproveStatusEnum.PRE_SUBMIT.name());
            initApplyInfoMap.put("_APPLY_STATUS_NAME",ApproveStatusEnum.PRE_SUBMIT.getValue());
            initApplyInfoMap.put("_APPLICANT_NAME",ContextSession.getCurrentLoginUserInfo().getStaffName());
            initApplyInfoMap.put("_APPLY_SUB_TYPE",subtypeEnum.name());
            initApplyInfoMap.put("_APPLY_SUB_TYPE_NAME",subtypeEnum.getValue());
            initApplyInfoMap.put("_MOD_NUM","0");
            convertApplyMap(initApplyInfoMap);
            result.put("_APPLYINFO",initApplyInfoMap);
        }
        return ResponseUtil.build().creatDeaultOkResponse(result);
    }

    private void convertApplyMap(Map applyInfo){
        if(applyInfo == null){
            return;
        }
        for (Map.Entry<String,Object> entry : (Set<Map.Entry<String,Object>>)applyInfo.entrySet()){
            String key = entry.getKey();
            Object obj = entry.getValue();
            if (obj != null && !(obj instanceof Map)){
                Map<String,Object> valueMap = new HashMap<>();
                valueMap.put("value",obj);
                applyInfo.put(key,valueMap);
            }

        }


    }


    @Override
    public PaginationResponse<List<Map>> queryApplyInfoByPageList(PaginationRequest<ApplyNoAndTypeDto> applyNoPaginationRequest) {
        String  applyNoKey = "_APPLY_NO";
        SubtypeEnum busiTypeEnum = SubtypeEnum.valueOf(applyNoPaginationRequest.getData().getBusiType());

        List<Map> applyList = new ArrayList<>();
        String applyNo = applyNoPaginationRequest.getData().getApplyNo();
        Integer page = applyNoPaginationRequest.getPage();
        Integer size = applyNoPaginationRequest.getSize();
        Query query = new Query();
        query.addCriteria(Criteria.where(applyNoKey).is(applyNo));
        query.skip((page - 1) * size).limit(size).with(new Sort(Sort.Direction.DESC, "_RID"));
        List<Map> documentList = baseMongoService.queryOneForMapList(query,busiTypeEnum.getTableName());
        for (Map tmp : documentList) {
            tmp.remove("_id");
            tmp.remove("_class");
        }
        Query queryRows = new Query();
        queryRows.addCriteria(Criteria.where(applyNoKey).is(applyNo));
        long total = baseMongoService.count(queryRows,busiTypeEnum.getTableName());
        return new PaginationResponse(applyNoPaginationRequest.getLanguage(),
                page,
                size,
                (int) total,
                null,
                Response.SUCCESS_CODE, null, documentList);
    }

    private Map createMapValue(Object value){
        Map<String,Object> map = new HashMap();
        map.put("value",value);
        return map;
    }

    /**
     * 上传文件
     * @param fileApplyRequestDto
     * @return
     */
    @Override
    @Transactional(propagation= Propagation.REQUIRES_NEW)
    public Response<Map> uploadApplyData(FileApplyRequestDto fileApplyRequestDto) {
        // todo 加入SAP需要改造
        String applyNo = fileApplyRequestDto.getApplyNo();
        String busiType = fileApplyRequestDto.getBusiType();
        QueryApplyUploadDto queryApplyUploadDto = new QueryApplyUploadDto();
        queryApplyUploadDto.setApplyNo(applyNo);
        queryApplyUploadDto.setBusiType(busiType);
        MultipartFile file = fileApplyRequestDto.getFile();
        PaginationResponse paginationResponse =null;
        Map map = new HashMap();
        PaginationRequest request = new PaginationRequest(queryApplyUploadDto,1,10,null);
        if (file.isEmpty()) {
            throw new BusinessException(FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getCode(), FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getMessage());
        }
        try {

            //生成数据
            // todo SAP后需要改进
            paginationResponse = mockService.queryUploadApplyData(request,false);
            map.putAll((Map) paginationResponse.getData());
            map.put("total",paginationResponse.getTotal());
            map.put("page",paginationResponse.getPage());
            map.put("size",paginationResponse.getSize());
            String fileName = downdAttachFile(file);
            String filePath = "C:\\Users\\Staryang\\Desktop\\";
            UploadApplyDto uploadApplyDto = new UploadApplyDto();
            uploadApplyDto.setApplyNo(applyNo);
            uploadApplyDto.setBusiType(busiType);
            uploadApplyDto.setFilename(fileName);
            uploadApplyDto.setFilePath(filePath);
            staffUpddateApplyDao.save(uploadApplyDto, HRCollection.STAFF_BATCH_UPLOAD);
            log.info("文件上传成功");
        } catch (Exception e) {
            log.error("文件上传失败", e);
            throw new BusinessException(FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getCode(), FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getMessage(), e);
        }
        return new Response(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "Success", map);
    }


    public void saveOrupdateSingleModeBusiData(Map reqDataMap){
        String applyNo = ValueGetTool.getStringFromMap(reqDataMap,"_APPLYINFO._APPLY_NO.value");
        String applyType = ValueGetTool.getStringFromMap(reqDataMap,"_APPLYINFO._APPLY_TYPE.value");
        String applySubType = ValueGetTool.getStringFromMap(reqDataMap,"_APPLYINFO._APPLY_SUB_TYPE.value");

        Map busiData = ValueGetTool.getSubMapFromMap(reqDataMap,"_BUSI_DATA[0]");
        if (CollectionUtils.isEmpty(busiData)){
            //  业务数据无时，从申请信息同级节点中获取业务数据
            Map reqCloneData = new HashMap();
            reqCloneData.putAll(reqDataMap);
            reqCloneData.remove(APPLY_KEY);
            reqCloneData.remove(ATTACHMENTS_KEY);
            busiData = reqCloneData;
        }

        SubtypeEnum busiType = SubtypeEnum.valueOf(applySubType);

        Query query = new Query();
        Criteria criteria = Criteria.where("_APPLY_NO").is(applyNo);
        query.addCriteria(criteria);
        Map map = baseMongoService.queryOneForMap(query, busiType.getTableName());
        String rid = null;
        if (map == null){
            rid = bussniessNoGeneratorService.getNewBussniessNo(busiType);
            busiData.put("_RID",rid);
            busiData.put("_APPLY_NO",applyNo);
        }else {
            rid = ValueGetTool.getStringFromMap(map,"_RID");
        }

        Query queryDetail = new Query();
        Criteria criteria1Detail = Criteria.where("_APPLY_NO").is(applyNo).and("_RID").is(rid);
        queryDetail.addCriteria(criteria1Detail);
        Update update = new Update();
        for (Map.Entry<String,Object> entry :  (Set<Map.Entry<String,Object>>)busiData.entrySet()){
            String key = entry.getKey();
            Object mapData = entry.getValue();
            update.set(key,mapData);
        }
        baseMongoService.updateAndFlush(query,update,busiType.getTableName());
    }

    /**
     * 将临时数据修改成正式数据
     * @param busiType
     * @param applyNo
     */
    public void updateBusiDataOffical(SubtypeEnum busiType,String applyNo){
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));

        long count = baseMongoService.count(query, busiType.getTableName());
        if (count > 0){
            Update update = new Update();
            update.set("_IS_OFFICAL_DATA",true);
            baseMongoService.updateAndFlush(query,update,busiType.getTableName());
        }
    }



    private String downdAttachFile(MultipartFile file) {
        BufferedInputStream buf = null;
        BufferedOutputStream bos = null;

        String oriFile = file.getOriginalFilename();
        int doxIndex = oriFile.lastIndexOf(".");
        if (doxIndex < 0) {
            doxIndex = oriFile.length();
        }
        String filePreName = oriFile.substring(0, doxIndex);
        String suffix = oriFile.substring(doxIndex + 1);
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        String filePath = "C:\\Users\\Staryang\\Desktop\\";
        String storeFileName = filePath + filePreName + "_" + uuid + "." + suffix;
        String filename = filePreName + "_" + uuid + "." + suffix;
        byte[] temp = new byte[1024];
        int len = -1;
        try {
            buf = new BufferedInputStream(file.getInputStream());
            bos = new BufferedOutputStream(new FileOutputStream(new File(storeFileName)));
            while ((len = buf.read(temp, 0, temp.length)) >= 0) {
                bos.write(temp, 0, len);
                bos.flush();
            }
        } catch (Exception e) {
            throw new BusinessException(FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getCode(), FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getMessage(), e);
        } finally {
            try {
                if (null != buf) {
                    buf.close();
                }
                if (null != bos) {
                    bos.close();
                }
            } catch (Exception e) {
                throw new BusinessException(FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getCode(), FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getMessage(), e);
            }
        }
        return filename;
    }

}
