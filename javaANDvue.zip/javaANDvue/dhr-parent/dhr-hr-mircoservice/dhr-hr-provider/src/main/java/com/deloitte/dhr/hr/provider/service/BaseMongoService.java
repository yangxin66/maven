package com.deloitte.dhr.hr.provider.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Mongo基础方法
 * @author chunliucq
 * @since 17/09/2019 16:20
 */
public interface BaseMongoService {
    void save(String jsonData, String collection);

    void updateAndFlush(JSONObject queryJson, Map<String, JSON> updateJson, String collection);

    void updateAndFlush(Query query, Update update, String collection);

    void save(Object obj, String collectionName);

    Map queryOneForMap(Query query,String collectionName);

    List<Map> queryOneForMapList(Query query,String collectionName);

    JSONObject queryOneForJson(Query query,String collectionName);

    void save(List objList, String collectionName);

    void insert(List objList, String collectionName);

    long count(Query query,String collectionName);

    boolean remove(Query query,String collectionName);
}
