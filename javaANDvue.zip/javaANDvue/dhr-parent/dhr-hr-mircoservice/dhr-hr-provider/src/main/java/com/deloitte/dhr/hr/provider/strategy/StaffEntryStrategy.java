package com.deloitte.dhr.hr.provider.strategy;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.dhr.hr.provider.service.StaffInfoService;
import com.deloitte.dhr.hr.provider.service.TaskNodeHandlerService;
import com.deloitte.infrastructure.ex.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 员工入职流程节点相关处理
 * date: 15/10/2019 9:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class StaffEntryStrategy implements Strategy{

    @Autowired
    private TaskNodeHandlerService taskNodeHandlerService;

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    HrNotificationService hrNotificationService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Override
    public boolean nodeHandler(AuditHandlerDto auditHandlerDto, String staffId,
                               String applyNo) {
        // 如果状态是提交就不用判断信息完整性
        if(ApplicationStatusEnum.SUBMITTED != auditHandlerDto.getApplicationStatusEnum()) {
            // 校验入职信息是否完整
            boolean isComplete = staffInfoService.isAllFillInComplete(staffId);

            if (!isComplete) {
                throw new BusinessException(HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getCode(), HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getMessage());
            }
        }
        boolean ended = taskNodeHandlerService.commonFlowNodeHandler(auditHandlerDto);
        if (ended) {
            PageDataRequest staffInfo = staffInfoDao.getStaffByStaffId(staffId);
            // TODO 调用SAP的添加员工入职信息接口 staffInfo是审批通过的员工信息
        }
        return ended;

    }

    @Override
    public void batchSendEmail(List<String> staffIds) {
        List<PageDataRequest> pageDataRequests = staffInfoDao.getStaffInfoDetailByStaffIds(staffIds);
        if (pageDataRequests == null || pageDataRequests.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_CODE_REPEAT_ERR.getCode(), HRMateInfo.STAFF_CODE_REPEAT_ERR.getMessage());
        }
        // 发送审批通过邮件
        hrNotificationService.batchSendApproveEmail(pageDataRequests);
    }

    @Override
    public ManagementTypeEnum getManagementType() {
        return ManagementTypeEnum.CREATE_STAFF;
    }
}
