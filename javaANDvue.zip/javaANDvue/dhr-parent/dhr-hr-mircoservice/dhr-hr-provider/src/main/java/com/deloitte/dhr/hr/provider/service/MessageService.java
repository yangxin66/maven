package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.model.MessageBatchAddDto;
import com.deloitte.dhr.hr.api.model.MessageCountDto;
import com.deloitte.dhr.hr.api.model.MessageDetailDto;
import com.deloitte.dhr.hr.api.model.MessageDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.util.List;

/**
 * date: 10/10/2019 20:59
 *
 * @author wgong
 * @since 0.0.1
 */
public interface MessageService {

    void addMessage(MessageBatchAddDto messageAddDtos);

    PaginationResponse<List<MessageDto>> findMessageByTypeAndPage(PaginationRequest<MessageTypeEnum> messageTypePaginationReq);

    MessageCountDto getMyAllMessageNum();

    MessageDetailDto findById(String id);

    void readMessage(String id);

    void deleteMessage(String id);

    void sendAllMessage(MessageBatchAddDto messageAddDto);
}
