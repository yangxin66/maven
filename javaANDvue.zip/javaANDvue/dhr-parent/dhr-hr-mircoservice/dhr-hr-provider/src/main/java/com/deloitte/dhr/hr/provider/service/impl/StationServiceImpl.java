package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.hr.api.model.OrganizationDto;
import com.deloitte.dhr.hr.api.model.OrganizationQueryDto;
import com.deloitte.dhr.hr.api.model.OrganizationSearchDto;
import com.deloitte.dhr.hr.api.model.OrganizationSearchResDto;
import com.deloitte.dhr.hr.provider.service.StationService;
import com.deloitte.dhr.hr.provider.utils.PaginationUtils;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * date: 21/08/2019 16:13
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class StationServiceImpl implements StationService {
    @Override
    public PaginationResponse<List<OrganizationSearchResDto>> getStationByPage(PaginationRequest<OrganizationSearchDto> paginationRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(paginationRequest.getPage(), paginationRequest.getSize());
        List<OrganizationSearchResDto> stationData = createStationData(pageRequest.getPageNumber(), pageRequest.getPageSize());
        return new PaginationResponse(paginationRequest.getLanguage(),
                pageRequest.getPageNumber(),
                pageRequest.getPageSize(),
                20,
                null,
                Response.SUCCESS_CODE, null, stationData);
    }

    @Override
    public PaginationResponse<List<OrganizationSearchResDto>> getDepartmentByPage(PaginationRequest<OrganizationSearchDto> paginationRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(paginationRequest.getPage(), paginationRequest.getSize());
        List<OrganizationSearchResDto> stationData = createOrgData(pageRequest.getPageNumber(), pageRequest.getPageSize());
        return new PaginationResponse(paginationRequest.getLanguage(),
                pageRequest.getPageNumber(),
                pageRequest.getPageSize(),
                20,
                null,
                Response.SUCCESS_CODE, null, stationData);
    }

    @Override
    public PaginationResponse<List<OrganizationSearchResDto>> getUnitByPage(PaginationRequest<OrganizationSearchDto> paginationRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(paginationRequest.getPage(), paginationRequest.getSize());
        List<OrganizationSearchResDto> stationData = createUnitData(pageRequest.getPageNumber(), pageRequest.getPageSize());
        return new PaginationResponse(paginationRequest.getLanguage(),
                pageRequest.getPageNumber(),
                pageRequest.getPageSize(),
                20,
                null,
                Response.SUCCESS_CODE, null, stationData);
    }



    /**
     * 根据上级组织编号和类型查找组织
     *
     * @param organizationQueryDto 组织查询传输实体
     */
    @Override
    public List<OrganizationDto> getOrganizationChild(OrganizationQueryDto organizationQueryDto) {
        OrganizationDto organizationDto1;
        OrganizationDto organizationDto2;
        OrganizationDto organizationDto3;
        List<OrganizationDto> organizationDtos = new ArrayList<>();
        if (StringUtils.isEmpty(organizationQueryDto.getParentCode()) && StringUtils.isEmpty(organizationQueryDto.getType())) {
            organizationDto1 = OrganizationDto.builder().code("1111").name("公司A").type("C").build();
            organizationDtos.add(organizationDto1);
        } else if ("1111".equals(organizationQueryDto.getParentCode()) && StringUtils.isEmpty(organizationQueryDto.getType())) {
            organizationDto2 = OrganizationDto.builder().code("2222").name("部门A").type("O").build();
            organizationDto3 = OrganizationDto.builder().code("3333").name("岗位A").type("S").build();
            organizationDtos.add(organizationDto2);
            organizationDtos.add(organizationDto3);
        } else if ("1111".equals(organizationQueryDto.getParentCode()) && "C,O".equals(organizationQueryDto.getType())) {
            organizationDto2 = OrganizationDto.builder().code("2222").name("部门A").type("O").build();
            organizationDto3 = OrganizationDto.builder().code("5555").name("子公司B").type("C").build();
            organizationDtos.add(organizationDto2);
            organizationDtos.add(organizationDto3);
        }else if ("1111".equals(organizationQueryDto.getParentCode()) && "C".equals(organizationQueryDto.getType())) {
            organizationDto3 = OrganizationDto.builder().code("5555").name("子公司B").type("C").build();
            organizationDtos.add(organizationDto3);
        } else if ("2222".equals(organizationQueryDto.getParentCode()) && StringUtils.isEmpty(organizationQueryDto.getType())) {
            organizationDto3 = OrganizationDto.builder().code("4444").name("岗位B").type("S").build();
            organizationDtos.add(organizationDto3);
        }else if ("2222".equals(organizationQueryDto.getParentCode()) && ("C,O".equals(organizationQueryDto.getType()))) {
            organizationDto3 = OrganizationDto.builder().code("6666").name("子部门B").type("O").build();
            organizationDtos.add(organizationDto3);
        }
        return organizationDtos;
    }

    private List<OrganizationSearchResDto> createStationData(int page, int size) {
        int s = page * size;
        List<OrganizationSearchResDto> list = new ArrayList<>(10);
        for (int i = 0; i < size; i++) {
            s++;
            OrganizationSearchResDto stationDto = new OrganizationSearchResDto("" + s, "测试岗位" + s, "100" + s,
                    "测试部门" + s);
            list.add(stationDto);
        }
        return list;
    }

    private List<OrganizationSearchResDto> createOrgData(int page, int size) {
        int s = page * size;
        List<OrganizationSearchResDto> list = new ArrayList<>(10);
        for (int i = 0; i < size; i++) {
            s++;
            OrganizationSearchResDto stationDto = new OrganizationSearchResDto("" + s, "测试部门" + s, "100" + s,
                    "测试公司" + s);
            list.add(stationDto);
        }
        return list;
    }

    private List<OrganizationSearchResDto> createUnitData(int page, int size) {
        int s = page * size;
        List<OrganizationSearchResDto> list = new ArrayList<>(10);
        for (int i = 0; i < size; i++) {
            s++;
            OrganizationSearchResDto stationDto = new OrganizationSearchResDto("" + s, "测试子单位" + s, "100" + s,
                    "测试单位" + s);
            list.add(stationDto);
        }
        return list;
    }
}
