package com.deloitte.dhr.hr.provider.mongo.dao.model;

import lombok.Data;

/**
 * 编号生成规则
 * @author chunliucq
 * @since 04/09/2019 20:38
 */
@Data
public class BusinessNoRule {
    /**
     * 编号模板
     */
    private String pattern;
    /**
     * 序号起始值
     */
    private Long start;
    /**
     * 当前序号
     */
    private Long index;
    /**
     * 序号增量
     */
    private Long step;
    /**
     * 当前日期  格式：yyyyMMdd
     */
    private String date;

}
