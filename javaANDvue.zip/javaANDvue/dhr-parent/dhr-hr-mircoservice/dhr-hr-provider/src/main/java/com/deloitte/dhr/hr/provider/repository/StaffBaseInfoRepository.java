package com.deloitte.dhr.hr.provider.repository;

import org.springframework.stereotype.Repository;

@Repository
interface StaffBaseInfoRepository  {

/*    Optional<UserPo> findByMobileAndDeletedIsFalse(String mobile);

    // 通过用户名查询用户信息
    UserPo findByMobileAndDeletedFalseAndEnabledTrue(String username);

    // 通过邮箱查询用户信息
    UserPo findByEmailAndDeletedFalseAndEnabledTrue(String username);*/

}
