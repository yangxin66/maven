package com.deloitte.dhr.hr.provider.repository.model;

import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "dhr_business_enum_item")
@Entity(name = "EnumItem")
@SQLDelete(sql = "update Enum set EnumItem.deleted = 1 where EnumItem.id = ?")
@Where(clause = "deleted = 0")
public class EnumItemPo extends BasePo {

    private static final long serialVersionUID = -2272339648956531994L;

    @Column(name = "enum_id")
    private Long enumId;

    //分组id
    @Column(name = "code", length = 20)
    private String code;

    //描述
    @Column(name = "item_des", length = 254)
    private String description;

    //枚举项id
    @Column(name = "item_code", length = 50)
    private String itemCode;

    //  枚举项值
    @Column(name = "item_value", length = 254)
    private String itemValue;

    @Column(name = "pid", length = 20)
    private String pid;   //pid

    //路径
    @Column(name = "item_path", length = 254)
    private String itemPath;

    //层级
    @Column(name = "item_level")
    private Integer itemLevel;
}
