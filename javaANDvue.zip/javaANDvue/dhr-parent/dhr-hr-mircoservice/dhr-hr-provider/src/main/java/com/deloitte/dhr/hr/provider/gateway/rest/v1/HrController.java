package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.HrInterface;
import com.deloitte.dhr.hr.api.model.SearchStaffCategoryInfoDto;
import com.deloitte.dhr.hr.api.model.SendStaffEmailDTO;
import com.deloitte.dhr.hr.api.model.VerifyStaffInfoDTO;
import com.deloitte.dhr.hr.provider.service.HrService;
import com.deloitte.dhr.hr.provider.service.StaffInfoService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


/**
 * hr填写信息
 * <br/>27/08/2019 11:32
 *
 * @author lshao
 */
@RestController
@RequestMapping(value = "/api/v1/hr", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class HrController implements HrInterface {
    @Autowired
    private HrService hrService;

    @Autowired
    private StaffInfoService staffInfoService;

    @PostMapping(value = "/save")
    @Override
    public Response<String> saveStaffInfo(@RequestBody Request<PageDataRequest> request) {
//        JSONObject jsonObject = ContextSession.getTokenJson();
        return hrService.save(request);
    }

    @Override
    @PostMapping(value = "/sendStaffEmail")
    public Response<String> sendStaffEmail(@RequestBody Request<SendStaffEmailDTO> request) {
        this.hrService.choiceSendStaffEmail(request.getData());
        return new Response<>(request.getLanguage(), Response.SUCCESS_CODE, null, null);
    }

    @Override
    public Response<String> verifyStaffInfo(@RequestBody Request<VerifyStaffInfoDTO> request) {

        return this.hrService.verifyStaffInfo(request);
    }

    /**
     * HR 修改员工信息  直接修改，并同步到SAP中
     * @param request
     * @return
     */
    @ApiOperation(value = "HR 修改员工信息",notes = "HR 直接修改员工信息同时更新到SAP")
    @ApiImplicitParam(name = "request", value = "员工信息", required = true, dataType = "Request«Map»")
    @Override
    @PostMapping(value = "/update/staffinfo")
    public Response<Void> updateStaffInfoByHr(@RequestBody Request<Map> request) {
        // todo check
        JSONObject reqData = new JSONObject(request.getData());
        // 先直接修改DHR中员工信息
        staffInfoService.savePartStaffInfo(reqData);

        // 将员工信息同步修改到SAP中
        hrService.updateStaffInfoByHr(reqData);
        return ResponseUtil.build().creatDeaultOkResponse(request.getLanguage(),null);
    }

    /**
     * HR 修改员工信息  直接修改，并同步到SAP中
     * @param request
     * @return
     */
    @ApiOperation(value = "员工信息变更-弹窗搜索查询",notes = "员工信息变更-弹窗搜索查询")
    @ApiImplicitParam(name = "request", value = "员工信息", required = true, dataType = "Request«SearchStaffCategoryInfoDto»")
    @Override
    @PostMapping(value = "/searchStaffCategoryInfo")
    public Response<JSONObject> searchStaffCategoryInfo(@RequestBody Request<SearchStaffCategoryInfoDto> request) {
        return ResponseUtil.build().creatDeaultOkResponse(request.getLanguage(),hrService.searchStaffCategoryInfo(request.getData()));
    }

}
