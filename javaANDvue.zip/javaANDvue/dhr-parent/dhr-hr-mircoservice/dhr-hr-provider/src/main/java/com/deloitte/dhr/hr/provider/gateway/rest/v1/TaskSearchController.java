package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.hr.api.TaskSearchInterface;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 任务查询接口
 *
 * @author chunliucq
 * @since 22/08/2019 11:25
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/hr/task", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class TaskSearchController implements TaskSearchInterface {


    @Autowired
    TaskSearchService taskSearchService;


    @Override
    @PostMapping("/search")
    @ApiOperation(value = "搜索待办已办任务")
    @ApiImplicitParam(name = "searchDtoPaginationRequest", value = "员工修改信息申请查询实体", required = true, dataType = "PaginationRequest«SearchDto»")
    public PaginationResponse<List<StaffInfoApplyDto>> searchStaffInfoTask(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
        return taskSearchService.searchTaskByPage(searchDtoPaginationRequest);
    }

    @Override
    @PostMapping("/search/my_application")
    @ApiOperation(value = "搜索我的申请")
    @ApiImplicitParam(name = "searchDtoPaginationRequest", value = "员工修改信息申请查询实体", required = true, dataType = "PaginationRequest«SearchDto»")
    public PaginationResponse<List<StaffInfoApplyDto>> searchMyApplicationByPage(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest) {
        return taskSearchService.searchMyApplicationByPage(searchDtoPaginationRequest);
    }

}
