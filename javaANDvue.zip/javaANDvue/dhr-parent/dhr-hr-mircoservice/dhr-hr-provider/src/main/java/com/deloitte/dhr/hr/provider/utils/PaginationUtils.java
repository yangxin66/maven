package com.deloitte.dhr.hr.provider.utils;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

import java.util.Collections;
import java.util.Map;

import static com.deloitte.infrastructure.jpa.service.pagination.PaginationConstant.*;


/**
 * 通用实体模型实现
 *
 * @author xideng
 */
public class PaginationUtils{


    /**
     * 默认的排序类型：ASC 正序排序
     */
    protected static final Sort.Direction DEFAULT_DIRECTION = Sort.DEFAULT_DIRECTION;

    /**
     * 预先留存的【字符串：排序类型】映射
     */
    protected static final Map<String, Sort.Direction> SORT_TYPE_MAPPING = Collections.singletonMap("DESC", Sort.Direction.DESC);

    /**
     * 对分页参数进行处理，并生成{@link PageRequest}分页对象
     *
     * @param page       分页页码
     * @param size       每页数据量
     * @param sortType   排序方式
     * @param properties 排序字段
     * @return Spring Data JPA分页对象
     */
    public static PageRequest pagePrepare(Integer page, Integer size, String sortType, String... properties) {
        Sort sort = null;
        // 判断是否需要排序，判断的逻辑是，只要有排序字段，那么就当做是需要排序的
        if (null != properties && properties.length > 0) {
            Sort.Direction direction = getDirectionFromString(sortType);
            sort = Sort.by(direction, properties);
        }

        // 对参数page进行校验和处理
        if (null == page || page < MIN_PAGE_FOR_VALID) {
            page = DEFAULT_PAGE;
        } else {
            // spring data jpa的第一页页码为0，所以期望外部传递正确的page，我们自己在方法内部进行处理
            page -= 1;
        }

        // 对参数size进行校验和处理
        if (null == size || size < MIN_SIZE_FOR_VALID) {
            size = DEFAULT_SIZE;
        } else if (size > MAX_SIZE_FOR_VALID) {
            size = MAX_SIZE_FOR_VALID;
        }

        if (null == sort) {
            return PageRequest.of(page, size);
        } else {
            return PageRequest.of(page, size, sort);
        }
    }

    /**
     * 简化{@link #pagePrepare(Integer, Integer, String, String...)}
     */
    public static PageRequest pagePrepare(Integer page, Integer size) {
        return pagePrepare(page, size, null);
    }

    /**
     * 将指定的<code>value</code>参数转换为{@link Sort.Direction}类型，
     * 如果<code>value</code>不合法导致服务转换你为{@link Sort.Direction}，则默认返回{@link #DEFAULT_DIRECTION}
     */
    private static Sort.Direction getDirectionFromString(String value) {
        if (null != value) {
            String upperV = value.toUpperCase();
            Sort.Direction direction = SORT_TYPE_MAPPING.get(upperV);
            return null == direction ? DEFAULT_DIRECTION : direction;
        }
        return DEFAULT_DIRECTION;
    }
}
