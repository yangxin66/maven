package com.deloitte.dhr.hr.provider.strategy;

import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 策略工厂
 * 根据不同的类型 审批处理不同的情况
 * date: 15/10/2019 17:08
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class StrategyManagement {

    @Autowired
    List<Strategy> strategyList;

//    static  {
//        strategyMap.put(ManagementTypeEnum.CREATE_STAFF, new StaffEntryStrategy());
//        strategyMap.put(ManagementTypeEnum.STAFF_INFO_MODIFY, new StaffInfoModifyStrategy());
//        strategyMap.put(ManagementTypeEnum.DECREASE_BOOK, new DecreaseBookStrategy());
//        strategyMap.put(ManagementTypeEnum.POSITION_CHANGE, new PositiveStrategy());
//        strategyMap.put(ManagementTypeEnum.POSITIVE, new PositiveStrategy());
//        strategyMap.put(ManagementTypeEnum.AND_POST, new AndPostStrategy());
//        strategyMap.put(ManagementTypeEnum.CONTRACT_MANAGEMENT, new ContractStrategy());
//    }

    public Strategy create(ManagementTypeEnum managementTypeEnum) {
        for (Strategy strategy : strategyList) {
            if (managementTypeEnum == strategy.getManagementType()) {
                return strategy;
            }
        }
        return null;
    }
}
