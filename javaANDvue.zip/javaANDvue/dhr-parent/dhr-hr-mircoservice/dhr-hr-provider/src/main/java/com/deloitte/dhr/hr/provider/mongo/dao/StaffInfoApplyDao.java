package com.deloitte.dhr.hr.provider.mongo.dao;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.model.StaffInfoApplyDto;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * date: 24/09/2019 17:06
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class StaffInfoApplyDao {

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    BaseMongoService baseMongoService;

    public StaffInfoApplyDto queryStaffInfoByProcessInstantId(String id){
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_PROCESS_INSTANCE_ID").is(id)), Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        if (list.size() == 0) {
            return null;
        }
        return SerializerUtils.deserialize(JSONObject.toJSONString(list.get(0)), StaffInfoApplyDto.class);
    }

    public StaffInfoApplyDto queryStaffInfoByApplyNo(String applyNo){
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        if (list.size() == 0) {
            return null;
        }
        return SerializerUtils.deserialize(JSONObject.toJSONString(list.get(0)), StaffInfoApplyDto.class);
    }


    /**
     * 将完成的状态更新到申请表中
     *
     * @param applyNo 业务编码
     * @param status  流程状态
     */
    public void updateStaffUpdateApplyStatus(String applyNo, String status, boolean ended) {
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String currentStaffNo = currentLoginUserInfo.getStaffNo();
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        List<Map> staffUpdateApplys = baseMongoService.queryOneForMapList(query, HRCollection.HR_STAFF_UPDATE_APPLY);
        if (staffUpdateApplys == null || staffUpdateApplys.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_UPDATE_APPLY_NO_IS_ERR.getCode(), HRMateInfo.STAFF_UPDATE_APPLY_NO_IS_ERR.getMessage());
        }
        Update update = new Update();
        update.set("_APPLY_STATUS", status);
        update.set("_APPLY_STATUS_NAME", ApproveStatusEnum.valueOf(status).getValue());
        if (ended) {
            update.set("_AUDIT_ID", currentStaffNo);
            update.set("_AUDIT_NAME", ContextSession.getCurrentLoginUserInfo().getStaffName());
            update.set("_AUDIT_TIME", Instant.now().toString());
        }
        baseMongoService.updateAndFlush(query, update, HRCollection.HR_STAFF_UPDATE_APPLY);
    }

    /**
     * 将发送邮件次数加一
     *
     * @param applyNo 业务编码
     */
    public void updateCreateStaffSendEmailNum(String applyNo) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        List<Map> staffUpdateApplys = baseMongoService.queryOneForMapList(query, HRCollection.HR_STAFF_UPDATE_APPLY);
        if (staffUpdateApplys == null || staffUpdateApplys.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_UPDATE_APPLY_NO_IS_ERR.getCode(), HRMateInfo.STAFF_UPDATE_APPLY_NO_IS_ERR.getMessage());
        }
        Map staffUpdateApply =  staffUpdateApplys.get(0);
        Object emailNum = staffUpdateApply.get("_SEND_EMAIL_NUM");
        int num = 0;
        if (emailNum != null) {
            num = (int)emailNum + 1;
        }
        Update update = new Update();
        update.set("_SEND_EMAIL_NUM", num);
        baseMongoService.updateAndFlush(query, update, HRCollection.HR_STAFF_UPDATE_APPLY);
    }
}
