package com.deloitte.dhr.hr.provider.gateway.rest.v1;



import com.deloitte.dhr.hr.api.ExcelOutInterface;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.service.ExcelExportService;
import com.deloitte.dhr.hr.provider.service.MockService;
import com.deloitte.infrastructure.communication.Request;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.Objects;

@Controller
@RequestMapping(value = "/api/v1/export")
public class ExcelController  implements ExcelOutInterface{


    @Autowired
    ExcelExportService excelExportService;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    MockService mockService;


    @Override
    @PostMapping(value = "/excel/currency/all")
    @ApiOperation(value = "导出全部excel", notes = "导出实体")
    @CrossOrigin("*")
    public void getInfoExcelCurrencyALL(@RequestBody Request<ExcelOutExportCurrencyALLDto> excelOutExportCurrencyALLDtoRequest) throws IOException,
            ParseException {
        ExcelOutExportCurrencyALLDto exportCurrencyALLDtoRequestData = excelOutExportCurrencyALLDtoRequest.getData();
        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        excelExportService.ExcelOutExportCurrencyAll(response, exportCurrencyALLDtoRequestData);

    }

    @Override
    @PostMapping(value = "/excel/currency/batch")
    @ApiOperation(value = "导出勾选excel", notes = "导出实体")
    @CrossOrigin("*")
    public void getInfoExcelCurrencyBatch(@RequestBody Request<ExcelOutExportCurrencyBatchDto> exportCurrencyDtoRequest) throws IOException, ParseException {
        ExcelOutExportCurrencyBatchDto currencyDtoRequestData = exportCurrencyDtoRequest.getData();
        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        excelExportService.ExcelOutExportCurrencyBatch(response, currencyDtoRequestData);
    }

    @Override
    @ApiOperation(value = "导出员工全部信息", notes = "导出员工全部信息到Excel中")
    @PostMapping(value = "/excel")
    public void getInfoExcel(@RequestBody Request<ExcelOutExprotDto> excelOutExprotDtoRequest) throws IOException
            , ParseException {
        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        ExcelOutExprotDto excelOutExprotDto = excelOutExprotDtoRequest.getData();
        excelExportService.ExcelOutExport(response, excelOutExprotDto);
    }


    @Override
    @ApiOperation(value = "导出申请信息", notes = "hr导出员工全部或部分申请信息到Excel中")
    @PostMapping(value = "/excel/apply/hr")
    public void getApplyExcelHr(@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException {

        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();

        ExcelApplyExportDto excelApplyExportDto = excelApplyExportDtoRequest.getData();

        excelExportService.ExcelAPPlyOutExport(response, excelApplyExportDto);

    }

    @Override
    @ApiOperation(value = "导出申请信息", notes = "Staff导出员工全部或部分申请信息到Excel中")
    @PostMapping(value = "/excel/apply/staff")
    public void getApplyExcelStaff(@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException, ParseException {

        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();

        ExcelApplyExportDto excelApplyExportDto = excelApplyExportDtoRequest.getData();

        excelExportService.ExcelAPPlyOutExportMy(response, excelApplyExportDto);
    }

    @Override
    @ApiOperation(value = "个人信息审批查看信息导出excel", notes = "个人信息审批查看信息到Excel中")
    @PostMapping("/excel/apply/audit")
    @CrossOrigin("*")
    public void getApplyAuditExcel(@RequestBody Request<ExcelApplyDetailedDto> excelApplyDetailedDtoRequest) throws IOException,
            ParseException {

        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();

        ExcelApplyDetailedDto excelApplyDetailedDto = excelApplyDetailedDtoRequest.getData();

        excelExportService.ExcelAPPlyAuditOutExport(response, excelApplyDetailedDto);
    }


    @Override
    @PostMapping("/download/excel")
    @ApiOperation(value = "下载数据模板")
    @ApiImplicitParam(name = "request", value = "下载数据模板",
            required = true, dataType = "Request«string»")
    public void downloadExcel(@RequestBody Request<String> request) throws IOException {
        SubtypeEnum subtypeEnum = SubtypeEnum.valueOf(request.getData());
        mockService.downloadExcel(subtypeEnum);
    }
}
