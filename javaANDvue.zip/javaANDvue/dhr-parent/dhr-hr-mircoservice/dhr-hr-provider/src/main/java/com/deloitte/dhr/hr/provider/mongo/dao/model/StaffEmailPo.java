package com.deloitte.dhr.hr.provider.mongo.dao.model;

import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;

/**
 * <br/>27/08/2019 17:49
 *
 * @author lshao
 */
@Data
@Document(collection = HRCollection.HR_STAFF_EMAIL_STATUS)
public class StaffEmailPo implements Serializable {

    private static final long serialVersionUID = 1056205364485254029L;

    @Id
    private String id;

    private String businessId;

    private Boolean sendFlag;

    private String owner;

}
