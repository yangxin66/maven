package com.deloitte.dhr.hr.provider.gateway.rest.v1.demo;

import com.alibaba.fastjson.JSON;
import com.deloitte.dhr.metadata.component.element.form.field.datetime.DateSelectValue;
import com.deloitte.dhr.metadata.component.element.form.field.hidden.HiddenValue;
import com.deloitte.dhr.metadata.component.element.form.field.input.TextInputValue;
import com.deloitte.dhr.metadata.component.element.form.field.select.SelectValue;
import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * TODO
 *
 * @author xideng
 */
@RestController
@RequestMapping("/api/v1/demo")
public class DemoRestController {

    @PostMapping("/submit")
    public Response<?> submit() {
        Map<String, Object> map = new HashMap<>();
        map.put("model", new Model("_BASE", "id"));
        map.put("modelValue", HiddenValue.of("123"));
        return new Response<>(null, Response.SUCCESS_CODE, null, map);
    }

    @PostMapping("/email")
    public Response<?> email() {
        return new Response<>(null, Response.SUCCESS_CODE, null, null);
    }

    @GetMapping("/table")
    public Response<List<Map<String, ModelValue>>> table(HttpServletRequest request) {
        List<Map<String, ModelValue>> data = new ArrayList<>(10);
        for (int i = 0; i < 10; i++) {
            Map<String, ModelValue> row = new HashMap<>();
            DateSelectValue v1 = new DateSelectValue();
            v1.setValue("2019-09-01");
            row.put("_OPTIONTIME", v1);
            TextInputValue v2 = new TextInputValue();
            v2.setValue("张");
            row.put("_DATA._BASE.NACHN", v2);
            TextInputValue v3 = new TextInputValue();
            v3.setValue(String.valueOf((i + 1) * 10000));
            row.put("_BUSINESSID", v3);
            SelectValue v4 = new SelectValue();
            if (i % 2 == 0) {
//                v4.setText("待审批");
                v4.setValue(true);
            } else {
//                v4.setText("未发送邮件");
                v4.setValue(false);
            }
            row.put("sendFlag", v4);
            TextInputValue v5 = new TextInputValue();
            v5.setValue(String.valueOf((i + 1) * 12345));
            row.put("_DATA._BASE.DHRSFZH", v5);

            data.add(row);
        }
        return new Response<>(null, Response.SUCCESS_CODE, null, data);
    }


    @PostMapping("/getProcessInfo")
    public Response<Object> getProcessInfo(@RequestBody Request<Map> req, HttpServletRequest request) {
        System.out.println(req.getData());
        String dataStr = "{\n" +
                "\t\"_APPLYINFO\": {\n" +
                "\t\t\"_BUSINESSID\": {\"value\":\"1569591873308\"},\n" +
                "\t\t\"_APPLY_TYPE\":  {\"value\":\"DECREASE_BOOK\"},\n" +
                "\t\t\"_APPLY_TYPE_TXT\": {\"value\":\"岗位变更\"} ,\n" +
                "\t\t\"_APPLY_SUB_TYPE\":  {\"value\":\"DIMISSION\"},\n" +
                "\t\t\"_APPLY_SUB_TXT\": {\"value\":\"未提交\"} ,\n" +
                "\t\t\"_CREATOR\": {\"value\": \"张三\"} ,\n" +
                "\t\t  \"_CREATE_TIME\":{\"value\":\"2019-10-11 19:47:19\"}\n" +
                "\t}\n" +
                "}";
        String a = "{\"time\":\""+LocalDateTime.now()+"\"}";
        System.out.println(JSON.parse(a));
        return new Response<>(null, Response.SUCCESS_CODE, null, JSON.parse(dataStr));
    }
}
