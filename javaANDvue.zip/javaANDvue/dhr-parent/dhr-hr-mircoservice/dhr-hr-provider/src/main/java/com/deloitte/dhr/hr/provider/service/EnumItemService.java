package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.provider.repository.model.EnumItemPo;

import java.util.List;

/**
 * @author chunliucq
 * @since 30/08/2019 17:12
 */
public interface EnumItemService {

    /**
     * 根据code查询枚举项
     * @param code
     * @return
     */
    List<EnumItemPo> queryEnum(String code);
}
