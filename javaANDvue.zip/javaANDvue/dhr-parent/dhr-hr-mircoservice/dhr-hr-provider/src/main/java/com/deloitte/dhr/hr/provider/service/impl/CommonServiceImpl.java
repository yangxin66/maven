package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.CommonStringConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.model.StaffInfoModifyDto;
import com.deloitte.dhr.hr.api.model.staff.StaffInfoUpdateApplyRdOpEnum;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.redis.CommonRedisRepository;
import com.deloitte.dhr.hr.provider.redis.RedisConstant;
import com.deloitte.dhr.hr.provider.service.BussniessNoGeneratorService;
import com.deloitte.dhr.hr.provider.service.CommonService;
import com.deloitte.infrastructure.ex.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 通用方法
 *
 * @author chunliucq
 * @since 29/08/2019 9:13
 */
@Service
public class CommonServiceImpl implements CommonService {

    @Autowired
    private CommonRedisRepository redisRepository;

    @Autowired
    BussniessNoGeneratorService bussniessNoGeneratorService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public String generatorToken(String businessId) {
        String token = UUID.randomUUID().toString();
        redisRepository.set(RedisConstant.EMAIL_STAFF_VERIFY_TOKEN + token, businessId, 24 * 60 * 60, TimeUnit.SECONDS);
        return token;
    }

    @Override
    public String getEmailTokenStaffNo(String token) {
        String staffNo = (String) redisRepository.get(RedisConstant.EMAIL_STAFF_VERIFY_TOKEN + token);
        return staffNo;
    }

    @Override
    public String modifySapStaffInfo(StaffInfoModifyDto staffInfoModifyDto) {
        // TODO 需要改成SAP的接口
        Map<String, Object> newData = staffInfoModifyDto.getData();
        String staffNo = staffInfoModifyDto.getStaffNo();
        String part = staffInfoModifyDto.getPart();
        JSONArray jsonArray;
        StaffInfoUpdateApplyRdOpEnum op = staffInfoModifyDto.getOp();
        String rid = bussniessNoGeneratorService.getNewBussniessNo(CommonStringConstant.BUSINESSNO_RID_KEY);
        if (StaffInfoUpdateApplyRdOpEnum.OP_NEW == op) {
            // 新增操作
            jsonArray = addSingleStaffInfo(newData, staffNo, part, rid);

        } else if (StaffInfoUpdateApplyRdOpEnum.OP_DELETE == op || StaffInfoUpdateApplyRdOpEnum.OP_UPDATE == op) {
            Object rid1 = newData.get("_RID");
            if (rid1 == null || StringUtils.isBlank((String) rid1)) {
                throw new BusinessException(HRMateInfo.STAFF_INFO_MODIFY_RID_ERR.getCode(),
                        HRMateInfo.STAFF_INFO_MODIFY_RID_ERR.getMessage());
            }
            rid = (String) rid1;
            // 修改操作
            jsonArray = modifyOrDeleteSingleStaffInfo(newData, staffNo, part, op);
        } else {

            // 不做任何操作
            return null;
//            throw new BusinessException(HRMateInfo.STAFF_INFO_MODIFY_STATUS_IS_ERR.getCode(), HRMateInfo.STAFF_INFO_MODIFY_STATUS_IS_ERR.getMessage());
        }
        if (jsonArray != null) {
            JSONObject queryJson = new JSONObject();
            queryJson.put(StaffInfoServiceImpl.STAFF_INFO_BUSINESSID, staffNo);
            Map<String, JSON> updateJson = new HashMap<>();
            updateJson.put("_DATA" + "." + part, jsonArray);
            staffInfoDao.updateAndFlush(queryJson, updateJson, HRCollection.HR_STAFF_INFO);
        }
        return rid;
    }

    private JSONArray addSingleStaffInfo(Map<String, Object> newData, String staffNo, String part, String rid) {
        PageDataRequest staffInfoDetail = staffInfoDao.getStaffByStaffId(staffNo);
        JSONObject staffInfo = staffInfoDetail.getData();
        JSONArray jsonArray;
        Object partJsonObject = staffInfo.get(part);
        if (partJsonObject == null) {
            newData.put("_RID", rid);
            jsonArray = new JSONArray();
            // 新增
            jsonArray.add(newData);
        } else {

            String s = JSON.toJSONString(partJsonObject);
            Object object = JSON.parse(s);
            // 如果本身是个对象 则不允许新增数据
            if (object instanceof JSONObject) {
                throw new BusinessException(HRMateInfo.STAFF_INFO_MODIFY_ADD_IS_ERR.getCode(), HRMateInfo.STAFF_INFO_MODIFY_ADD_IS_ERR.getMessage());
            } else {
                // 允许增加一条数据
                newData.put("_RID", rid);
                jsonArray = (JSONArray) object;
                // 新增
                jsonArray.add(newData);
            }
        }
        return jsonArray;

    }

    private JSONArray modifyOrDeleteSingleStaffInfo(Map<String, Object> newData, String staffNo, String part,
                                                    StaffInfoUpdateApplyRdOpEnum op) {
        PageDataRequest staffInfoDetail = staffInfoDao.getStaffByStaffId(staffNo);
        JSONObject staffInfo = staffInfoDetail.getData();
        JSONArray jsonArray = null;
        Object partJsonObject = staffInfo.get(part);
        Object rid = newData.get("_RID");
        // 如果本身没有数据 则无需修改与删除
        if (partJsonObject == null) {
            return null;
        }
        String s = JSON.toJSONString(partJsonObject);
        Object object = JSON.parse(s);
        // 如果是对象
        if (object instanceof JSONObject) {
            if (StaffInfoUpdateApplyRdOpEnum.OP_UPDATE == op) {
                Query query = new Query(Criteria.where("_BUSINESSID").is(staffNo));
                Update update = new Update();
                update.set("_DATA." + part, newData);
                mongoTemplate.updateFirst(query, update, Map.class, HRCollection.HR_STAFF_INFO);
                return null;
            }
        } else {
            // 如果是集合 则修改或删除某条数据
            // 更新和删除操作
            jsonArray = (JSONArray) object;
            Iterator<Object> iterator = jsonArray.iterator();
            // 删除
            if (StaffInfoUpdateApplyRdOpEnum.OP_DELETE == op) {
                while (iterator.hasNext()) {
                    Object current = iterator.next();
                    JSONObject currentObj = (JSONObject) current;
                    String ridOld = currentObj.getString("_RID");
                    if (rid.equals(ridOld)) {
                        iterator.remove();
                        break;
                    }
                }
            } else {
                // 修改
                boolean flag = false;
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject josnObj = (JSONObject) jsonArray.get(i);
                    String ridOld = josnObj.getString("_RID");
                    if (rid.equals(ridOld)) {
                        flag = true;
//                        newData.put("_RID",rid);
                        jsonArray.set(i, newData);
                        break;
                    }
                }
                if (!flag) {
                    throw new BusinessException(HRMateInfo.STAFF_INFO_MODIFY_UPDATE_IS_ERR.getCode(), HRMateInfo.STAFF_INFO_MODIFY_UPDATE_IS_ERR.getMessage());
                }
            }
        }
        return jsonArray;
    }

}
