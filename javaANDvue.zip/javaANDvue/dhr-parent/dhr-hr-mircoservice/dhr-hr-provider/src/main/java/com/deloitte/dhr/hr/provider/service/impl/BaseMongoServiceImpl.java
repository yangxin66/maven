package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.hr.provider.mongo.dao.BaseSimpleMongoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.bson.Document;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author chunliucq
 * @since 17/09/2019 16:14
 */
@Service
public class BaseMongoServiceImpl implements com.deloitte.dhr.hr.provider.service.BaseMongoService {

    @Autowired
    private BaseSimpleMongoDao baseSimpleMongoDao;

    @Override
    public void save(String jsonData, String collection){
        baseSimpleMongoDao.save(jsonData,collection);
    }

    @Override
    public void updateAndFlush(JSONObject queryJson, Map<String, JSON> updateJson, String collection){
        baseSimpleMongoDao.updateAndFlush(queryJson,updateJson,collection);
    }

    @Override
    public void updateAndFlush(Query query, Update update, String collection){
        baseSimpleMongoDao.updateAndFlush(query,update,collection);
    }

    @Override
    public void save(Object obj, String collectionName){
        baseSimpleMongoDao.save(obj,collectionName);
    }

    @Override
    public Map<String, Object> queryOneForMap(Query query, String collectionName) {
        Document document = baseSimpleMongoDao.queryOneForDocument(query,collectionName);
        return document;
    }

    @Override
    public List<Map> queryOneForMapList(Query query,String collectionName){
        List<Map> resuslt = new ArrayList<>();
        List<Document> documentList = baseSimpleMongoDao.queryForDocument(query,collectionName);
        if (documentList == null){
            return resuslt;
        }
        for (Document doc : documentList){
            Map<String, Object> record = JSONObject.parseObject(doc.toJson());
            resuslt.add(record);
        }
        return resuslt;
    }

    @Override
    public JSONObject queryOneForJson(Query query, String collectionName) {
        Document document = baseSimpleMongoDao.queryOneForDocument(query,collectionName);
        return document == null ? null:JSONObject.parseObject(document.toJson());
    }

    @Override
    public void save(List objList, String collectionName) {
        baseSimpleMongoDao.save(objList,collectionName);
    }

    @Override
    public void insert(List objList, String collectionName) {
        baseSimpleMongoDao.insert(objList,collectionName);
    }

    @Override
    public long count(Query query,String collectionName){
        return baseSimpleMongoDao.count(query,collectionName);
    }

    @Override
    public boolean remove(Query query,String collectionName){
        return baseSimpleMongoDao.remove(query,collectionName);
    }
}
