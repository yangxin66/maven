package com.deloitte.dhr.hr.provider.gateway.rest.v1;


import com.deloitte.dhr.hr.api.MockInterface;
import com.deloitte.dhr.hr.api.model.QueryApplyUploadDto;
import com.deloitte.dhr.hr.api.model.staff.StaffNoDto;
import com.deloitte.dhr.hr.provider.service.MockService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/api/v1/hr/apply",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class MockController implements MockInterface {


    @Autowired
    MockService mockService;

    @Override
    @PostMapping("/query/apply/upload")
    @ApiOperation(value = "查询上传文件的详情")
    @ApiImplicitParam(name = "request", value = "申请编号和业务类型",
            required = true, dataType = "PaginationRequest«QueryApplyUploadDto»")
    public PaginationResponse<Map<String, Object>> queryApplyUpload(@RequestBody PaginationRequest<QueryApplyUploadDto> request) {

        return mockService.queryUploadApplyData(request,true);
    }

    @Override
    @PostMapping("/query/Concurrent/post")
    @ApiOperation(value = "通过员工编号查询兼职信息")
    @ApiImplicitParam(name = "request", value = "员工编号分页实体",
            required = true, dataType = "PaginationRequest«StaffNoDto»")
    public PaginationResponse<List> queryConcurrentPost(@RequestBody PaginationRequest<StaffNoDto> request) {
        return mockService.queryConcurrentPost(request);
    }



    @Override
    @PostMapping("/query/apply/staffinfo")
    @ApiOperation(value = "新增单条时查询员工的基本信息")
    @ApiImplicitParam(name = "staffNoDto", value = "员工编号",
            required = true, dataType = "Request«StaffNoDto»")
    public Response<List> queryApplyStaffInfo(@RequestBody Request<StaffNoDto> staffNoDto) {

        return mockService.queryApplyStaffInfo(staffNoDto.getData().getStaffNo());
    }


    @Override
    @PostMapping("/query/apply/estimate")
    @ApiOperation(value = "查询员工待确认信息")
    public Response<Map> queryApplyEstimate(@RequestBody Request<StaffNoDto> staffNoRequest) {

        return mockService.queryUploadEstimate(staffNoRequest.getData().getStaffNo());
    }
}
