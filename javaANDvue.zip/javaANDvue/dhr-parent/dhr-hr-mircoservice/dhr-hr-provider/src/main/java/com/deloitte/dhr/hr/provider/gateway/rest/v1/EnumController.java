package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.hr.api.HrEnumInterface;
import com.deloitte.dhr.hr.api.model.EnumResult;
import com.deloitte.dhr.hr.provider.service.EnumService;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * DHR 所有枚举获取Controller
 * @author chunliucq
 * @since 20/08/2019 10:22
 */
@RestController
@RequestMapping(value = "/api/v1/hr/enum",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class EnumController implements HrEnumInterface {
    @Autowired
    EnumService enumService;

    @ApiOperation(value = "查询下拉菜单枚举列表",notes = "查询下拉菜单枚举列表,支持查询一个或多个下拉菜单的枚举值")
    @ApiImplicitParam(name = "keyList",value="查询下拉菜单枚举列表的Key值",required = true,dataType = "Request«List«string»»")
    @PostMapping(value = "/query/enmuns/")
    @Override
    public Response<EnumResult> queryEnumList(@RequestBody Request<List<String>> keyList){

        EnumResult resultData = enumService.queryEnumInfo(keyList.getData());
        Response<EnumResult> resp = new Response<EnumResult>(LanguageEnum.getDefault(),Response.SUCCESS_CODE,"Success",resultData);
        return resp;
    }

}
