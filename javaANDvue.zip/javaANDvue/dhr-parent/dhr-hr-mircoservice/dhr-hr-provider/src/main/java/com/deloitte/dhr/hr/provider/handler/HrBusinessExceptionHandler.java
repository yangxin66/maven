package com.deloitte.dhr.hr.provider.handler;

import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.ex.handler.ExceptionHandler;
import com.deloitte.infrastructure.ex.handler.Notice;
import org.springframework.stereotype.Component;

/**
 * date: 05/09/2019 15:26
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class HrBusinessExceptionHandler implements ExceptionHandler {

    @Override
    public boolean support(Exception e) {
        return e instanceof BusinessException;
    }

    @Override
    public Notice handle(Exception e) {
        BusinessException businessException = (BusinessException)e;

        return new Notice(businessException.getCode(), businessException.getMessage());
    }
}
