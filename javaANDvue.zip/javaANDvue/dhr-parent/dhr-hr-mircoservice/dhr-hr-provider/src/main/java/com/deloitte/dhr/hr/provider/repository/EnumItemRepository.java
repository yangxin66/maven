package com.deloitte.dhr.hr.provider.repository;

import com.deloitte.dhr.hr.provider.repository.model.EnumItemPo;
import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnumItemRepository extends BaseRepository<EnumItemPo> {
    /**
     * 根据编码查询枚举项
     * @param code
     * @return
     */
    public List<EnumItemPo> findByCode(String code);
}
