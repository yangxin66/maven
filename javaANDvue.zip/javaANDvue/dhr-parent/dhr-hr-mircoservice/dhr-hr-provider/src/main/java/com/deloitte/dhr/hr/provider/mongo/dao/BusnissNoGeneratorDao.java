package com.deloitte.dhr.hr.provider.mongo.dao;

import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.provider.mongo.dao.model.BusinessNoGeneratorPo;
import com.deloitte.dhr.hr.provider.mongo.dao.model.BusinessNoRule;
import com.mongodb.BasicDBObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

/**
 * @author chunliucq
 * @since 05/09/2019 15:21
 */
@Repository
public class BusnissNoGeneratorDao extends BaseSimpleMongoDao {

    @Autowired
    private MongoTemplate mongoTemplate;

    public BusinessNoGeneratorPo queryGeneratorRuleByKey(String key){
        Query query = new Query();
        query.addCriteria(Criteria.where("key").is(key));
        BusinessNoGeneratorPo po = mongoTemplate.findOne(query, BusinessNoGeneratorPo.class, HRCollection.HR_BUSNISS_NO);
        return po;
    }

    public void updateGeneratorRule(BusinessNoGeneratorPo po){
        Query query = new Query();
        query.addCriteria(Criteria.where("key").is(po.getKey()));

        Update update = new Update();
        BusinessNoRule rule = po.getRule();
        update.set("rule.index",rule.getIndex());
        update.set("rule.date",rule.getDate());
        mongoTemplate.upsert(query,update,HRCollection.HR_BUSNISS_NO);
    }
}
