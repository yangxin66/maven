package com.deloitte.dhr.hr.provider.mongo.dao;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.infrastructure.ex.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * @author chunliucq
 * @since 27/08/2019 13:47
 */
@Slf4j
@Repository
public class StaffInfoDao extends BaseSimpleMongoDao {
    /**
     * 员工编号字段
     */
    private static String Staff_NO_KEY = "_BUSINESSID";

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 通过员工编号查询mongodb中员工信息
     *
     * @param staffNo
     * @return
     */
    public String queryStaffInfoByStaffNo(String staffNo) {
        Query query = new Query();
        query.addCriteria(Criteria.where(Staff_NO_KEY).is(staffNo));

        Document document = mongoTemplate.findOne(query, Document.class, HRCollection.HR_STAFF_INFO);
        if (document == null){
            throw new BusinessException(HRMateInfo.STAFF_NOT_FOUND_ERR.getCode(),HRMateInfo.STAFF_NOT_FOUND_ERR.getMessage());
        }
        JSONObject jsonObject = JSONObject.parseObject(document.toJson());
        JSONObject jsonObject1 = jsonObject.getJSONObject("_DATA");
        for (String key : jsonObject1.keySet()) {
            boolean isDataObj = isJsonObject(jsonObject1, key);
            if (isDataObj) {
                JSONObject jsonObject2 = jsonObject1.getJSONObject(key);
                if (Objects.nonNull(jsonObject2)){
                    jsonObject2.put("_OP", "");
                }
            } else {
                JSONArray jsonArray = jsonObject1.getJSONArray(key);
                if (jsonArray == null){
                    continue;
                }
                int k = jsonArray.size();
                for (int i = 0; i < k; i++) {
                    JSONObject jsonObject2 = jsonArray.getJSONObject(i);
                    if (Objects.nonNull(jsonObject2)){
                        jsonObject2.put("_OP", "");
                    }
                }
            }

        }
        return jsonObject.toJSONString();
    }

    /**
     * 根据员工唯一键集合查询员工信息
     *
     * @param staffIds 员工唯一键集合
     */
    public List<PageDataRequest> getStaffInfoDetailByStaffIds(List<String> staffIds) {
        Query query = new Query(Criteria.where("_BUSINESSID").in(staffIds));
        List<Map> list = mongoTemplate.find(query, Map.class, "staff_info");
        if (list.size() == 0) {
            return null;
        }
        List<PageDataRequest> pageDataRequests = new ArrayList<>(list.size());

        list.forEach(lt -> pageDataRequests.add(JSONObject.parseObject(JSONObject.toJSONString(lt), PageDataRequest.class)));
        return pageDataRequests;
    }

    public PageDataRequest getStaffByStaffId(String staffId) {
        List<PageDataRequest> staffInfoDetailByStaffIds = getStaffInfoDetailByStaffIds(Collections.singletonList(staffId));
        if (staffInfoDetailByStaffIds == null || staffInfoDetailByStaffIds.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_NOT_FOUND_ERR.getCode(), HRMateInfo.STAFF_NOT_FOUND_ERR.getMessage());
        }
        return staffInfoDetailByStaffIds.get(0);
    }

    private boolean isJsonObject(JSONObject jsonObject, String key) {
        String jsonStr = null;
        try {
            JSONArray tempJson = jsonObject.getJSONArray(key);
            if (tempJson != null) {
                jsonStr = tempJson.toJSONString();
            }
            if (jsonStr != null || jsonStr.startsWith("[")) {
                return false;
            }
        } catch (Exception e) {
            return true;
        }
        return true;
    }

}
