package com.deloitte.dhr.hr.provider.strategy;

import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;

import java.util.List;

/**
 * 流程节点处理策略
 * date: 15/10/2019 9:27
 *
 * @author wgong
 * @since 0.0.1
 */
public interface Strategy {

    boolean nodeHandler(AuditHandlerDto auditHandlerDto, String staffId,
                        String applyNo);

    default void batchSendEmail(List<String> staffIds){

    }

    ManagementTypeEnum getManagementType();
}
