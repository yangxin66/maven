package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.hr.api.MessageInterface;
import com.deloitte.dhr.hr.api.PositiveInterface;
import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.provider.service.MessageService;
import com.deloitte.dhr.hr.provider.service.PositiveService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.ex.BusinessException;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 转正接口
 *
 * @author chunliucq
 * @since 22/08/2019 11:25
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/hr/positive", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class PositiveController implements PositiveInterface {


    @Autowired
    PositiveService positiveService;


    @Override
    @PostMapping("/staff_unpositive")
    @ApiOperation(value = "查询待转正的员工数据")
    @ApiImplicitParam(name = "request", value = "传输实体", required = true, dataType = "PaginationRequest«UnposotiveSearchDto»")
    public PaginationResponse<List<UnposotiveStaffInfoDto>> getUnPositiveStaff(@RequestBody PaginationRequest<UnposotiveSearchDto> request) {
        return positiveService.getUnPositiveStaffInfoByPage(request);
    }
}
