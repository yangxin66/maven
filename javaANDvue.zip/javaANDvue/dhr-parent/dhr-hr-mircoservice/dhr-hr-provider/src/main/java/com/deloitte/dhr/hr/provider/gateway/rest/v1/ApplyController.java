package com.deloitte.dhr.hr.provider.gateway.rest.v1;

import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.hr.api.ApplyInterface;
import com.deloitte.dhr.hr.api.model.ApplyRecordDelDto;
import com.deloitte.dhr.hr.api.model.FileApplyRequestDto;
import com.deloitte.dhr.hr.api.model.staff.ApplyNoAndTypeDto;
import com.deloitte.dhr.hr.provider.service.ApplyService;
import com.deloitte.dhr.hr.provider.service.StaffApplyAlterService;
import com.deloitte.dhr.hr.provider.service.StaffInfoService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Example;
import io.swagger.annotations.ExampleProperty;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

/**
 * 申请管理 如员工信息变更申请、转正申请、网位变动申请等
 * @author chunliucq
 * @since 08/10/2019 13:37
 */
@RestController
@RequestMapping(value = "/api/v1/hr/apply",produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class ApplyController implements ApplyInterface {

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    private ApplyService applyService;

    @Autowired
    private StaffApplyAlterService staffApplyAlterService;

    /**
     * 保存各种申请 岗位变动、员工转正、兼岗等
     * @param applyRequest
     * @return
     */
    @Override
    @PostMapping("/add/save")
    @ApiOperation(value = "员工保存申请请求")
    @ApiImplicitParam(name = "applyRequest", value = "申请信息", required = true, dataType = "Request«Map»",
            examples = @Example({@ExampleProperty(mediaType = "_BUSINESSID", value = "00000000"), @ExampleProperty(mediaType = "AA", value = "00000000")}))
    public Response<Void> saveApply(@RequestBody Request<Map> applyRequest) {
        return applyService.saveApplyInfo(applyRequest, ApproveStatusEnum.PRE_SUBMIT);
    }

    /**
     * 提交审批各种申请 岗位变动、员工转正、兼岗等
     * @param applyRequest
     * @return
     */
    @Override
    @PostMapping("/add/submit")
    @ApiOperation(value = "员工提交申请请求")
    @ApiImplicitParam(name = "applyRequest", value = "申请信息", required = true, dataType = "Request«Map»",
            examples = @Example({@ExampleProperty(mediaType = "_BUSINESSID", value = "00000000"), @ExampleProperty(mediaType = "AA", value = "00000000")}))
    public Response<Void> submitApply(@RequestBody Request<Map> applyRequest) {
        return applyService.saveApplyInfo(applyRequest, ApproveStatusEnum.SUBMITTED);
    }

    /**
     *
     * @param requestData
     * @return
     */
    @PostMapping("/add/applydetail")
    @ApiOperation(value = "申请信息中新增或修改单条业务数据")
    @Override
    public Response<Void> appendRecord(@RequestBody Request<Map> requestData){
        Response<Void> resp = applyService.saveApplyDetailRecord(requestData,Boolean.FALSE,Boolean.FALSE);
        return resp;
    }

    @PostMapping("/del/applydetail")
    @ApiOperation(value = "删除单条业务数据")
    @ApiImplicitParam(name = "delDtoRequest", value = "业务编号、业务类型、业务数据ID", required = true, dataType = "Request«ApplyRecordDelDto»")
    @Override
    public Response<Void> deleteRecord(@RequestBody Request<ApplyRecordDelDto> delDtoRequest){
        ApplyRecordDelDto applyRecordDelDto = delDtoRequest.getData();
        Response<Void> resp = applyService.delApplyDetailRecord(applyRecordDelDto);
        return resp;
    }


    public Response<Void> uploadExcelData(@RequestBody Request<String> requestDate){

        return null;
    }


    /**
     * 通过申请编号查询申请信息
     * @param applyNoRequest 申请编号
     * @return
     */
    @Override
    @PostMapping("/query/applyinfo")
    @ApiOperation(value = "查询申请记录根据申请编号")
    @ApiImplicitParam(name = "applyNoRequest", value = "申请编号",
            required = true, dataType = "Request«ApplyNo»")
    public Response<Map> queryApplyByApplyNo(@RequestBody Request<ApplyNoAndTypeDto> applyNoRequest) {
        Response<Map> resp = applyService.queryApplyInfoOrInitNewApply(applyNoRequest.getData());
        return resp;
    }

    @PostMapping("/query/applydetail/page")
    @ApiOperation(value = "查询业务数据，分页显示")
    @ApiImplicitParam(name = "applyPaginationRequest", value = "申请编号、业务类型",
            required = true, dataType = "PaginationRequest«ApplyNoAndTypeDto»")
    @Override
    public PaginationResponse<List<Map>> queryApplyInfoByPageList(@RequestBody PaginationRequest<ApplyNoAndTypeDto> applyPaginationRequest){
        return applyService.queryApplyInfoByPageList(applyPaginationRequest);
    }

    @ApiOperation(value = "查询业务数据，分页显示")
    @ApiImplicitParam(name = "applyPaginationRequest", value = "申请编号、业务类型",
            required = true, dataType = "PaginationRequest«ApplyNoAndTypeDto»")
    @PostMapping("/query/applydetail/page/conf")
    @Override
    public PaginationResponse<Map> queryApplyInfoByPageListForConf(@RequestBody PaginationRequest<ApplyNoAndTypeDto> applyPaginationRequest){
        PaginationResponse<List<Map>> PageListResponse = applyService.queryApplyInfoByPageList(applyPaginationRequest);
        if (Response.SUCCESS_CODE.equals(PageListResponse.getCode())){
            List<Map> busiDataResultList = new ArrayList<>();
            List<Map> busiDataList = PageListResponse.getData();
            if (busiDataList != null){
                Map result = new HashMap();
                for (Map map : busiDataList){
                    Map resultMap = convertConfPageMap(map);
                    busiDataResultList.add(resultMap);
                }
            }
            Map respMap = new HashMap();
            respMap.put("_BUSI_DATA",busiDataResultList);
            return new PaginationResponse<>(PageListResponse.getLanguage(),PageListResponse.getPage(),
                    PageListResponse.getSize(),PageListResponse.getTotal(),PageListResponse.getSortBy(),
                    PageListResponse.getCode(),PageListResponse.getMessage(),respMap);
        }else {
            return new PaginationResponse<>(PageListResponse.getLanguage(),PageListResponse.getPage(),
                    PageListResponse.getSize(),PageListResponse.getTotal(),PageListResponse.getSortBy(),
                    PageListResponse.getCode(),PageListResponse.getMessage(),null);
        }
    }

    /**
     * 去掉新增单条数据时的封装节
     * @param map
     * @return
     */
    private Map convertConfPageMap(Map map){
        Map result = new HashMap();
        for (Map.Entry<String,Object> entry : (Set<Map.Entry<String,Object>>)map.entrySet()){
            String key = entry.getKey();
            Object obj = entry.getValue();
            if (obj == null){
                continue;
            }
            if (obj instanceof Map){
                ((Map<String,Object>)obj).entrySet().forEach(tmp -> {
                    String tmpKey = tmp.getKey();
                    Object tmpObj = tmp.getValue();
                    if (!(tmpObj instanceof List)){
                        result.put(tmpKey,tmpObj);
                    }
                });
            }else if (! (obj instanceof List)){
                result.put(key,obj);
            }
        }
        return result;
    }

    @Override
    @ApiOperation(value = "上传申请数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "_APPLY_NO", value = "业务编号", required = true, dataType = "string"),
            @ApiImplicitParam(name = "_APPLY_SUB_TYPE", value = "业务类型", required = true, dataType = "string"),
    })
    @PostMapping(value = "/save/apply/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE,produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public Response<Map> UploadApplyData(@RequestParam(required = false,value = "_APPLY_NO") String applyNo,
                                         @RequestParam(required = false,value = "_APPLY_SUB_TYPE") String busiType,
                                         @RequestPart(required = false,value = "attach") MultipartFile file) {
        FileApplyRequestDto fileApplyRequestDto = new FileApplyRequestDto();
        fileApplyRequestDto.setApplyNo(applyNo);
        fileApplyRequestDto.setBusiType(busiType);
        fileApplyRequestDto.setFile(file);
        return applyService.uploadApplyData(fileApplyRequestDto);
    }





}
