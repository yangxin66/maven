package com.deloitte.dhr.hr.provider.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author chunliucq
 * @since 24/09/2019 17:10
 */
@Data
@Component
@ConfigurationProperties(prefix = "dhr.duser")
public class HrUserConfig {

    /**
     * DHR 同步到DUSER注册员工关联用户地址
     */
    private String registerUrl;
}
