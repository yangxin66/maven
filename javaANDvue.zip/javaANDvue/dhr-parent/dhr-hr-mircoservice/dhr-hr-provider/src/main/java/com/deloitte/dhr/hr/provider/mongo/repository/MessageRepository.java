package com.deloitte.dhr.hr.provider.mongo.repository;


import com.deloitte.dhr.hr.provider.mongo.repository.model.MessagePo;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;


/**
 * 盒子页面持久化仓库接口
 *
 * @author xideng
 */
@Repository
public interface MessageRepository extends MongoRepository<MessagePo, String> {


    /**
     * 根据消息类型和员工编号分页查询消息
     *
     * @param messageType 消息类型
     * @param staffNo     员工编号
     * @param pageRequest 分页参数
     */
    List<MessagePo> findAllByMessageTypeIsAndAndStaffNoIs(String messageType, String staffNo, PageRequest pageRequest);

    /**
     * 根据消息类型和员工编号查询消息
     *
     * @param messageType 消息类型
     * @param staffNo     员工编号
     */
    List<MessagePo> findAllByMessageTypeIsAndAndStaffNoIs(String messageType, String staffNo);

    /**
     * 根据消息类型查询消息
     *
     * @param messageType 消息类型
     */
    List<MessagePo> findAllByMessageTypeIs(String messageType);



}
