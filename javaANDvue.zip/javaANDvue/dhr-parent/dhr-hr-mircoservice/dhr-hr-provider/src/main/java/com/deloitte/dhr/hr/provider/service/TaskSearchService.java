package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.util.List;
import java.util.Map;

/**
 * @author chunliucq
 * @since 22/08/2019 15:03
 */
public interface TaskSearchService {


    PaginationResponse<List<StaffInfoApplyDto>> searchTaskByPage(PaginationRequest<SearchDto> searchDtoPaginationResponse);

    PaginationResponse<List<StaffInfoApplyDto>> searchMyApplicationByPage(PaginationRequest<SearchDto> searchDtoPaginationResponse);

}
