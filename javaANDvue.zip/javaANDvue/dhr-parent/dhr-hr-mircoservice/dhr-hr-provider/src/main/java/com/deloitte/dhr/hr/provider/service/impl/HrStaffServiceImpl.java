package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.deloitte.dhr.common.constant.ApplyPartEnum;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.mongo.dao.model.AuditNodePo;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.dhr.hr.provider.utils.PaginationUtils;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import com.deloitte.workflow.api.WfProcessApi;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.constant.ConditionRelType;
import com.deloitte.workflow.api.model.dto.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * date: 21/08/2019 16:13
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class HrStaffServiceImpl implements HrStaffService {

//    static final String currentUserOid = "1567075417765";

    /**
     * 申请编号
     *
     * @return
     */
    private static final String STAFF_APPLY_NO = "_APPLY_NO";

    static final String hrRoleId = "hr";

    private static final String SEND_EMAIL_STATUS_NAME = "sendFlag";

    private final PlatformTransactionManager dataSourceTransactionManager;

    private final TransactionDefinition transactionDefinition;

    private final HrNotificationService hrNotificationService;

    private final WfTaskApi wfTaskApi;

    private final WfProcessApi wfProcessApi;

    private final MongoTemplate mongoTemplate;

    private final StaffInfoService staffInfoService;

    @Autowired
    CommonService commonService;

    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;

    @Autowired
    BussniessNoGeneratorService bussniessNoGeneratorService;

    @Autowired
    AuditNodeService auditNodeService;

    @Autowired
    StaffInfoDao staffInfoDao;

    public HrStaffServiceImpl(PlatformTransactionManager dataSourceTransactionManager, TransactionDefinition transactionDefinition,
                              HrNotificationService hrNotificationService, WfTaskApi wfTaskApi, MongoTemplate mongoTemplate,
                              WfProcessApi wfProcessApi, StaffInfoService staffInfoService) {
        this.dataSourceTransactionManager = dataSourceTransactionManager;
        this.transactionDefinition = transactionDefinition;
        this.hrNotificationService = hrNotificationService;
        this.wfTaskApi = wfTaskApi;
        this.mongoTemplate = mongoTemplate;
        this.wfProcessApi = wfProcessApi;
        this.staffInfoService = staffInfoService;
    }

    /**
     * 根据搜索条件查询员工列表
     *
     * @param searchDtoRequest 搜索参数
     */
    @Override
    public List<StaffInfoStatus> exportJsonObjects(Request<SearchDto> searchDtoRequest) {
        //TODO 加入登录后用户信息需要改造
        SearchDto data = searchDtoRequest.getData();
        SearchTypeEnum type = data.getType();
        boolean complete = true;
        // 查询待审批任务
        if (SearchTypeEnum.UNCOMPLETE_TASK.toString().equals(type.name())) {
            complete = false;
        }
        // 已审批的任务
        return searchEmployeeInfoByApproveStatus(searchDtoRequest, complete);
    }

    /**
     * 分页查询待审批或已审批员工入职信息
     *
     * @param searchDtoPaginationRequest 搜索参数
     * @param complete                   待审批或已审批
     */
    private PaginationResponse<List<StaffNodeDto>> searchEmployeeInfoByApproveStatusAndPage(PaginationRequest<SearchDto> searchDtoPaginationRequest,
                                                                                            boolean complete) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoPaginationRequest.getPage(), searchDtoPaginationRequest.getSize());

        // 获取待审批或已审批的任务以及流程的businessKey
        List<ProcessInstanceTaskDto> processInstanceTaskDtos = findProcessInstanceTaskDto(searchDtoPaginationRequest, complete);
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        if (processInstanceTaskDtos == null || processInstanceTaskDtos.size() == 0) {
            return new PaginationResponse<>(searchDtoPaginationRequest.getLanguage(),
                    page,
                    size,
                    0,
                    null,
                    Response.SUCCESS_CODE, null, null);
        }
        // 获取上面查出的结果的流程的businessKey
        Set<String> businessKeySet = processInstanceTaskDtos.stream().map(ProcessInstanceTaskDto::getBusinessKey).collect(Collectors.toSet());

        SearchDto searchDto = searchDtoPaginationRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        if (firstFieldCustoms == null || firstFieldCustoms.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getMessage());
        }
        Criteria sendEmailCriteria = createSendEmailCriteria(businessKeySet, firstFieldCustoms);
        Criteria searchStaffInfoCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffInfoList");
        List<StaffNodeDto> searchEmployFromStaffInfoList = getStaffInfoFromCriteriaByPage(sendEmailCriteria, searchStaffInfoCriteria, processInstanceTaskDtos, page, size);
        int total = getSearchEmployFromStaffInfoTotal(sendEmailCriteria, searchStaffInfoCriteria);
        return new PaginationResponse<>(searchDtoPaginationRequest.getLanguage(),
                page,
                size,
                total,
                null,
                Response.SUCCESS_CODE, null, searchEmployFromStaffInfoList);
    }

    /**
     * 查询待审批或已审批员工入职信息
     *
     * @param searchDtoRequest 搜索参数
     * @param complete         待审批或已审批
     */
    private List<StaffInfoStatus> searchEmployeeInfoByApproveStatus(Request<SearchDto> searchDtoRequest,
                                                                    boolean complete) {
        // 获取待审批或已审批的任务以及流程的businessKey
        List<ProcessInstanceTaskDto> processInstanceTaskDtos = findProcessInstanceTaskDto(searchDtoRequest, complete);
        // 获取上面查出的结果的流程的businessKey
        if (processInstanceTaskDtos == null || processInstanceTaskDtos.size() == 0) {
            return null;
        }
        Set<String> businessKeySet = processInstanceTaskDtos.stream().map(ProcessInstanceTaskDto::getBusinessKey).collect(Collectors.toSet());

        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        if (firstFieldCustoms == null || firstFieldCustoms.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getMessage());
        }
        Criteria sendEmailCriteria = createSendEmailCriteria(businessKeySet, firstFieldCustoms);
        Criteria searchStaffInfoCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffInfoList");
        return getEmployJsonObjectList(sendEmailCriteria, searchStaffInfoCriteria);
    }

    private List<StaffNodeDto> getStaffInfoFromCriteriaByPage(Criteria sendEmailCriteria, Criteria searchStaffInfoCriteria,
                                                              List<ProcessInstanceTaskDto> processInstanceTaskDtos,
                                                              int page, int size) {
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(sendEmailCriteria),
                Aggregation.lookup("staff_info", "businessId", "_BUSINESSID", "staffInfoList"),
                Aggregation.match(searchStaffInfoCriteria),
                Aggregation.sort(Sort.by(Sort.Direction.DESC, "staffInfoList._OPTIONTIME")),
                Aggregation.skip((long) page * size),
                Aggregation.limit(size)
        );
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, "staff_email_status", Map.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();

        List<StaffNodeDto> staffNodeDtoList = new ArrayList<>();
        mappedResults.forEach(m -> {
            StaffInfoEmailStatusRelDto staffInfoEmailStatusRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), StaffInfoEmailStatusRelDto.class);
            List<PageDataRequest> staffInfoList = staffInfoEmailStatusRelDto.getStaffInfoList();
            if (staffInfoList != null && staffInfoList.size() > 0) {
                PageDataRequest pageDataRequest = staffInfoList.get(0);
                for (ProcessInstanceTaskDto p : processInstanceTaskDtos) {
                    if (p.getBusinessKey() != null && p.getBusinessKey().equals(pageDataRequest.getBusinessId())) {
                        StaffNodeDto staffNodeDto = new StaffNodeDto();
                        staffNodeDto.setData(staffInfoList.get(0));
                        staffNodeDto.setSendFlag(staffInfoEmailStatusRelDto.getSendFlag());
                        staffNodeDto.setTaskId(p.getTaskId());
                        staffNodeDtoList.add(staffNodeDto);
                        break;
                    }
                }
            }
        });
        return staffNodeDtoList;
    }

    private int getSearchEmployFromStaffInfoTotal(Criteria sendEmailCriteria, Criteria searchStaffInfoCriteria) {
        Aggregation aggregationTotal = Aggregation.newAggregation(
                Aggregation.match(sendEmailCriteria),
                Aggregation.lookup("staff_info", "businessId", "_BUSINESSID", "staffInfoList"),
                Aggregation.match(Criteria.where("staffInfoList").exists(true).andOperator(searchStaffInfoCriteria))
        );
        return mongoTemplate.aggregate(aggregationTotal, "staff_email_status", Map.class).getMappedResults().size();
    }

    private List<StaffInfoStatus> getEmployJsonObjectList(Criteria sendEmailCriteria, Criteria searchStaffInfoCriteria) {
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(sendEmailCriteria),
                Aggregation.lookup("staff_info", "businessId", "_BUSINESSID", "staffInfoList"),
                Aggregation.match(searchStaffInfoCriteria)
        );
        return getStaffInfoStatuses(aggregation);
    }

    @Override
    public List<StaffInfoStatus> getEmployJsonObjectListFromStaffIds(List<String> ids) {
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("businessId").in(ids)),
                Aggregation.lookup("staff_info", "businessId", "_BUSINESSID", "staffInfoList"),
                Aggregation.match(Criteria.where("staffInfoList").exists(true))

        );
        return getStaffInfoStatuses(aggregation);
    }

    private List<StaffInfoStatus> getStaffInfoStatuses(Aggregation aggregation) {
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, "staff_email_status", Map.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
        List<StaffInfoStatus> objects = new ArrayList<>();
        mappedResults.forEach(m -> {
            StaffInfoEmailStatusRelDto staffInfoEmailStatusRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), StaffInfoEmailStatusRelDto.class);
            List<PageDataRequest> staffInfoList = staffInfoEmailStatusRelDto.getStaffInfoList();
            if (staffInfoList != null && staffInfoList.size() > 0) {
                PageDataRequest pageDataRequest = staffInfoList.get(0);
                //JSONObject jsonObject = staffInfoList.get(0).getData();
                StaffInfoStatus staffInfoStatus = new StaffInfoStatus();
                //staffInfoStatus.setOptionTime(staffInfoList.get(0).getOptionTime());
                staffInfoStatus.setSendFlag(staffInfoEmailStatusRelDto.getSendFlag());
                staffInfoStatus.setData(pageDataRequest);
                objects.add(staffInfoStatus);
            }
        });
        return objects;
    }


    private List<ProcessInstanceTaskDto> findProcessInstanceTaskDto(Request<SearchDto> searchDtoPaginationRequest, boolean complete) {
        TaskDto taskDto = new TaskDto();
        Map<String, Object> map = new HashMap<>(1);
        map.put("instanceType", "new_staff");
        taskDto.setCompleted(complete);
        taskDto.setProcessVariables(map);
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Response<List<TaskDto>> response;
        if (!complete) {
            taskDto.setCandidateGroups(ContextSession.getCurrentLoginUserRoleCodes());
            taskDto.setConditionRelType(ConditionRelType.OR);
            taskDto.setAssignee(staffNo);
            Request<TaskDto> request = new Request<>(taskDto);
            // 如果需要根据候选组查找必须查任务表  不能查历史任务表 因为历史任务表没有候选组的字段
            response = wfTaskApi.list(request);
        } else {
            taskDto.setAssignee(staffNo);
            Request<TaskDto> request = new Request<>(taskDto);
            response = wfTaskApi.historyTaskList(request);
        }

        if (!response.successful()) {
            throw new BusinessException(response.getCode(), response.getMessage());
        }
        List<TaskDto> taskDtos = response.getData();
        if (taskDtos == null || taskDtos.size() == 0) {
            return null;
        }
        List<ProcessInstanceTaskDto> processInstanceTaskDtos = new ArrayList<>();
        taskDtos.forEach(t -> {
            Map<String, Object> processVariables = t.getProcessVariables();
            if (processVariables.get("staffId") != null) {
                ProcessInstanceTaskDto processInstanceTaskDto = new ProcessInstanceTaskDto();
                processInstanceTaskDto.setTaskId(t.getTaskId());
                processInstanceTaskDto.setBusinessKey((String) processVariables.get("staffId"));
                processInstanceTaskDtos.add(processInstanceTaskDto);
            }
        });
        return processInstanceTaskDtos;
    }


    private Criteria createSendEmailCriteria(Set<String> businessKeySet, List<FieldCustomDto> fieldCustoms) {
        List<FieldCustomDto> collect = fieldCustoms.stream().filter(f -> f.getKey().equals(SEND_EMAIL_STATUS_NAME)).collect(Collectors.toList());
        Criteria criteria = Criteria.where("businessId").in(businessKeySet);
        // 需要查询是否发送邮件表
        if (collect.size() != 0 && !StringUtils.isEmpty(collect.get(0).getValue())) {
            // 查询是否发送邮件
            criteria.andOperator(Criteria.where("sendFlag").is(collect.get(0).getValue()));
        }
        return criteria;
    }

    private Criteria createStaffInfoCriteria(List<FieldCustomDto> firstFieldCustoms, List<FieldCustomDto> secondFieldCustoms, String prefix) {

        Criteria criteria = createCriteria(firstFieldCustoms, SearchRelationEnum.AND, prefix + ".");
        // 关联staff_info的员工信息要存在
        Criteria criteriaStaffInfoList = Criteria.where(prefix).exists(true);
        // 添加员工信息查询条件
        if (secondFieldCustoms != null && secondFieldCustoms.size() != 0) {
            Criteria criteria2 = createCriteria(secondFieldCustoms, SearchRelationEnum.OR, prefix + ".");
            criteriaStaffInfoList.andOperator(criteria, criteria2);
        } else {
            criteriaStaffInfoList.andOperator(criteria);
        }
        return criteriaStaffInfoList;

    }

    private Criteria createCriteria(List<FieldCustomDto> fieldCustomList, SearchRelationEnum searchRelationEnum, String prefix) {
        prefix = (prefix == null ? "" : prefix);
        List<Criteria> criteriaList = new ArrayList<>();
        Criteria criteria = new Criteria();
        for (FieldCustomDto f : fieldCustomList) {
            if (StringUtils.isNotBlank(f.getKey()) && StringUtils.isNotBlank(f.getValue())) {
                if (SearchConditionEnum.eq.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).is(f.getValue()));
                } else if (SearchConditionEnum.like.equals(f.getCondition())) {
                    String value = dealSpecialStr(f.getValue());
                    criteriaList.add(Criteria.where(prefix + f.getKey()).regex(".*?" + value + ".*"));
                } else if (SearchConditionEnum.lt.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).lt(f.getValue()));
                } else if (SearchConditionEnum.gt.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).gt(f.getValue()));
                } else if (SearchConditionEnum.ne.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).ne(f.getValue()));
                } else if (SearchConditionEnum.lte.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).lte(f.getValue()));
                } else if (SearchConditionEnum.gte.equals(f.getCondition())) {
                    criteriaList.add(Criteria.where(prefix + f.getKey()).gte(f.getValue()));
                }
            }
        }
        if (criteriaList.size() > 0) {
            Criteria[] criteriaArr = new Criteria[criteriaList.size()];
            for (int i = 0; i < criteriaList.size(); i++) {
                criteriaArr[i] = criteriaList.get(i);
            }
            if (SearchRelationEnum.AND.name().equals(searchRelationEnum.name())) {
                criteria.andOperator(criteriaArr);
            } else if (SearchRelationEnum.OR.name().equals(searchRelationEnum.name())) {
                criteria.orOperator(criteriaArr);
            } else {
                throw new IllegalStateException("暂不支持该关系");
            }
        }

        return criteria;
    }

    /**
     * 处理正则表达式的特殊字符
     *
     * @param value 原字符
     */
    private String dealSpecialStr(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }
        if (value.contains(".") || value.contains("\\") || value.contains("?") || value.contains("<") || value.contains(">")
                || value.contains("^")) {
            return "\\" + value;
        }

        return value;
    }

    /**
     * 根据员工唯一键查询员工信息
     *
     * @param staffId 员工唯一键
     */
    @Override
    public PageDataRequest getStaffInfoDetail(String staffId) {
        return staffInfoDao.getStaffByStaffId(staffId);
    }


    /**
     * 获取员工dhr和sap的对比数据
     *
     * @param staffId 员工唯一键
     */
    @Override
    public StaffDetailCompareDto getStaffDetailCompare(String staffId) {
        PageDataRequest dhrData = getStaffInfoDetail(staffId);
        StaffDetailCompareDto staffDetailCompareDto = new StaffDetailCompareDto();
        staffDetailCompareDto.setDhrData(dhrData);
        return staffDetailCompareDto;
    }

    /**
     * 批量审批
     *
     * @param approveStaffDtoList 批量审批参数集合
     */
    @Override
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public void approveStaffInfo(List<ApproveStaffDto> approveStaffDtoList) {

        List<TaskClaimDto> taskClaimDtos = new ArrayList<>(approveStaffDtoList.size());
        List<TaskCompleteDto> taskCompleteDtos = new ArrayList<>(approveStaffDtoList.size());
        List<String> staffIds = new ArrayList<>(approveStaffDtoList.size());
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        approveStaffDtoList.forEach(approveStaffDto -> {
            // 拼装批量认领任务数据 因为之前分配任务时没有设置Assign 所以在完成任务之前设置Assign
            String taskId = approveStaffDto.getTaskId();
            TaskClaimDto taskClaimDto = new TaskClaimDto();
            taskClaimDto.setTaskId(taskId);
            taskClaimDto.setUserOid(staffNo);
            taskClaimDto.setUserName(currentLoginUserInfo.getStaffName());
            taskClaimDtos.add(taskClaimDto);

            // 拼装批量完成任务数据
            TaskCompleteDto taskCompleteDto = new TaskCompleteDto();
            taskCompleteDto.setId(taskId);
            taskCompleteDtos.add(taskCompleteDto);

            // 拼装用户id 为了后面去mongoDb批量查员工
            String staffId = approveStaffDto.getStaffId();
            staffIds.add(staffId);

            // 校验
            boolean isComplete = staffInfoService.isAllFillInComplete(staffId);

            if (!isComplete) {
                throw new BusinessException(HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getCode(), HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getMessage());
            }
        });
        // 手动开启事务
//        TransactionStatus transactionStatus = dataSourceTransactionManager.getTransaction(transactionDefinition);
//        try {
        //TODO 添加保存数据到SAP
        List<PageDataRequest> pageDataRequests = staffInfoDao.getStaffInfoDetailByStaffIds(staffIds);
        if (pageDataRequests == null || pageDataRequests.size() == 0 || pageDataRequests.size() != approveStaffDtoList.size()) {
            throw new BusinessException(HRMateInfo.STAFF_CODE_REPEAT_ERR.getCode(), HRMateInfo.STAFF_CODE_REPEAT_ERR.getMessage());
        }
        // 发送审批通过邮件
        hrNotificationService.batchSendApproveEmail(pageDataRequests);
//        dataSourceTransactionManager.commit(transactionStatus);

        // 批量认领任务
        Request<List<TaskClaimDto>> taskClaimDtoRequest = new Request<>(taskClaimDtos);
        Response<Object> response = wfTaskApi.claimTaskList(taskClaimDtoRequest);
        if (!response.successful()) {
            throw new BusinessException(response.getCode(), response.getMessage());
        }

        // 批量完成任务
        Request<List<TaskCompleteDto>> request1 = new Request<>(taskCompleteDtos);
        Response<Object> response1 = wfTaskApi.completeTaskList(request1);
        if (!response1.successful()) {
            throw new BusinessException(response1.getCode(), response1.getMessage());
        }

//        } catch (Exception e) {
//            dataSourceTransactionManager.rollback(transactionStatus);
//            if (e instanceof BusinessException) {
//                BusinessException businessException = (BusinessException) e;
//                throw new BusinessException(businessException.getCode(), businessException.getMessage(), businessException.getCause());
//            }
//            throw new BusinessException(HRMateInfo.APPROVE_UNKNOW_ERR.getCode(), HRMateInfo.APPROVE_UNKNOW_ERR.getMessage(), e);
//
//        }

    }

    /**
     * 获取我的申请 已完成任务列表
     *
     * @param searchDtoRequest
     * @return
     */
    private PaginationResponse<List<StaffInfoApplyDto>> getMyApplicationCompleteApplyByPage(PaginationRequest<SearchDto> searchDtoRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoRequest.getPage(), searchDtoRequest.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Criteria completeCriteria = Criteria.where("_AUDIT_TIME").exists(true);
        Criteria staffNoCriteria = Criteria.where("_APPLICANT_ID").is(staffNo);
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(completeCriteria);
        criteriaList.add(staffNoCriteria);
        Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

        Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_AUDIT_TIME"));
        List<Map> list = mongoTemplate.find(query.skip((long) page * size).limit(size),
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        int total = mongoTemplate.find(query,
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY).size();

        List<StaffInfoApplyDto> staffInfoModifyFlowDtoList = new ArrayList<>();
        list.forEach(m -> {
            StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
            staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
            String type1 = staffInfoApplyDto.getType();
            staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
            // 如果是查询待审核的任务 应该设置状态为待审核  因为HRCollection.HR_STAFF_UPDATE_APPLY集合中存储的状态是针对表单状态：已提交、审核中、
            staffInfoModifyFlowDtoList.add(staffInfoApplyDto);
        });
        return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                page,
                size,
                total,
                searchDtoRequest.getSortPairs(), staffInfoModifyFlowDtoList);

    }


    private List<Map> getMyApplicationCompleteApply(Request<SearchDto> searchDtoRequest) {
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Criteria completeCriteria = Criteria.where("_AUDIT_TIME").exists(true);
        Criteria staffNoCriteria = Criteria.where("_APPLICANT_ID").is(staffNo);
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(completeCriteria);
        criteriaList.add(staffNoCriteria);
        Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

        Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_AUDIT_TIME"));
        List<Map> list = mongoTemplate.find(query, Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        List<Map> mapList = new ArrayList<>();
        list.forEach(m -> {
            Map map = new HashMap(m);
            StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
            staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
            String type1 = staffInfoApplyDto.getType();
            staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
            Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
            });
            mapList.add(stringObjectMap);
        });
        return mapList;

    }

    /**
     * 获取我的申请 未完成任务列表
     *
     * @param searchDtoRequest
     * @return
     */
    private PaginationResponse<List<StaffInfoApplyDto>> getTaskByPageFromFlow(PaginationRequest<SearchDto> searchDtoRequest, boolean complete) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoRequest.getPage(), searchDtoRequest.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();

        List<TaskDto> taskDtos = findStaffModifyTask(complete);
        if (taskDtos == null || taskDtos.size() == 0) {
            return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                    page,
                    size,
                    0,
                    searchDtoRequest.getSortPairs(), null);
        }
        String status = getStatusByfirstFieldCustoms(firstFieldCustoms);
        List<String> flowTaskIds = taskDtos.stream().map(TaskDto::getTaskId).collect(Collectors.toList());
        Criteria searchStaffInfoApplyCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffApplyList");
        Criteria taskNodeCriteria = Criteria.where("taskId").in(flowTaskIds);
        Sort sort;
        if (status != null) {
            taskNodeCriteria.andOperator(Criteria.where("status").is(status));
        }
        Criteria staffApplyCriteria;
        if (complete) {
            staffApplyCriteria = Criteria.where("auditTime").exists(true).andOperator(searchStaffInfoApplyCriteria);
            sort = Sort.by(Sort.Direction.DESC, "auditTime");
        } else {
            staffApplyCriteria = searchStaffInfoApplyCriteria;
            sort = Sort.by(Sort.Direction.DESC, "staffApplyList._APPLY_TIME");
        }
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(taskNodeCriteria),
                Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                Aggregation.match(staffApplyCriteria),
                Aggregation.sort(sort),
                Aggregation.skip((long) page * size),
                Aggregation.limit(size)
        );
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, HRCollection.HR_TASK_AUDIT_NODE, Map.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
        List<StaffInfoApplyDto> staffInfoApplyDtos = new ArrayList<>();
        mappedResults.forEach(m -> {
            TaskAuditNodeStaffInfoApplyRelDto nodeStaffInfoApplyRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), TaskAuditNodeStaffInfoApplyRelDto.class);
            List<StaffInfoApplyDto> staffApplyList = nodeStaffInfoApplyRelDto.getStaffApplyList();
            if (staffApplyList != null && staffApplyList.size() > 0) {
                StaffInfoApplyDto staffInfoApplyDto = staffApplyList.get(0);
                staffInfoApplyDto.setAuditTime(nodeStaffInfoApplyRelDto.getAuditTime());
                staffInfoApplyDto.setTaskId(nodeStaffInfoApplyRelDto.getTaskId());
                staffInfoApplyDto.setStatus(nodeStaffInfoApplyRelDto.getStatus());
                staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(nodeStaffInfoApplyRelDto.getStatus()).getValue());
                staffInfoApplyDto.setAuditId(nodeStaffInfoApplyRelDto.getAuditorId());
                staffInfoApplyDto.setAuditName(nodeStaffInfoApplyRelDto.getAuditorName());
                String type1 = staffInfoApplyDto.getType();
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
                staffInfoApplyDtos.add(staffInfoApplyDto);
            }
        });

        Aggregation aggregationTotal = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("status").is(status).andOperator(Criteria.where("taskId").in(flowTaskIds))),
                Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                Aggregation.match(searchStaffInfoApplyCriteria),
                Aggregation.match(Criteria.where("auditTime").exists(true))
        );
        int total = mongoTemplate.aggregate(aggregationTotal, HRCollection.HR_TASK_AUDIT_NODE, Map.class).getMappedResults().size();
        return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                page,
                size,
                total,
                searchDtoRequest.getSortPairs(), staffInfoApplyDtos);

    }

    private List<Map> getTaskFromFlow(Request<SearchDto> searchDtoRequest, boolean complete) {

        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();

        List<TaskDto> taskDtos = findStaffModifyTask(complete);
        if (taskDtos == null || taskDtos.size() == 0) {
            return null;
        }
        String status = getStatusByfirstFieldCustoms(firstFieldCustoms);
        List<String> flowTaskIds = taskDtos.stream().map(TaskDto::getTaskId).collect(Collectors.toList());
        Criteria searchStaffInfoApplyCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffApplyList");
        Criteria taskNodeCriteria = Criteria.where("taskId").in(flowTaskIds);
        Sort sort;
        if (status != null) {
            taskNodeCriteria.andOperator(Criteria.where("status").is(status));
        }
        Criteria staffApplyCriteria;
        if (complete) {
            staffApplyCriteria = Criteria.where("auditTime").exists(true).andOperator(searchStaffInfoApplyCriteria);
            sort = Sort.by(Sort.Direction.DESC, "auditTime");
        } else {
            staffApplyCriteria = searchStaffInfoApplyCriteria;
            sort = Sort.by(Sort.Direction.DESC, "staffApplyList._APPLY_TIME");
        }
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(taskNodeCriteria),
                Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                Aggregation.match(staffApplyCriteria),
                Aggregation.sort(sort)
        );
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, HRCollection.HR_TASK_AUDIT_NODE, Map.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
//        List<StaffInfoApplyDto> staffInfoApplyDtos = new ArrayList<>();
        List<Map> mapList = new ArrayList<>();
        mappedResults.forEach(m -> {
            TaskAuditNodeStaffInfoApplyRelDto nodeStaffInfoApplyRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), TaskAuditNodeStaffInfoApplyRelDto.class);
            List<StaffInfoApplyDto> staffApplyList = nodeStaffInfoApplyRelDto.getStaffApplyList();
            if (staffApplyList != null && staffApplyList.size() > 0) {
                StaffInfoApplyDto staffInfoApplyDto = staffApplyList.get(0);
                staffInfoApplyDto.setAuditTime(nodeStaffInfoApplyRelDto.getAuditTime());
                staffInfoApplyDto.setTaskId(nodeStaffInfoApplyRelDto.getTaskId());
                staffInfoApplyDto.setStatus(nodeStaffInfoApplyRelDto.getStatus());
                staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(nodeStaffInfoApplyRelDto.getStatus()).getValue());
                staffInfoApplyDto.setAuditId(nodeStaffInfoApplyRelDto.getAuditorId());
                staffInfoApplyDto.setAuditName(nodeStaffInfoApplyRelDto.getAuditorName());
                String type1 = staffInfoApplyDto.getType();
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
                Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
                });
                mapList.add(stringObjectMap);
            }

        });
        return mapList;

    }


    private List<Map> getTaskFromFlowAndApplyNo(SearchDto searchDto, boolean complete, List<String> applyNoList) {

        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();

        List<TaskDto> taskDtos = findStaffModifyTask(complete);
        if (taskDtos == null || taskDtos.size() == 0) {
            return null;
        }
        List<String> flowTaskIds = taskDtos.stream().map(TaskDto::getTaskId).collect(Collectors.toList());
        String status = getStatusByfirstFieldCustoms(firstFieldCustoms);
        List<AuditNodePo> auditNodePos = auditNodeService.findByTaskIdAndStatusAndApplyNo(flowTaskIds, applyNoList, status);
        List<String> taskNodeIds = auditNodePos.stream().map(AuditNodePo::getTaskId).collect(Collectors.toList());
        Criteria searchStaffInfoApplyCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffApplyList");
        Criteria taskNodeCriteria = Criteria.where("taskId").in(taskNodeIds);
        Sort sort;
        if (status != null) {
            taskNodeCriteria.andOperator(Criteria.where("status").is(status));
        }
        Criteria staffApplyCriteria;
        if (complete) {
            staffApplyCriteria = Criteria.where("auditTime").exists(true).andOperator(searchStaffInfoApplyCriteria);
            sort = Sort.by(Sort.Direction.DESC, "auditTime");
        } else {
            staffApplyCriteria = searchStaffInfoApplyCriteria;
            sort = Sort.by(Sort.Direction.DESC, "staffApplyList._APPLY_TIME");
        }
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(taskNodeCriteria),
                Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                Aggregation.match(staffApplyCriteria),
                Aggregation.sort(sort)
        );
        AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, HRCollection.HR_TASK_AUDIT_NODE, Map.class);
        List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
        List<Map> mapList = new ArrayList<>();
        mappedResults.forEach(m -> {
            TaskAuditNodeStaffInfoApplyRelDto nodeStaffInfoApplyRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), TaskAuditNodeStaffInfoApplyRelDto.class);
            List<StaffInfoApplyDto> staffApplyList = nodeStaffInfoApplyRelDto.getStaffApplyList();
            if (staffApplyList != null && staffApplyList.size() > 0) {
                StaffInfoApplyDto staffInfoApplyDto = staffApplyList.get(0);
                staffInfoApplyDto.setAuditTime(nodeStaffInfoApplyRelDto.getAuditTime());
                staffInfoApplyDto.setTaskId(nodeStaffInfoApplyRelDto.getTaskId());
                staffInfoApplyDto.setStatus(nodeStaffInfoApplyRelDto.getStatus());
                staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(nodeStaffInfoApplyRelDto.getStatus()).getValue());
                staffInfoApplyDto.setAuditId(nodeStaffInfoApplyRelDto.getAuditorId());
                staffInfoApplyDto.setAuditName(nodeStaffInfoApplyRelDto.getAuditorName());
                String type1 = staffInfoApplyDto.getType();
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
//                staffInfoApplyDtos.add(staffInfoApplyDto);
                Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
                });
                mapList.add(stringObjectMap);
            }
        });
        return mapList;

    }

    @Override
    public List<Map> ExportApplyMap(Request<SearchDto> searchDtoRequest) {
        SearchDto searchDto = searchDtoRequest.getData();
        SearchTypeEnum type = searchDto.getType();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        if (firstFieldCustoms == null || firstFieldCustoms.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getMessage());
        }
        if (SearchTypeEnum.COMPLETE_TASK == type) {
            return getTaskFromFlow(searchDtoRequest, true);
        } else if (SearchTypeEnum.UNCOMPLETE_TASK == type) {
            return getTaskFromFlow(searchDtoRequest, false);
        } else {
            throw new BusinessException(HRMateInfo.SEARCH_TYPE_IS_UNSUPPORT_ERR.getCode(), HRMateInfo.SEARCH_TYPE_IS_UNSUPPORT_ERR.getMessage());
        }
    }

    @Override
    public List<Map> ExportApplyMyApplication(Request<SearchDto> searchDtoRequest) {
        //TODO 加入登录后用户信息需要改造
        SearchDto searchDto = searchDtoRequest.getData();
        SearchTypeEnum type = searchDto.getType();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        if (firstFieldCustoms == null || firstFieldCustoms.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_SEARCH_IS_EMPTY_ERR.getMessage());
        }
        if (SearchTypeEnum.PROCESSING == type) {
            // 查询正则进行中的任务
            return getMyApplicationProcessingTasks(searchDtoRequest);
        } else if (SearchTypeEnum.COMPLETE_TASK == type) {
            return getMyApplicationCompleteApply(searchDtoRequest);
        } else {
            return getTaskFromFlow(searchDtoRequest, false);
        }
    }

    @Override
    public List<Map> ExportApplyMapFormApplyNoHr(ApplySearchDto applySearchDto) {
        List<String> applyNoList = applySearchDto.getApplyNoList();
//        List<Map> mapList = staffApplyAlterDao.ExportApplyMapFormApplyNo(applyNoList);
        SearchDto searchDto = applySearchDto.getSearchDto();
        SearchTypeEnum type = searchDto.getType();
        if (SearchTypeEnum.COMPLETE_TASK == type) {
            return getTaskFromFlowAndApplyNo(searchDto, true, applyNoList);
        } else if (SearchTypeEnum.UNCOMPLETE_TASK == type) {
            return getTaskFromFlowAndApplyNo(searchDto, false, applyNoList);
        } else {
            throw new BusinessException(HRMateInfo.SEARCH_TYPE_IS_UNSUPPORT_ERR.getCode(), HRMateInfo.SEARCH_TYPE_IS_UNSUPPORT_ERR.getMessage());
        }
    }

    @Override
    public List<Map> ExportApplyMapFormApplyNoStaff(ApplySearchDto applySearchDto) {

        List<String> applyNoList = applySearchDto.getApplyNoList();
        SearchDto searchDto = applySearchDto.getSearchDto();
        SearchTypeEnum type = searchDto.getType();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        List<TaskDto> taskDtos;
        if (SearchTypeEnum.COMPLETE_TASK == type) {
            List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
            List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
            Criteria criteria1 = Criteria.where("_APPLICANT_ID").is(staffNo);
            Criteria c1 = Criteria.where("_AUDIT_TIME").exists(false);
            Criteria c2 = Criteria.where("_APPLY_STATUS").ne("REJECT");
            Criteria c3 = Criteria.where(STAFF_APPLY_NO).in(applyNoList);
            List<Criteria> criteriaList = new ArrayList<>();
            criteriaList.add(c1);
            criteriaList.add(c2);
            criteriaList.add(c3);
            criteriaList.add(criteria1);
            Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

            Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_APPLY_TIME"));
            List<Map> list = mongoTemplate.find(query, Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
            List<Map> mapList = new ArrayList<>();
            list.forEach(m -> {
                Map map = new HashMap(m);
                StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
                staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
                String type1 = staffInfoApplyDto.getType();
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
                Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
                });
                mapList.add(stringObjectMap);
            });
            return mapList;
        } else if (SearchTypeEnum.UNCOMPLETE_TASK == type) {
            List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
            List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
            Criteria completeCriteria = Criteria.where("_AUDIT_TIME").exists(true);
            Criteria staffNoCriteria = Criteria.where("_APPLICANT_ID").is(staffNo);
            Criteria c3 = Criteria.where("_APPLY_STATUS").in(applyNoList);
            List<Criteria> criteriaList = new ArrayList<>();
            criteriaList.add(completeCriteria);
            criteriaList.add(staffNoCriteria);
            criteriaList.add(c3);
            Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

            Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_AUDIT_TIME"));
            List<Map> list = mongoTemplate.find(query, Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
            List<Map> mapList = new ArrayList<>();
            list.forEach(m -> {
                Map map = new HashMap(m);
                StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
                staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
                String type1 = staffInfoApplyDto.getType();
                staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
                Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
                });
                mapList.add(stringObjectMap);
            });
            return mapList;
        } else {
            List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
            List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();

            taskDtos = findStaffModifyTask(false);
            if (taskDtos == null || taskDtos.size() == 0) {
                return null;
            }
            String status = getStatusByfirstFieldCustoms(firstFieldCustoms);
            List<String> flowTaskIds = taskDtos.stream().map(TaskDto::getTaskId).collect(Collectors.toList());
            Criteria searchStaffInfoApplyCriteria = createStaffInfoCriteria(firstFieldCustoms, secondFieldCustoms, "staffApplyList");
            Criteria taskNodeCriteria = Criteria.where("taskId").in(flowTaskIds).andOperator(Criteria.where(STAFF_APPLY_NO).in(applyNoList));
            Sort sort;
            if (status != null) {
                taskNodeCriteria.andOperator(Criteria.where("status").is(status));
            }
            Criteria staffApplyCriteria;
            staffApplyCriteria = searchStaffInfoApplyCriteria;
            sort = Sort.by(Sort.Direction.DESC, "staffApplyList._APPLY_TIME");
            Aggregation aggregation = Aggregation.newAggregation(
                    Aggregation.match(taskNodeCriteria),
                    Aggregation.lookup(HRCollection.HR_STAFF_UPDATE_APPLY, "processInstanceId", "_PROCESS_INSTANCE_ID", "staffApplyList"),
                    Aggregation.match(staffApplyCriteria),
                    Aggregation.sort(sort)
            );
            AggregationResults<Map> staffInfoEmailStatusRelDtos = mongoTemplate.aggregate(aggregation, HRCollection.HR_TASK_AUDIT_NODE, Map.class);
            List<Map> mappedResults = staffInfoEmailStatusRelDtos.getMappedResults();
//        List<StaffInfoApplyDto> staffInfoApplyDtos = new ArrayList<>();
            List<Map> mapList = new ArrayList<>();
            mappedResults.forEach(m -> {
                TaskAuditNodeStaffInfoApplyRelDto nodeStaffInfoApplyRelDto = JSONObject.parseObject(JSONObject.toJSONString(m), TaskAuditNodeStaffInfoApplyRelDto.class);
                List<StaffInfoApplyDto> staffApplyList = nodeStaffInfoApplyRelDto.getStaffApplyList();
                if (staffApplyList != null && staffApplyList.size() > 0) {
                    StaffInfoApplyDto staffInfoApplyDto = staffApplyList.get(0);
                    staffInfoApplyDto.setAuditTime(nodeStaffInfoApplyRelDto.getAuditTime());
                    staffInfoApplyDto.setTaskId(nodeStaffInfoApplyRelDto.getTaskId());
                    staffInfoApplyDto.setStatus(nodeStaffInfoApplyRelDto.getStatus());
                    staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(nodeStaffInfoApplyRelDto.getStatus()).getValue());
                    staffInfoApplyDto.setAuditId(nodeStaffInfoApplyRelDto.getAuditorId());
                    staffInfoApplyDto.setAuditName(nodeStaffInfoApplyRelDto.getAuditorName());
                    String type1 = staffInfoApplyDto.getType();
                    staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
                    Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
                    });
                    mapList.add(stringObjectMap);
                }

            });
            return mapList;
        }
    }

    @Override
    public List<StaffInfoSearchDto> searchStaffInfoByKeyword(String keyword) {
        // TODO 需要SAP提供接口
        Criteria criteria = new Criteria();
        criteria.orOperator(Criteria.where("_DATA._BASE.PERNR").regex(".*?" + keyword + ".*"),
                Criteria.where("_DATA._BASE.NACHN").regex(".*?" + keyword + ".*"),
                Criteria.where("_DATA._BASE.ENAME").regex(".*?" + keyword + ".*"));
        List<Map> list = mongoTemplate.find(new Query(criteria),
                Map.class, HRCollection.HR_STAFF_INFO);
        List<StaffInfoSearchDto> staffInfoSearchDtos = new ArrayList<>();
        list.forEach(l -> {

            PageDataRequest pageDataRequest = SerializerUtils.deserialize(JSONObject.toJSONString(l), PageDataRequest.class);
            JSONObject data = pageDataRequest.getData();
            if (data != null) {
                String staffNo = data.getJSONObject("_BASE").getString("PERNR");
                String nachn = data.getJSONObject("_BASE").getString("NACHN");
                String ename = data.getJSONObject("_BASE").getString("ENAME");
                nachn = (nachn == null ? "" : nachn);
                ename = (ename == null ? "" : ename);
                // TODO 需要部门名称
                StaffInfoSearchDto staffInfoSearchDto = StaffInfoSearchDto.builder().staffNo(staffNo)
                        .stationName("测试岗位")
                        .departmentName("测试部门")
                        .companyName("测试公司")
                        .name(nachn + ename).build();
                staffInfoSearchDtos.add(staffInfoSearchDto);
            }
        });
        return staffInfoSearchDtos;
    }

    @Override
    public String modifyStaffInfoToSap(StaffInfoModifyDto staffInfoModifyDto) {
        return commonService.modifySapStaffInfo(staffInfoModifyDto);
    }


    private String getStatusByfirstFieldCustoms(List<FieldCustomDto> firstFieldCustoms) {
        Iterator<FieldCustomDto> it = firstFieldCustoms.iterator();
        while (it.hasNext()) {
            FieldCustomDto firstFieldCustom = it.next();
            if ("_APPLY_STATUS".equals(firstFieldCustom.getKey())) {
                String value = firstFieldCustom.getValue();
                if (value == null || StringUtils.isBlank(value)) {
                    return null;
                }
                it.remove();
                return value;
            }
        }
        return null;
    }

    private PaginationResponse<List<StaffInfoApplyDto>> getMyApplicationProcessingTasksByPage(PaginationRequest<SearchDto> searchDtoRequest) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(searchDtoRequest.getPage(), searchDtoRequest.getSize());
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Criteria criteria1 = Criteria.where("_APPLICANT_ID").is(staffNo);
        Criteria c1 = Criteria.where("_AUDIT_TIME").exists(false);
        Criteria c2 = Criteria.where("_APPLY_STATUS").ne("REJECT");
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(c1);
        criteriaList.add(c2);
        criteriaList.add(criteria1);
        Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

        Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_APPLY_TIME"));
        List<Map> list = mongoTemplate.find(query.skip((long) page * size).limit(size),
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        int total = mongoTemplate.find(query,
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY).size();

        List<StaffInfoApplyDto> staffInfoModifyFlowDtoList = new ArrayList<>();
        list.forEach(m -> {
            StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
            staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
            String type1 = staffInfoApplyDto.getType();
            staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
            // 如果是查询待审核的任务 应该设置状态为待审核  因为HRCollection.HR_STAFF_UPDATE_APPLY集合中存储的状态是针对表单状态：已提交、审核中、
            staffInfoModifyFlowDtoList.add(staffInfoApplyDto);
        });
        return ResponseUtil.build().creatDeaultOkPaginationResponse(searchDtoRequest.getLanguage(),
                page,
                size,
                total,
                searchDtoRequest.getSortPairs(), staffInfoModifyFlowDtoList);
    }

    private List<Map> getMyApplicationProcessingTasks(Request<SearchDto> searchDtoRequest) {
        SearchDto searchDto = searchDtoRequest.getData();
        List<FieldCustomDto> firstFieldCustoms = searchDto.getFirstFieldCustoms();
        List<FieldCustomDto> secondFieldCustoms = searchDto.getSecondFieldCustoms();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        Criteria criteria1 = Criteria.where("_APPLICANT_ID").is(staffNo);
        Criteria c1 = Criteria.where("_AUDIT_TIME").exists(false);
        Criteria c2 = Criteria.where("_APPLY_STATUS").ne("REJECT");
        List<Criteria> criteriaList = new ArrayList<>();
        criteriaList.add(c1);
        criteriaList.add(c2);
        criteriaList.add(criteria1);
        Criteria staffInfoModifyCriteria = createStaffInfoModifyCriteria(firstFieldCustoms, secondFieldCustoms, criteriaList);

        Query query = new Query(staffInfoModifyCriteria).with(Sort.by(Sort.Direction.DESC, "_APPLY_TIME"));
        List<Map> list = mongoTemplate.find(query, Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        List<Map> mapList = new ArrayList<>();
        list.forEach(m -> {
            Map map = new HashMap(m);
            StaffInfoApplyDto staffInfoApplyDto = SerializerUtils.deserialize(JSONObject.toJSONString(m), StaffInfoApplyDto.class);
            staffInfoApplyDto.setStatusName(ApproveStatusEnum.valueOf(staffInfoApplyDto.getStatus()).getValue());
            String type1 = staffInfoApplyDto.getType();
            staffInfoApplyDto.setPratName(ApplyPartEnum.valueOf(type1).getValue());
            Map<String, Object> stringObjectMap = JSON.parseObject(JSON.toJSONString(staffInfoApplyDto), new TypeReference<Map<String, Object>>() {
            });
            mapList.add(stringObjectMap);
        });
        return mapList;
    }


    /**
     * 查询已完成或未完成的员工信息修改任务
     *
     * @param complete 是否完成
     */
    private List<TaskDto> findStaffModifyTask(boolean complete) {
        TaskDto taskDto = new TaskDto();
        Response<List<TaskDto>> response;
        Map<String, Object> map = new HashMap<>(1);
        map.put("instanceType", "modify_staff");
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        taskDto.setCompleted(complete);
        taskDto.setProcessVariables(map);
        if (!complete) {
            taskDto.setCandidateGroups(ContextSession.getCurrentLoginUserRoleCodes());
            taskDto.setConditionRelType(ConditionRelType.OR);
            taskDto.setAssignee(staffNo);
            Request<TaskDto> request = new Request<>(taskDto);
            response = wfTaskApi.list(request);
        } else {
            taskDto.setAssignee(staffNo);
            Request<TaskDto> request = new Request<>(taskDto);
            response = wfTaskApi.historyTaskList(request);
        }

        if (!response.successful()) {
            throw new BusinessException(response.getCode(), response.getMessage());
        }
        return response.getData();
    }

    private Criteria createStaffInfoModifyCriteria(List<FieldCustomDto> firstFieldCustoms,
                                                   List<FieldCustomDto> secondFieldCustoms,
                                                   List<Criteria> criteriaStaffInfoList) {
        Criteria criteria = createCriteria(firstFieldCustoms, SearchRelationEnum.AND, "");
        criteriaStaffInfoList.add(criteria);
        Criteria criteria1 = new Criteria();
        // 关联staff_info的员工信息要存在
//        Criteria criteriaStaffInfoList;
//        if (processInstanceIds == null || processInstanceIds.size() == 0) {
//            criteriaStaffInfoList = new Criteria();
//        } else {
//            criteriaStaffInfoList = Criteria.where("_PROCESS_INSTANCE_ID").in(processInstanceIds);
//        }
        // 添加员工信息更改查询条件
        if (secondFieldCustoms != null && secondFieldCustoms.size() != 0) {
            Criteria criteria2 = createCriteria(secondFieldCustoms, SearchRelationEnum.OR, "");
            criteriaStaffInfoList.add(criteria2);
        }
        if (criteriaStaffInfoList.size() > 0) {
            Criteria[] criteriaArr = new Criteria[criteriaStaffInfoList.size()];
            for (int i = 0; i < criteriaStaffInfoList.size(); i++) {
                criteriaArr[i] = criteriaStaffInfoList.get(i);
            }
            criteria1.andOperator(criteriaArr);
        }
        return criteria1;

    }


}
