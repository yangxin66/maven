package com.deloitte.dhr.hr.provider.mongo.dao;


import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.model.ApplyList;
import com.deloitte.dhr.hr.api.model.staff.ApplyNo;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;

import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class StaffApplyAlterDao {
    /**
     * 员工编号
     *
     * @return
     */
    private static final String Staff_NO_KEY = "_BUSINESSID";
    private static final String Staff_DATA = "_DATA";
    /**
     * 申请状态
     *
     * @return
     */
    private static final String Staff_APPLY_STATUS = "_APPLY_STATUS";
    /**
     * 申请的模块
     *
     * @return
     */
    private static final String Staff_DATA_PART = "_DATA_PART";
    /**
     * 申请编号
     *
     * @return
     */
    private static final String STAFF_APPLY_NO = "_APPLY_NO";
    /**
     * rid
     *
     * @return
     */
    private static final String STAFF_RID = "_RID";

    @Autowired
    MongoTemplate mongoTemplate;
    @Autowired
    MongoOperations mongoOperations;

    public List<Map> ExportApplyMapFormApplyNo(List<String> applyNoList) {

        Query query = new Query();
        query.addCriteria(Criteria.where(STAFF_APPLY_NO).in(applyNoList));
        List<Map> mapList = mongoTemplate.find(query, Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        return mapList;
    }

    public List<Map> ExportApplyMapFormDetailed(List<String> applyNoList) {

        Query query = new Query();
        query.addCriteria(Criteria.where(STAFF_APPLY_NO).in(applyNoList));
        List<Map> mapList = mongoTemplate.find(query, Map.class, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        return mapList;
    }

    public List<Document> QueryApplyAlter(String staffNo, List<String> status,
                                          List<String> partList) {
        Criteria criteria = new Criteria();
        criteria.and(Staff_NO_KEY).is(staffNo);
        criteria.and(Staff_APPLY_STATUS).in(status);
        criteria.and(Staff_DATA_PART).in(partList);
        Query query = new Query(criteria);
        return mongoTemplate.find(query, Document.class,
                HRCollection.HR_STAFF_UPDATE_APPLY);
    }

    public List<Document> QueryApplyAlter(String staffNo,
                                          String part) {
        Criteria criteria = new Criteria();
        criteria.and(Staff_NO_KEY).is(staffNo);
        criteria.and(Staff_DATA_PART).is(part);
        Query query = new Query(criteria);
        return mongoTemplate.find(query, Document.class,
                HRCollection.HR_STAFF_UPDATE_APPLY);
    }

    public List<Document> QueryApplyDetail(List<ApplyList> applyLists) {
        List<Document> documentList = new ArrayList<>();
        for (ApplyList applyList : applyLists) {
            Criteria criteria = new Criteria();
            criteria.and(STAFF_RID).is(applyList.getRid());
            criteria.and(STAFF_APPLY_NO).is(applyList.getApplyNo());
            Query query = new Query(criteria);
            Document one = mongoTemplate.findOne(query, Document.class,
                    HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
            documentList.add(one);
        }
        return documentList;
    }

    public Document QueryByApplyNo(String ApplyNo) {
        Query query = new Query();
        query.addCriteria(Criteria.where(STAFF_APPLY_NO).is(ApplyNo));
        Document document = mongoTemplate.findOne(query, Document.class, HRCollection.HR_STAFF_UPDATE_APPLY);
//        String part = (String)document.get("_DATA_PART");
//        document.put("_DATA_PART_NAME", ApplyPartEnum.valueOf(part).getValue());
        String status = (String) document.get("_APPLY_STATUS");
        document.put("_STATUS_NAME", ApproveStatusEnum.valueOf(status).getValue());
        document.remove("_id");
        Query queryRid = new Query();
        queryRid.addCriteria(Criteria.where(STAFF_APPLY_NO).is(ApplyNo)).with(new Sort(Sort.Direction.DESC, "_RID"));
//        queryRid.fields().include("_RID");
        List<Document> ridList = mongoTemplate.find(queryRid, Document.class, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
//        Collections.sort(ridList);
        List list = new ArrayList();
        for (Document document1 : ridList) {
            list.add(document1.getString("_RID"));
        }
        document.put("_RID_LIST", list);
//        JSONArray array = new JSONArray();
//        array.add(map);
        return document;
    }


    public List<Document> ExcelByApplyNoAndRid(List<String> applyNoList, List<String> ridList) {

        List<Document> documentList = new ArrayList<>();
        if (applyNoList.size() > ridList.size()) {
            for (String rid : ridList) {
                Query query = new Query();
                query.addCriteria(Criteria.where(STAFF_APPLY_NO).in(applyNoList));
                query.addCriteria(Criteria.where("_RID").is(rid));
                query.with(new Sort(Sort.Direction.DESC, "_RID"));
                List<Document> documentList1 = mongoTemplate.find(query, Document.class, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
                documentList.addAll(documentList1);
            }
        } else {
            for (String applyNo : applyNoList) {
                for (String rid : ridList) {
                    Query query = new Query();
                    query.addCriteria(Criteria.where(STAFF_APPLY_NO).is(applyNo));
                    query.addCriteria(Criteria.where("_RID").in(rid));
                    query.with(new Sort(Sort.Direction.DESC, "_RID"));
                    List<Document> documentList1 = mongoTemplate.find(query, Document.class, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
                    documentList.addAll(documentList1);
                }
            }
        }
//        Collections.sort(documentList, new Comparator<Document>(){
//            public int compare(Document p1, Document p2) {
//                if(Integer.parseInt(p1.getString("_RID")) >Integer.parseInt( p2.getString("_RID"))){
//                    return 1;
//                }
//                if(Integer.parseInt(p1.getString("_RID")) >Integer.parseInt( p2.getString("_RID"))){
//                    return 0;
//                }
//                return -1;
//            }
//        });
        return documentList;
    }

    public Boolean UpdateByApplyNoAndRid(String ApplyNo, String rid, Map map) {

        Query query = new Query();
        query.addCriteria(Criteria.where(STAFF_APPLY_NO).is(ApplyNo));
        query.addCriteria(Criteria.where("_RID").is(rid));
//        mongoTemplate.update(Map.class).matching(query).replaceWith(map);
        return false;
    }

    public PaginationResponse<List<Map>> QueryByApplyNoInfoList(PaginationRequest<ApplyNo> applyNoPaginationRequest) {

        List<Map> applyList = new ArrayList<>();
        String applyNo = applyNoPaginationRequest.getData().getApplyNo();
        Integer page = applyNoPaginationRequest.getPage();
        Integer size = applyNoPaginationRequest.getSize();
        Query query = new Query();
        query.addCriteria(Criteria.where(STAFF_APPLY_NO).is(applyNo));
        query.skip((page - 1) * size).limit(size).with(new Sort(Sort.Direction.DESC, "_RID"));
        List<Document> documentList = mongoTemplate.find(query, Document.class,
                HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        for (Document d : documentList) {
            d.remove("_id");
            d.remove("_class");
        }
        Query queryRows = new Query();
        queryRows.addCriteria(Criteria.where(STAFF_APPLY_NO).is(applyNo));
        long total = mongoTemplate.count(queryRows,
                HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        return new PaginationResponse(applyNoPaginationRequest.getLanguage(),
                page,
                size,
                (int) total,
                null,
                Response.SUCCESS_CODE, null, documentList);
    }
}
