package com.deloitte.dhr.hr.provider.repository;

import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.provider.mongo.dao.BaseSimpleMongoDao;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * @author chunliucq
 * @since 15/10/2019 10:16
 */
@Repository
public class BusiDataRepository {
    @Autowired
    private BaseSimpleMongoDao baseSimpleMongoDao;


    public Map<String,Object> queryOneBusiData(String applyNo, String rid, SubtypeEnum busiType){
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo).and("_RID").is(rid));
        Document document = baseSimpleMongoDao.queryOneForDocument(query, busiType.getTableName());
        return document;
    }

}
