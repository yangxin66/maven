package com.deloitte.dhr.hr.provider.service;


import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.hr.api.model.ApplyCompare;
import com.deloitte.dhr.hr.api.model.ApplyStatus;
import com.deloitte.dhr.hr.api.model.staff.ApplyNo;
import com.deloitte.dhr.hr.api.model.staff.ApplyNoPageSize;
import com.deloitte.dhr.hr.api.model.staff.StaffApplyDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import java.util.List;
import java.util.Map;


public interface StaffApplyAlterService {

   /**
    * 根据员工编号,申请模块,申请状态
    * @param applyDtoRequest
    * @return
    */
   List<ApplyStatus> queryApplyAlter(Request<StaffApplyDto> applyDtoRequest);


   /**
    * 根据申请编号
    * @param applyNo
    * @return
    */
   JSONObject queryApplyAlterByApply(String applyNo);

   /**
    * 比较前后信息
    * @param ApplyBefore
    * @return
    */
   List<ApplyCompare> CompareApplyAndInfo(JSONObject ApplyBefore);



   /**
    * 申请记录查询
    * @param ApplyBefore
    * @return
    */
   List<ApplyCompare> CompareApplyList(JSONObject ApplyBefore);

   /**
    * 申请分页查询
    * @param applyNoPaginationRequest
    * @return
    */
   PaginationResponse<List<Map>> ApplyPage(PaginationRequest<ApplyNo> applyNoPaginationRequest);

}
