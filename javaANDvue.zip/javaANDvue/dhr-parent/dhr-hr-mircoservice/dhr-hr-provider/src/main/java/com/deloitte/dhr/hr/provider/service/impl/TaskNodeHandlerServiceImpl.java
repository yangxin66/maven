package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.api.model.StaffInfoApplyDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoApplyDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.mongo.dao.model.AuditNodePo;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import com.deloitte.workflow.api.WfProcessApi;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.model.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

/**
 * date: 15/10/2019 9:32
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class TaskNodeHandlerServiceImpl implements TaskNodeHandlerService {

    @Autowired
    WfProcessApi wfProcessApi;

    @Autowired
    StaffInfoService staffInfoService;

    @Autowired
    AuditNodeService auditNodeService;

    @Autowired
    WfTaskApi wfTaskApi;

    @Autowired
    BaseMongoService baseMongoService;

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    StaffInfoApplyDao staffInfoApplyDao;

    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;

    @Autowired
    CommonService commonService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    HrNotificationService hrNotificationService;
    @Override
    public boolean commonFlowNodeHandler(AuditHandlerDto auditHandlerDto) {
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        if (auditHandlerDto == null) {
            throw new BusinessException(HRMateInfo.AUDIT_PARAMETER_IS_NULL.getCode(), HRMateInfo.AUDIT_PARAMETER_IS_NULL.getMessage());
        }
        // TODO 加入登录后这里需要更改
        String remark = auditHandlerDto.getRemark();
//        Instant auditTime = Instant.now();
        String processInstantId = auditHandlerDto.getProcessInstantId();
        String taskId = auditHandlerDto.getTaskId();
        StaffInfoApplyDto staffInfoApplyDto = getStaffInfoApplyDto(processInstantId);
        String applyNo = staffInfoApplyDto.getApplyNo();

        // 设置分配者
        // TODO 如果添加了流程配置  这边可能需要修改
        setAssigner(taskId, staffNo, ContextSession.getCurrentLoginUserInfo().getStaffName());

        // 完成任务
        ProcessInstanceDto processInstanceDto = completeTask(auditHandlerDto);

        // 更新当前任务节点状态信息
        updateCurrentTaskNode(processInstantId, taskId, auditHandlerDto.getApplicationStatusEnum(), remark);

        // 将完成的状态更新到申请表中 并且设置下一个任务的候选组

        // 如果整个流程完成 需要做额外的操作 则返回流程是否结束的状态
        return updateStatusAndHandlerNextTask(processInstanceDto, auditHandlerDto, applyNo, staffInfoApplyDto);
    }

    private boolean updateStatusAndHandlerNextTask(ProcessInstanceDto processInstanceDto, AuditHandlerDto auditHandlerDto, String applyNo, StaffInfoApplyDto staffInfoApplyDto) {
        if (processInstanceDto != null) {
            Boolean ended = processInstanceDto.getEnded();
            String taskId = auditHandlerDto.getTaskId();
            ApplicationStatusEnum applicationStatusEnum = auditHandlerDto.getApplicationStatusEnum();
            if (Boolean.TRUE.equals(ended)) {
                // 如果最后一个节点是审核通过 说明状态为审核通过
                if (ApplicationStatusEnum.APPROVED == applicationStatusEnum) {
                    staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.APPROVED.name(), true);
                    return true;
//                    approve(applyNo);
                } else if (ApplicationStatusEnum.REJECT == applicationStatusEnum) {
                    staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.UNAPPROVED.name(), true);
                } else if (ApplicationStatusEnum.CLOSE == applicationStatusEnum) {
                    staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.CLOSE.name(), true);
                }
                // 设置下一个任务的候选组或候选人
            } else {
                List<TaskNodeDto> taskNodes = processInstanceDto.getTaskNodes();
                String status = ApproveStatusEnum.APPROVAL_PENDING.name();
                // 如果不是最后一个节点 审核通过 说明状态为待审核
                if (ApplicationStatusEnum.APPROVED == applicationStatusEnum) {
                    staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.APPROVAL_PENDING.name(), false);

                } else if (ApplicationStatusEnum.REJECT == applicationStatusEnum) {
                    staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.REJECT.name(), false);
                    status = ApproveStatusEnum.REJECT.name();
                    // TODO 如果驳回  则读取配置表  驳回给谁

                } else if (ApplicationStatusEnum.SUBMITTED == applicationStatusEnum) {
                    staffInfoApplyDao.updateStaffUpdateApplyStatus(applyNo, ApproveStatusEnum.APPROVAL_PENDING.name(), false);
                }

                CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
                auditNodeService.addNextTaskNode(taskNodes, applyNo, status, taskId,
                        currentLoginUserInfo.getStaffNo(), currentLoginUserInfo.getStaffName());
                // 如果是驳回 暂时驳回给员工发起人
                // TODO 加入可配置项后这里需要修改
                // 如果是审核通过就设置下一个任务节点的分配者或候选组
                assignTaskByConfig(taskNodes, applicationStatusEnum, staffInfoApplyDto, auditHandlerDto);
            }
        }
        return false;
    }

    private void updateCurrentTaskNode(String processInstantId, String taskId,
                                       ApplicationStatusEnum applicationStatusEnum, String remark) {
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String staffNo = currentLoginUserInfo.getStaffNo();
        // TODO 从SAP获取员工信息 暂时从DHR这边获取信息
        String staffInfoJson = staffInfoService.queryStaffInfoByStaffNo(staffNo);
        if (staffInfoJson == null) {
            throw new BusinessException(HRMateInfo.CURRENT_LOGIN_STAFF_NO_ERR.getCode(), HRMateInfo.CURRENT_LOGIN_STAFF_NO_ERR.getMessage());
        }
        JSONObject staffInfo = JSONObject.parseObject(staffInfoJson);
        JSONObject imgjsonObject = staffInfo.getJSONObject("_DATA").getJSONObject("_BASE").getJSONObject("AVATAR");
        String imgUrl = imgjsonObject == null ? null : imgjsonObject.getString("url");
        // TODO 加入登录后这里需要更改
        String auditorFirstName = staffInfo.getJSONObject("_DATA").getJSONObject("_BASE").getString("NACHN");
        String auditorSecondName = staffInfo.getJSONObject("_DATA").getJSONObject("_BASE").getString("ENAME");
        String auditorName = (auditorFirstName == null ? "" : auditorFirstName) + (auditorSecondName == null ? "" : auditorSecondName);
        // 将审核状态保存在表中
        AuditNodePo auditNodePo = auditNodeService.findByProcessInstanceIdEqualsAndTaskIdEquals(processInstantId, taskId);
        if (auditNodePo != null) {
            auditNodePo.setAuditorId(staffNo);
            auditNodePo.setAuditorName(auditorName);
            auditNodePo.setAuditTime(Instant.now());
            auditNodePo.setImgUrl(imgUrl);
            auditNodePo.setStatus(applicationStatusEnum.name());
            auditNodePo.setStatusName(ApproveStatusEnum.valueOf(applicationStatusEnum.name()).getValue());
            auditNodePo.setRemark(remark);

            auditNodeService.saveAndUpdate(auditNodePo);
        }

    }

    /**
     * 根据流程配置信息 设置下一个任务的分配者或者候选组
     *
     * @param taskNodes         任务集合
     * @param statusEnum        状态
     * @param staffInfoApplyDto 员工申请记录信息
     */
    private void assignTaskByConfig(List<TaskNodeDto> taskNodes, ApplicationStatusEnum statusEnum,
                                    StaffInfoApplyDto staffInfoApplyDto, AuditHandlerDto auditHandlerDto) {
        String lastTaskId = auditHandlerDto.getTaskId();
        String lastProcessInstanceId = auditHandlerDto.getProcessInstantId();
        if (taskNodes != null && taskNodes.size() != 0) {
            taskNodes.forEach(taskNodeDto -> {
                if (statusEnum == ApplicationStatusEnum.REJECT) {
                    // 任务id
                    String taskId = taskNodeDto.getTaskId();
                    AuditNodePo auditNodePo = auditNodeService.findByProcessInstanceIdEqualsAndTaskIdEquals(lastProcessInstanceId, lastTaskId);
                    if (auditNodePo.getLastAuditorId() == null ||
                            auditNodePo.getLastTaskId() == null) {
                        throw  new BusinessException(HRMateInfo.CURRENT_NODE_NOT_SUPPORT_REJECT.getCode(),
                                HRMateInfo.CURRENT_NODE_NOT_SUPPORT_REJECT.getMessage());
                    }
                    setAssigner(taskId, auditNodePo.getLastAuditorId(), auditNodePo.getLastAuditorName());
                    // TODO 加入配置后需要修改
                    // 如果查询时要用候选组和分配者等查询 则必须要设置候选组
                    TaskCandidateGroupDto taskCandidateGroupDto = new TaskCandidateGroupDto();
                    taskCandidateGroupDto.setTaskId(taskNodeDto.getTaskId());
                    taskCandidateGroupDto.setCandidateGroup("null");
                    List<TaskCandidateGroupDto> taskCandidateGroupDtos = new ArrayList<>(Collections.singletonList(taskCandidateGroupDto));
                    setCandidateGroup(taskCandidateGroupDtos);
//                    setAssigner(taskNodeDto.getTaskId(), staffInfoApplyDto.getApplicantId(), staffInfoApplyDto.getApplicantName());
                }
//                else {
//                    // TODO 加入配置后分配者需要修改
//                    List<String> currentLoginUserRoleCodes = Collections.singletonList(HrStaffServiceImpl.hrRoleId);
//                    List<TaskCandidateGroupDto> taskCandidateGroupDtos = new ArrayList<>(currentLoginUserRoleCodes.size());
//                    currentLoginUserRoleCodes.forEach(roleCode -> {
//                        TaskCandidateGroupDto taskCandidateGroupDto = new TaskCandidateGroupDto();
//                        taskCandidateGroupDto.setTaskId(taskNodeDto.getTaskId());
//                        taskCandidateGroupDto.setCandidateGroup(roleCode);
//                        taskCandidateGroupDtos.add(taskCandidateGroupDto);
//                    });
//
//                    setCandidateGroup(taskCandidateGroupDtos);
//                }
            });

        }

    }

    /**
     * 完成任务
     *
     * @param auditHandlerDto 流程审核节点处理传输实体
     */
    private ProcessInstanceDto completeTask(AuditHandlerDto auditHandlerDto) {
        String taskId = auditHandlerDto.getTaskId();
        TaskCompleteDto taskCompleteDto = new TaskCompleteDto();
        taskCompleteDto.setId(taskId);
        Map<String, Object> map = new HashMap<>(1);
        map.put("approve", auditHandlerDto.getApplicationStatusEnum().getValue());
        taskCompleteDto.setProcessVariables(map);
        Response<ProcessInstanceDto> processInstanceDtoResponse = wfTaskApi.complete(new Request<>(taskCompleteDto));
        if (!processInstanceDtoResponse.successful()) {
            throw new BusinessException(processInstanceDtoResponse.getCode(), processInstanceDtoResponse.getMessage());
        }
        return processInstanceDtoResponse.getData();
    }

    private StaffInfoApplyDto getStaffInfoApplyDto(String processInstantId) {
        List<Map> list = mongoTemplate.find(new Query(Criteria.where("_PROCESS_INSTANCE_ID").is(processInstantId)),
                Map.class, HRCollection.HR_STAFF_UPDATE_APPLY);
        if (list.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_INFO_APPLY_NOT_FOUND_ERR.getCode(), HRMateInfo.STAFF_INFO_APPLY_NOT_FOUND_ERR.getMessage());
        }
        return SerializerUtils.deserialize(JSONObject.toJSONString(list.get(0)), StaffInfoApplyDto.class);
    }

    /**
     * 设置分配者
     * @param taskId 任务id
     * @param userOid 分配者id
     * @param userName 分配者姓名
     */
    private void setAssigner(String taskId, String userOid, String userName) {
        List<TaskClaimDto> taskClaimDtos = new ArrayList<>(1);
        TaskClaimDto taskClaimDto = new TaskClaimDto();
        taskClaimDto.setTaskId(taskId);
        taskClaimDto.setUserOid(userOid);
        taskClaimDto.setUserName(userName);
        taskClaimDtos.add(taskClaimDto);
        Request<List<TaskClaimDto>> taskClaimDtoRequest = new Request<>(taskClaimDtos);
        Response<Object> response = wfTaskApi.claimTaskList(taskClaimDtoRequest);
        if (!response.successful()) {
            throw new BusinessException(response.getCode(), response.getMessage());
        }
    }

    /**
     * 给任务设置候选组
     * @param taskCandidateGroupDtos
     */
    private void setCandidateGroup(List<TaskCandidateGroupDto> taskCandidateGroupDtos) {

        Request<List<TaskCandidateGroupDto>> taskClaimDtoRequest = new Request<>(taskCandidateGroupDtos);
        Response<Object> response = wfTaskApi.addCandidateGroup(taskClaimDtoRequest);
        if (!response.successful()) {
            throw new BusinessException(response.getCode(), response.getMessage());
        }
    }


    /**
     * 新增员工入职申请审批通过后的操作
     *
     * @param staffIds 员工id集合
     * @param applyNos 业务编号集合
     */
    private void createStaffApprovedHandler(List<String> staffIds, List<String> applyNos) {
        List<PageDataRequest> pageDataRequests = staffInfoDao.getStaffInfoDetailByStaffIds(staffIds);
        if (pageDataRequests == null || pageDataRequests.size() == 0) {
            throw new BusinessException(HRMateInfo.STAFF_CODE_REPEAT_ERR.getCode(), HRMateInfo.STAFF_CODE_REPEAT_ERR.getMessage());
        }
        // 发送审批通过邮件
        hrNotificationService.batchSendApproveEmail(pageDataRequests);

        // 发送邮件次数加1
        applyNos.forEach(applyNo -> {
            staffInfoApplyDao.updateCreateStaffSendEmailNum(applyNo);
        });

        // TODO 并且将新建的员工信息更新到SAP中
    }
}
