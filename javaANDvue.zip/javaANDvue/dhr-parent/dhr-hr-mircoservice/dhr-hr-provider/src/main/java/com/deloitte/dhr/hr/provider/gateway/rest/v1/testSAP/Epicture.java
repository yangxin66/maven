package com.deloitte.dhr.hr.provider.gateway.rest.v1.testSAP;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * <br/>23/08/2019 17:25
 *
 * @author lshao
 */
@Data
public class Epicture {
    @JsonProperty("LINE")
    private String line;
}
