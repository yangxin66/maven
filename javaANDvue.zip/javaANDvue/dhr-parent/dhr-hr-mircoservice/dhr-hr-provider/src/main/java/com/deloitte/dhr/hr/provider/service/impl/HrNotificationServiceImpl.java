package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.model.RejectStaffDto;
import com.deloitte.dhr.hr.api.model.StaffInfoApplyDto;
import com.deloitte.dhr.hr.provider.config.HrEmailConfig;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoApplyDao;
import com.deloitte.dhr.hr.provider.service.CommonService;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.dhr.hr.provider.service.StaffInfoService;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.notification.provider.api.EmailRestInterface;
import com.deloitte.notification.provider.api.model.EmailParamDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * date: 29/08/2019 14:44
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class HrNotificationServiceImpl implements HrNotificationService {

    @Autowired
    CommonService commonService;

    @Autowired
    EmailRestInterface emailRestInterface;

    @Autowired
    private HrEmailConfig hrEmailConfig;

    @Autowired
    private StaffInfoService staffInfoService;

    @Autowired
    StaffInfoApplyDao staffInfoApplyDao;

    /**
     * 发送驳回邮件
     *
     * @param rejectStaffDto 驳回实体
     */
    @Override
    public void sendRejectStaffInfoEmail(RejectStaffDto rejectStaffDto) {
        String staffId = rejectStaffDto.getStaffId();
        String reason = rejectStaffDto.getReason();
        String staffInfoJson = staffInfoService.queryStaffInfoByStaffNo(staffId);
        if (staffInfoJson == null) {
            throw new BusinessException(HRMateInfo.STAFF_NOT_FOUND_ERR.getCode(), HRMateInfo.STAFF_NOT_FOUND_ERR.getMessage());
        }
        JSONObject staffInfo = JSONObject.parseObject(staffInfoJson);

        String email = staffInfo.getJSONObject("_DATA").getJSONObject("_CONTACT").getString("EMAIL");
        String name = staffInfo.getJSONObject("_DATA").getJSONObject("_BASE").getString("ENAME");
        String msgTemplate = "%s,您好：<br/>" +
                "    您填写的入职信息存在以下问题，请点击链接修改后提交：" +
                "%s <br/>" +
                "信息修改链接: %s";
        String subject = "员工入职信息修改通知";
        String token = commonService.generatorToken(staffId);
        String urlTemplate = "%s/external/authentication?token=%s";
        String url = String.format(urlTemplate, hrEmailConfig.getDomain(), token);
        String msg = String.format(msgTemplate, name, reason, url);
        if (email == null || name == null) {
            throw new BusinessException(HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getCode(), HRMateInfo.STAFF_INFO_IN_COMPLETE_ERR.getMessage());
        }
        EmailParamDto emailParamDto = EmailParamDto.builder()
                .subject(subject)
                .receivers(email)
                .content(msg)
                .build();
        Response<String> stringResponse = emailRestInterface.sendEmailWithNoAttachment(emailParamDto);
        if (!stringResponse.successful()){
            throw new BusinessException(stringResponse.getCode(), stringResponse.getMessage());
        }
    }

    @Override
    public void doCommingInSendMail(List<String> applyNoList){
        List<String> staffIds = new ArrayList<>();
        applyNoList.forEach(applyNo -> {
            staffInfoApplyDao.updateCreateStaffSendEmailNum(applyNo);
            StaffInfoApplyDto staffInfoApplyDto = staffInfoApplyDao.queryStaffInfoByApplyNo(applyNo);
            if (staffInfoApplyDto != null) {
                String staffId = staffInfoApplyDto.getStaffId();
                if (staffId != null) {
                    staffIds.add(staffId);
                }
            }

        });

        List<EmailParamDto> emailParamDtoList = new ArrayList<>();
        for(String staffNo : staffIds){
            // 查询员工信息
            String staffInfoJson = staffInfoService.queryStaffInfoByStaffNo(staffNo);

            if (staffInfoJson == null){
                throw new BusinessException(HRMateInfo.STAFF_NOT_FOUND_ERR.getCode(), HRMateInfo.STAFF_NOT_FOUND_ERR.getMessage());
            }
            JSONObject staffInfo = JSONObject.parseObject(staffInfoJson);

            String email = staffInfo.getJSONObject("_DATA").getJSONObject("_CONTACT").getString("EMAIL");
            String staffName = staffInfo.getJSONObject("_DATA").getJSONObject("_BASE").getString("ENAME");
            // TODO 需要添加公司
            String companyName = staffInfo.getJSONObject("_DATA").getJSONObject("_BASE").getString("WERKSTX");
            companyName = (companyName == null) ? hrEmailConfig.getCompanyName():companyName;

            String msgTemplate = "%s,您好：<br/>" +
                    "    欢迎您加入%s，请点击下方链接完善您的详细信息，" +
                    "在此您可以核对基本信息，如有问题请联系HR进行再次确认。 <br/>" +
                    "链接地址: %s";
            String subject = "员工入职通知";

            String token = commonService.generatorToken(staffNo);
            String urlTemplate = "%s/external/authentication?token=%s";

            String url = String.format(urlTemplate,hrEmailConfig.getDomain(),token);
            String msg = String.format(msgTemplate,staffName,companyName,url);

            EmailParamDto emailParamDto = EmailParamDto.builder().build();
            emailParamDto.setSubject(subject);
            emailParamDto.setReceivers(email);
            emailParamDto.setContent(msg);

            emailParamDtoList.add(emailParamDto);
        }
        //emailRestInterface.sendEmailWithNoAttachment(emailParamDto);
        emailRestInterface.sendBatchEmailWithNoAttachment(emailParamDtoList);
    }

    @Override
    public void batchSendApproveEmail(List<PageDataRequest> pageDataRequests) {
        List<EmailParamDto> emailParamDtos = new ArrayList<>(pageDataRequests.size());
        pageDataRequests.forEach(pageDataRequest -> {
            JSONObject data = pageDataRequest.getData();
            String email = data.getJSONObject("_CONTACT").getString("EMAIL");
            String name = data.getJSONObject("_BASE").getString("ENAME");
            // TODO 待加入公司
            String company = data.getJSONObject("_BASE").getString("COMPANY");
            if (email == null || name == null) {
                throw new BusinessException(HRMateInfo.STAFF_INFO_EMAIL_OR_NAME_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_INFO_EMAIL_OR_NAME_IS_EMPTY_ERR.getMessage());
            }
            String msgTemplate = "%s,您好：<br/>" +
                        "    您填写的个人信息已通过审核，欢迎您加入XXXX公司，请按约定的入职时间及时办理入职！<br/>" +
                        "如有任何问题，请及时与HR联系！";
            String subject = "员工入职信息审批通过通知";
            String msg = String.format(msgTemplate, name);

            EmailParamDto emailParamDto = EmailParamDto.builder()
                    .subject(subject)
                    .receivers(email)
                    .content(msg)
                    .build();
            emailParamDtos.add(emailParamDto);
        });
        if (emailParamDtos.size() > 0) {
            Response<String> stringResponse = emailRestInterface.sendBatchEmailWithNoAttachment(emailParamDtos);
            if (!stringResponse.successful()){
                throw new BusinessException(stringResponse.getCode(), stringResponse.getMessage());
            }
        }

    }

    @Override
    public void sendCreateStaffApproveEmail(PageDataRequest pageDataRequest) {
            JSONObject data = pageDataRequest.getData();
            String email = data.getJSONObject("_CONTACT").getString("EMAIL");
            String name = data.getJSONObject("_BASE").getString("ENAME");
            // TODO 待加入公司
            String company = data.getJSONObject("_BASE").getString("COMPANY");
            if (email == null || name == null) {
                throw new BusinessException(HRMateInfo.STAFF_INFO_EMAIL_OR_NAME_IS_EMPTY_ERR.getCode(), HRMateInfo.STAFF_INFO_EMAIL_OR_NAME_IS_EMPTY_ERR.getMessage());
            }
            String msgTemplate = "%s,您好：<br/>" +
                    "    您填写的个人信息已通过审核，欢迎您加入XXXX公司，请按约定的入职时间及时办理入职！<br/>" +
                    "如有任何问题，请及时与HR联系！";
            String subject = "员工入职信息审批通过通知";
            String msg = String.format(msgTemplate, name);

            EmailParamDto emailParamDto = EmailParamDto.builder()
                    .subject(subject)
                    .receivers(email)
                    .content(msg)
                    .build();
            Response<String> stringResponse = emailRestInterface.sendEmailWithNoAttachment(emailParamDto);
            if (!stringResponse.successful()){
                throw new BusinessException(stringResponse.getCode(), stringResponse.getMessage());
            }

    }
}
