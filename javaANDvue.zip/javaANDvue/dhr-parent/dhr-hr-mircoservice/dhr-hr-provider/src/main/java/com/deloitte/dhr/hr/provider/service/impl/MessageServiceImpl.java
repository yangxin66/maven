package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.MessageReadStatusEnum;
import com.deloitte.dhr.hr.api.constant.MessageSubTypeEnum;
import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.model.MessageBatchAddDto;
import com.deloitte.dhr.hr.api.model.MessageCountDto;
import com.deloitte.dhr.hr.api.model.MessageDetailDto;
import com.deloitte.dhr.hr.api.model.MessageDto;
import com.deloitte.dhr.hr.provider.mongo.repository.MessageRepository;
import com.deloitte.dhr.hr.provider.mongo.repository.model.MessagePo;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import com.deloitte.dhr.hr.provider.service.MessageService;
import com.deloitte.dhr.hr.provider.service.PositiveService;
import com.deloitte.dhr.hr.provider.utils.PaginationUtils;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.netflix.discovery.converters.Auto;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * date: 10/10/2019 21:04
 *
 * @author wgong
 * @since 0.0.1
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class MessageServiceImpl implements MessageService {

    private static int BATCH_SIZE = 1000;

    @Autowired
    private EntityManager em;

    @Autowired
    private BaseMongoService baseMongoService;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private PositiveService positiveService;

    /**
     * 添加消息
     *
     * @param messageAddDto 批量添加的消息传输实体
     */
    @Override
    public void addMessage(MessageBatchAddDto messageAddDto) {
        List<String> staffNos = messageAddDto.getStaffNos();
        BulkOperations ops = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, HRCollection.HR_MESSAGE);
        staffNos.forEach(staffNo -> {
            MessagePo messagePo = new MessagePo();
            BeanUtils.copyProperties(messageAddDto, messagePo);
            messagePo.setStaffNo(staffNo);
            messagePo.setCreateTime(Instant.now());
            messagePo.setStatus(MessageReadStatusEnum.UN_READ.name());
            messagePo.setStatusName(MessageReadStatusEnum.UN_READ.getValue());
            ops.insert(messagePo);
        });
        ops.execute();
        MessageSubTypeEnum subtypeEnum = messageAddDto.getSubtypeEnum();
        if (MessageSubTypeEnum.POSITIVE == subtypeEnum) {
            // TODO 更新SAP发送邮件的次数
        }
    }

    /**
     * 根据消息查询
     *
     * @param messageTypePaginationReq 消息类型
     */
    @Override
    public PaginationResponse<List<MessageDto>> findMessageByTypeAndPage(PaginationRequest<MessageTypeEnum> messageTypePaginationReq) {
        PageRequest pageRequest = PaginationUtils.pagePrepare(messageTypePaginationReq.getPage(), messageTypePaginationReq.getSize(), "DESC", "status", "createTime");
        MessageTypeEnum typeEnum = messageTypePaginationReq.getData();
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        List<MessagePo> messagePos = messageRepository.findAllByMessageTypeIsAndAndStaffNoIs(typeEnum.name(), currentLoginUserInfo.getStaffNo(), pageRequest);
        int page = pageRequest.getPageNumber();
        int size = pageRequest.getPageSize();
        int total = messageRepository.findAllByMessageTypeIsAndAndStaffNoIs(typeEnum.name(), currentLoginUserInfo.getStaffNo()).size();

        List<MessageDto> messageDtos = messagePos.stream().map(messagePo -> {
            MessageDto messageDto = new MessageDto();
            BeanUtils.copyProperties(messagePo, messageDto);
            return messageDto;
        }).collect(Collectors.toList());
        return new PaginationResponse<>(messageTypePaginationReq.getLanguage(),
                page,
                size,
                total,
                null,
                Response.SUCCESS_CODE, null, messageDtos);
    }

    @Override
    public MessageCountDto getMyAllMessageNum() {
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        int myMessageSize = messageRepository.findAllByMessageTypeIsAndAndStaffNoIs(MessageTypeEnum.PERSONAL_MESSAGE.name(), currentLoginUserInfo.getStaffNo()).size();
        int noticSize = messageRepository.findAllByMessageTypeIsAndAndStaffNoIs(MessageTypeEnum.SYS_NOTICE.name(), currentLoginUserInfo.getStaffNo()).size();

        MessageCountDto messageCountDto = new MessageCountDto();
        messageCountDto.setMessageNum(myMessageSize);
        messageCountDto.setNoticNum(noticSize);
        return messageCountDto;

    }

    @Override
    public MessageDetailDto findById(String id) {
        MessagePo messagePo = messageRepository.findById(id).orElse(null);
        if (messagePo == null) {
            return null;
        }
        readMessage(id);
        MessageDetailDto messageDto = new MessageDetailDto();
        BeanUtils.copyProperties(messagePo, messageDto);
        return messageDto;
    }

    @Override
    public void readMessage(String id) {
        MessagePo messagePo = messageRepository.findById(id).orElse(null);
        if (messagePo != null) {
            if (!MessageReadStatusEnum.READ.name().equals(messagePo.getStatus())) {
                messagePo.setStatus(MessageReadStatusEnum.READ.name());
                messagePo.setStatusName(MessageReadStatusEnum.READ.getValue());
                messageRepository.save(messagePo);
            }
        }
    }

    @Override
    public void deleteMessage(String id) {
        messageRepository.findById(id).ifPresent(messagePo -> messageRepository.delete(messagePo));

    }

    @Override
    public void sendAllMessage(MessageBatchAddDto messageAddDto) {
        // TODO 从SAP获取所有待转正的员工id
        List<String> unPositiveStaffInfoNos = positiveService.getUnPositiveStaffInfoNos();
        messageAddDto.setStaffNos(unPositiveStaffInfoNos);
        addMessage(messageAddDto);
    }

}
