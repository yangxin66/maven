package com.deloitte.dhr.hr.provider.strategy;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.ApplyService;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.dhr.hr.provider.service.TaskNodeHandlerService;
import com.deloitte.infrastructure.communication.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 员工转正管理流程节点相关处理
 * date: 15/10/2019 9:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class PositiveStrategy implements Strategy {

    @Autowired
    private TaskNodeHandlerService taskNodeHandlerService;

    @Autowired
    HrNotificationService hrNotificationService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    ApplyService applyService;

    @Override
    public boolean nodeHandler(AuditHandlerDto auditHandlerDto, String staffId,
                               String applyNo) {
        boolean ended = taskNodeHandlerService.commonFlowNodeHandler(auditHandlerDto);
        JSONObject businessData = auditHandlerDto.getBusinessData();
        // 提交审批需要更新数据
        if (businessData != null) {
            Request<Map> request = new Request<>(businessData);
            // 这里的状态只要不是submit 传任意状态就行
            applyService.saveApplyInfo(request, ApproveStatusEnum.APPROVED);
        }
        // TODO 可能需要将临时数据需要修改为正式数据
        if (ended) {
            if (SubtypeEnum.POSITIVE == auditHandlerDto.getSubtypeEnum()) {
                // 员工离职审批完后的操作
                positiveApprovedHandler(applyNo);
            }

        }
        return ended;
    }

    @Override
    public ManagementTypeEnum getManagementType() {
        return ManagementTypeEnum.POSITIVE;
    }

    /**
     * 员工转正审批通过后的操作
     *
     * @param staffId 员工id
     */
    private void positiveApprovedHandler(String staffId) {
        // TODO 需要调用SAP的接口 将员工状态变成转正
    }

}
