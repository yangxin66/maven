package com.deloitte.dhr.hr.provider.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.extension.beans.sap.SapDataPaginationResponse;
import com.deloitte.dhr.hr.api.model.SearchStaffCategoryInfoDto;
import com.deloitte.dhr.hr.api.model.SendStaffEmailDTO;
import com.deloitte.dhr.hr.api.model.VerifyStaffInfoDTO;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;

/**
 * hr相关输入业务处理类
 * <br/>27/08/2019 11:44
 *
 * @author lshao
 */
public interface HrService {

    Response<String> save(Request<PageDataRequest> request);

    void choiceSendStaffEmail(SendStaffEmailDTO request);

    Response<String> verifyStaffInfo(Request<VerifyStaffInfoDTO> request);

    /**
     * 将员工修改信息同步到SAP中
     * @param staffInfo
     * @return
     */
    Response<Void> updateStaffInfoByHr(JSONObject staffInfo);

    /**
     * 员工信息变更-弹窗条件搜索
     * @param dto
     * @return
     */
    JSONObject searchStaffCategoryInfo(SearchStaffCategoryInfoDto dto);
}
