package com.deloitte.dhr.hr.provider.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.ApplyPartEnum;
import com.deloitte.dhr.common.constant.ApproveStatusEnum;
import com.deloitte.dhr.common.constant.CommonStringConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.common.global.session.ContextSession;
import com.deloitte.dhr.common.global.session.CurrentLoginUserInfo;
import com.deloitte.dhr.common.utils.ResponseUtil;
import com.deloitte.dhr.common.utils.ValueGetTool;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.constant.ProcessInstanceTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.provider.mongo.dao.BaseSimpleMongoDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoCheckDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.notification.provider.api.EmailRestInterface;
import com.deloitte.workflow.api.WfProcessApi;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.model.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.*;

/**
 * @author chunliucq
 * @since 27/08/2019 11:28
 */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class StaffInfoServiceImpl implements StaffInfoService {

    @Autowired
    private StaffInfoDao staffInfoDao;

    @Autowired
    private StaffInfoCheckDao staffInfoCheckDao;

    @Autowired
    private EmailRestInterface emailRestInterface;

    @Autowired
    BaseSimpleMongoDao baseSimpleMongoDao;

    @Autowired
    private BaseMongoService baseMongoService;

    @Autowired
    private BussniessNoGeneratorService bussniessNoGeneratorService;

    @Autowired
    private WfProcessApi wfProcessApi;
    @Autowired
    private WfTaskApi wfTaskApi;

    @Autowired
    private FlowTraceService flowTraceService;

    @Autowired
    private AuditNodeService auditNodeService;

    @Autowired
    private StaffApplyAlterService staffApplyAlterService;

    private static String STAFF_INFO_DATA = "_DATA";
    private static String STAFF_INFO_DATA_CHECK = "_DATA_CHECK";
    private static String STAFF_INFO_CHECK_LIST = "_CHECK_LIST";

    public static String STAFF_INFO_BUSINESSID = "_BUSINESSID";

    @Override
    public JSONObject savePartStaffInfo(JSONObject staffInfoJson) {

        log.info("req:{}", staffInfoJson.toJSONString());

        // 人员编号
        String ipeer = staffInfoJson.getString(STAFF_INFO_BUSINESSID);
        JSONObject staffData = staffInfoJson.getJSONObject(STAFF_INFO_DATA);
        for (String key : staffData.keySet()) {

            JSONObject queryJson = new JSONObject();
            queryJson.put(STAFF_INFO_BUSINESSID, ipeer);

            Map<String, JSON> updateJson = new HashMap<>();

            boolean isDataObj = isJsonObject(staffData, key);
            if (isDataObj) {
                JSONObject moduleData = staffData.getJSONObject(key);
                updateJson.put(STAFF_INFO_DATA + "." + key, moduleData);
            } else {
                JSONArray staffArrData = staffData.getJSONArray(key);
                if (staffArrData != null && staffArrData.size() > 0) {
                    for (int i = 0, len = staffArrData.size(); i < len; i++) {
                        JSONObject tmpObject = staffArrData.getJSONObject(i);
                        String rid = bussniessNoGeneratorService.getNewBussniessNo(CommonStringConstant.BUSINESSNO_RID_KEY);
                        tmpObject.put("_RID", rid);
                    }
                }
                updateJson.put(STAFF_INFO_DATA + "." + key, staffArrData);
            }

            staffInfoDao.updateAndFlush(queryJson, updateJson, HRCollection.HR_STAFF_INFO);
            updateStaffInfoCheckPart(ipeer, key, true);
        }
        return staffInfoJson;
    }

    @Override
    public String queryStaffInfoByStaffNo(String staffNo) {
        return staffInfoDao.queryStaffInfoByStaffNo(staffNo);
    }

    private boolean isJsonObject(JSONObject jsonObject, String key) {
        String jsonStr = null;
        try {
            JSONArray tempJson = jsonObject.getJSONArray(key);
            if (tempJson != null) {
                jsonStr = tempJson.toJSONString();
            }
            if (jsonStr != null || jsonStr.startsWith("[")) {
                return false;
            }
        } catch (Exception e) {
            return true;
        }
        return true;
    }

    @Override
    public void updateStaffInfoCheckPart(String staffNo, String staffInfoPartNode, boolean checkResult) {
        Document document = staffInfoCheckDao.queryStaffInfoCheckListByStaffNo(staffNo);

        if (document == null) {
            // TODO 添加配置后这里需要修改
            String[] checkListArr = {"_BASE", "_PARTY", "_BANK", "_HOME", "_ADDRESS", "_EDUCATION",
                    "_WORK", "_TRAIN", "_CAREER", "_POSITION", "_LANGUAGE", "_AWARD", "_JIANZHI"};
            List<String> checkList = Arrays.asList(checkListArr);


            JSONObject checkNode = new JSONObject();
            checkNode.put(staffInfoPartNode, checkResult);

            JSONObject checkdata = new JSONObject();
            checkdata.put(STAFF_INFO_BUSINESSID, staffNo);
            checkdata.put(STAFF_INFO_CHECK_LIST, checkListArr);
            checkdata.put(STAFF_INFO_DATA_CHECK, checkNode);
            staffInfoDao.save(checkdata.toJSONString(), HRCollection.HR_STAFF_INFO_CHECK);
        } else {
            JSONObject checkData = JSONObject.parseObject(document.toJson());
            // 人员编号
            JSONObject staffDataCheck = checkData.getJSONObject(STAFF_INFO_DATA_CHECK);

            JSONObject queryJson = new JSONObject();
            queryJson.put(STAFF_INFO_BUSINESSID, staffNo);
            Query query = new Query();
            query.addCriteria(Criteria.where(STAFF_INFO_BUSINESSID).is(staffNo));

            Update update = new Update();
            update.set(STAFF_INFO_DATA_CHECK + "." + staffInfoPartNode, checkResult);
            staffInfoDao.updateAndFlush(query, update, HRCollection.HR_STAFF_INFO_CHECK);
        }
    }

    @Override
    public boolean isAllFillInComplete(String staffNo) {
        Document document = staffInfoCheckDao.queryStaffInfoCheckListByStaffNo(staffNo);
        if (document == null) {
            return false;
        }
        JSONObject staffCheckData = JSONObject.parseObject(document.toJson());

        JSONArray checkListJson = staffCheckData.getJSONArray(STAFF_INFO_CHECK_LIST);
        String[] checkListArr = checkListJson.toArray(new String[]{});

        JSONObject checkPointJson = staffCheckData.getJSONObject(STAFF_INFO_DATA_CHECK);

        boolean isComplete = true;
        for (String check : checkListArr) {
            Boolean tempResult = checkPointJson.getBoolean(check);
            if (tempResult == null || tempResult.booleanValue() == false) {
                isComplete = false;
                break;
            }
        }
        return isComplete;
    }

    @Override
    public Response<Map> queryUpdateDetailInfo(String applyNo, String rid) {
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        query.addCriteria(Criteria.where("_RID").is(rid));
        Map applyChangedmap = baseMongoService.queryOneForMap(query, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        if (applyChangedmap == null) {
            return ResponseUtil.build().createBadResponse(HRMateInfo.STAFF_INFO_UPDATE_APPLY_ERR_APPNO_NONE.getCode(),
                    HRMateInfo.STAFF_INFO_UPDATE_APPLY_ERR_APPNO_NONE.getMessage());
        }

        JSONObject applyDoc = staffApplyAlterService.queryApplyAlterByApply(applyNo);
        if (applyDoc == null) {
            return ResponseUtil.build().createBadResponse(HRMateInfo.STAFF_INFO_UPDATE_APPLY_ERR_APPNO_NONE.getCode(),
                    HRMateInfo.STAFF_INFO_UPDATE_APPLY_ERR_APPNO_NONE.getMessage());
        }

        String staffNo = applyDoc.getString("_BUSINESSID");
        String dataPart = applyDoc.getString("_DATA_PART");
        Object op1 = applyChangedmap.get("_OP");
        String opType = String.valueOf(op1);

        Map<String, Object> result = new HashMap<>();
        result.put("_OP", opType);
        String staffInfoJson = this.queryStaffInfoByStaffNo(staffNo);
        if (staffInfoJson == null) {
            return ResponseUtil.build().createBadResponse(HRMateInfo.STAFF_NOT_FOUND_ERR.getCode(),
                    HRMateInfo.STAFF_NOT_FOUND_ERR.getMessage());
        }
        if (staffInfoJson == null) {
            return ResponseUtil.build().createBadResponse(HRMateInfo.STAFF_NOT_FOUND_ERR.getCode(),
                    HRMateInfo.STAFF_NOT_FOUND_ERR.getMessage());
        }
        Map<String, Object> staffInfoMap = (Map<String, Object>) JSONObject.parseObject(staffInfoJson);
        Map<String, Object> changeBefor = queryRecord(staffInfoMap, dataPart, rid);
        result.put("change_before", changeBefor);
        result.put("change_after", applyChangedmap);
        return ResponseUtil.build().creatDeaultOkResponse(result);
    }

    @Override
    public Boolean queryDetailInfoUpdate(Request<Map> staffUpdateApplyRecordRequest) {


        Map<String, Object> data = staffUpdateApplyRecordRequest.getData();
        Map map = (Map) data.get("_DATA");
        String part = (String) data.get("_DATA_PART");
        Map map1 = (Map) map.get(part);
        String applyNo = (String) map1.get("_APPLY_NO");
        String rid = (String) map1.get("_RID");
        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        query.addCriteria(Criteria.where("_RID").is(rid));
        baseSimpleMongoDao.removeAndFlush(query, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        baseSimpleMongoDao.save(map1, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        return true;
    }

    private Map<String, Object> queryRecord(Map<String, Object> infoMap, String key, String rid) {
        Object tmpData = ((Map<String, Object>) infoMap.get("_DATA")).get(key);
        Map<String, Object> record = null;
        if (tmpData instanceof List) {
            List<Map<String, Object>> recordList = (List<Map<String, Object>>) tmpData;
            record = getRecordByRid(recordList, rid);
        } else {
            record = (Map<String, Object>) tmpData;
        }
        return record;
    }

    @Override
    public void doSendMail(String staffNo, String msgTemplate, String... msgParams) {

    }

    @Override
    public Response<Void> applyModStaffInfo(Request<Map> applyRequest) {
        // 校验是否提交申请
        Map reqData = applyRequest.getData();
        String applyNo = bussniessNoGeneratorService.getNewBussniessNo("MOD_UPDATE_APPLY_NO");
        reqData.put("_APPLY_NO", applyNo);
        reqData.put("_APPLY_TIME", Instant.now());
        reqData.put("_APPLY_STATUS", ApproveStatusEnum.SUBMITTED);

        String dataPart = (String) reqData.get("_DATA_PART");

        String staffNo = (String) reqData.get("_BUSINESSID");
        String reason = (String) reqData.get("_REASON");
        if (reason != null && reason.length() > 100) {
            throw new BusinessException(HRMateInfo.APPLY_REMARK_LONG_OVER_LONG_ERR.getCode(), HRMateInfo.APPLY_REMARK_LONG_OVER_LONG_ERR.getMessage());
        }
        // todo liuchun  从SAP中查询员工信息
        // 暂时从DHR获取
        /*****************************************/
        String staffJsonStr = queryStaffInfoByStaffNo(staffNo);
        JSONObject staffInfoJson = JSONObject.parseObject(staffJsonStr);

        /****************************************/


        Map<String, Object> data = (Map<String, Object>) reqData.get("_DATA");
        Set<String> dataKeySet = data.keySet();
        if (dataKeySet == null || dataKeySet.size() == 0) {
            return ResponseUtil.build().createBadResponse(HRMateInfo.STAFF_INFO_UPDATE_APPLY_REQUEST_ERR.getCode(),
                    HRMateInfo.STAFF_INFO_UPDATE_APPLY_REQUEST_ERR.getMessage());
        }
        for (String key : dataKeySet) {
            dataPart = key;
        }
        // 修改记录条数
        int modNum = 0;
        Object applyChange = data.get(dataPart);
        if (applyChange instanceof List) {
            List<Map<String, Object>> changeList = (List<Map<String, Object>>) applyChange;
            if (CollectionUtils.isEmpty(changeList)) {
                return ResponseUtil.build().createBadResponse(HRMateInfo.STAFF_INFO_UPDATE_APPLY_REQUEST_ERR.getCode(),
                        HRMateInfo.STAFF_INFO_UPDATE_APPLY_REQUEST_ERR.getMessage());
            }
            for (Map<String, Object> map : changeList) {
                map.put("_APPLY_NO", applyNo);
                if (StringUtils.isEmpty(map.get("_RID"))) {
                    String rid = bussniessNoGeneratorService.getNewBussniessNo(CommonStringConstant.BUSINESSNO_RID_KEY);
                    map.put("_RID", rid);
                }
            }
            modNum = changeList.size();
            baseMongoService.save(changeList, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
        } else {
            Map<String, Object> change = (Map<String, Object>) applyChange;
            change.put("_APPLY_NO", applyNo);
            if (change.get("_RID") == null) {
                String rid = bussniessNoGeneratorService.getNewBussniessNo(CommonStringConstant.BUSINESSNO_RID_KEY);
                change.put("_RID", rid);
            }
            baseMongoService.save(JSONObject.toJSONString(change), HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);
            modNum = 1;
        }

        reqData.remove("_DATA");
        reqData.put("_DATA_PART", dataPart);
        String partName = ApplyPartEnum.valueOf(dataPart).getValue();
        reqData.put("_DATA_PART_MAME", partName);
        reqData.put("_MOD_NUM", String.valueOf(modNum));
        // 设置员工相关信息
        reqData.put("_NAME", ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.NACHN")
                + ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.ENAME"));
        reqData.put("_APPLICANT_ID", ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.DEPARTMENT"));
        reqData.put("_DEPARTMENT_NAME", ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.DEPARTMENT"));
        reqData.put("_DEPARTMENT_NAME", ValueGetTool.getStringFromJsonByKey(staffInfoJson, "_DATA._BASE.DEPARTMENT"));
        // TODO
        CurrentLoginUserInfo currentLoginUserInfo = ContextSession.getCurrentLoginUserInfo();
        String currentStaffNo = currentLoginUserInfo.getStaffNo();
        reqData.put("_APPLICANT_ID", currentStaffNo);
        reqData.put("_APPLICANT_NAME", reqData.get("_NAME"));
        reqData.put("_IS_MY_APPLICATION", "1");
        reqData.put("_APPLY_TYPE", ManagementTypeEnum.STAFF_INFO_MODIFY.name());
        reqData.put("_APPLY_SUB_TYPE", SubtypeEnum.STAFF_INFO_MODIFY.name());

        baseMongoService.save(JSONObject.toJSONString(reqData), HRCollection.HR_STAFF_UPDATE_APPLY);

        //启动流程引擎
        ProcessStartDto processStartDto = new ProcessStartDto();
        //HARDCODE
        processStartDto.setKey(ProcessInstanceTypeEnum.STAFF_INFO_MODIFY.getKey());
        Map<String, Object> parmaeter = new HashMap<>();
        parmaeter.put("instanceType", ManagementTypeEnum.STAFF_INFO_MODIFY.name());
        // todo 修改变化员工编号
        processStartDto.setVariables(parmaeter);
        Response<ProcessInstanceDto> wfResonse = wfProcessApi.start(new Request<>(processStartDto));
        ProcessInstanceDto processInstanceDto = wfResonse.getData();
        List<TaskNodeDto> taskList = processInstanceDto.getTaskNodes();

        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        Update update = new Update();
        update.set("_PROCESS_INSTANCE_ID", wfResonse.getData().getId());
        baseMongoService.updateAndFlush(query, update, HRCollection.HR_STAFF_UPDATE_APPLY);

        auditNodeService.addNextTaskNode(taskList, applyNo, ApproveStatusEnum.SUBMITTED.name(), null, null, null);
        taskList.forEach(tmp -> {
            AuditHandlerDto auditHandlerDto = new AuditHandlerDto();
            auditHandlerDto.setProcessInstantId(wfResonse.getData().getId());
            auditHandlerDto.setRemark(reason);
            auditHandlerDto.setTaskId(tmp.getTaskId());
            auditHandlerDto.setApplicationStatusEnum(ApplicationStatusEnum.SUBMITTED);
            auditHandlerDto.setSubtypeEnum(SubtypeEnum.STAFF_INFO_MODIFY);
            Request<List<AuditHandlerDto>> flowNodeHanderReq = new Request<>(Collections.singletonList(auditHandlerDto));
            flowTraceService.flowNodeHandler(flowNodeHanderReq);
        });


        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    private Map<String, Object> getRecordByRid(List<Map<String, Object>> rdMapList, String rid) {
        Map<String, Object> rdMap = null;
        for (Map<String, Object> map : rdMapList) {
            if (map != null && map.get("_RID") != null && map.get("_RID").equals(rid.trim())) {
                rdMap = map;
                break;
            }
        }
        return rdMap;
    }

}
