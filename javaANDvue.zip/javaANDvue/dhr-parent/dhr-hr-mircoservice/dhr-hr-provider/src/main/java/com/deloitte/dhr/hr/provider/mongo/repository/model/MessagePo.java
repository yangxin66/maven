package com.deloitte.dhr.hr.provider.mongo.repository.model;

import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@Document(collection = HRCollection.HR_MESSAGE)
public class MessagePo {

    @Id
    private String id;

    /**
     * 消息标题
     */
    String title;

    /**
     * 消息类型
     */
    MessageTypeEnum messageType;

    /**
     * 消息
     */
    String message;

    /**
     * 创建时间
     */
    Instant createTime;

    /**
     * 员工编号
     */
    String staffNo;

    String status;

    String statusName;

}
