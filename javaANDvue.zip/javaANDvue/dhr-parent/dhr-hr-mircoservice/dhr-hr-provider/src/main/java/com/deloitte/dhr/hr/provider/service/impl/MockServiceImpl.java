package com.deloitte.dhr.hr.provider.service.impl;

import com.deloitte.dhr.common.export.ExcelExportImpl;
import com.deloitte.dhr.common.export.model.ExportTitle;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.QueryApplyUploadDto;
import com.deloitte.dhr.hr.api.model.TextValue;
import com.deloitte.dhr.hr.api.model.staff.StaffNoDto;
import com.deloitte.dhr.hr.provider.config.ApplyProcessEnum;
import com.deloitte.dhr.hr.provider.service.ApplyService;
import com.deloitte.dhr.hr.provider.service.MockService;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class MockServiceImpl implements MockService {


    @Autowired
    ApplyService applyService;

    private static List<Map> mapList;

    @Override
    /**
     * 查询员工的待确认信息
     */
    public Response queryUploadEstimate(String staffNo) {
        // todo 加入SAP需要修改
        Map<String, Object> map = new HashMap<>();
        List<String> list = new ArrayList<>();
        list.add("北京");
        list.add("重庆");
        list.add("天津");
        list.add("上海");
        final double d = Math.random();
        final int i = (int) (d * 100);
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        map.put("_SOCIAL_SECURITY_TIME", sDateFormat.format(new Date()));
        map.put("_SOCIAL_SECURITY_LAND1", list.get(i % 4));
        map.put("_ACCUMULATION_FUND_TIME", sDateFormat.format(new Date()));
        map.put("_ACCUMULATION_FUND_LAND1", list.get(i % 4));
        map.put("_ANNUAL_LEAVE_DATE", i / 10);
        map.put("_ARREARS", i);
        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "Success", map);
    }

    @Override
    /**
     * 文件上传,并返回上传数据的第一页数据
     * 按照申请编号和申请任务的类型生成数据并返回
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public PaginationResponse<Map<String, Object>> queryUploadApplyData(PaginationRequest<QueryApplyUploadDto> request,Boolean type) {
        // todo  加入SAP后需要改造
        String busiType = request.getData().getBusiType();
        SubtypeEnum subtypeEnum = SubtypeEnum.valueOf(busiType);
        ApplyProcessEnum byBusiType = ApplyProcessEnum.getByBusiType(subtypeEnum);
        String applyNo = request.getData().getApplyNo();
        int page = request.getPage();
        int size = request.getSize();
        //生成数据
        MoKeData(byBusiType);
        int total = mapList.size();
        //生成表头数据
        List<ExportTitle> titleList = MoKoTitle(subtypeEnum,false);
        List<Map> trueList = new ArrayList<>();
        for (Map map9 : mapList) {
            Map<String, Object> map = new HashMap<>();
            map9.get("UPLOAD_STATUS");
            //判断正确的数据
            if ((Boolean) map9.get("UPLOAD_STATUS")) {
                if (byBusiType.equals(ApplyProcessEnum.DIMISSION) || byBusiType.equals(ApplyProcessEnum.RETIRE) || byBusiType.equals(ApplyProcessEnum.STAFF_DECEASE)
                        || byBusiType.equals(ApplyProcessEnum.TERMINATE_THE_CONTRACT_FROM_PROTOCOL) || byBusiType.equals(ApplyProcessEnum.TERMINATE_THE_CONTRACT_FROM_DISCIPLINE)
                        || byBusiType.equals(ApplyProcessEnum.DIMISSION_FROM_EMPLOYEES)) {
                    //如果时离职
                    Map<String, Object> map1 = new HashMap<>();
                    map1.put("_DIMISSION_TYPE", getTextValue("LIZHI"));
                    map1.put("_DIMISSION_TYPE_NAME", getTextValue("离职"));
                    map1.put("_LAST_WORK_DATE", getTextValue("2019-10-14T16:00:00.000Z"));
                    map1.put("_COMPENSATION_TYPE", getTextValue("LEIBIE1"));
                    map1.put("_COMPENSATION_TYPE_NAME", getTextValue("类别1"));
                    map1.put("_COMPENSATION_AMOUNT", getTextValue("123"));
                    map1.put("_REASON", getTextValue("123"));
                    map1.put("_REMARK", getTextValue("123"));
                    map1.put("_INTERVIEW", getTextValue("123"));
                    map.put("_DIMISSION_INFO", map1);

                    Map<String, Object> map2 = new HashMap<>();
                    map2.put("_BEGIN_DATE", getTextValue(""));
                    map2.put("_END_DATE", getTextValue(""));
                    map2.put("_DATE_NUMS", getTextValue(""));
                    map.put("_ABSENCE_INFO", map2);

                    Map<String, Object> map3 = new HashMap<>();
                    map3.put("_HANDED_OVER", getTextValue(""));
                    map3.put("_HANDED_OVER_NAME", getTextValue(""));
                    map3.put("_COMPUTER_RETURNED", getTextValue(""));
                    map3.put("_COMPUTER_RETURNED_NAME", getTextValue(""));
                    map3.put("_FINANCES_ETTLED", getTextValue(""));
                    map3.put("_FINANCES_ETTLED_NAME", getTextValue(""));
                    map.put("HANDOVER", map3);

                    Map<String, Object> map4 = new HashMap<>();
                    map4.put("_IS_ADD", getTextValue(""));
                    map4.put("_IS_ADD_NAME", getTextValue(""));
                    map4.put("_ADD_REMARK", getTextValue(""));
                    map.put("BLACK_LIST", map4);

                    Map<String, Object> map5 = new HashMap<>();
                    map5.put("_APPLY_TYPE", getTextValue(""));
                    map5.put("_BUSINESSID", getTextValue(""));
                    map.put("_APPLYINFO", map5);

                    Map<String, Object> map6 = new Hashtable<>();
                    map6.put("_BUSINESSID", getTextValue("1567075173598"));
                    map6.put("_NAME",getTextValue("李四"));
                    map6.put("GESCH",getTextValue("男") );
                    map6.put("COMPANY", getTextValue("德勤"));
                    map6.put("PLANSTX", getTextValue("普通员工"));
                    map6.put("ZGSBMZW", getTextValue("人力资源部"));
                    map6.put("HIREDATE",getTextValue("2019-10-14"));
                    map6.put("DHRSFZH", getTextValue("503407199012345678"));
                    map6.put("_STATUS", getTextValue("在职"));
                    map6.put("RYDJ", getTextValue("基层"));
                    map6.put("URL",getTextValue("http://172.16.4.94:8022/gateway/api/v1/hr/attach/download?key=group1%2FM01%2F00%2F11%2FrBAEn12OZ4WAZo" +
                            "-aAABmo2nWtsE561.jpg&attachType=FILE&attachName=6.jpg&_t=1569585245233 ") );
                    map6.put("BTRTL", getTextValue("黑龙江_大庆市"));
                    map6.put("RACE",getTextValue("汉"));
                    map6.put("INFTY", getTextValue("共青团团员"));
                    map.put("_STAFF_INFO", map6);
                } else if (byBusiType.equals(ApplyProcessEnum.STAFF_POSITION_CHANGE)) {
                    //如果时员工岗位变动
                    Map<String, Object> map1 = new HashMap<>();
                    map1.put("_REASON", getTextValue("不想做了"));
                    map1.put("_APPLY_TIME", getTextValue("2019-08-29"));
                    map.put("_APPLY_OP_INFO", map1);

                    Map<String, Object> map2 = new HashMap<>();
                    map2.put("PERNR", getTextValue("1567075173598"));
                    map2.put("_NAME", getTextValue("张三"));
                    map2.put("GESCHTX", getTextValue("男"));
                    map2.put("GBDAT", getTextValue("2000-08-29"));
                    map2.put("DHRSFZH", getTextValue("503407199012345678"));
                    map2.put("RACE", getTextValue("汉"));
                    map2.put("PCODE", getTextValue("共青团团员"));
                    map.put("_STAFF_INFO", map2);

                    Map<String, Object> map3 = new HashMap<>();
                    map3.put("WERKS", map9.get("WERKS"));
                    map3.put("BTRTL", map9.get("BTRTL"));
                    map3.put("ZZGWXL", map9.get("ZZGWXL"));
                    map3.put("ZZZD", map9.get("ZZZD"));
                    map3.put("ZEBM", map9.get("ZEBM"));
                    map3.put("ZZZX", map9.get("ZZZX"));
                    map3.put("ZZGWCJ", map9.get("ZZGWCJ"));
                    map.put("_ALTERATION_INFO", map3);
                } else if (byBusiType.equals(ApplyProcessEnum.START_AND_POST) || byBusiType.equals(ApplyProcessEnum.END_AND_POST)) {
                    //兼职信息
                    Map<String, Object> map1 = new HashMap<>();
                    map1.put("ZEJZDWMC", getTextValue(" 德勤"));
                    map1.put("BTRTL", getTextValue("人力资源部"));
                    map1.put("ZZZX", getTextValue("人力资源部经理"));
                    map.put("MAIN_POST_INFO", map1);

                    Map<String, Object> map2 = new HashMap<>();
                    map2.put("PERNR", getTextValue("1567075173598"));
                    map2.put("_NAME", map9.get("_NAME"));
                    map2.put("GESCHTX", getTextValue("男"));
                    map2.put("ZEJZDWMC", getTextValue(" 德勤"));
                    map2.put("BTRTL", getTextValue("人力资源部"));
                    map2.put("ZZZX", getTextValue("人力资源部经理"));
                    map2.put("GBDAT", getTextValue("2000-08-29"));
                    map2.put("HIREDATE", getTextValue("2018-08-29"));
                    map2.put("_STATUS", getTextValue("在职"));
                    map.put("_STAFF_INFO", map2);

                    List<Object> JZList = new ArrayList<>();
                    Map<String, Object> map4 = new HashMap<>();
                    Map<String, Object> map3 = new HashMap<>();
                    Map<String, Object> map5 = new HashMap<>();
                    JZList.add(map3);
                    JZList.add(map4);
                    JZList.add(map5);
                    List<Object> JSJZList = new ArrayList<>();
                    Map<String, Object> map6 = new HashMap<>();
                    Map<String, Object> map7 = new HashMap<>();
                    JSJZList.add(map6);
                    JSJZList.add(map7);
                    if (byBusiType.equals(ApplyProcessEnum.START_AND_POST)) {
                        //开始兼职
                        startPost(map9, map6);

                        startPost(map9, map7);
                        map.put("_JIANZHI_INFO_SAVE", JSJZList);
                    } else {
                        //结束兼职
                        getJSJZ(map9, map4);

                        getJSJZ(map9, map3);

                        getJSJZ(map9, map5);

                        map.put("_JIANZHI_INFO_SAVE", JZList);
                    }


                } else if (byBusiType.equals(ApplyProcessEnum.START_CONTRACT) || byBusiType.equals(ApplyProcessEnum.END_CONTRACT) || byBusiType.equals(ApplyProcessEnum.EXTEND_CONTRACT)) {
                    //合同信息
                    Map<String, Object> map2 = new HashMap<>();
                    map2.put("PERNR", getTextValue("1567075173598"));
                    map2.put("_NAME", getTextValue("张三"));
                    map2.put("GESCHTX", getTextValue("男"));
                    map2.put("ZEJZDWMC", getTextValue(" 德勤"));
                    map2.put("BTRTL", getTextValue("人力资源部"));
                    map2.put("ZZZX", getTextValue("人力资源部经理"));
                    map2.put("GBDAT", getTextValue("2000-08-29"));
                    map2.put("HIREDATE", getTextValue("2018-08-29"));
                    map2.put("_STATUS", getTextValue("在职"));
                    map.put("_STAFF_INFO", map2);

                    Map<String, Object> map4 = new HashMap<>();
                    if (byBusiType.equals(ApplyProcessEnum.EXTEND_CONTRACT)) {
                        //续签合同
                        getContract(map9, map4);
                        map4.put("_CONTRACT_EXTEND_TIME", map9.get("_CONTRACT_EXTEND_TIME"));

                    } else if (byBusiType.equals(ApplyProcessEnum.START_CONTRACT)) {
                        //开始合同
                        getContract(map9, map4);

                    } else {
                        //结束合同
                        getContract(map9, map4);
                        map4.put("_CONTRACT_STOP", map9.get("_CONTRACT_STOP"));
                        map4.put("_CONTRACT_STOP_REASON", map9.get("_CONTRACT_STOP_REASON"));


                    }
                    map.put("_CONTRACT_INFO", map4);

                }
                trueList.add(map);
            }
        }
        //正确的数据保存到数据库中
        if(!type){
            applyService.saveApplyDetailRecord(busiType, applyNo, trueList, true, false);
        }
        Map<String, Object> response = new HashMap<>();
        List<Object> arrayList = new ArrayList<>();
        //总条数小于一页的条数
        if (total < size) {
            size = total;
        }
        //上传文件返回第一页10条数据
        if (mapList.size() > 10) {
            for (int i = 0; i < 10; i++) {
                arrayList.add(mapList.get(i));
            }
        } else {
            for (int i = 0; i < size; i++) {
                arrayList.add(mapList.get(i));
            }
        }
        response.put("data", arrayList);
        response.put("title", titleList);
        //正确的条数
        response.put("TRUE_SIZE", trueList.size());
        return new PaginationResponse<>(request.getLanguage(),
                page,
                size,
                total,
                null,
                Response.SUCCESS_CODE, null, response);
    }

    //开始兼岗
    private void startPost(Map map9, Map<String, Object> map6) {
        map6.put("ZEJZDWMC", map9.get("ZEJZDWMC"));
        map6.put("JZBM", map9.get("JZBM"));
        map6.put("JZZW", map9.get("JZZW"));
        map6.put("BEGDA", map9.get("BEGDA"));
        map6.put("_JZJSRQ", map9.get("_JZJSRQ"));
        map6.put("_JIANZHI_TYPE", map9.get("_JIANZHI_TYPE"));
    }
    //结束兼岗
    private void getJSJZ(Map map9, Map<String, Object> map4) {
        map4.put("ZEJZDWMC", map9.get("ZEJZDWMC"));
        map4.put("BEGDA", map9.get("BEGDA"));
        map4.put("JZBM", map9.get("JZBM"));
        map4.put("_JIANZHI_TYPE", map9.get("_JIANZHI_TYPE"));
        map4.put("JZZW", map9.get("JZZW"));
        map4.put("_JZJSRQ", map9.get("_JZJSRQ"));
    }
    //合同的基本信息
    private void getContract(Map map9, Map<String, Object> map4) {
        map4.put("_CONTRACT_NO", getTextValue("_CONTRACT_NO"));
        map4.put("_CONTRACT_TYPE", map9.get("_CONTRACT_TYPE"));
        map4.put("_CONTRACT_BEGDA", map9.get("_CONTRACT_BEGDA"));
        map4.put("_CONTRACT_ZZGZDW", map9.get("_CONTRACT_ZZGZDW"));
        map4.put("_CONTRACT_JSRQ", map9.get("_CONTRACT_JSRQ"));
        map4.put("_CONTRACT_NUM", map9.get("_CONTRACT_NUM"));
        map4.put("_CONTRACT_SUBJECT", map9.get("_CONTRACT_SUBJECT"));
    }


    /**
     * 通过员工编号查询员工的基本信息
     *
     * @param staffNo 员工编号
     * @return 数据
     */
    @Override
    public Response<List> queryApplyStaffInfo(String staffNo) {

        // todo  需要加入SAP之后在改造
        List<Object> responseList = new ArrayList<>();

        //姓名
        List<String> list = new ArrayList<>();
        list.add("张三");
        list.add("李四");
        list.add("王五");
        list.add("曹操");
        list.add("关羽");
        list.add("马超");
        list.add("刘备");
        list.add("韩信");
        list.add("李白");
        list.add("黄忠");
        //城市
        List<String> list2 = new ArrayList<>();
        list2.add("北京");
        list2.add("重庆");
        list2.add("天津");
        list2.add("上海");
        //身份证
        List<String> sfz = new ArrayList<>();
        sfz.add("503407199012345678");
        sfz.add("1234567890987654321");
        sfz.add("235555555555555555");
        sfz.add("1501111111111");
        sfz.add("1504241995087346722");
        sfz.add("522127199612125016");
        //员工编号
        List<String> staffNoList = new ArrayList<>();
        staffNoList.add("1567075173598");
        staffNoList.add("1567132734570");
        staffNoList.add("1567157746328");
        staffNoList.add("1567158700105");
        staffNoList.add("1567563695459");
        staffNoList.add("1567077163406");
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        int size = staffNoList.size();
        for (int i = 0; i < 1; i++) {
            String s = staffNoList.get(i);
//            if (s.startsWith(staffNo)) {
                final double d = Math.random();
                final int k = (int) (d * 100);
                Map<String, Object> map = new Hashtable<>();
                map.put("_BUSINESSID", staffNo);
                map.put("_NAME", list.get(i));
                map.put("GESCH", "男");
                map.put("COMPANY", "德勤");
                map.put("PLANSTX", "普通员工");
                map.put("ZGSBMZW", "人力资源部");
                map.put("_DEPARTMENT_NAME", "人力资源部");
                map.put("HIREDATE", sDateFormat.format(new Date()));
                map.put("GBDAT", "1994-01-15");
                map.put("RYDJ", "01");
                map.put("_STATUS", "在职");
                map.put("ZZZD", "1");
                map.put("URL", "http://172.16.4.94:8022/gateway/api/v1/hr/attach/download?key=group1%2FM01%2F00%2F11%2FrBAEn12OZ4WAZo-aAABmo2nWtsE561.jpg&attachType=FILE&attachName=6.jpg&_t=1569585245233 ");
                map.put("WERKS", "集团公司");
                map.put("BTRTL", "黑龙江_大庆市");
                map.put("ZZGWXL", "01 管理类");
                map.put("RACE", "汉");
                map.put("INFTY", "共青团团员");
                map.put("DHRSFZH", sfz.get(i));

                //主岗信息
                Map<String, Object> map7 = new Hashtable<>();
                map7.put("ZEJZDWMC","德勤");
                map7.put("BTRTL","人力资源部");
                map7.put("ZZZX","人事专员");
                map.put("MAIN_POST_INFO",map7);

                //待确认信息
                Map<String, Object> socialMap = new HashMap<>();
                socialMap.put("_SOCIAL_SECURITY_TIME", sDateFormat.format(new Date()));
                socialMap.put("_SOCIAL_SECURITY_LAND1", list2.get(k % 4));
                socialMap.put("_ACCUMULATION_FUND_TIME", sDateFormat.format(new Date()));
                socialMap.put("_ACCUMULATION_FUND_LAND1", list2.get(k % 4));
                socialMap.put("_ANNUAL_LEAVE_DATE", k / 10);
                socialMap.put("_ARREARS", "10" + k);
                map.put("_SOCIAL_SECURITY", socialMap);

                //原合同信息
                List<Object> contractList = new ArrayList<>();
                Map<String, Object> contractMap1 = new HashMap<>();
                getContractMap(contractList, contractMap1, "1");

                Map<String, Object> contractMap2 = new HashMap<>();
                getContractMap(contractList, contractMap2, "2");

                Map<String, Object> contractMap3 = new HashMap<>();
                getContractMap(contractList, contractMap3, "3");
                map.put("_CONTRACT_INFO", contractList);

                //转正信息
                Map<String, Object> map5 = new HashMap<>();
                map5.put("_PROBATION_PERIOD","3");
                map5.put("_CONTRACT_BEGDA","2018-4-4");
                map5.put("_JHZZ_DATE","2018-7-5");
                map5.put("_CONTRACT_JSRQ","2019-4-4");
                map5.put("_ZZPXCJ","80");
                map5.put("_CONTRACT_SUBJECT",list.get(i));
                map.put("POSITIVE_INFO",map5);

                //兼岗信息
                List<Object> JZList = new ArrayList<>();
                Map<String, Object> map4 = new HashMap<>();
                map4.put("ZEJZDWMC", "德勤");
                map4.put("BEGDA", sDateFormat.format(new Date()));
                map4.put("JZBM", "人力资源部");
                map4.put("_JZJSRQ", "");
                map4.put("_JIANZHI_TYPE", "兼职");
                map4.put("JZZW", "普通员工");
                JZList.add(map4);

                Map<String, Object> map1 = new HashMap<>();
                map1.put("ZEJZDWMC", "德勤");
                map1.put("BEGDA", sDateFormat.format(new Date()));
                map1.put("JZBM", "人力资源部");
                map1.put("_JZJSRQ", "");
                map1.put("_JIANZHI_TYPE", "兼任");
                map1.put("JZZW", "部门经理");
                JZList.add(map1);

                Map<String, Object> map2 = new HashMap<>();
                map2.put("ZEJZDWMC", "德勤");
                map2.put("BEGDA", sDateFormat.format(new Date()));
                map2.put("JZBM", "技术部");
                map2.put("_JIANZHI_TYPE", "兼任");
                map2.put("_JZJSRQ", "");
                map2.put("JZZW", "部门经理");
                JZList.add(map2);

                map.put("_JIANZHI_INFO", JZList);

                responseList.add(map);
            }
//        }
        return new Response<>(LanguageEnum.getDefault(), Response.SUCCESS_CODE, "Success", responseList);
    }

    private void getContractMap(List<Object> contractList, Map<String, Object> contractMap3, String s2) {
        contractMap3.put("_CONTRACT_TYPE", "固定期限劳动合同");
        contractMap3.put("_CONTRACT_BEGDA", "2000-08-29");
        contractMap3.put("_CONTRACT_NO", "1234565");
        contractMap3.put("_CONTRACT_JSRQ", "2000-08-29");
        contractMap3.put("_CONTRACT_ZZGZDW","德勤");
        contractMap3.put("_CONTRACT_SUBJECT", "德勤");
        contractMap3.put("_CONTRACT_NUM", s2);
        contractList.add(contractMap3);
    }

    /**
     * 通过员工编号查询兼职信息
     * 数据是mock的
     *
     * @param request 实体
     * @return 分页数据
     */
    @Override
    public PaginationResponse queryConcurrentPost(PaginationRequest<StaffNoDto> request) {
        // todo 加入SAP后需要把数据从SAP中读取出来进行处理
        int size = request.getSize();
        int page = request.getPage();
        String staffNo = request.getData().getStaffNo();
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        List<Object> responseList = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("ZEJZDWMC", "德勤");
        map.put("BEGDA", sDateFormat.format(new Date()));
        map.put("JZBM", "人力资源部");
        map.put("_JIANZHI_TYPE", "普通兼职");
        map.put("JZZW", "普通员工");
        responseList.add(map);

        Map<String, Object> map1 = new HashMap<>();
        map1.put("ZEJZDWMC", "德勤");
        map1.put("BEGDA", sDateFormat.format(new Date()));
        map1.put("JZBM", "人力资源部");
        map1.put("_JIANZHI_TYPE", "领导兼职");
        map1.put("JZZW", "部门经理");
        responseList.add(map1);

        Map<String, Object> map2 = new HashMap<>();
        map2.put("ZEJZDWMC", "德勤");
        map2.put("BEGDA", sDateFormat.format(new Date()));
        map2.put("JZBM", "技术部");
        map2.put("_JIANZHI_TYPE", "领导兼职");
        map2.put("JZZW", "部门经理");
        responseList.add(map2);

        Map<String, Object> map3 = new HashMap<>();
        map3.put("ZEJZDWMC", "德勤");
        map3.put("BEGDA", sDateFormat.format(new Date()));
        map3.put("JZBM", "人力资源部");
        map3.put("_JIANZHI_TYPE", "普通兼职");
        map3.put("JZZW", "部门经理");
        responseList.add(map3);

        Map<String, Object> map4 = new HashMap<>();
        map4.put("ZEJZDWMC", "德勤");
        map4.put("BEGDA", sDateFormat.format(new Date()));
        map4.put("JZBM", "人力资源部");
        map4.put("_JIANZHI_TYPE", "普通兼职");
        map4.put("JZZW", "部门经理");
        responseList.add(map4);
        int total = responseList.size();
        return new PaginationResponse<>(request.getLanguage(),
                page,
                size,
                total,
                null,
                Response.SUCCESS_CODE, null, responseList);
    }


    /**
     * 下载数据模板
     * @param subtypeEnum  模板的类型
     * @throws IOException
     */
    @Override
    public void downloadExcel(SubtypeEnum subtypeEnum) throws IOException {
        // todo 加入SAP后直接导出excel
        HttpServletResponse response = ((ServletRequestAttributes) Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getResponse();
        HSSFWorkbook wb = new HSSFWorkbook();
        assert response != null;
        OutputStream out = response.getOutputStream();
        HSSFSheet sheet = wb.createSheet("下载模板");
        try {
            List<ExportTitle> titleList = MoKoTitle(subtypeEnum,true);
            ExcelExportImpl excelExport = new ExcelExportImpl();
            excelExport.ReadyStream(response,"数据模板");
            excelExport.CreateTitle(wb,titleList,sheet);
            wb.write(out);
            out.flush();
        }finally {
            out.close();
        }
    }

    //生成数据
    private void MoKeData(ApplyProcessEnum byBusiType) {

        double ds = Math.random();
        int s = (int) (ds * 100);
        List<String> list = new ArrayList<>();
        list.add("张三");
        list.add("李四");
        list.add("王五");
        list.add("曹操");
        list.add("关羽");
        list.add("马超");
        list.add("刘备");
        list.add("貂蝉");
        list.add("李白");
        list.add("黄忠");

        List<Map> mapList1 = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        Map<String, Object> map2 = new HashMap<>();
        Map<String, Object> map3 = new HashMap<>();
        if (byBusiType.equals(ApplyProcessEnum.DIMISSION) || byBusiType.equals(ApplyProcessEnum.RETIRE) || byBusiType.equals(ApplyProcessEnum.STAFF_DECEASE)
                || byBusiType.equals(ApplyProcessEnum.TERMINATE_THE_CONTRACT_FROM_PROTOCOL) || byBusiType.equals(ApplyProcessEnum.TERMINATE_THE_CONTRACT_FROM_DISCIPLINE)
                || byBusiType.equals(ApplyProcessEnum.DIMISSION_FROM_EMPLOYEES)) {
            //离职
            map1.put("UPLOAD_STATUS", true);
            map1.put("UPLOAD_STATUS_NAME", getTextValue("正确"));
            map1.put("_REASON", getTextValue(null));
            map1.put("ZZZX", getTextValue("总经理"));
            map1.put("ZZGWCJ", getTextValue("高层"));
            map1.put("BEGDA", getTextValue("2019-08-29T18:39:33.602"));
            map1.put("ENDDA", getTextValue("2019-08-29T18:39:33.602"));
            map1.put("_NAME", getTextValue(list.get(9)));
            map1.put("GBDAT", getTextValue("1994-01-15"));
            map1.put("MOLGA", getTextValue("中国"));
            map1.put("STATE", getTextValue("四川"));
            map1.put("ZEBM", getTextValue("人力资源部"));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));

            map2.put("UPLOAD_STATUS", false);
            map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
            map2.put("_REASON", getTextValue("没有人员组织的权限"));
            map2.put("ZZZX", getTextValue("普通员工"));
            map2.put("ZZGWCJ", getTextValue("低层"));
            map2.put("BEGDA", getTextValue("2019-08-29T18:39:33.602"));
            map2.put("ENDDA", getTextValue("2019-08-29T18:39:33.602"));
            map2.put("_NAME", getTextValue(list.get(6)));
            map2.put("GBDAT", getTextValue("1994-01-15"));
            map2.put("MOLGA", getTextValue("中国"));
            map2.put("STATE", getTextValue("北京"));
            map2.put("ZEBM", getTextValue("人力资源部"));
            map2.put("_BUSINESSID", getTextValue("1569591873308"));

            map3.put("UPLOAD_STATUS", true);
            map3.put("UPLOAD_STATUS_NAME", getTextValue("正确"));
            map3.put("_REASON", getTextValue(null));
            map3.put("ZZZX", getTextValue("高级员工"));
            map3.put("ZZGWCJ", getTextValue("中层"));
            map3.put("BEGDA", getTextValue("2019-08-29T18:39:33.602"));
            map3.put("ENDDA", getTextValue("2019-08-29T18:39:33.602"));
            map3.put("_NAME", getTextValue(list.get(3)));
            map3.put("GBDAT", getTextValue("1994-01-15"));
            map3.put("MOLGA", getTextValue("中国"));
            map3.put("STATE", getTextValue("四川"));
            map3.put("ZEBM", getTextValue("人力资源部"));
            map3.put("_BUSINESSID", getTextValue("1569591873308"));

        } else if (byBusiType.equals(ApplyProcessEnum.STAFF_POSITION_CHANGE)) {
            //岗位变动
            map1.put("UPLOAD_STATUS", true);
            map1.put("UPLOAD_STATUS_NAME", getTextValue("正确"));
            map1.put("_REASON", getTextValue(null));
            map1.put("_NAME", getTextValue(list.get(9)));
            map1.put("GESCHTX", getTextValue("男"));
            map1.put("WERKS", getTextValue("集团公司"));
            map1.put("BTRTL", getTextValue("黑龙江_大庆市"));
            map1.put("ZZGWXL", getTextValue("01 管理类"));
            map1.put("ZZZD", getTextValue(" 01 1"));
            map1.put("ZEBM", getTextValue("人力资源部"));
            map1.put("ZZZX", getTextValue("人力资源部经理"));
            map1.put("ZZGWCJ", getTextValue(" 中层"));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));

            getPositionChange(list, map2, "信息错误");
            map2.put("_BUSINESSID", getTextValue("1567075173598"));

            getPositionChange(list, map3, "信息重复");
            map3.put("_BUSINESSID", getTextValue("1569591873308"));
        } else if (byBusiType.equals(ApplyProcessEnum.START_AND_POST)) {
            //开始兼岗
            getStartPost(map1);
            map1.put("_NAME", getTextValue(list.get(6)));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));

            getStartPost(map2);
            map2.put("UPLOAD_STATUS", false);
            map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
            map2.put("_REASON", getTextValue("时间错误"));
            map2.put("_NAME", getTextValue(list.get(3)));
            map2.put("_BUSINESSID", getTextValue("1567075173598"));

            getStartPost(map3);
            map3.put("_NAME", getTextValue(list.get(5)));
            map3.put("_BUSINESSID", getTextValue("15223092306"));

        } else if (byBusiType.equals(ApplyProcessEnum.END_AND_POST)) {
            //结束兼岗
            getEndPost(map1);
            map1.put("_NAME", getTextValue(list.get(9)));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));

            getEndPost(map2);
            map2.put("UPLOAD_STATUS", false);
            map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
            map2.put("_REASON", getTextValue("时间错误"));
            map2.put("_NAME", getTextValue(list.get(7)));
            map2.put("_BUSINESSID", getTextValue("1567075173598"));

            getEndPost(map3);
            map3.put("_NAME", getTextValue(list.get(5)));
            map3.put("GESCHTX", getTextValue("男"));
            map3.put("_BUSINESSID", getTextValue("15223092306"));
        } else if (byBusiType.equals(ApplyProcessEnum.START_CONTRACT)) {
            //开始合同
            getStartContract(map1);
            map1.put("_NAME", getTextValue(list.get(9)));
            map1.put("_CONTRACT_NO", getTextValue("200008291804"));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));


            getStartContract(map2);
            map2.put("UPLOAD_STATUS", false);
            map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
            map2.put("_REASON", getTextValue("人员没有找到"));
            map2.put("_NAME", getTextValue(list.get(7)));
            map2.put("GESCHTX", getTextValue("男"));
            map2.put("_BUSINESSID", getTextValue("1567075173598"));

            getStartContract(map3);
            map3.put("_CONTRACT_NO", getTextValue("200008291804"));
            map3.put("_NAME", getTextValue(list.get(4)));
            map3.put("_BUSINESSID", getTextValue("15223092306"));
        } else if (byBusiType.equals(ApplyProcessEnum.EXTEND_CONTRACT)) {
            //续签合同
            getStartContract(map1);
            map1.put("_CONTRACT_NO", getTextValue("200008291804"));
            map1.put("_NAME", getTextValue(list.get(9)));
            map1.put("_APPLY_SUB_TYPE", getTextValue("续签合同"));
            map1.put("_CONTRACT_NUM", getTextValue("2"));
            map1.put("_CONTRACT_EXTEND_TIME", getTextValue("2019-04-01"));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));

            getStartContract(map2);
            map2.put("_CONTRACT_NO", getTextValue("200008291804"));
            map2.put("_CONTRACT_NUM", getTextValue("2"));
            map2.put("UPLOAD_STATUS", false);
            map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
            map2.put("_REASON", getTextValue("人员没有找到"));
            map2.put("_NAME", getTextValue(list.get(7)));
            map2.put("_APPLY_SUB_TYPE", getTextValue("续签合同"));
            map2.put("_CONTRACT_EXTEND_TIME", getTextValue("2019-04-01"));
            map2.put("_BUSINESSID", getTextValue("1567075173598"));

            getStartContract(map3);
            map3.put("_CONTRACT_NO", getTextValue("200008291804"));
            map3.put("_NAME", getTextValue(list.get(4)));
            map3.put("_APPLY_SUB_TYPE", getTextValue("续签合同"));
            map3.put("_CONTRACT_NUM", getTextValue("2"));
            map3.put("_CONTRACT_EXTEND_TIME", getTextValue("2019-04-01"));
            map3.put("_BUSINESSID", getTextValue("15223092306"));
        } else if (byBusiType.equals(ApplyProcessEnum.END_CONTRACT)) {
            //终止合同
            getStartContract(map1);
            map1.put("_CONTRACT_NO", getTextValue("200008291804"));
            map1.put("_CONTRACT_STOP", getTextValue("2004-08-29"));
            map1.put("_APPLY_SUB_TYPE", getTextValue("终止合同"));
            map1.put("_CONTRACT_STOP_REASON", getTextValue(""));
            map1.put("_CONTRACT_NUM", getTextValue("2"));
            map1.put("_NAME", getTextValue(list.get(9)));
            map1.put("GESCHTX", getTextValue("男"));
            map1.put("_BUSINESSID", getTextValue("1569591873308"));

            getStartContract(map2);
            map2.put("_CONTRACT_NO", getTextValue("200008291804"));
            map2.put("_APPLY_SUB_TYPE", getTextValue("终止合同"));
            map2.put("_CONTRACT_STOP", getTextValue("2004-08-29"));
            map2.put("_CONTRACT_STOP_REASON", getTextValue("离职"));
            map1.put("_CONTRACT_NUM", getTextValue("2"));
            map2.put("UPLOAD_STATUS", false);
            map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
            map2.put("_REASON", getTextValue("人员没有找到"));
            map2.put("_NAME", getTextValue(list.get(7)));
            map2.put("_BUSINESSID", getTextValue("1567075173598"));

            getStartContract(map3);
            map3.put("_CONTRACT_NO", getTextValue("200008291804"));
            map3.put("_APPLY_SUB_TYPE", getTextValue("终止合同"));
            map1.put("_CONTRACT_NUM", getTextValue("1"));
            map3.put("_NAME", getTextValue(list.get(4)));
            map3.put("GESCHTX", getTextValue("男"));
            map2.put("_CONTRACT_STOP", getTextValue("2004-08-29"));
            map2.put("_CONTRACT_STOP_REASON", getTextValue("合同到期"));
            map3.put("_BUSINESSID", getTextValue("15223092306"));
        }
        mapList1.add(map1);
        mapList1.add(map2);
        mapList1.add(map3);
        mapList = new ArrayList<>();
        mapList.add(mapList1.get(0));
        mapList.add(mapList1.get(1));
        mapList.add(mapList1.get(2));
        mapList.add(mapList1.get(1));

    }

    private void getPositionChange(List<String> list, Map<String, Object> map2, String string) {
        map2.put("UPLOAD_STATUS", false);
        map2.put("UPLOAD_STATUS_NAME", getTextValue("错误"));
        map2.put("_REASON", getTextValue(string));
        map2.put("_NAME", getTextValue(list.get(7)));
        map2.put("GESCHTX", getTextValue("男"));
        map2.put("WERKS", getTextValue("集团公司"));
        map2.put("BTRTL", getTextValue("黑龙江_大庆市"));
        map2.put("ZZGWXL", getTextValue("01 管理类"));
        map2.put("ZZZD", getTextValue(" 01 1"));
        map2.put("ZEBM", getTextValue("人力资源部"));
        map2.put("ZZZX", getTextValue("人力资源部副经理"));
        map2.put("ZZGWCJ", getTextValue(" 中层"));
    }

    private void getStartPost(Map<String, Object> map1) {
        map1.put("ZEJZDWMC", getTextValue("德勤"));
        map1.put("BEGDA", getTextValue("2000-08-29"));
        map1.put("JZBM", getTextValue("技术部"));
        map1.put("_JIANZHI_TYPE", getTextValue("兼职"));
        map1.put("JZZW", getTextValue("部门经理"));
        map1.put("UPLOAD_STATUS", true);
        map1.put("UPLOAD_STATUS_NAME", getTextValue("正确"));
        map1.put("_REASON", getTextValue(null));
        map1.put("GESCHTX", getTextValue("男"));
        map1.put("_APPLY_SUB_TYPE", getTextValue("开始兼岗"));
        map1.put("_CREATE_TIME", getTextValue("2019-04-01"));
    }

    private void getEndPost(Map<String, Object> map1) {
        map1.put("ZEJZDWMC", getTextValue("德勤"));
        map1.put("BEGDA", getTextValue("2000-08-29"));
        map1.put("JZBM", getTextValue("人力资源部"));
        map1.put("_JIANZHI_TYPE", getTextValue("兼职"));
        map1.put("JZZW", getTextValue("普通员工"));
        map1.put("_JZJSRQ", getTextValue("2001-08-29"));
        map1.put("UPLOAD_STATUS", true);
        map1.put("UPLOAD_STATUS_NAME", getTextValue("正确"));
        map1.put("_REASON", getTextValue(null));
        map1.put("GESCHTX", getTextValue("男"));
        map1.put("_APPLY_SUB_TYPE", getTextValue("结束兼岗"));
        map1.put("_END_TIME", getTextValue("2019-04-01"));
    }

    private void getStartContract(Map<String, Object> map1) {
        map1.put("_CONTRACT_BEGDA", getTextValue("2000-08-29"));
        map1.put("_CONTRACT_ZZGZDW", getTextValue("德勤"));
        map1.put("_CONTRACT_JSRQ", getTextValue("2000-08-29"));
        map1.put("_CONTRACT_NUM", getTextValue("1"));
        map1.put("_CONTRACT_SUBJECT", getTextValue("德勤"));
        map1.put("_CONTRACT_TYPE", getTextValue("固定期限劳动合同"));
        map1.put("GESCHTX", getTextValue("男"));
        map1.put("_APPLY_SUB_TYPE", getTextValue("发起合同"));
        map1.put("UPLOAD_STATUS", true);
        map1.put("UPLOAD_STATUS_NAME", getTextValue("正确"));
        map1.put("_REASON", getTextValue(null));
    }

    /**
     * 生成表头
     * @param type 是否生成excel
     * @return 表头
     */
    private List<ExportTitle> MoKoTitle(SubtypeEnum subtypeEnum,Boolean type) {
        ApplyProcessEnum byBusiType = ApplyProcessEnum.getByBusiType(subtypeEnum);
        List<ExportTitle> titleList = new ArrayList<>();
        if(!type){
            titleList.add(getExportTitle("上传数据状态名称", "UPLOAD_STATUS_NAME.value"));
            titleList.add(getExportTitle("消息描述", "_REASON.value"));
        }
        assert byBusiType != null;
        titleList.add(getExportTitle("员工编号", "_BUSINESSID.value"));
        titleList.add(getExportTitle("姓名", "_NAME.value"));
        if (byBusiType.equals(ApplyProcessEnum.DIMISSION) || byBusiType.equals(ApplyProcessEnum.RETIRE) || byBusiType.equals(ApplyProcessEnum.STAFF_DECEASE)
                || byBusiType.equals(ApplyProcessEnum.TERMINATE_THE_CONTRACT_FROM_PROTOCOL) || byBusiType.equals(ApplyProcessEnum.TERMINATE_THE_CONTRACT_FROM_DISCIPLINE)
                || byBusiType.equals(ApplyProcessEnum.DIMISSION_FROM_EMPLOYEES)) {
            //离职
            titleList.add(getExportTitle("岗位", "ZZZX.value"));
            titleList.add(getExportTitle("层级", "ZZGWCJ.value"));
            titleList.add(getExportTitle("开始日期", "BEGDA.value"));
            titleList.add(getExportTitle("结束日期", "ENDDA.value"));
            titleList.add(getExportTitle("出生日期", "GBDAT.value"));
            titleList.add(getExportTitle("国家", "MOLGA.value"));
            titleList.add(getExportTitle("出生地", "STATE.value"));
            titleList.add(getExportTitle("部门", "ZEBM.value"));

        } else if (byBusiType.equals(ApplyProcessEnum.STAFF_POSITION_CHANGE)) {
            //岗位变动
            titleList.add(getExportTitle("性别", "GESCHTX.value"));
            titleList.add(getExportTitle("人事范围", "WERKS.value"));
            titleList.add(getExportTitle("人事子范围", "BTRTL.value"));
            titleList.add(getExportTitle("岗位序列", "ZZGWXL.value"));
            titleList.add(getExportTitle("职等", "ZZZD.value"));
            titleList.add(getExportTitle("部门", "ZEBM.value"));
            titleList.add(getExportTitle("岗位", "ZZZX.value"));
            titleList.add(getExportTitle("人员层级", "ZZGWCJ.value"));
        } else if (byBusiType.equals(ApplyProcessEnum.START_AND_POST) || byBusiType.equals(ApplyProcessEnum.END_AND_POST)) {
            //兼岗
            titleList.add(getExportTitle("公司", "ZEJZDWMC.value"));
            if (byBusiType.equals(ApplyProcessEnum.END_AND_POST)) {
                titleList.add(getExportTitle("结束时间", "_JZJSRQ.value"));
            }
            titleList.add(getExportTitle("开始时间", "BEGDA.value"));
            titleList.add(getExportTitle("部门", "JZBM.value"));
            titleList.add(getExportTitle("兼职类型", "_JIANZHI_TYPE.value"));
            titleList.add(getExportTitle("性别", "GESCHTX.value"));
            titleList.add(getExportTitle("业务类型", "_APPLY_SUB_TYPE.value"));
            titleList.add(getExportTitle("创建时间", "_CREATE_TIME.value"));
        } else if (byBusiType.equals(ApplyProcessEnum.START_CONTRACT)) {
            //合同
            getContract(titleList);
        } else if (byBusiType.equals(ApplyProcessEnum.EXTEND_CONTRACT)) {
            getContract(titleList);
            titleList.add(getExportTitle("续签时间", "_CONTRACT_EXTEND_TIME.value"));
        } else if (byBusiType.equals(ApplyProcessEnum.END_CONTRACT)) {
            getContract(titleList);
            titleList.add(getExportTitle("终止时间", "_CONTRACT_STOP.value"));
            titleList.add(getExportTitle("终止原因", "_CONTRACT_STOP_REASON.value"));
        }
        return titleList;
    }
    private void getContract(List<ExportTitle> titleList) {
        titleList.add(getExportTitle("所属单位", "_CONTRACT_ZZGZDW.value"));
        titleList.add(getExportTitle("合同编号", "_CONTRACT_NO.value"));
        titleList.add(getExportTitle("开始时间", "_CONTRACT_BEGDA.value"));
        titleList.add(getExportTitle("结束时间", "_CONTRACT_JSRQ.value"));
        titleList.add(getExportTitle("签订次数", "_CONTRACT_NUM.value"));
        titleList.add(getExportTitle("合同主体", "_CONTRACT_SUBJECT.value"));
        titleList.add(getExportTitle("性别", "GESCHTX.value"));
        titleList.add(getExportTitle("业务类型", "_APPLY_SUB_TYPE.value"));
        titleList.add(getExportTitle("合同类型", "_CONTRACT_TYPE.value"));
    }
    private ExportTitle getExportTitle(String name, String field) {
        ExportTitle exportTitle = new ExportTitle();
        exportTitle.setName(name);
        exportTitle.setField(field);
        return exportTitle;
    }
    private TextValue getTextValue(String value) {
        TextValue textValue = new TextValue();
        textValue.setValue(value);
        return textValue;
    }
}
