package com.deloitte.dhr.hr.provider.strategy;

import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import com.deloitte.dhr.hr.api.model.AuditHandlerDto;
import com.deloitte.dhr.hr.api.model.StaffInfoModifyDto;
import com.deloitte.dhr.hr.api.model.staff.StaffInfoUpdateApplyRdOpEnum;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoApplyDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import com.deloitte.dhr.hr.provider.service.CommonService;
import com.deloitte.dhr.hr.provider.service.HrNotificationService;
import com.deloitte.dhr.hr.provider.service.TaskNodeHandlerService;
import com.deloitte.infrastructure.ex.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 员工信息修改管理节点审批
 * date: 15/10/2019 9:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class StaffInfoModifyStrategy implements Strategy {

    @Autowired
    private TaskNodeHandlerService taskNodeHandlerService;

    @Autowired
    HrNotificationService hrNotificationService;

    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    CommonService commonService;

    @Autowired
    BaseMongoService baseMongoService;

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    StaffInfoApplyDao staffInfoApplyDao;

    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;

    @Override
    public boolean nodeHandler(AuditHandlerDto auditHandlerDto, String staffId,
                               String applyNo) {
        boolean ended = taskNodeHandlerService.commonFlowNodeHandler(auditHandlerDto);
        // TODO 可能需要将临时数据需要修改为正式数据
        if (ended) {
            // 员工信息修改审批完后的操作
            staffInfoModifyApprovedHandler(applyNo);
        }
        return ended;
    }


    @Override
    public ManagementTypeEnum getManagementType() {
        return ManagementTypeEnum.STAFF_INFO_MODIFY;
    }

    /**
     * 员工信息修改审批通过后的操作
     *
     * @param applyNo 业务编号
     */
    private void staffInfoModifyApprovedHandler(String applyNo) {
        // TODO 需要调用SAP的接口 修改员工信息
        Map applyRecord = staffApplyAlterDao.QueryByApplyNo(applyNo);
        // 员工编号
        String staffNo = (String) applyRecord.get("_BUSINESSID");
        // 修改信息的模块
        String dataPart = (String) applyRecord.get("_DATA_PART");

        Query query = new Query();
        query.addCriteria(Criteria.where("_APPLY_NO").is(applyNo));
        // 修改的具体的信息
        List<Map> detailList = baseMongoService.queryOneForMapList(query, HRCollection.HR_STAFF_UPDATE_APPLY_CHANGERD);

        Map<String, StaffInfoUpdateApplyRdOpEnum> opMap = new HashMap<>();
        opMap.put("1", StaffInfoUpdateApplyRdOpEnum.OP_NEW);
        opMap.put("2", StaffInfoUpdateApplyRdOpEnum.OP_UPDATE);
        opMap.put("3", StaffInfoUpdateApplyRdOpEnum.OP_DELETE);

        if (!CollectionUtils.isEmpty(detailList)) {
            for (Map map : detailList) {
                Object op1 = map.get("_OP");
                if (op1 != null) {
                    String op = Integer.toString((Integer) op1);
                    StaffInfoModifyDto staffInfoModifyDto = new StaffInfoModifyDto();
                    staffInfoModifyDto.setOp(opMap.get(op));
                    staffInfoModifyDto.setStaffNo(staffNo);
                    staffInfoModifyDto.setPart(dataPart);
                    if (staffInfoModifyDto.getOp() == null) {
                        throw new BusinessException(HRMateInfo.MODIFY_STAFF_INFO_OP_IS_ERR.getCode(), HRMateInfo.MODIFY_STAFF_INFO_OP_IS_ERR.getMessage());
                    }
                    map.remove("_id");
                    map.remove("_OP");
                    map.remove("_APPLY_NO");
                    staffInfoModifyDto.setData(map);
                    commonService.modifySapStaffInfo(staffInfoModifyDto);
                } else {
                    throw new BusinessException(HRMateInfo.MODIFY_STAFF_INFO_OP_IS_ERR.getCode(), HRMateInfo.MODIFY_STAFF_INFO_OP_IS_ERR.getMessage());
                }
            }
        }
    }

}
