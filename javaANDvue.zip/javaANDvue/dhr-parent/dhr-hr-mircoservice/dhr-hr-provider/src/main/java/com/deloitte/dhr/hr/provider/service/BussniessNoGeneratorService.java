package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.constant.SubtypeEnum;

/**
 * @author chunliucq
 * @since 05/09/2019 16:01
 */
public interface BussniessNoGeneratorService {
    String getNewBussniessNo(String key);

    String getNewBussniessNo(SubtypeEnum key);
}
