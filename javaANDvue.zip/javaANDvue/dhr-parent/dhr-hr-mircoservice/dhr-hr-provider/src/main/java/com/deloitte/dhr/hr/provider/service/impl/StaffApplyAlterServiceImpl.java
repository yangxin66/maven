package com.deloitte.dhr.hr.provider.service.impl;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.hr.api.model.ApplyCompare;
import com.deloitte.dhr.hr.api.model.ApplyStatus;
import com.deloitte.dhr.hr.api.model.staff.ApplyNo;
import com.deloitte.dhr.hr.api.model.staff.StaffApplyDto;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffApplyAlterDao;
import com.deloitte.dhr.hr.provider.mongo.dao.StaffInfoDao;
import com.deloitte.dhr.hr.provider.service.StaffApplyAlterService;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.workflow.api.WfTaskApi;
import com.deloitte.workflow.api.model.dto.TaskDto;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Service
public class StaffApplyAlterServiceImpl implements StaffApplyAlterService {


    private static String STAFF_INFO_DATA = "_DATA";

    private static  final String STAFF_APPLY_NO="_APPLY_NO";

    private static  final String STAFF_DATA_PART="_DATA_PART";
    @Autowired
    StaffApplyAlterDao staffApplyAlterDao;
    
    @Autowired
    StaffInfoDao staffInfoDao;

    @Autowired
    private WfTaskApi wfTaskApi;

    @Override
    public List<ApplyStatus> queryApplyAlter(Request<StaffApplyDto> applyDtoRequest) {
        List<ApplyStatus> list=new ArrayList<>();
        String staffNo = applyDtoRequest.getData().getStaffNo();
        List<String> partList = applyDtoRequest.getData().getPart();
        String status = applyDtoRequest.getData().getStatus();
        List<String> statusList = new ArrayList<>();
        if (StringUtils.isBlank(status)){
            statusList.add("APPROVAL_PENDING");
            statusList.add("SUBMITTED");
            statusList.add("REJECT");
        }else {
            statusList.add(status);
        }
        List<Document> documentList = staffApplyAlterDao.QueryApplyAlter(staffNo,
                statusList, partList);
        for (int i=0;i<documentList.size();i++) {
            ApplyStatus applyStatus=new ApplyStatus();
            Document applyRecord=documentList.get(i);
            if(applyRecord!=null){
                String string = applyRecord.getString(STAFF_DATA_PART);
                if(partList.contains(string)){
                    applyStatus.setResult(true);
                    applyStatus.setApplyNo(applyRecord.getString(STAFF_APPLY_NO));
                    applyStatus.setPart(string);
                    applyStatus.setProcessId(applyRecord.getString("_PROCESS_INSTANCE_ID"));

                    TaskDto taskDto = new TaskDto();
                    taskDto.setProcessInstanceId(applyStatus.getProcessId());
                    taskDto.setCandidateGroups(Arrays.asList(new String[]{HrStaffServiceImpl.hrRoleId}));
                    Request<TaskDto> request = new Request<>(taskDto);
                    Response<List<TaskDto>> resp = wfTaskApi.list(request);
                    if (Response.SUCCESS_CODE.equals(resp.getCode())){
                        List<TaskDto> taskDtoList = resp.getData();
                        if (!CollectionUtils.isEmpty(taskDtoList)){
                            applyStatus.setTaskId(taskDtoList.get(0).getTaskId());
                        }
                    }
                    partList.remove(string);
                    list.add(applyStatus);
                }
            }
        }
        for(String part:partList){
            ApplyStatus applyStatus=new ApplyStatus();
            applyStatus.setResult(false);
            applyStatus.setPart(part);
            list.add(applyStatus);
        }
        return list;
    }

    @Override
    public JSONObject queryApplyAlterByApply(String applyNo) {

        Map ApplyRecord = staffApplyAlterDao.QueryByApplyNo(applyNo);
//        JSONObject ApplyRecord = new JSONObject(map);
//        if (ApplyRecord.getString("_AUDIT_HIS") == null || StringUtils.isEmpty(ApplyRecord.getString("_AUDIT_HIS"))) {
//            return ApplyRecord;
//        } else {
//            return (JSONObject) ApplyRecord.remove("_AUDIT_HIS");
//        }
        return new JSONObject(ApplyRecord);
    }

    @Override
    public List<ApplyCompare> CompareApplyAndInfo(JSONObject ApplyBefore) {
       String StaffNo= (String)ApplyBefore.get("_BUSINESSID");
       String applyNo=(String)ApplyBefore.get("_APPLY_NO");
        String part = null;
        List<String> rid=new ArrayList<>();
        for (String key:ApplyBefore.keySet()) {
            boolean isDataObj = isJsonObject(ApplyBefore,key);
            if (isDataObj){
                JSONObject moduleData = ApplyBefore.getJSONObject(key);
                 rid.add((String) moduleData.get("_RID"));
                 part=key;
            }else {
                JSONArray staffArrData = ApplyBefore.getJSONArray(key);
                if (staffArrData != null && staffArrData.size() > 0){
                    for (int i = 0,len = staffArrData.size();i < len; i++){
                        JSONObject tmpObject = staffArrData.getJSONObject(i);
                        rid.add((String)tmpObject.get("_RID"));
                    }
                }
            }
        }
        String Info = staffInfoDao.queryStaffInfoByStaffNo(StaffNo);
        JSONObject jsonObject = JSONObject.parseObject(Info);
        List<String> rid1=new ArrayList<>();
        boolean isDataObj = isJsonObject(ApplyBefore,part);
        if (isDataObj){
            JSONObject moduleData = ApplyBefore.getJSONObject(part);
             rid1.add((String)moduleData.get("_RID"));
        }else {
            JSONArray staffArrData = ApplyBefore.getJSONArray(part);
            if (staffArrData != null && staffArrData.size() > 0){
                for (int i = 0,len = staffArrData.size();i < len; i++){
                    JSONObject tmpObject = staffArrData.getJSONObject(i);
                    rid1.add((String) tmpObject.get("_RID"));
                }
            }
        }
        return null;
    }

    @Override
    public List<ApplyCompare> CompareApplyList(JSONObject ApplyBefore) {
        return null;
    }

    @Override
    public PaginationResponse<List<Map>> ApplyPage(PaginationRequest<ApplyNo> applyNoPaginationRequest) {

        return staffApplyAlterDao.QueryByApplyNoInfoList(applyNoPaginationRequest);
    }

    private boolean isJsonObject(JSONObject jsonObject,String key){
        String jsonStr = null;
        try {
            JSONArray tempJson = jsonObject.getJSONArray(key);
            if (tempJson != null){
                jsonStr = tempJson.toJSONString();
            }
            if (jsonStr != null || jsonStr.startsWith("[")){
                return false;
            }
        }catch (Exception e){
            return true;
        }
        return true;
    }
}
