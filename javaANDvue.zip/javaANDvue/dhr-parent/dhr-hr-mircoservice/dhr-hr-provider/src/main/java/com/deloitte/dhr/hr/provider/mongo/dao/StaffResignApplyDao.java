package com.deloitte.dhr.hr.provider.mongo.dao;

import com.deloitte.dhr.common.utils.ValueGetTool;
import com.deloitte.dhr.extension.mongodb.schema.HRCollection;
import com.deloitte.dhr.hr.provider.service.BaseMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * date: 24/09/2019 17:06
 *
 * @author wgong
 * @since 0.0.1
 */
@Component
public class StaffResignApplyDao {

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    BaseMongoService baseMongoService;


    public List<Map> queryStaffInfoByApplyNo(String applyNo){
        return mongoTemplate.find(new Query(Criteria.where("_APPLY_NO").is(applyNo)), Map.class, HRCollection.HR_DISMISSION_DETAIL);
    }
}
