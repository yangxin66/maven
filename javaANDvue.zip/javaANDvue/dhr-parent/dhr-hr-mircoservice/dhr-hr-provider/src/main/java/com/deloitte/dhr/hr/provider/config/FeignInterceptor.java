package com.deloitte.dhr.hr.provider.config;

import com.deloitte.dhr.common.constant.CommonConstant;
import com.deloitte.dhr.common.global.session.ContextSession;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

/**
 * @author amzheng
 * @disc
 * @type
 * @creatTime 26/04/2019
 */
@Component
public class FeignInterceptor implements RequestInterceptor {
    @Override
    public void apply(RequestTemplate requestTemplate) {
        requestTemplate.header(CommonConstant.TOKEN_JWT, ContextSession.getLoginUseToken());
//        requestTemplate.header(ResourceBundleUtil.LANGUAGE, ResourceBundleUtil.getUserLanguage());


        HttpServletRequest request = ContextSession.getHttpServletRequest();
        requestTemplate.header(CommonConstant.LOGIN_USER_INFO, request.getHeader(CommonConstant.LOGIN_USER_INFO));
    }
}
