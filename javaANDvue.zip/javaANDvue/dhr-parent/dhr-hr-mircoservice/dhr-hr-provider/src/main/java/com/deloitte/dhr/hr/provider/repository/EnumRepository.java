package com.deloitte.dhr.hr.provider.repository;


import com.deloitte.dhr.hr.provider.repository.model.EnumPo;
import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EnumRepository extends BaseRepository<EnumPo> {

   EnumPo findByCode(String code);

}
