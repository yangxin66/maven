package com.deloitte.dhr.hr.provider.repository.model;

import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "dhr_business_enum")
@Entity(name = "Enum")
@SQLDelete(sql = "update Enum set Enum.deleted = 1 where Enum.id = ?")
@Where(clause = "deleted = 0")
public class EnumPo extends BasePo {

    private static final long serialVersionUID = -1426496386150187379L;

    //字段公司id
    @Column(name = "company_id",length = 50)
    private String companyId;

    //  分组id
    @Column(name = "code",length = 20)
    private String code;

    //分组名称
    @Column(name = "code_name" ,length = 50)
    private String codeName;

    @OneToMany
    @JoinColumn(name = "enum_id")
    private List<EnumItemPo> enumItemPoList;
}
