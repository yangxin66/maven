package com.deloitte.dhr.hr.provider.service;

import com.deloitte.dhr.hr.api.model.StaffInfoModifyDto;

/**
 * 通用Service  包含各Service中共用方法
 * @author chunliucq
 * @since 29/08/2019 9:11
 */
public interface CommonService {

    /**
     * 共成Token，并存到Redis缓存
     * @param businessId
     * @return
     */
    String generatorToken(String businessId);

    /**
     *
     * 获取缓存中的token对应的员工编号
     * @param token
     * @return 员工编号，若token过期，返回null
     */
    String getEmailTokenStaffNo(String token);

    String modifySapStaffInfo(StaffInfoModifyDto staffInfoModifyDto);
}
