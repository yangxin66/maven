package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.model.MessageBatchAddDto;
import com.deloitte.dhr.hr.api.model.MessageCountDto;
import com.deloitte.dhr.hr.api.model.MessageDetailDto;
import com.deloitte.dhr.hr.api.model.MessageDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 消息接口
 * @author chunliucq
 * @since 22/08/2019 11:22
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/messages")
public interface MessageInterface {


    /**
     * 批量发送消息
     *
     * @param messageAddDtoRequest 添加消息传输实体
     */
    @PostMapping("/batch")
    Response<Object> addMessage(@RequestBody @Validated Request<MessageBatchAddDto> messageAddDtoRequest);

    /**
     * 全部发送消息提醒
     *
     * @param messageAddDtoRequest 添加消息传输实体
     */
    @PostMapping
    Response<Object> sendAllMessage(@RequestBody @Validated Request<MessageBatchAddDto> messageAddDtoRequest);


    /**
     * 分页查询消息
     *
     * @param messageAddDtoRequest 添加消息传输实体
     */
    @PostMapping("/page")
    PaginationResponse<List<MessageDto>> findMessageByPage(@RequestBody PaginationRequest<MessageTypeEnum> messageAddDtoRequest);

    /**
     * 添加消息
     *
     * @param request 请求传输实体
     */
    @PostMapping("/count")
    Response<MessageCountDto> findMyAllMessageCount(@RequestBody Request<Object> request);

    /**
     * 查看消息
     *
     * @param request 请求传输实体
     */
    @PostMapping("/{id}")
    Response<MessageDetailDto> findById(@PathVariable("id")String id, @RequestBody Request<String> request);

    /**
     * 标记已读
     *
     * @param request 请求传输实体
     */
    @PostMapping("/modify/{id}")
    Response<Object> readMessage(@PathVariable("id")String id, @RequestBody Request<String> request);

    /**
     * 根据id删除消息
     *
     * @param request 请求传输实体
     */
    @PostMapping("/delete/{id}")
    Response<Object> deleteMessage(@PathVariable("id")String id, @RequestBody Request<String> request);

}
