package com.deloitte.dhr.hr.api.constant;


/**
 * 人事管理子类型
 * date: 08/10/2019 14:19
 *
 * @author wgong
 * @since 0.0.1
 */
public enum SubtypeEnum {

    /**
     * 员工新建入职
     */
    CREATE_STAFF("员工新建入职", "staff_info_update_apply_detail", "SNCW"),
    /**
     * 员工信息修改
     */
    STAFF_INFO_MODIFY("员工信息修改", "staff_info_update_apply_detail", "SIMM"),
    /**
     * 领导岗位变动
     */
    LEADER_POSITION_CHANGE("领导岗位变动", "staff_position_change_detail", "LCHG"),
    /**
     * 员工岗位变动
     */
    STAFF_POSITION_CHANGE("员工岗位变动", "staff_position_change_detail", "SCHG"),
    /**
     * 离职
     */
    DIMISSION("离职", "staff_resign_apply_detail", "RESIGN"),
    /**
     * 员工自离
     */
    DIMISSION_FROM_EMPLOYEES("员工自离", "staff_resign_apply_detail", "RESIGN"),
    /**
     * 违纪解除合同
     */
    TERMINATE_THE_CONTRACT_FROM_DISCIPLINE("违纪解除合同", "staff_resign_apply_detail", "RESIGN"),

    /**
     * 协议解除合同
     */
    TERMINATE_THE_CONTRACT_FROM_PROTOCOL("协议解除合同", "staff_resign_apply_detail", "RESIGN"),

    /**
     * 身故
     */
    STAFF_DECEASE("身故", "staff_resign_apply_detail", "RESIGN"),

    /**
     * 退休
     */
    RETIRE("退休", "staff_resign_apply_detail", "RESIGN"),

    /**
     * 转正
     */
    POSITIVE("转正", "staff_become_regular_detail", "SBRD"),


    /**
     * 开始兼岗
     */
    START_AND_POST("开始兼岗", "staff_part_time_job_start_detail", "PTJS"),

    /**
     * 结束兼岗
     */
    END_AND_POST("结束兼岗", "staff_part_time_job_end_detail", "PTJE"),

    /**
     * 发起合同
     */
    START_CONTRACT("发起合同", "staff_contract_detail", "SCMD"),

    /**
     * 续签合同
     */
    EXTEND_CONTRACT("续签合同", "staff_contract_detail", "SCMD"),

    /**
     * 终止合同
     */
    END_CONTRACT("终止合同", "staff_contract_detail", "SCMD");

    /**
     *
     */
    private String value;

    /**
     * 业务类型对应明细数据表
     */
    private String tableName;

    /**
     * 业务编号前缀
     */
    private String autoNoPrefix;

    SubtypeEnum(String value, String tableName, String autoNoPrefix) {
        this.value = value;
        this.tableName = tableName;
        this.autoNoPrefix = autoNoPrefix;
    }

    public String getValue() {
        return value;
    }

    public String getTableName() {
        return tableName;
    }

    public String getAutoNoPrefix() {
        return autoNoPrefix;
    }

}
