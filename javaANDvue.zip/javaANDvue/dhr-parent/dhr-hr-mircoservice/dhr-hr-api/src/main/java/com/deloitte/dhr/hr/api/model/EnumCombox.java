package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.util.List;

/**
 * Combox下拉组合框的数据抽象类
 * @author chunliucq
 * @since 20/08/2019 11:08
 */
@Data
public class EnumCombox {
    /**
     * 下拉菜单的查询KEY(分组id)
     */
    private String key;

    /**
     * 字段名称(分组名称)
     */
    private String keyName;

    /**
     * 下拉菜单的列表数据
     */
    private List<EnumItem> enumItemList;
}
