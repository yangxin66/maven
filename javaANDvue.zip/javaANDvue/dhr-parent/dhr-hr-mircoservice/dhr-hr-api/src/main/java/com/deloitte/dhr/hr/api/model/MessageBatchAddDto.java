package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.hr.api.constant.MessageSubTypeEnum;
import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class MessageBatchAddDto {

    /**
     * 消息标题
     */
    @NotBlank(message = "消息标题不允许为空")
    @Length(max = 100, message = "消息标题不允许超过500字")
    String title;

    /**
     * 消息类型
     */
    @NotNull(message = "消息类型不允许为空")
    MessageTypeEnum messageType;

    /**
     * 消息子类型
     */
    MessageSubTypeEnum subtypeEnum;

    /**
     * 消息
     */
    @NotBlank(message = "消息不允许为空")
    @Length(max = 500, message = "消息长度不允许超过500字")
    String message;

    /**
     * 员工编号
     */
    List<String> staffNos;

}
