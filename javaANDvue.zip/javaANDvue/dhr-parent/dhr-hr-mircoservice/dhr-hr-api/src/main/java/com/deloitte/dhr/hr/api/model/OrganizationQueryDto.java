package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * date: 22/08/2019 18:09
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class OrganizationQueryDto implements Serializable {

    private static final long serialVersionUID = 5356504564965506923L;
    /**
     * 组织类型
     */
    private String type;

    /**
     * 上级组织编号
     */
    private String parentCode;
}
