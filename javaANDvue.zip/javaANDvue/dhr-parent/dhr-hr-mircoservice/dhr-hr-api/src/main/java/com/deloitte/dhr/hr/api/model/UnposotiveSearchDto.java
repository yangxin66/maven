package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.util.List;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class UnposotiveSearchDto {

    /**
     * 一级搜索字段列表
     */
    private List<FieldCustomDto> firstFieldCustoms;

    /**
     * 二级搜索字段列表
     */
    private  List<FieldCustomDto> secondFieldCustoms;


}
