package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Data
public class StaffInfoStatus implements Serializable {

    private static final long serialVersionUID = -1210057425023783661L;

    private  boolean sendFlag;

    private PageDataRequest data;
}
