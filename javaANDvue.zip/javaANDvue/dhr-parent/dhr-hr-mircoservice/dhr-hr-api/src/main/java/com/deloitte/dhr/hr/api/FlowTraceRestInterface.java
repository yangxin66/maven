package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;


/**
 * 流程节点相关api
 * date: 18/09/2019 15:26
 *
 * @author wgong
 * @since 0.0.1
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/flow_trace")
public interface FlowTraceRestInterface {

    /**
     * 根据流程实例id查询流程节点信息
     *
     * @param request 查询参数传输实体
     */
    @PostMapping
    Response<FlowTraceLogDto> getFlowTraceLogDetail(@RequestBody Request<String> request);


    /**
     * 流程节点处理
     *
     * @param request 查询参数传输实体
     */
    @PostMapping("/node_handler")
    Response<Object> flowNodeHandler(@Validated @RequestBody Request<List<AuditHandlerDto>> request);
}
