package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UploadApplyDto {

    /**
     * 文件名
     */
    @JSONField(name = "_FILE_NAME")
    private String filename;

    /**
     * 文件路径
     */
    @JSONField(name = "_FILE_PATH")
    private String filePath;
    /**
     * 业务编号
     */
    @JSONField(name = "_APPLY_NO")
    private String applyNo;
    /**
     * 业务类型
     */
    @JSONField(name = "_BUSI_TYPE")
    private String busiType;
}
