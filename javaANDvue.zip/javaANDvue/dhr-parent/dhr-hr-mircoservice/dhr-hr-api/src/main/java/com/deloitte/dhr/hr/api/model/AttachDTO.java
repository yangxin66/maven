package com.deloitte.dhr.hr.api.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * 附件上传后返回的实体
 * <br/>29/08/2019 10:47
 *
 * @author lshao
 */
public class AttachDTO {

    public static String ATTACHTYPE_FILE = "FILE";

    /**
     * 关联的资源主键
     */
    @Getter
    @Setter
    @NotNull
    private String key;
    /**
     * 用于后端解析时识别当前对象处理，FILE-文件
     */
    @Getter
    @Setter
    @NotNull
    private String attachType;

    @Getter
    @Setter
    @NotNull
    private String attachName;
}
