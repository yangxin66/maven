package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.hr.api.constant.ManagementTypeEnum;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * date: 22/08/2019 17:03
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class SearchDto implements Serializable {

    private static final long serialVersionUID = 6418522838619999156L;

    /**
     * 类型 比如已完成、未完成、进行中
     */
    @NotNull(message = "节点类型不允许为空")
    private SearchTypeEnum type;

    /**
     * 管理类型
     */
    private ManagementTypeEnum managementType;

    /**
     * 字段列表
     */
    @NotNull(message = "搜索条件不允许为空")
    private  List<FieldCustomDto> firstFieldCustoms;

    /**
     * 二级搜索字段列表
     */
    private  List<FieldCustomDto> secondFieldCustoms;

}
