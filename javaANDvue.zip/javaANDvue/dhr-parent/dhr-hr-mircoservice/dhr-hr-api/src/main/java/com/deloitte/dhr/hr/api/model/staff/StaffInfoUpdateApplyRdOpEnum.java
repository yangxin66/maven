package com.deloitte.dhr.hr.api.model.staff;

/**
 * @author chunliucq
 * @since 17/09/2019 20:55
 */
public enum StaffInfoUpdateApplyRdOpEnum {

    OP_NEW("1","新增"),
    OP_UPDATE("2","修改"),
    OP_DELETE("3","删除"),
    ;


    private String code;
    private String message;

    private StaffInfoUpdateApplyRdOpEnum(String code,String message){
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
