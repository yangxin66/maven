package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * 入职邮件url链接过后的认证页面提交参数DTO
 * <br/>27/08/2019 21:55
 *
 * @author lshao
 */
@Data
public class VerifyStaffInfoDTO {

    @NotNull(message = "token不能为空")
    private String token;
    @NotNull(message = "姓名不能为空")
    private String name;
    @NotNull(message = "身份证不能为空")
    private String card;
}
