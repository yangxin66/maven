package com.deloitte.dhr.hr.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * @author chunliucq
 * @since 09/10/2019 19:47
 */
@Data
public class ApplyRecordDelDto {
    /**
     * 业务编号
     */
    @JsonProperty(value = "_APPLY_NO")
    private String applyNo;

    @JsonProperty(value = "_APPLY_SUB_TYPE")
    private String busiType;
    /**
     * 业务数据记录ID
     */
    private List<String> ridList;
}
