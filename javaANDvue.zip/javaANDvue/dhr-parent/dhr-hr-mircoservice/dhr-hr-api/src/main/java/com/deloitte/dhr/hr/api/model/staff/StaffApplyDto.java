package com.deloitte.dhr.hr.api.model.staff;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class StaffApplyDto {
    @JsonProperty("_BUSINESSID")
    private String staffNo;
    private String status;
    @JsonProperty("_DATA_PART")
    private List<String> part;
}
