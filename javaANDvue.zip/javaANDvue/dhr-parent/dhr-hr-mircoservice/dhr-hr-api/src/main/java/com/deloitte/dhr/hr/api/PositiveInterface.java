package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.UnposotiveSearchDto;
import com.deloitte.dhr.hr.api.model.UnposotiveStaffInfoDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 转正接口
 * @author chunliucq
 * @since 22/08/2019 11:22
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/positive")
public interface PositiveInterface {


    /**
     * 查询待转正的员工数据
     *
     * @param request 请求数据
     */
    @PostMapping("/staff_unpositive")
    PaginationResponse<List<UnposotiveStaffInfoDto>> getUnPositiveStaff(@RequestBody PaginationRequest<UnposotiveSearchDto> request);

}
