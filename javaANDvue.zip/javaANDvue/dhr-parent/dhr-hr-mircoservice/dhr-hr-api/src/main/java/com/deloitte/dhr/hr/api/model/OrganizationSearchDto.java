package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.io.Serializable;

/**
 * 组织查询传输实体
 * date: 21/08/2019 14:59
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class OrganizationSearchDto implements Serializable {

    private static final long serialVersionUID = 8668574101419451377L;

    /**
     * 组织编码 可以是岗位、部门
     */
    private String code;

    /**
     * 组织名称 可以是岗位、部门
     */
    private String name;


}
