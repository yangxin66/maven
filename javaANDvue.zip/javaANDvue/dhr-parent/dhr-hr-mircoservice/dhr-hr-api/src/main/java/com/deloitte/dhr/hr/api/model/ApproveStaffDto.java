package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * date: 28/08/2019 18:03
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class ApproveStaffDto implements Serializable {

    private static final long serialVersionUID = 4614573983251251689L;
    /**
     * 员工名称
     */
    @NotNull(message = "员工唯一键不允许为空")
    @NotBlank(message = "员工唯一键不允许为空")
    private String staffId;

    /**
     * 任务id
     */
    @NotNull(message = "任务id不允许为空")
    @NotBlank(message = "任务id不允许为空")
    private String taskId;
}
