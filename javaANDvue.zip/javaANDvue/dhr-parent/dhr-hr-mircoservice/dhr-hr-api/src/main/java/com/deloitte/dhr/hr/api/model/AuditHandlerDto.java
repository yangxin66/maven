package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.hr.api.constant.ApplicationStatusEnum;
import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 流程审核节点处理传输实体
 * 比如审核通过 variable为1  审核驳回 variable为0
 * date: 20/09/2019 9:46
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class AuditHandlerDto {

    /**
     * 实例id
     */
    @NotNull(message = "流程实例id不允许为空")
    @NotBlank(message = "流程实例id不允许为空")
    private String processInstantId;

    /**
     * 任务id
     */
    @NotNull(message = "任务id不允许为空")
    @NotBlank(message = "任务id不允许为空")
    private String taskId;


    /**
     * 审批状态
     */
    @NotNull(message = "审核状态不允许为空")
    private ApplicationStatusEnum applicationStatusEnum;

    /**
     * 备注
     */
//    @Length(max = 100, message = "备注的长度不应超过100")
    private String remark;

    /**
     * 审批的类型：比如
     */
    @NotNull(message = "业务子类型不能为空")
    private SubtypeEnum subtypeEnum;

    /**
     * 业务数据
     */
    private JSONObject businessData;
}
