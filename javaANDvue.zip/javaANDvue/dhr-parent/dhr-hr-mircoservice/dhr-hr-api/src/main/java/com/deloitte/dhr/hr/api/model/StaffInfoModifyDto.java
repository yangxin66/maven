package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.deloitte.dhr.hr.api.model.staff.StaffInfoUpdateApplyRdOpEnum;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * date: 24/09/2019 19:45
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class StaffInfoModifyDto {

    @JsonProperty("_BUSINESSID")
    @JSONField(name = "_BUSINESSID")
    @NotNull(message = "员工编号不允许为空")
    @NotBlank(message = "员工编号不允许为空")
    private String staffNo;

    @JsonProperty("_OP")
    @JSONField(name = "_OP")
    @NotNull(message = "操作不允许为空")
    private StaffInfoUpdateApplyRdOpEnum op;

    @JsonProperty("_PART")
    @JSONField(name = "_PART")
    @NotNull(message = "模块名称不允许为空")
    @NotBlank(message = "模块名称不允许为空")
    private String part;

    @JsonProperty("_DATA")
    @JSONField(name = "_DATA")
    @NotNull(message = "数据不允许为空")
    private Map<String, Object> data;
}
