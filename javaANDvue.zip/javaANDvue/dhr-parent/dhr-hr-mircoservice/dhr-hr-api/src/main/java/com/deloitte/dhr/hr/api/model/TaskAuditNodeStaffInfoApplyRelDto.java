package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * date: 04/09/2019 16:53
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class TaskAuditNodeStaffInfoApplyRelDto extends AuditNodeDto implements Serializable {

    private static final long serialVersionUID = -3506175713746535002L;

    List<StaffInfoApplyDto> staffApplyList;
}
