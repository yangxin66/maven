package com.deloitte.dhr.hr.api.model;

public enum  OutExportType {

    ALL_EXPORTS,
    BATCH_EXPORT,
}

