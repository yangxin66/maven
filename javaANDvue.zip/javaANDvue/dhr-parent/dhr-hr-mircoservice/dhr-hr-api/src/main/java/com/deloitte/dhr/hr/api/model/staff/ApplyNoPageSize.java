package com.deloitte.dhr.hr.api.model.staff;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ApplyNoPageSize {

    @JsonProperty("_APPLY_NO")
    private String applyNo;
    private Integer page;
    private Integer size;
}
