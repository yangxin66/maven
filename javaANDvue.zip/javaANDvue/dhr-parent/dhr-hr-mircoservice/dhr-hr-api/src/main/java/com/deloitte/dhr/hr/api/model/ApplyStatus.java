package com.deloitte.dhr.hr.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ApplyStatus {


    private Boolean result;

    @JsonProperty("_DATA_PART")
    private String part;

    @JsonProperty("_APPLY_NO")
    private String applyNo;

    @JsonProperty("_PROCESS_INSTANCE_ID")
    private String processId;

    @JsonProperty("_TASK_ID")
    private String taskId;
}
