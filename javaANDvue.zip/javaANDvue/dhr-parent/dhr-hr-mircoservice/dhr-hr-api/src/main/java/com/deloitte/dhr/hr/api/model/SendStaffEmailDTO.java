package com.deloitte.dhr.hr.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 新建入职邮件发送DTO
 * <br/>27/08/2019 17:26
 *
 * @author lshao
 */
@Data
public class SendStaffEmailDTO {

    @NotNull(message = "业务编号不能为空")
    @NotBlank(message = "业务编号不能为空")
    private String applyNo;

    @NotNull(message = "发送邮件状态不能为空")
    private Boolean sendFlag;
}
