package com.deloitte.dhr.hr.api.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;

/**
 * date: 22/08/2019 18:02
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@Builder
public class OrganizationDto implements Serializable {

    private static final long serialVersionUID = 3766084187265283919L;
    /**
     * 组织类型  比如公司、部门、岗位
     */
    private String type;

    /**
     * 组织名称
     */
    private String name;

    /**
     * 组织编码
     */
    private String code;
}
