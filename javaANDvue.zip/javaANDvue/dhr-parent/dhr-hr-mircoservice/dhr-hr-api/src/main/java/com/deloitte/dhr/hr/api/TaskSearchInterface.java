package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 任务搜索接口
 * @author chunliucq
 * @since 22/08/2019 11:22
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/task")
public interface TaskSearchInterface {


    /**
     * 根据查询条件查询待办已办列表
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
    @PostMapping("/search")
    PaginationResponse<List<StaffInfoApplyDto>> searchStaffInfoTask(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest);

    /**
     * 搜索我的申请
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
    @PostMapping("/search/my_application")
    PaginationResponse<List<StaffInfoApplyDto>> searchMyApplicationByPage(@RequestBody @Validated PaginationRequest<SearchDto> searchDtoPaginationRequest);


}
