package com.deloitte.dhr.hr.api.model;

public enum SearchConditionEnum {
    // 等于
    eq,
    // 小于
    lt,
    // 模糊查询
    like,
    // 不等于
    ne,
    // 大于
    gt,
    // 小于等于
    lte,
    // 大于等于
    gte
}
