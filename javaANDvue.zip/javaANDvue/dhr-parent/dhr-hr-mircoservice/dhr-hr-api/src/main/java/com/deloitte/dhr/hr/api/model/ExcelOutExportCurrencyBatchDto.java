package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.export.model.ExportTitle;
import lombok.Data;

import java.util.List;

@Data
public class ExcelOutExportCurrencyBatchDto {

    /**
     * 表头结构
     */
    private List<ExportTitle> title;

    /**
     * 导出其他参数
     */
   private JSONObject data;

    /**
     * 导出的url
     */
   private String url;

    /**
     * 选择的数据
     */
   private List<PageAndSize> pageAndSizeList;

    /**
     * 唯一字段对应的值
     */
   private String name;

    /**
     * 上传导出错误数据时使用
     */
    private String status;
}
