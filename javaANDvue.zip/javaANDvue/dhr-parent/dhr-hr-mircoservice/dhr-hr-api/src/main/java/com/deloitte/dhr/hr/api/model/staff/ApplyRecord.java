package com.deloitte.dhr.hr.api.model.staff;

import lombok.Data;

/**
 * @author chunliucq
 * @since 18/09/2019 19:17
 */
@Data
public class ApplyRecord {
    private String applyNo;
    private String rid;
}
