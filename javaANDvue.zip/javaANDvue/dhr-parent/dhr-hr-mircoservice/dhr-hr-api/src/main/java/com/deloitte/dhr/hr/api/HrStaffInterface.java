package com.deloitte.dhr.hr.api;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.dhr.hr.api.model.staff.*;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

/**
 * 员工信息操作接口
 * @author chunliucq
 * @since 22/08/2019 11:22
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/staff")
public interface HrStaffInterface {

    /**
     * 保存员工入职时，员工信息填写
     * @param staffInfoJson
     * @return
     */
    @PostMapping(value = "/save")
    Response<Map> saveStaffInfo(@RequestBody Request<JSONObject> staffInfoJson);

    /**
     * 员工填写信息提交
     * @param staffInfoJson
     * @return
     */
    @ApiOperation(value = "员工提交个人信息",notes = "员工填写个人信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "staffInfoJson", value = "员工信息", required = true, dataType = "JSONObject")
    })
    @PostMapping(value = "/submit")
    Response<Map> submitStaffInfo(@RequestBody Request<JSONObject> staffInfoJson);

    /**
     * 检查员工身份
     * @param request
     * @return
     */
    @PostMapping(value = "/check/person")
    Response<String> staffPersonCheck(@RequestBody Request<StaffPersonCheckDto> request);

    /**
     * 根据员工编号查询DHR员工信息
     * @param staffNo
     * @return
     */
    @PostMapping(value = "/query/detail/dhr")
    Response<Map> queryStaffInfoByStaffNo(@RequestBody Request<StaffNoDto> staffNo);

    /**
     * 根据Token查询DHR员工信息
     * @param tokenDtoRequest
     * @return
     */
    @PostMapping(value = "/query/detail/token")
    Response<Map> queryStaffInfoByToken(@RequestBody Request<TokenDto> tokenDtoRequest);

    /**
     * 根据查询条件查询员工入职信息
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
//    @PostMapping("/search")
//    PaginationResponse<List<StaffNodeDto>> searchEmployee(@RequestBody @Validated  PaginationRequest<SearchDto> searchDtoPaginationRequest);

    /**
     * 根据id查询员工入职对比信息
     *
     * @param idRequest 查询参数传输实体
     */
    @PostMapping("/detail/compare")
    Response<StaffDetailCompareDto> getStaffDetailCompare(@RequestBody Request<String> idRequest);


    /**
     * 审核通过
     *
     * @param listRequest 批量审核通过实体
     */
//    @PostMapping("/batch/approve")
//    Response<Object> approveStaffInfo(@Validated @RequestBody Request<List<ApproveStaffDto>> listRequest);

    /**
     * 根据查询条件查询待办已办列表
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
//    @PostMapping("/search/modify_info_apply")
//    PaginationResponse<List<StaffInfoApplyDto>> searchStaffInfoModifyTask(@RequestBody @Validated  PaginationRequest<SearchDto> searchDtoPaginationRequest);

    /**
     * 搜索我的申请
     *
     * @param searchDtoPaginationRequest 查询参数传输实体
     */
//    @PostMapping("/search/my_application")
//    PaginationResponse<List<StaffInfoApplyDto>> searchMyApplication(@RequestBody @Validated  PaginationRequest<SearchDto> searchDtoPaginationRequest);

    /**
     * 变更申请查询
     *
     * @param applyRequest 查询申请的基本信息
     */
    @PostMapping("/modinfo/applied")
    Response<List<ApplyStatus>> queryApply(@Validated @RequestBody Request<StaffApplyDto> applyRequest);


    /**
     * 变更申请查询
     *
     * @param applyNo 申请编号
     */
    @PostMapping("/modinfo/apply/query/applyno")
    Response<Map> queryApplyByApplyNo( @RequestBody Request<ApplyNo> applyNo);


    /**
     * 变更申请前后比较
     *
     * @param applyNoPaginationRequest 分页查询申请号
     */
    @PostMapping("/modinfo/apply/query/applypage")
    PaginationResponse<List<Map>> queryApplyCompare(PaginationRequest<ApplyNo> applyNoPaginationRequest);


    /**
     * 员工提效个人信息变更申请
     * @param applyRequest
     * @return
     */
    @PostMapping("/modinfo/apply")
    Response<Void> applyModStaffInfo(@RequestBody Request<Map> applyRequest);


    /**
     * 修改员工信息到SAP中
     *
     * @param request 修改信息传输实体
     */
    @PostMapping("/modify/staff_info/sap")
    Response<String> modifyStaffInfoToSap(@Validated @RequestBody Request<StaffInfoModifyDto> request);

    @PostMapping("/modinfo/apply/querydetail")
    public Response<Map> queryUpdateDetailInfo(@RequestBody Request<ApplyRecord> applyRecordRequest);

    /**
     * 修改员工信息变更申请的记录
     * @param staffUpdateApplyRecordRequest
     * @return
     */
    @PostMapping("/modinfo/apply/update/record")
    public Response<Void> updateApplyRecord(@RequestBody Request<Map> staffUpdateApplyRecordRequest);


    /**
     * 根据关键字搜索员工信息
     * @param request 含关键字的传输实体
     * @return
     */
    @PostMapping("/search/staff_info")
    Response<List<StaffInfoSearchDto>> searchStaffInfoByKeyword(@RequestBody Request<String> request);
}
