package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.util.List;

@Data
public class PageAndSize {

    /**
     * 第几页
     */
    private Integer page;

    /**
     * 这一页选择了那些
     */
    private List<String> idList;
}
