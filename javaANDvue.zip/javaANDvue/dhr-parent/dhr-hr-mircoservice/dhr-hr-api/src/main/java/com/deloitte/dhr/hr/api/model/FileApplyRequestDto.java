package com.deloitte.dhr.hr.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;

@Data
public class FileApplyRequestDto implements Serializable {


    /**
     * 文件
     */
    private MultipartFile file;

    /**
     * 业务编号
     */
    @JsonProperty(value = "_APPLY_NO")
    private String applyNo;

    /**
     * 业务类型
     */
    @JsonProperty(value = "_APPLY_SUB_TYPE")
    private String busiType;

}
