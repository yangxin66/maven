package com.deloitte.dhr.hr.api;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author chunliucq
 * @since 09/10/2019 13:55
 */
public interface BusinessNoInterface {

    /**
     * 根据KEy生成业务编号
     * @param request
     * @return
     */
    Response<String> generatorBusinessNo(@RequestBody Request<String> request);

    /**
     * 根据业务类型生成业务编号的KEY
     * @param request
     * @return
     */
    Response<String> generatorBusinessNoByBusiType(@RequestBody Request<String> request);
}
