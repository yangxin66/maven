package com.deloitte.dhr.hr.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;


/**
 * @author chunliucq
 * @since 20/08/2019 11:01
 */
@Data
public class EnumItem {

    @JsonIgnore
    private String itemId;
    /**
     * 下拉列表选项的value值
     */
    private String value;
    /**
     * 下拉列表选项的value值对应的描述
     */
    private String description;

    /**
     * 字段下拉选项顺序
     */
    //@JsonIgnore
    //private int order;
}
