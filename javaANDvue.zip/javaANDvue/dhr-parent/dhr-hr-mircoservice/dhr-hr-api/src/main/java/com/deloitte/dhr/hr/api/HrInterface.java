package com.deloitte.dhr.hr.api;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import com.deloitte.dhr.hr.api.model.SearchStaffCategoryInfoDto;
import com.deloitte.dhr.hr.api.model.SendStaffEmailDTO;
import com.deloitte.dhr.hr.api.model.VerifyStaffInfoDTO;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * 新建入职操作接口
 * @author lshao
 * @since 22/08/2019 11:22
 */
// todo
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr")
public interface HrInterface {

    /**
     * 保存员工入职时，员工信息填写
     * @param
     * @return
     */
    @PostMapping(value = "/save")
    Response<String> saveStaffInfo(@RequestBody Request<PageDataRequest> request);

    @PostMapping(value = "/sendStaffEmail")
    Response<String> sendStaffEmail(@RequestBody Request<SendStaffEmailDTO> request);

    /**
     * 输入用户名身份证进行验证
     * @param request
     * @return
     */
    @PostMapping(value = "/verifyStaffInfo")
    Response<String> verifyStaffInfo(@RequestBody Request<VerifyStaffInfoDTO> request);

    /**
     * HR 修改员工信息  直接修改，并同步到SAP中
     * @param request
     * @return
     */
    @PostMapping(value = "/update/staffinfo")
    Response<Void> updateStaffInfoByHr(@RequestBody Request<Map> request);

    /**
     * 员工信息变更各项分类信息查询
     * @param request
     * @return
     */
    @PostMapping(value = "/searchStaffCategoryInfo")
    Response<JSONObject> searchStaffCategoryInfo(@RequestBody Request<SearchStaffCategoryInfoDto> request);

}
