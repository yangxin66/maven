package com.deloitte.dhr.hr.api;


import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



import java.io.IOException;
import java.text.ParseException;

@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/export")
public interface ExcelOutInterface {


    @PostMapping(value = "/excel/currency/all")
    void getInfoExcelCurrencyALL(@RequestBody Request<ExcelOutExportCurrencyALLDto> excelOutExportCurrencyALLDtoRequest) throws IOException,
            ParseException;

    @PostMapping(value = "/excel/currency/batch")
    void getInfoExcelCurrencyBatch(@RequestBody Request<ExcelOutExportCurrencyBatchDto> exportCurrencyDtoRequest) throws IOException,
            ParseException;

    @PostMapping(value = "/excel")
    void getInfoExcel(@RequestBody Request<ExcelOutExprotDto> excelOutExprotDtoRequest) throws IOException,
            ParseException;

    @PostMapping(value = "/excel/apply/hr")
    void getApplyExcelHr(@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException;

    @PostMapping(value = "/excel/apply/staff")
    void getApplyExcelStaff(@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException;

    @PostMapping("/excel/apply/audit")
    @CrossOrigin("*")
    void getApplyAuditExcel(@RequestBody Request<ExcelApplyDetailedDto> excelApplyDetailedDtoRequest) throws IOException,
            ParseException;

    /**
     * 模拟的下载模板接口
     * @param request
     * @throws IOException
     */
    @PostMapping("/download/excel")
    void downloadExcel(@RequestBody Request<String> request) throws IOException;
}
