package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.common.export.model.ExportTitle;
import lombok.Data;

import java.util.List;

@Data
public class ExcelApplyExportDto {

    private List<ExportTitle> title;

    private List<String> applyNoList;

    private OutExportType OutType;

    private SearchDto searchDto;
}
