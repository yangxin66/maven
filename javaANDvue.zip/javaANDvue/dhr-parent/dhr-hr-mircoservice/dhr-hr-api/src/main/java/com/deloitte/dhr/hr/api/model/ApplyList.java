package com.deloitte.dhr.hr.api.model;


import lombok.Data;

@Data
public class ApplyList {

    private String applyNo;

    private String rid;
}
