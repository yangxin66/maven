package com.deloitte.dhr.hr.api.constant;

/**
 * 人事管理类型枚举
 * date: 08/10/2019 14:19
 *
 * @author wgong
 * @since 0.0.1
 */
public enum ManagementTypeEnum {
    /**
     * 员工新建入职
     */
    CREATE_STAFF("员工新建入职"),

    /**
     * 员工信息修改
     */
    STAFF_INFO_MODIFY("员工信息修改"),
    /**
     * 岗位变动
     */
    POSITION_CHANGE("岗位变动"),
    /**
     * 减册
     */
    DECREASE_BOOK("减册"),
    /**
     * 转正
     */
    POSITIVE("转正"),
    /**
     * 兼职
     */
    AND_POST("兼岗"),
    /**
     * 合同管理
     */
    CONTRACT_MANAGEMENT("合同管理");

    private String value;

    ManagementTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
