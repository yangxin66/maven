package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.ApplyRecordDelDto;
import com.deloitte.dhr.hr.api.model.staff.ApplyNoAndTypeDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;

import com.deloitte.notification.provider.api.configure.FeignMultipartSupportConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 *
 * @author chunliucq
 * @since 08/10/2019 14:24
 */
@FeignClient(value = "dhr-hr-microservice",configuration = FeignMultipartSupportConfig.class, path = "/api/v1/hr/apply")
public interface ApplyInterface {
    /**
     * 保存各种申请 岗位变动、员工转正、兼岗等
     * @param applyRequest
     * @return
     */
    @PostMapping("/add/save")
    Response<Void> saveApply(@RequestBody Request<Map> applyRequest);

    /**
     * 提交审批各种申请 岗位变动、员工转正、兼岗等
     * @param applyRequest
     * @return
     */
    @PostMapping("/add/submit")
    Response<Void> submitApply(@RequestBody Request<Map> applyRequest);

    @PostMapping("/add/applydetail")
    Response<Void> appendRecord(@RequestBody Request<Map> requestData);

    @PostMapping("/del/applydetail")
    Response<Void> deleteRecord(@RequestBody Request<ApplyRecordDelDto> delDtoRequest);

    @PostMapping("/query/applydetail/page")
    public PaginationResponse<List<Map>> queryApplyInfoByPageList(@RequestBody PaginationRequest<ApplyNoAndTypeDto> applyPaginationRequest);

    @PostMapping("/query/applydetail/page/conf")
    public PaginationResponse<Map> queryApplyInfoByPageListForConf(@RequestBody PaginationRequest<ApplyNoAndTypeDto> applyPaginationRequest);

    @PostMapping("/query/applyinfo")
    Response<Map> queryApplyByApplyNo(@RequestBody Request<ApplyNoAndTypeDto> applyNoRequest);

    @PostMapping(value = "/save/apply/upload",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    Response<Map> UploadApplyData(@RequestParam(required = false,value = "_APPLY_NO") String applyNo,
                                  @RequestParam(required = false,value = "_APPLY_SUB_TYPE") String busiType,
                                  @RequestPart(required = false,value = "attach") MultipartFile file);




}
