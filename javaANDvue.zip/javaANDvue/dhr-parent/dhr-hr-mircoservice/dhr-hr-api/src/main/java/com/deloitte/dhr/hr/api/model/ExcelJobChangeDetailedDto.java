package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.common.export.model.ExportTitle;
import lombok.Data;

import java.util.List;

@Data
public class ExcelJobChangeDetailedDto {

    /**
     * 表头结构
     */
    private List<ExportTitle> title;

    /**
     * 导出类型（全部/批量）
     */
    private OutExportType OutType;

    /**
     * 员工变动业务编号
     */
    private String changeNo;

    /**
     * 员工编号
     * 批量导出的时候使用
     */
    private List<String> ridList;

}
