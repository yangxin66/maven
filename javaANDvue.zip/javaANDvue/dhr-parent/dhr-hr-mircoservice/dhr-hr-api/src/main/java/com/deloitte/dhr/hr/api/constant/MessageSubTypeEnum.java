package com.deloitte.dhr.hr.api.constant;

/**
 * 消息类型枚举
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
public enum MessageSubTypeEnum {
    /**
     * 转正
     */
    POSITIVE
}
