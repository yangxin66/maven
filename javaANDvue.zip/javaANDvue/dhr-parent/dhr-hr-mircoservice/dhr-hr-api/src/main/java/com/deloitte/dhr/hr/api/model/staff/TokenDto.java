package com.deloitte.dhr.hr.api.model.staff;

import lombok.Data;

/**
 * @author chunliucq
 * @since 30/08/2019 16:22
 */
@Data
public class TokenDto {
    /**
     * 员工token参数
     */
    private String token;
}
