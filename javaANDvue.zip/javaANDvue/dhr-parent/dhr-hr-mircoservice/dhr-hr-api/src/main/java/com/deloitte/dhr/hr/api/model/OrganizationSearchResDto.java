package com.deloitte.dhr.hr.api.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

/**
 * 组织搜索结果传输实体
 * date: 21/08/2019 15:55
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@AllArgsConstructor
public class OrganizationSearchResDto implements Serializable {

    private static final long serialVersionUID = -6566049723468468733L;
    /**
     * 岗位编码
     */
    private String code;

    /**
     * 岗位名称
     */
    private String name;

    /**
     * 所属部门ID
     */
    private String parentId;

    /**
     * 所属部门名称
     */
    private String parentName;


}
