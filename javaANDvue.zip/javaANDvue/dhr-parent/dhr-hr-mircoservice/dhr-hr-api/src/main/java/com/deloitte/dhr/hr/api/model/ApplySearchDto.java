package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.util.List;

@Data
public class ApplySearchDto {

    List<String> applyNoList;
    SearchDto searchDto;

}
