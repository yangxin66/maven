package com.deloitte.dhr.hr.api.model;

/**
 * date: 26/08/2019 17:43
 *
 * @author wgong
 * @since 0.0.1
 */
public enum SearchTypeEnum {

    /**
     * 未完成任务
     */
    UNCOMPLETE_TASK,

    /**
     * 已完成任务
     */
    COMPLETE_TASK,

    /**
     * 进行中
     */
    PROCESSING
}
