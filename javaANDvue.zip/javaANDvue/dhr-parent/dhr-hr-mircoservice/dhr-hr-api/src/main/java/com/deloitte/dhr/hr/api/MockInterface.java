package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.constant.SubtypeEnum;
import com.deloitte.dhr.hr.api.model.QueryApplyUploadDto;
import com.deloitte.dhr.hr.api.model.staff.StaffNoDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/apply")
public interface MockInterface {


    /**
     * 员工基本信息
     * @param staffNoRequest  员工编号
     * @return
     */
    @PostMapping("/query/apply/staffinfo")
    Response<List> queryApplyStaffInfo(@RequestBody Request<StaffNoDto> staffNoRequest);

    /**
     * 查询待确认信息
     * @param staffNoRequest  员工编号
     * @return
     */
    @PostMapping("/query/apply/estimate")
    Response<Map> queryApplyEstimate(@RequestBody Request<StaffNoDto> staffNoRequest);

    /**
     * 上传文件
     * @param request   上传文件的一些基本信息
     * @return
     */
    @PostMapping("/query/apply/upload")
    PaginationResponse<Map<String, Object>> queryApplyUpload(@RequestBody PaginationRequest<QueryApplyUploadDto> request);

    /**
     * 同员工编号查询兼岗信息
     * @param request  员工编号
     * @return
     */
    @PostMapping("/query/Concurrent/post")
    PaginationResponse<List> queryConcurrentPost(@RequestBody PaginationRequest<StaffNoDto> request);

}
