package com.deloitte.dhr.hr.api.model.staff;


import lombok.Data;

@Data
public class ApplyNo {
    /**
     * 申请编号
     */
    private String applyNo;

    /**
     * 业务类型
     */
    private String busiType;
}
