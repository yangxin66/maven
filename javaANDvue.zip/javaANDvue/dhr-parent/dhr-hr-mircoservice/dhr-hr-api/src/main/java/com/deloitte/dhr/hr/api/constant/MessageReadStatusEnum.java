package com.deloitte.dhr.hr.api.constant;

/**
 * date: 11/10/2019 16:01
 *
 * @author wgong
 * @since 0.0.1
 */
public enum MessageReadStatusEnum {
    /**
     * 未读
     */
    UN_READ("未读"),
    /**
     * 已读
     */
    READ("已读");

    private String value;

    MessageReadStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
