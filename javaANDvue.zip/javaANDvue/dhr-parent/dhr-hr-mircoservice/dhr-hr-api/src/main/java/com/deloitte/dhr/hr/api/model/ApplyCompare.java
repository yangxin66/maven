package com.deloitte.dhr.hr.api.model;

import java.util.List;

public class ApplyCompare {

    List<StaffInfoBeforeAndAfter> ApplyCompare;

}
