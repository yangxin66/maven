package com.deloitte.dhr.hr.api.model;

public enum SearchRelationEnum {
    AND,
    OR
}
