package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.io.Serializable;
import java.time.Instant;

/**
 * 员工修改信息流程信息表
 * date: 17/09/2019 11:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class StaffInfoApplyDto implements Serializable {

    private static final long serialVersionUID = -6818305015306405095L;

    @JsonProperty("_PROCESS_INSTANCE_ID")
    @JSONField(name = "_PROCESS_INSTANCE_ID")
    private String processInstanceId;

    @JsonProperty("_BUSINESSID")
    @JSONField(name = "_BUSINESSID")
    private String staffId;

    @JsonProperty("_APPLY_NO")
    @JSONField(name = "_APPLY_NO")
    private String applyNo;

    @JsonProperty("_NAME")
    @JSONField(name = "_NAME")
    private String name;

    @JsonProperty("_DEPARTMENT_ID")
    @JSONField(name = "_DEPARTMENT_ID")
    private String departmentId;

    @JsonProperty("_DEPARTMENT_NAME")
    @JSONField(name = "_DEPARTMENT_NAME")
    private String departmentName;

    @JsonProperty("_DATA_PART")
    @JSONField(name = "_DATA_PART")
    private String type;

    @JsonProperty("_DATA_PART_NAME")
    @JSONField(name = "_DATA_PART_NAME")
    private String pratName;

    @JsonProperty("_APPLICANT_NAME")
    @JSONField(name = "_APPLICANT_NAME")
    private String applicantName;

    @JsonProperty("_APPLICANT_ID")
    @JSONField(name = "_APPLICANT_ID")
    private String applicantId;

    @JsonProperty("_MOD_NUM")
    @JSONField(name = "_MOD_NUM")
    private String modNum;

    @JsonProperty("_REASON")
    @JSONField(name = "_REASON")
    private String reason;

    @JsonProperty("_APPLY_TIME")
    @JSONField(name = "_APPLY_TIME")
    private Instant applyTime;

    @JsonProperty("_AUDIT_ID")
    @JSONField(name = "_AUDIT_ID")
    private String auditId;

    @JsonProperty("_AUDIT_TIME")
    @JSONField(name = "_AUDIT_TIME")
    private Instant auditTime;

    @JsonProperty("_AUDIT_NAME")
    @JSONField(name = "_AUDIT_NAME")
    private String auditName;

    @JsonProperty("_APPLY_STATUS_NAME")
    @JSONField(name = "_APPLY_STATUS_NAME")
    private String statusName;

    @JsonProperty("_APPLY_STATUS")
    @JSONField(name = "_APPLY_STATUS")
    private String status;

    @JsonProperty("_TASK_STATUS_NAME")
    @JSONField(name = "_TASK_STATUS_NAME")
    private String taskStatusName;

    @JsonProperty("_TASK_STATUS")
    @JSONField(name = "_TASK_STATUS")
    private String taskStatus;

    @JsonProperty("_TASK_ID")
    @JSONField(name = "_TASK_ID")
    private String taskId;

    @JsonProperty("DHRSFZH")
    @JSONField(name = "DHRSFZH")
    private String idNumber;

    @JsonProperty("_COMPANY")
    @JSONField(name = "_COMPANY")
    private String company;

    /**
     * 申请说明
     */
    @JsonProperty("_TITLE")
    @JSONField(name = "_TITLE")
    private String title;

    @JsonProperty("_SEND_EMAIL_NUM")
    @JSONField(name = "_SEND_EMAIL_NUM")
    private String sendEmailNum;

    @JsonProperty("_APPLY_TYPE")
    @JSONField(name = "_APPLY_TYPE")
    private String applyType;

    @JsonProperty("_APPLY_TYPE_NAME")
    @JSONField(name = "_APPLY_TYPE_NAME")
    private String applyTypeName;

    @JsonProperty("_APPLY_SUB_TYPE")
    @JSONField(name = "_APPLY_SUB_TYPE")
    private String applySubType;

    @JsonProperty("_APPLY_SUB_TYPE_NAME")
    @JSONField(name = "_APPLY_SUB_TYPE_NAME")
    private String applySubTypeName;


}
