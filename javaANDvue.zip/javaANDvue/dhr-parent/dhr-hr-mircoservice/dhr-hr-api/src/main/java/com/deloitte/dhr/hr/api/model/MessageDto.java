package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import lombok.Data;

import java.time.Instant;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class MessageDto {

    private String id;

    /**
     * 消息标题
     */
    private String title;

    /**
     * 消息类型
     */
    private MessageTypeEnum messageType;

    /**
     * 创建时间
     */
    private Instant createTime;

    /**
     * 员工编号
     */
    private String staffNo;

    private String status;

    private String statusName;

}
