package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.extension.beans.sap.SapDataPaginationRequest;
import lombok.Data;

import java.time.LocalDate;

/**
 * 员工信息变更的弹窗搜索条件dto
 * <br/>23/09/2019 18:11
 *
 * @author lshao
 */
@Data
public class SearchStaffCategoryInfoDto extends SapDataPaginationRequest {

    private LocalDate startTime;

    private LocalDate endTime;
    /**
     * 查询的信息分类，例如标识查询的是工作经历、党政信息等
     */
    private String category;
}
