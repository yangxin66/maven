package com.deloitte.dhr.hr.api.model;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * 员工信息搜索结果传输实体
 * 根据关键字搜索员工信息结果的传输实体
 * date: 24/09/2019 10:13
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@Builder
public class StaffInfoSearchDto implements Serializable {

    private static final long serialVersionUID = 5402497142487299392L;

    private String staffNo;

    private String name;

    private String departmentName;

    private String companyName;

    private String stationName;

}
