package com.deloitte.dhr.hr.api.constant;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
public enum MessageTypeEnum {
    /**
     * 消息通知
     */
    PERSONAL_MESSAGE,

    /**
     * 消息公告
     */
    SYS_NOTICE
}
