package com.deloitte.dhr.hr.api.constant;

/**
 * 审核可选择的申请状态
 * date: 17/09/2019 20:14
 *
 * @author wgong
 * @since 0.0.1
 */
public enum ApplicationStatusEnum {

    /**
     * 流程关闭
     */
    CLOSE("2"),
    /**
     * 已提交
     */
    SUBMITTED("1"),
    /**
     * 审核通过
     */
    APPROVED("1"),

    /**
     * 驳回
     */
    REJECT("0"),

    /**
     * 删除流程
     */
    DELETE("1");


    private String value;

    ApplicationStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
