package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.export.model.ExportTitle;
import lombok.Data;

import java.util.List;

@Data
public class ExcelOutExportCurrencyALLDto {

    /**
     * 表头结构
     */
    private List<ExportTitle> title;


    /**
     * 导出其他参数
     */
   private JSONObject data;

    /**
     * 导出的url
     */
   private String url;


}
