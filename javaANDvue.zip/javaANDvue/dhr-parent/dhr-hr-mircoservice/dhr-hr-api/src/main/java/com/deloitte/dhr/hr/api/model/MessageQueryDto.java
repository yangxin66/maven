package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.hr.api.constant.MessageTypeEnum;
import com.sun.corba.se.spi.ior.ObjectId;
import lombok.Data;

import java.time.Instant;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class MessageQueryDto {

    MessageTypeEnum messageTypeEnum;

    SearchConditionEnum searchCondition;

}
