package com.deloitte.dhr.hr.api;


import com.deloitte.dhr.hr.api.model.*;
import com.deloitte.infrastructure.communication.Request;
import feign.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.IOException;
import java.text.ParseException;

@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/export")
public interface ExcelOutDownLoadInterface {

    @PostMapping(value = "/excel/currency/all")
    Response getInfoExcelCurrencyALL(@RequestBody Request<ExcelOutExportCurrencyALLDto> excelOutExportCurrencyALLDtoRequest) throws IOException,
            ParseException;

    @PostMapping(value = "/excel/currency/batch")
    Response getInfoExcelCurrencyBatch(@RequestBody Request<ExcelOutExportCurrencyBatchDto> exportCurrencyDtoRequest) throws IOException,
            ParseException;

    @PostMapping("/excel/apply/audit")
    @CrossOrigin("*")
    Response getApplyAuditExcel(@RequestBody Request<ExcelApplyDetailedDto> excelApplyDetailedDtoRequest) throws IOException,
            ParseException;


    @PostMapping(value = "/excel/apply/hr")
    Response getApplyExcelHr(@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException;


    @PostMapping(value = "/excel/apply/staff")
    Response getApplyExcelStaff(@RequestBody Request<ExcelApplyExportDto> excelApplyExportDtoRequest) throws IOException,
            ParseException;


    @PostMapping(value = "/excel")
    Response getInfoExcel(@RequestBody Request<ExcelOutExprotDto> excelOutExprotDtoRequest) throws IOException,
            ParseException;

    @PostMapping("/download/excel")
    Response downloadExcel(@RequestBody Request<String> request) throws IOException;
}
