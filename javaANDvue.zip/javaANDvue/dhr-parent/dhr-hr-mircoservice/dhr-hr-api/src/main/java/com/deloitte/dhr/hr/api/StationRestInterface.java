package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.OrganizationSearchDto;
import com.deloitte.dhr.hr.api.model.OrganizationDto;
import com.deloitte.dhr.hr.api.model.OrganizationQueryDto;
import com.deloitte.dhr.hr.api.model.OrganizationSearchResDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 组织岗位相关api
 * date: 21/08/2019 15:26
 *
 * @author wgong
 * @since 0.0.1
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/organizations")
public interface StationRestInterface {

    /**
     * 根据岗位名称或岗位编码分页查询岗位数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @PostMapping("/stations/page")
    PaginationResponse<List<OrganizationSearchResDto>> getStationByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest);

    /**
     * 根据部门名称或部门编码分页查询部门数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @PostMapping("/departments/page")
    PaginationResponse<List<OrganizationSearchResDto>> getDepartmentByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest);

    /**
     * 根据单位名称或单位编码分页查询部门数据
     *
     * @param paginationRequest 查询参数传输实体
     */
    @PostMapping("/unit/page")
    PaginationResponse<List<OrganizationSearchResDto>> getUnitByPage(@RequestBody PaginationRequest<OrganizationSearchDto> paginationRequest);


    /**
     * 根据上级组织编号和类型查找组织
     *
     * @param organizationQueryDtoRequest 查询参数传输实体
     */
    @PostMapping("/child")
    Response<List<OrganizationDto>> getOrganizationChild(@RequestBody Request<OrganizationQueryDto> organizationQueryDtoRequest);

}
