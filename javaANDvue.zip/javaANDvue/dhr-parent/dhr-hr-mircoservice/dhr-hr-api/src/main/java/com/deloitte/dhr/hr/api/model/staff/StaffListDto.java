package com.deloitte.dhr.hr.api.model.staff;

import lombok.Data;

import java.util.List;

/**
 * @author chunliucq
 * @since 27/08/2019 21:40
 */
@Data
public class StaffListDto  {
    /**
     * 员工编号列表
     */
    private List<String> staffNoList;
}
