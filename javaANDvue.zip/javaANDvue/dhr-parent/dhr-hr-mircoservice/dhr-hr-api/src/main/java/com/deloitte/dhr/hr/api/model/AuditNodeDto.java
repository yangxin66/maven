package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.io.Serializable;
import java.time.Instant;
import java.util.Date;

/**
 * 流程动态节点传输实体
 *
 * @author wgong
 */
@Data
public class AuditNodeDto implements Serializable {

    private String taskId;

    /**
     * 任务名称
     */
    private String taskName;

    private String auditorId;

    /**
     * 用户名称
     */
    private String auditorName;

    /**
     * 备注
     */
    private String remark;

    /**
     * 状态
     */
    private String status;

    /**
     * 状态名称
     */
    private String statusName;

    /**
     * 处理时间
     */
    private Instant auditTime;

    /**
     * 是否完成
     */
    private boolean completed;

    /**
     * 员工头像
     */
    private String imgUrl;
}
