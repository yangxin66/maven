package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import lombok.Data;

import java.io.Serializable;

/**
 * 员工详情对比数据
 * 包括dhr的员工信息数据和sap的员工信息数据
 * date: 29/08/2019 13:59
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class StaffDetailCompareDto implements Serializable {

    private static final long serialVersionUID = -93411934538211077L;

    /**
     * dhr中的最新员工数据
     */
    private PageDataRequest dhrData;

    /**
     * SAP中的最初员工数据
     */
    private PageDataRequest sapData;
}
