package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.util.List;

/**
 * 枚举值的查询结果
 * @author chunliucq
 * @since 20/08/2019 11:00
 */
@Data
public class EnumResult {
    /**
     * 枚举值的查询结果，支持返回多个查询KEY的结果
     */
    private List<EnumCombox> resultList;
}
