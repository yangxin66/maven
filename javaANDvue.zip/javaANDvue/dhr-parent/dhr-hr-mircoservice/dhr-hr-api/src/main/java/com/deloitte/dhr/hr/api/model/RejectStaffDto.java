package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 驳回--》重新发送邮件 传输实体
 * date: 28/08/2019 17:54
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class RejectStaffDto implements Serializable {

    private static final long serialVersionUID = -6470145186988373560L;
    /**
     * 员工唯一键
     */
    @NotNull(message = "员工唯一键不允许为空")
    @NotBlank(message = "员工唯一键不允许为空")
    private String staffId;

    /**
     * 驳回理由
     */
    @NotNull(message = "员工唯一键不允许为空")
    @NotBlank(message = "员工唯一键不允许为空")
    private String reason;
}
