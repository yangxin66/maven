package com.deloitte.dhr.hr.api.model.staff;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author chunliucq
 * @since 22/08/2019 11:54
 */
@Data
@ApiModel("员工入职请求填写信息")
public class StaffInfoDto {

    /**
     * 会话token
     */
    private String token;

    /**
     *
     */
    private String staffNo;

    /**
     * 员工姓名
     */
    @JsonProperty(value = "NACHN")
    // todo
    private String staffName;
}
