package com.deloitte.dhr.hr.api.model;

import com.alibaba.fastjson.JSONObject;

public class StaffInfoBeforeAndAfter {


    JSONObject beforeData;
    JSONObject afterData;
}
