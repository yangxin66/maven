package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.RejectStaffDto;
import com.deloitte.dhr.hr.api.model.staff.StaffListDto;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @author chunliucq
 * @since 22/08/2019 13:49
 */
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/notification")
public interface HrNotificationInterface {

    /**
     * 驳回 --》重新发送邮件
     *
     * @param request 查询参数传输实体
     */
    @PostMapping("/reject_entry_email")
    Response<Object> sendRejectEmail(@Validated @RequestBody Request<RejectStaffDto> request);

    @PostMapping(value = "/send_entry_email")
    Response<Object> sendEmail(@RequestBody Request<List<String>> staffListDtoRequest);
}
