package com.deloitte.dhr.hr.api.model;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 流程动态传输实体
 *
 * @author wgong
 */
@Data
@Builder
public class FlowTraceLogDto implements Serializable {

    private static final long serialVersionUID = -3738444471573637684L;

    private List<AuditNodeDto> flowSteps;

    private List<AuditNodeDto> flowLogDetail;
}
