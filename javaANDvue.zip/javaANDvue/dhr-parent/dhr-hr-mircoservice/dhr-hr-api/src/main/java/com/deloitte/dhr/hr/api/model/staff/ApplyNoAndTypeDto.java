package com.deloitte.dhr.hr.api.model.staff;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @author chunliucq
 * @since 11/10/2019 15:34
 */
@Data
public class ApplyNoAndTypeDto {
    /**
     * 申请编号
     */
    @JsonProperty(value = "_APPLY_NO")
    private String applyNo;

    /**
     * 业务类型
     */
    @JsonProperty(value = "_APPLY_SUB_TYPE")
    private String busiType;
}
