package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import java.time.Instant;

/**
 * date: 10/10/2019 20:51
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class UnposotiveStaffInfoDto {

    /**
     * 姓名
     */
    private String name;

    /**
     * 人员编号
     */
    private String staffNo;

    /**
     * 理由
     */
    private String reason;

    /**
     * 转正状态
     */
    private String statusName;

    /**
     * 单位
     */
    private String unit;

    /**
     * 发送邮件次数
     */
    private int sendMessageNum;

    /**
     * 入职时间
     */
    private Instant entryTime;


    /**
     * 合同转正剩余天数
     */
    private int remainingDays;


}
