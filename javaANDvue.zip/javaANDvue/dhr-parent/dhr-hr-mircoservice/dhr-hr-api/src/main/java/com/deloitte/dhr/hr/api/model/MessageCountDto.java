package com.deloitte.dhr.hr.api.model;

import lombok.Data;

/**
 * date: 11/10/2019 17:34
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class MessageCountDto {

    private int messageNum;

    private int noticNum;
}
