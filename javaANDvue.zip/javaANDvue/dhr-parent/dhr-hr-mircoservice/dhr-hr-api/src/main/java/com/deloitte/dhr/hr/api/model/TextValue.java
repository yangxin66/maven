package com.deloitte.dhr.hr.api.model;

import lombok.Data;

@Data
public class TextValue {


    private String value;
}
