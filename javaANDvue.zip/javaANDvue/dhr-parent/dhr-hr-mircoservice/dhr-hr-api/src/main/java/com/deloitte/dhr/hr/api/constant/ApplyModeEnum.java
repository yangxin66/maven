package com.deloitte.dhr.hr.api.constant;

/**
 * @author chunliucq
 * @since 14/10/2019 10:47
 */
public enum ApplyModeEnum {
    MULTIPLE("批量业务数据申请处理","批量业务数据，申请主请求中不带业务数据，业务数据在提交申请前已预保存"),
    SINGLE("单条业务数据申请处理","单条业务数据，申请主请求中必须带业务数据，且业务数据会被最新的数据数增覆盖"),
    MINGLE("多条业务数据申请处理","多条业务数据申请处理,申请主请求中必须带业务数据，且业务数据会带有_RID字段，此时需要更新对应业务数据"),
    SINGLE_MEANWHILE("单条业务数据申请处理,同时业务数据与申请信息一起，且数据结果与申请信息同级","单条业务数据申请处理,同时业务数据与申请信息一起，申请保存时，同时保存业务数据，且业务数据会带有_RID字段，此时需要更新对应业务数据"),
    ;


    /**
     * 业务申请处理模式
     */
    private String applyMode;
    /**
     * 业务申请处理模式 说明
     */
    private String applyModeDesc;

    public String getApplyMode() {
        return applyMode;
    }

    public String getApplyModeDesc() {
        return applyModeDesc;
    }

    ApplyModeEnum(String applyMode, String applyModeDesc) {
        this.applyMode = applyMode;
        this.applyModeDesc = applyModeDesc;
    }
}
