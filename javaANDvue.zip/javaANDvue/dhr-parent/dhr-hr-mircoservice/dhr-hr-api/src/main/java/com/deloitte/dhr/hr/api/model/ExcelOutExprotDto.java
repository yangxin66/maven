package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.common.export.model.ExportTitle;
import com.deloitte.dhr.hr.api.model.staff.StaffListDto;
import com.deloitte.infrastructure.communication.pagination.PaginationRequest;
import lombok.Data;

import java.util.List;

@Data
public class ExcelOutExprotDto {

    private List<ExportTitle> title;

    private StaffListDto staffListDto;

    private OutExportType OutType;

    private SearchDto searchDto;
}
