package com.deloitte.dhr.hr.api;

import com.deloitte.dhr.hr.api.model.EnumResult;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * @author chunliucq
 * @since 22/08/2019 11:18
 */
// todo
@FeignClient(value = "dhr-hr-microservice", path = "/api/v1/hr/enum")
public interface HrEnumInterface {
    /**
     * 查询下拉菜单枚举列表
     * @param keyList
     * @return
     */
    @GetMapping(value = "/query/enmuns")
    Response<EnumResult> queryEnumList(Request<List<String>> keyList);
}
