package com.deloitte.dhr.hr.api.model.staff;

import lombok.Data;

/**
 * 员工入职填写身份校验
 * @author chunliucq
 * @since 28/08/2019 14:34
 */
@Data
public class StaffPersonCheckDto {
    private String token;

    private String staffName;

    private String IdNumber;
}
