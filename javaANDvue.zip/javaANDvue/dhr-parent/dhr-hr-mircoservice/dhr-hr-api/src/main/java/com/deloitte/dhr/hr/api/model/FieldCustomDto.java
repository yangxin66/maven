package com.deloitte.dhr.hr.api.model;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * date: 22/08/2019 17:05
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class FieldCustomDto {

    /**
     * 字段名称
     */
    @NotNull(message = "字段名称不允许为空")
    @NotBlank(message = "字段名称不允许为空")
    private String key;

    /**
     * 字段值
     */
    private String value;

    /**
     * 条件
     */
    @NotNull(message = "字段条件不允许为空")
    private SearchConditionEnum condition;
}
