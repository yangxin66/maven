package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.common.export.model.ExportTitle;
import lombok.Data;

import java.util.List;

@Data
public class ExcelJobChangeExportDto {

    private List<ExportTitle> title;

    private List<String> changeNoList;

    private OutExportType OutType;

    private SearchDto searchDto;

    /**
     * 总共有多少条数据（全部导出时使用）
     */
    private  Integer  total;
}
