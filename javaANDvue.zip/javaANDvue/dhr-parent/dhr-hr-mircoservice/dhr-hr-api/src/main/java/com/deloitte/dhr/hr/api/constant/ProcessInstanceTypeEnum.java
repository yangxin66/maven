package com.deloitte.dhr.hr.api.constant;


/**
 * date: 08/10/2019 20:10
 *
 * @author wgong
 * @since 0.0.1
 */
public enum ProcessInstanceTypeEnum {

    /**
     * 新建入职
     */
    NEW_STAFF("staffinfo-modify-process"),
    /**
     * 员工信息修改
     */
    STAFF_INFO_MODIFY("staffinfo-modify-process"),

    /**
     * HR发起员工离职
     */
    STAFF_DIMISSION("staff-process"),

    /**
     * 领导岗位变动
     */
    LEADER_POSITION_CHANGE("leader-process"),

    /**
     * 员工岗位变动
     */
    STAFF_POSITION_CHANGE("staff-process"),

    /**
     * 转正
     */
    POSITIVE("staffinfo-modify-process"),
    /**
     * 开始兼岗
     */
    START_AND_POST("staff-process"),
    /**
     * 结束兼岗
     */
    END_AND_POST("staff-process"),

    /**
     * 员工自离
     */
    DIMISSION_FROM_EMPLOYEES("staff-process"),

    /**
     * 违纪解除合同
     */
    TERMINATE_THE_CONTRACT_FROM_DISCIPLINE("staff-process"),
    /**
     * 协议解除合同
     */
    TERMINATE_THE_CONTRACT_FROM_PROTOCOL("staff-process"),
    /**
     * 身故
     */
    STAFF_DECEASE("staff-process"),
    /**
     * 退休
     */
    RETIRE("staff-process"),
    /**
     * 发起合同
     */
    START_CONTRACT("staff-process"),
    /**
     * 续签合同
     */
    EXTEND_CONTRACT("staff-process"),
    /**
     * 终止合同
     */
    END_CONTRACT("staff-process"),

    ;


    private String key;


    ProcessInstanceTypeEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}

