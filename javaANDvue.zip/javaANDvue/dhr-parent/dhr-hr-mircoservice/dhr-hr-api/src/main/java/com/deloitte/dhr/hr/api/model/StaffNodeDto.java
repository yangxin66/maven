package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.extension.beans.mongo.PageDataRequest;
import lombok.Data;

import java.io.Serializable;

/**
 * date: 27/08/2019 21:26
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class StaffNodeDto implements Serializable {

    private static final long serialVersionUID = -7366027574678539555L;

    private String taskId;

    private Boolean sendFlag;

    private PageDataRequest data;
}
