package com.deloitte.dhr.hr.api.model;

import com.deloitte.dhr.common.export.model.ExportTitle;
import lombok.Data;

import java.util.List;

@Data
public class ExcelApplyDetailedDto {

    private List<ExportTitle> title;

    private String part;

    private OutExportType OutType;

    private List<ApplyList> applyList;

    private String StaffNo;

    private  List<String> ridList;
}
