package com.deloitte.dhr.extension.sap.utils;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {

	public static final ObjectMapper OM = new ObjectMapper();

	static {
		OM.setSerializationInclusion(Include.NON_NULL);
	}

	public static <T> T getEntity(String json, Class<T> clazz) {
		try {
			return OM.readValue(json, clazz);
		} catch (Exception e) {
			return null;
		}
	}

	public static String toJson(Object obj) {
		try {
			return OM.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			return null;
		}
	}
}
