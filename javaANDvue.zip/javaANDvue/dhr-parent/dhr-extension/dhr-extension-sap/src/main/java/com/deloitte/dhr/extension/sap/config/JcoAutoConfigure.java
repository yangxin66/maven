package com.deloitte.dhr.extension.sap.config;

import com.deloitte.dhr.extension.sap.config.properties.JcoProperties;
import com.deloitte.dhr.extension.sap.service.JCOService;
import com.deloitte.dhr.extension.sap.service.SapService;
import com.deloitte.dhr.extension.sap.service.impl.JCOServiceImpl;
import com.deloitte.dhr.extension.sap.service.impl.SapServiceImpl;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * <br/>21/08/2019 17:08
 *
 * @author lshao
 */
@Configuration
@EnableConfigurationProperties(JcoProperties.class)
@PropertySource(value = "classpath:jco-application.properties", encoding = "UTF-8")
public class JcoAutoConfigure {

    @Bean
    public JcoDestionProvider jcoDestionProvider(JcoProperties jcoProperties) {
        JcoDestionProvider jcoDestionProvider = new JcoDestionProvider();
        jcoDestionProvider.setProperties(jcoProperties);
        jcoDestionProvider.registerProvider();
        return jcoDestionProvider;
    }

    @Bean
    public JCOService getSapRfcServiceImpl(){
        return new JCOServiceImpl();
    }

    @Bean
    public SapService getSapSapServiceImpl(){
        return new SapServiceImpl();
    }
}
