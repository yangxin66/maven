package com.deloitte.dhr.extension.sap.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.sap.bean.RFC;
import com.deloitte.dhr.extension.sap.bean.parameter.ImportParameter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <br/>26/08/2019 13:35
 *
 * @author lshao
 */
public class ParameterConvert {
    /**
     *
     * @param jsonObject
     * @return
     */
    public static ImportParameter convert(JSONObject jsonObject, RFC rfc) {
        ImportParameter importParameter = new ImportParameter();
        importParameter.setRfc(rfc.getCode());
        for (String key : jsonObject.keySet()) {
            Object jsonObj = null;
            try {
                jsonObj = jsonObject.getJSONObject(key);
            } catch (ClassCastException e) {
                jsonObj = jsonObject.getJSONArray(key);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (jsonObj instanceof JSONArray) {
                List<Object> tables = ((JSONArray) jsonObj);
                importParameter.setTables(tables);
            } else {
                importParameter.setImporting(jsonObj);
            }
        }
        return importParameter;
    }
}
