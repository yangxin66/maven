package com.deloitte.dhr.extension.sap.service;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.sap.bean.parameter.ImportParameter;
import com.deloitte.dhr.extension.sap.bean.parameter.OutputParameter;

/**
 * <br/>22/08/2019 09:33
 *
 * @author lshao
 */
public interface SapService {

//    <K,V> OutputParameter<K,V> call(ImportParameter ip,Class<K> c,Class<V> v);

    JSONObject call(ImportParameter ip) throws RuntimeException;

    <T> T getExports(JSONObject jsonObject, Class<T> t);

    <T> T getTables(JSONObject jsonObject, Class<T> t);
}
