
package com.deloitte.dhr.extension.sap.service;

import com.alibaba.fastjson.JSONObject;

public interface JCOService {

    JSONObject metaData(String rfcName);

    JSONObject call(JSONObject queryCondition);

    JSONObject call2JSON(String rfc,JSONObject parameter);

}
