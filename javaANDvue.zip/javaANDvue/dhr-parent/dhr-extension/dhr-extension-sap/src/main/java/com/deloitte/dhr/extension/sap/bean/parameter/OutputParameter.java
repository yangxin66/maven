package com.deloitte.dhr.extension.sap.bean.parameter;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * <br/>22/08/2019 09:54
 *
 * @author lshao
 */
@Data
public class OutputParameter<K, V> {

    private boolean status;
    private String message;

    private Exports exports;
    private List<V> tables;

    public OutputParameter(boolean status, String message, Exports exports, List<V> tables) {
        this.status = status;
        this.message = message;
        this.exports = exports;
        this.tables = tables;
    }


}
