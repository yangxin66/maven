
package com.deloitte.dhr.extension.sap.service.impl;

import java.util.Iterator;
import java.util.Objects;

import com.deloitte.dhr.extension.sap.bean.Constants;
import com.deloitte.dhr.extension.sap.bean.ErrorCode;
import com.deloitte.dhr.extension.sap.config.JcoDestionProvider;
import com.deloitte.dhr.extension.sap.service.JCOService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoField;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRecordFieldIterator;
import com.sap.conn.jco.JCoStructure;
import com.sap.conn.jco.JCoTable;
/**
 * <p>Title: JCOServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2019</p>
 * <p>Company: </p>
 * @author Jiac Wei
 * @date 2019年5月21日 : 下午10:26:46
 * @version 1.0
 */
public class JCOServiceImpl implements JCOService {

	@Autowired
	JcoDestionProvider jcoDestionProvider;

	/* (non-Javadoc)
	 * @see com.dtt.hcm.allin.service.SapRfcService#metaData()
	 */
	@Override
	public JSONObject metaData(String rfcName) {
		JSONObject metaData = new JSONObject();

		JCoDestination jCoDestination = jcoDestionProvider.getDestination();
		JCoFunction function = null;
		try {
			function = jCoDestination.getRepository().getFunction(rfcName);
		} catch (JCoException e) {
			e.printStackTrace();
		}
		// 输入参数
		JCoParameterList jcoImportParameterList = function.getImportParameterList();
		// 表
		JCoParameterList jcoTableParameterList = function.getTableParameterList();
		// Changing
		JCoParameterList jcoChangingParameterList = function.getChangingParameterList();
		// Exceprion
		//AbapException[] abapException = function.getExceptionList();
		// Exporting
		JCoParameterList jcoExportParameterList = function.getExportParameterList();
		// 	
		JSONObject importParameter = processJcoParameterMetaData(jcoImportParameterList);
		JSONObject changingParameter = processJcoParameterMetaData(jcoChangingParameterList);
		JSONObject tableParameter = processJcoParameterMetaData(jcoTableParameterList);
		JSONObject exportParameter = processJcoParameterMetaData(jcoExportParameterList);

		metaData.put("IMPORT", importParameter);
		metaData.put("CHANGING", changingParameter);
		metaData.put("TABLES", tableParameter);
		metaData.put("EXPORT", exportParameter);
		return metaData;
	}
	/* (non-Javadoc)
	 * @see com.dtt.hcm.allin.service.SapRfcService#call(com.alibaba.fastjson.JSONObject)
	 */
	@Override
	public JSONObject call(JSONObject queryCondition) {
		JSONObject feedback = new JSONObject();
		if (queryCondition == null) {
			throw new RuntimeException(ErrorCode.RFC_ERROR_10001.getValue());
		}

		JCoDestination jCoDestination = jcoDestionProvider.getDestination();
		String rfcName = queryCondition.getString(Constants.PARAMETER_KEY_OF_RFC);
		JCoFunction function = null;

		if (StringUtils.isEmpty(rfcName)) {
			throw new RuntimeException(ErrorCode.RFC_ERROR_10002.getValue());
		}
		try {
			function = jCoDestination.getRepository().getFunction(rfcName);
		} catch (JCoException e) {
			e.printStackTrace();
		}
		// importing
		if (queryCondition.containsKey("importing")) {
			importParameters(function.getImportParameterList(), queryCondition.getJSONObject("importing"));
		}
		// importing table parameter
		if (queryCondition.containsKey("tables")) {
			importParameters(function.getTableParameterList(), queryCondition.getJSONObject("tables"));
		}
		// importing changing parameter
		if (queryCondition.containsKey("changing")) {
			importParameters(function.getChangingParameterList(), queryCondition.getJSONObject("changing"));
		}

		try {
			function.execute(jCoDestination);
		} catch (JCoException e) {
			throw new RuntimeException(ErrorCode.RFC_ERROR_10005.getValue());
		}

		JCoParameterList exportParameterList = function.getExportParameterList();
		JCoParameterList exportTableParameterList = function.getTableParameterList();
		feedback.put("exports", exportParameter(exportParameterList));
		feedback.put("tables", exportTable(exportTableParameterList));
		return feedback;
	}

	@Override
	public JSONObject call2JSON(String rfc, JSONObject parameter) {
		JSONObject feedback = new JSONObject();
		if (Objects.isNull(parameter)) {
			throw new RuntimeException(ErrorCode.RFC_ERROR_10001.getValue());
		}
		JCoDestination jCoDestination = jcoDestionProvider.getDestination();
		JCoFunction function = null;
		if (StringUtils.isEmpty(rfc)) {
			throw new RuntimeException(ErrorCode.RFC_ERROR_10002.getValue());
		}
		try {
			function = jCoDestination.getRepository().getFunction(rfc);
		} catch (JCoException e) {
			e.printStackTrace();
			throw new RuntimeException(ErrorCode.ERROR_STATUS.getValue(),e);
		}
		function.getImportParameterList().setValue("IMPORTS", parameter.toJSONString());
		try {
			function.execute(jCoDestination);
		} catch (JCoException e) {
			throw new RuntimeException(ErrorCode.RFC_ERROR_10005.getValue());
		}
		JCoParameterList exportParameterList = function.getExportParameterList();
		feedback.put("data",exportParameter(exportParameterList));
		return feedback;
	}

	public JSONObject processJcoParameterMetaData(JCoParameterList jcoParameterList) {
		if (jcoParameterList == null) {
			return null;
		}
		JSONObject metaData = new JSONObject();
		Iterator<JCoField> iterator = jcoParameterList.iterator();

		while (iterator.hasNext()) {
			JCoField field = (JCoField) iterator.next();
			JSONObject fieldInfo = new JSONObject();
			// 字段名称
			String name = field.getName();
			// ABAP数据类型
			String type = field.getTypeAsString();
			// 长度
			int length = field.getLength();
			// 描述
			String description = field.getDescription();
			// JAVA类型
			String javaType = field.getClassNameOfValue();
			// 小数位，对BCD类型，其它为0
			int decimals = field.getDecimals();
			fieldInfo.put("field", name);
			fieldInfo.put("abapType", type);
			fieldInfo.put("javaType", javaType);
			fieldInfo.put("length", length);
			fieldInfo.put("decimals", decimals);
			fieldInfo.put("description", description);

			if (field.isStructure()) {
				fieldInfo.put("metaData", processJCoStructureMetaData(field.getStructure()));
			} else if (field.isTable()) {
				fieldInfo.put("metaData", processJCoTableMetaData(field.getTable()));
			}
			metaData.put(name, fieldInfo);
		}
		return metaData;
	}

	public JSONObject processJCoStructureMetaData(JCoStructure jcoStructure) {
		JSONObject structureParameter = new JSONObject();
		JCoRecordFieldIterator i = jcoStructure.getRecordFieldIterator();
		while (i.hasNextField()) {
			JSONObject fieldInfo = new JSONObject();
			JCoField field = (JCoField) i.nextRecordField();
			// 字段名称
			String name = field.getName();
			// ABAP数据类型
			String type = field.getTypeAsString();
			// 长度
			int length = field.getLength();
			// 描述
			String description = field.getDescription();
			// JAVA类型
			String javaType = field.getClassNameOfValue();
			// 小数位，对BCD类型，其它为0
			int decimals = field.getDecimals();

			fieldInfo.put("field", name);
			fieldInfo.put("abapType", type);
			fieldInfo.put("javaType", javaType);
			fieldInfo.put("length", length);
			fieldInfo.put("decimals", decimals);
			fieldInfo.put("description", description);

			if (field.isStructure()) {
				fieldInfo.put("metaData", processJCoStructureMetaData(field.getStructure()));
			} else if (field.isTable()) {
				fieldInfo.put("metaData", processJCoTableMetaData(field.getTable()));
			}
			structureParameter.put(name, fieldInfo);
		}
		return structureParameter;
	}

	public JSONObject processJCoTableMetaData(JCoTable jcoTable) {
		JSONObject tableParameter = new JSONObject();
		JCoRecordFieldIterator i = jcoTable.getRecordFieldIterator();
		while (i.hasNextField()) {
			JSONObject fieldInfo = new JSONObject();
			JCoField field = (JCoField) i.nextRecordField();
			// 字段名称
			String name = field.getName();
			// ABAP数据类型
			String type = field.getTypeAsString();
			// 长度
			int length = field.getLength();
			// 描述
			String description = field.getDescription();
			// JAVA类型
			String javaType = field.getClassNameOfValue();
			// 小数位，对BCD类型，其它为0
			int decimals = field.getDecimals();

			fieldInfo.put("field", name);
			fieldInfo.put("abapType", type);
			fieldInfo.put("javaType", javaType);
			fieldInfo.put("length", length);
			fieldInfo.put("decimals", decimals);
			fieldInfo.put("description", description);

			if (field.isStructure()) {
				fieldInfo.put("metaData", processJCoStructureMetaData(field.getStructure()));
			} else if (field.isTable()) {
				fieldInfo.put("metaData", processJCoTableMetaData(field.getTable()));
			}
			tableParameter.put(name, fieldInfo);
		}
		return tableParameter;
	}

	
	/**
	 * @param parameterList
	 * @return
	 * return JSONObject
	 */
	public JSONObject exportParameter(JCoParameterList parameterList) {
		if (parameterList == null) {
			return null;
		}
		JSONObject result = new JSONObject();
		Iterator<JCoField> iterator = parameterList.iterator();
		while (iterator.hasNext()) {
			JCoField field = (JCoField) iterator.next();
			// 字段名称
			String name = field.getName();
			/*// ABAP数据类型
			String type = field.getTypeAsString();
			// 长度
			int length = field.getLength();
			// 描述
			String description = field.getDescription();
			// JAVA类型
			String javaType = field.getClassNameOfValue();
			// 小数位，对BCD类型，其它为0
			int decimals = field.getDecimals();*/
			if (field.isStructure()) {
				result.put(name, dealStructure(field.getStructure()));
			} else if (field.isTable()) {
				result.put(name, dealTable(field.getTable()));
			} else {
				result.put(name, field.getString());
			}
		}
		return result;
	}

	public JSONObject exportTable(JCoParameterList tableList) {
		if (tableList == null) {
			return null;
		}
		JSONObject result = new JSONObject();
		// loop table names
		Iterator<JCoField> iterator = tableList.iterator();
		while (iterator.hasNext()) {
			JCoField field = (JCoField) iterator.next();
			// 字段名称
			String name = field.getName();

			if (field.isStructure()) {
				result.put(name, dealStructure(field.getStructure()));
			} else if (field.isTable()) {
				result.put(name, dealTable(field.getTable()));
			} else {
				result.put(name, field.getString());
			}
		}
		return result;
	}

	/**
	 * @param structure
	 * @return
	 * return JSONObject
	 * Deal Structure
	 */
	public JSONObject dealStructure(JCoStructure structure) {
		JSONObject result = new JSONObject();
		JCoRecordFieldIterator iterator = structure.getRecordFieldIterator();
		while (iterator.hasNextField()) {
			JCoField field = (JCoField) iterator.nextRecordField();
			// 字段名称
			String name = field.getName();
			if (field.isStructure()) {
				result.put(name, dealStructure(field.getStructure()));
			} else if (field.isTable()) {
				result.put(name, dealTable(field.getTable()));
			} else {
				result.put(name, field.getString());
			}
		}
		return result;
	}

	/**
	 * @param table
	 * @return
	 * return JSONArray
	 * Deal Table
	 */
	public JSONArray dealTable(JCoTable table) {
		JSONArray result = new JSONArray();

		if (table.getNumRows() > 0) {
			for (int i = 0; i < table.getNumRows(); i++) {
				JSONObject jo = new JSONObject();
				table.setRow(i);
				JCoRecordFieldIterator iterator = table.getRecordFieldIterator();
				while (iterator.hasNextField()) {
					JCoField field = (JCoField) iterator.nextRecordField();
					// 字段名称
					String name = field.getName();
					if (field.isStructure()) {
						jo.put(name, dealStructure(field.getStructure()));
					} else if (field.isTable()) {
						jo.put(name, dealTable(field.getTable()));
					} else {
						jo.put(name, field.getString());
					}
				}
				result.add(jo);
			}
		}
		return result;
	}

	/**
	 * 写入参数 
	 */
	public void importParameters(JCoParameterList jcoParameterList, JSONObject postValues) {
		if (jcoParameterList == null || postValues == null || postValues.isEmpty()) {
			return;
		}
		Iterator<JCoField> iterator = jcoParameterList.iterator();
		while (iterator.hasNext()) {
			JCoField field = (JCoField) iterator.next();
			String fieldName = field.getName();
			if (field.isStructure()) {
				if (postValues.containsKey(fieldName)) {
					JSONObject postStructureValues = postValues.getJSONObject(fieldName);
					importStructure(jcoParameterList, postStructureValues, fieldName);
				}
			} else if (field.isTable()) {
				if (postValues.containsKey(fieldName)) {
					JSONArray postTableValues = postValues.getJSONArray(fieldName);
					importTable(jcoParameterList, postTableValues, fieldName);
				}
			} else {
				if (postValues.containsKey(fieldName)) {
					jcoParameterList.setValue(fieldName, postValues.getString(fieldName));
					//postValues.remove(fieldName);
				}

			}
		}
	}

	/**
	 * 写入结构参数 
	 */
	void importStructure(JCoParameterList jcoParameterList, JSONObject postValues, String structureName) {
		JCoStructure structure = jcoParameterList.getStructure(structureName);
		if (postValues == null || postValues.isEmpty()) {
			return;
		}
		JCoRecordFieldIterator i = structure.getRecordFieldIterator();

		while (i.hasNextField()) {
			JCoField field = (JCoField) i.nextRecordField();
			String fieldName = field.getName();

			if (field.isStructure()) {
				if (postValues.containsKey(fieldName)) {
					JSONObject postStructureValues = postValues.getJSONObject(fieldName);
					setStructureMetaDataValue(field.getStructure(), postStructureValues);
				}
			} else if (field.isTable()) {
				if (postValues.containsKey(fieldName)) {
					JSONArray postTableValues = postValues.getJSONArray(fieldName);
					setTableMetaDataValue(field.getTable(), postTableValues);
				}
			} else {
				if (postValues.containsKey(fieldName)) {
					structure.setValue(fieldName, postValues.getString(fieldName));
					//postValues.remove(fieldName);
				}
			}
		}
		jcoParameterList.setValue(structureName, structure);
	}

	/**
	 * 写入表参数 
	 */
	void importTable(JCoParameterList jcoParameterList, JSONArray postValues, String tableName) {
		JCoTable jcoTable = jcoParameterList.getTable(tableName);
		if (postValues == null || postValues.isEmpty()) {
			return;
		}
		for (int j = 0; j < postValues.size(); j++) {
			jcoTable.appendRow();
			jcoTable.setRow(j);
			JCoRecordFieldIterator i = jcoTable.getRecordFieldIterator();
			while (i.hasNextField()) {
				JCoField field = (JCoField) i.nextRecordField();
				String fieldName = field.getName();
				JSONObject row = postValues.getJSONObject(j);
				if (field.isStructure()) {
					if (row.containsKey(fieldName)) {
						JSONObject postStructureValues = row.getJSONObject(fieldName);
						setStructureMetaDataValue(field.getStructure(), postStructureValues);
					}
				} else if (field.isTable()) {
					if (row.containsKey(fieldName)) {
						JSONArray postTableValues = row.getJSONArray(fieldName);
						setTableMetaDataValue(field.getTable(), postTableValues);
					}
				} else {
					if (row.containsKey(fieldName)) {
						jcoTable.setValue(fieldName, row.getString(fieldName));
					}
				}
			}
		}
		jcoParameterList.setValue(tableName, jcoTable);
	}

	// 处理表类型嵌套
	void setTableMetaDataValue(JCoTable jcoTable, JSONArray postValues) {
		if (postValues == null || postValues.isEmpty()) {
			return;
		}
		for (int j = 0; j < postValues.size(); j++) {
			jcoTable.appendRow();
			jcoTable.setRow(j);
			JCoRecordFieldIterator i = jcoTable.getRecordFieldIterator();
			while (i.hasNextField()) {
				JCoField field = (JCoField) i.nextRecordField();
				String fieldName = field.getName();
				JSONObject row = postValues.getJSONObject(j);
				if (field.isStructure()) {
					if (row.containsKey(fieldName)) {
						JSONObject postStructureValues = row.getJSONObject(fieldName);
						setStructureMetaDataValue(field.getStructure(), postStructureValues);
					}
				} else if (field.isTable()) {
					if (row.containsKey(fieldName)) {
						JSONArray postTableValues = row.getJSONArray(fieldName);
						setTableMetaDataValue(field.getTable(), postTableValues);
					}
				} else {
					if (row.containsKey(fieldName)) {
						jcoTable.setValue(fieldName, row.getString(fieldName));
					}
				}
			}
		}
	}

	// 处理结构类型嵌套
	void setStructureMetaDataValue(JCoStructure structure, JSONObject postValues) {
		if (postValues == null || postValues.isEmpty()) {
			return;
		}
		JCoRecordFieldIterator i = structure.getRecordFieldIterator();

		while (i.hasNextField()) {
			JCoField field = (JCoField) i.nextRecordField();
			String fieldName = field.getName();

			if (field.isStructure()) {
				if (postValues.containsKey(fieldName)) {
					JSONObject postStructureValues = postValues.getJSONObject(fieldName);
					setStructureMetaDataValue(field.getStructure(), postStructureValues);
				}
			} else if (field.isTable()) {
				if (postValues.containsKey(fieldName)) {
					JSONArray postTableValues = postValues.getJSONArray(fieldName);
					setTableMetaDataValue(field.getTable(), postTableValues);
				}
			} else {
				if (postValues.containsKey(fieldName)) {
					structure.setValue(fieldName, postValues.getString(fieldName));
				}
			}
		}
	}
}