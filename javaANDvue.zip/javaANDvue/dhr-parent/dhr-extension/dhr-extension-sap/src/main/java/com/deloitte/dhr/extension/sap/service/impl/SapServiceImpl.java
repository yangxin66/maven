package com.deloitte.dhr.extension.sap.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.extension.sap.bean.parameter.Exports;
import com.deloitte.dhr.extension.sap.bean.parameter.ImportParameter;
import com.deloitte.dhr.extension.sap.service.JCOService;
import com.deloitte.dhr.extension.sap.service.SapService;
import com.deloitte.dhr.extension.sap.utils.JsonUtil;
import com.deloitte.infrastructure.serializer.utils.SerializerUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;


/**
 * <br/>22/08/2019 09:33
 *
 * @author lshao
 */
public class SapServiceImpl implements SapService {

    @Autowired
    private JCOService JCOService;


//    @Override
//    public <K, V> OutputParameter<K, V> call(ImportParameter ip, Class<K> structClazz, Class<V> tablesClazz) {
//        JSONObject jsonResult = JCOServiceImpl.call(JSONObject.parseObject(JsonUtil.toJson(ip)));
//        System.out.println(jsonResult.get("exports"));
//        System.out.println(jsonResult.get("exports").toString());
//        return new OutputParameter<>(true, "", null, null);
//    }

    @Override
    public JSONObject call(ImportParameter ip) throws RuntimeException{
        JSONObject jsonObject = JCOService.call(JSONObject.parseObject(JsonUtil.toJson(ip)));
        Exports exports = this.getExports(jsonObject,Exports.class);
        if(!StringUtils.equals(exports.getSubrc(),"S")){
           throw new RuntimeException(exports.getMessage());
        }
        return jsonObject;
    }

    @Override
    public <T> T getExports(JSONObject jsonObject, Class<T> t) {
        return SerializerUtils.deserialize(jsonObject.get("exports").toString(), t);
    }

    @Override
    public <T> T getTables(JSONObject jsonObject, Class<T> t) {
        return SerializerUtils.deserialize(jsonObject.get("tables").toString(), t);
    }
}
