package com.deloitte.dhr.extension.sap.bean.parameter;

import lombok.Data;

/**
 * <br/>22/08/2019 15:47
 *
 * @author lshao
 */
@Data
public class SAPResult {
    boolean Status;

    String message;

    Object data;
}
