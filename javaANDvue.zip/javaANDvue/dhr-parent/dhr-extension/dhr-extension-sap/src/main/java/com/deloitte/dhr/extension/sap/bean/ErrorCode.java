package com.deloitte.dhr.extension.sap.bean;


/**
 * 错误返回码
 *
 */
public enum ErrorCode{

	SUCCESS_STATUS(Constants.SUCCESS, "成功 "),
	
	ERROR_STATUS(Constants.ERROR , "发生错误"),

	SYS_ERROR_00000("SYS_ERROR_00000" , "系统繁忙，请稍后再试"),
	SYS_ERROR_00001("SYS_ERROR_00001" , "缺少必须的参数"),
	SYS_ERROR_00002("SYS_ERROR_00002" , "用户不存在"),	
	SYS_ERROR_00003("SYS_ERROR_00003" , "账号或密码无效或已过期"),
	SYS_ERROR_00004("SYS_ERROR_00004" , "非法的请求参数"),
	SYS_ERROR_00005("SYS_ERROR_00005" , "不支持的请求方法：%s"),
	SYS_ERROR_00006("SYS_ERROR_00006" , "无法保存文件"),

	SYS_ERROR_00007("SYS_ERROR_00007" , "您无权访问该资源"),
	SYS_ERROR_00008("SYS_ERROR_00008" , "您正访问该受保护的资源"),
	SYS_ERROR_00009("SYS_ERROR_00009" , "正在使用已过期的Token"),
	SYS_ERROR_00010("SYS_ERROR_00010" , "登入失败"),
	SYS_ERROR_00011("SYS_ERROR_00011" , "Session已失效，请重新登录"),
	SYS_ERROR_00012("SYS_ERROR_00012" , "链接已失效！"),
	
	RFC_ERROR_10001("RFC_ERROR_10001" , "RFC传入参数为空"),
	RFC_ERROR_10002("RFC_ERROR_10002" , "RFC名称为空"),	
	RFC_ERROR_10003("RFC_ERROR_10003" , "RFC接口调用错误"),	
	RFC_ERROR_10004("RFC_ERROR_10004" , "RFC接口配置文件读取失败"),	
	RFC_ERROR_10005("RFC_ERROR_10005" , "RFC执行失败"),	
	RFC_ERROR_10006("RFC_ERROR_10006" , "RFC执行完毕，但是没有任何数据返回。"),	
	RFC_ERROR_10007("RFC_ERROR_10007" , "照片文件为空"),	
	RFC_ERROR_10008("RFC_ERROR_10008" , "无用户数据"),	

	READ_ERROR_001("READ_ERROR_001", "设备未连接！"),
	READ_ERROR_002("READ_ERROR_002", "读取身份证信息失败！"),
	READ_ERROR_003("READ_ERROR_003", "未读取到身份证信息！"),
	READ_ERROR_004("READ_ERROR_004", "未找到图片信息！"),

	SEND_MSG_ERROR_001("SEND_MSG_ERROR_001", "未找到消息服务器"),
	SEND_MSG_ERROR_002("SEND_MSG_ERROR_002", "消息为空"),
	SEND_MSG_ERROR_003("SEND_MSG_ERROR_003", "消息接收人为空"),
	

	;

	private String code;

	private String value;

	private ErrorCode(final String code, final String value){
		this.code = code;
		this.value = value;

	}

	/**
	 * @param code
	 * @return value
	 */
	public static String getExtValueByCode(final String code){
		for (final ErrorCode e : ErrorCode.values()){
			if (e.getCode().equals(code)){
				return e.value;
			}
		}
		return null;
	}

	/**
	 * @return code
	 */
	public String getCode(){
		return code;
	}

	/**
	 * @return the value
	 */
	public String getValue(){
		return value;
	}
}
