package com.deloitte.dhr.extension.sap.bean.parameter;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * <br/>22/08/2019 14:28
 *
 * @author lshao
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Exports {
    @JsonProperty("E_SUBRC")
    private String subrc;
    @JsonProperty("E_MESSAGE")
    private String message;

}