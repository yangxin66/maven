package com.deloitte.dhr.extension.sap.bean;

public class Constants {

	private Constants() {
	}

	public static final String SUCCESS = "success";

	public static final String ERROR = "error";

	public static final String DEFAULT_ERROR_PAGE = "error";
	public static final String DEFAULT_ERROR_PAGE_FOR_NOLOGIN = "error2";

	public static final String SESSION_KEY = "user";
	public static final String SESSION_KEY_INFOTYPE = "infoType";
	
	public static final String FILE_DIR = "/ics";

	public static final String PARAMETER_KEY_OF_RFC = "rfc";
	public static final String PREFIX_RFC_STRUCTURE = "sobj_";
	public static final String PREFIX_RFC_TABLE = "tobj_";

	public static final String WORKBENCH_INFO_COLLECT = "WORKBENCH_INFO_COLLECT";
	public static final String STAFF_INFO_UPDATE = "STAFF_INFO_UPDATE";
	
	public static final String HR_DUMMY_ACCOUNT = "yx.hrly";

	/**
	 * RFC返回的成功标识
	 */
	public static final String E_SUBRC_S = "S";

}
