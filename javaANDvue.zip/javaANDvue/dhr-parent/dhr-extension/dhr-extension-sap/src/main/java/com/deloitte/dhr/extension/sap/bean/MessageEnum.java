package com.deloitte.dhr.extension.sap.bean;

public enum MessageEnum {
	LOG_INFO_MSG("用户{0}调用了接口{1},时间{2},结果{3}"),
	LOG_ERR_MSG("调用接口{0}失败，错误原因{1},时间{2}"),
	
	;
	
	private String content;
	
	MessageEnum(String content){
		this.content = content;
	}

	public String getContent() {
		return content;
	}
}
