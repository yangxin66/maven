package com.deloitte.dhr.extension.sap.bean.parameter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * java与sap接口对接入参对象
 * <br/>22/08/2019 09:46
 *
 * @author lshao
 */
@Data
@AllArgsConstructor
public class ImportParameter {
    String rfc;
    Object importing;
    List<Object> tables;
    Object changing;
    public ImportParameter() {
    }
    public ImportParameter(String rfc, Object importing) {
        this.rfc = rfc;
        this.importing = importing;
    }

    public ImportParameter(String rfc, List<Object> tables) {
        this.rfc = rfc;
        this.tables = tables;
    }

    public ImportParameter(String rfc, Object importing, List<Object> tables) {
        this.rfc = rfc;
        this.importing = importing;
        this.tables = tables;
    }
}
