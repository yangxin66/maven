package com.deloitte.dhr.extension.sap.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author JIACWEI
 * @date Jun 4, 2018
 * @version 1.0
 * RFC.java
 * SAP Remote Function Call Details ENUM
 * 
 */
public enum RFC {

	STFC_CONNECTION("STFC_CONNECTION" , "SAP测试接口"),
	ZFM_PA_CHECKLIST("ZFM_PA_CHECKLIST" , "下拉列表数据同步接口"),
	ZFM_PA_HIRE_BASIC("ZFM_PA_HIRE_BASIC" , "新建员工接口"),
	ZFM_PA_HIRE_PLANS("ZFM_PA_HIRE_PLANS" , "读取岗位层级接口"),
	ZFM_PA_READPHOTO("ZFM_PA_READPHOTO" , "照片读取接口"),
	ZFM_PA_SAVEPHOTO("ZFM_PA_SAVEPHOTO" , "照片更新接口"),
	ZFM_OM_PLANS_NAMESEARCH("ZFM_OM_PLANS_NAMESEARCH" , "职位搜索帮助"),
	ZFM_PA_EMP_SEARCH("ZFM_PA_EMP_SEARCH" , "员工搜索"),
	ZFM_PA_HIRE_OTHERS("ZFM_PA_HIRE_OTHERS" , "员工入职报道信息采集-其他信息"),
	ZFM_PA_HIRE_0006("ZFM_PA_HIRE_0006" , "员工入职报道信息采集/显示-地址信息 "),
	ZFM_PA_HIRE_0021("ZFM_PA_HIRE_0021" , "员工入职报道信息采集/显示-家庭成员信息"),
	ZFM_PA_HIRE_0022("ZFM_PA_HIRE_0022" , "员工入职报道信息采集/显示-学历信息"),
	ZFM_PA_HIRE_0023("ZFM_PA_HIRE_0023" , "员工入职报道信息采集/显示-工作经历信息"),
	ZFM_PA_HIRE_0534("ZFM_PA_HIRE_0534" , "员工入职报道信息采集/显示-党政信息"),
	ZFM_PA_HIRE_9011("ZFM_PA_HIRE_9011" , "员工入职报道信息采集/显示-职业资格信息"),
	ZFM_PA_HIRE_9019("ZFM_PA_HIRE_9019" , "员工入职报道信息采集/显示-语言能力信息"),
	ZFM_PA_HIRE_9021("ZFM_PA_HIRE_9021" , "员工入职报道信息采集/显示-职称管理信息"),
	ZFM_PA_HIRE_9022("ZFM_PA_HIRE_9022" , "员工入职报道信息采集/显示-培训信息"),
	ZFM_PA_BASICINFO("ZFM_PA_BASICINFO" , "人员基本信息读取"),
	ZFM_SS_GET_AUTHORIZATION("ZFM_SS_GET_AUTHORIZATION" , "自助权限读取接口"),
	ZFM_PA_BANKCODE("ZFM_PA_BANKCODE" , "银行代码读取/搜索接口"),
	ZFM_SS_PA009("ZFM_SS_PA009" , "根据AD帐号读取员工编号"),
	ZFM_PA_HIRE_9001("ZFM_PA_HIRE_9001" , "员工入职报道信息采集/显示-奖励情况"),
	ZFM_PA_HIRE_9506("ZFM_PA_HIRE_9506" , "员工入职报道信息采集/显示-外部兼职"),
	
	;
	
	
	private RFC(String code, String description) {
		this.code = code;
		this.description = description;
	}
	private String code;
	private String description;
	
	public String getCode() {
		return code;
	}
	
	public String getDescription() {
		return description;
	}
	
	public static List<Map<String, String>> getList(){
		List<Map<String, String>> list = new ArrayList<>();
		for(RFC rfc : RFC.values()){
			String code = rfc.getCode();
			String description = rfc.getDescription();
			String name = rfc.name();
			Map<String, String> map = new HashMap<>();
			map.put(name, code + "=>" + description);
			list.add(map);
		}
		return list;
	}
}
