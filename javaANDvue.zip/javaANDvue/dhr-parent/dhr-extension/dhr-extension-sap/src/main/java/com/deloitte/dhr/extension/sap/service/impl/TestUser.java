package com.deloitte.dhr.extension.sap.service.impl;

import lombok.Data;

import java.util.Date;

/**
 * <br/>22/08/2019 14:00
 *
 * @author lshao
 */
@Data
public class TestUser {
    private Integer id;
    private String name;
    private Integer age;
    private Date birthday;
    private String email;
}
