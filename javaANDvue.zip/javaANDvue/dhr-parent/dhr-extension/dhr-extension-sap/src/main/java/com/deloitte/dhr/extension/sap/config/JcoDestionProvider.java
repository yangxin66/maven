package com.deloitte.dhr.extension.sap.config;

import java.util.Properties;

import com.deloitte.dhr.extension.sap.config.properties.JcoProperties;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.ext.DestinationDataProvider;
import com.sap.conn.jco.ext.Environment;

public class JcoDestionProvider {
	
	private String  destionName = "ECC_POOL";
	
	private Properties properties = new Properties();
	
	public Properties setProperties(JcoProperties jcoProperties) {
		properties.setProperty(DestinationDataProvider.JCO_ASHOST, jcoProperties.getAshost());
		properties.setProperty(DestinationDataProvider.JCO_SYSNR, jcoProperties.getSysnr());
		properties.setProperty(DestinationDataProvider.JCO_CLIENT, jcoProperties.getClient());
		properties.setProperty(DestinationDataProvider.JCO_USER, jcoProperties.getUser());
		properties.setProperty(DestinationDataProvider.JCO_PASSWD, jcoProperties.getPasswd());
		properties.setProperty(DestinationDataProvider.JCO_LANG, jcoProperties.getLang());
		properties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, jcoProperties.getPool_capacity());
		properties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, jcoProperties.getPeak_limit());
		properties.setProperty(DestinationDataProvider.JCO_EXPIRATION_TIME, jcoProperties.getExpiration_time());
		properties.setProperty(DestinationDataProvider.JCO_MAX_GET_TIME, jcoProperties.getMax_get_client_time());
		properties.setProperty(DestinationDataProvider.JCO_EXPIRATION_PERIOD,jcoProperties.getExpiration_check_period());
		return properties;
	}
	public JCoDestination getDestination() {
		JCoDestination jCoDestination = null;
		try {
			jCoDestination = JCoDestinationManager.getDestination(destionName);
		} catch (JCoException e) {
			e.printStackTrace();
		}
		return jCoDestination;
	}
	
	public void registerProvider() {
		if (!Environment.isDestinationDataProviderRegistered()) {
			DestinationDataProviderImp destDataProvider = new DestinationDataProviderImp();
			destDataProvider.addDestinationProperties(destionName, properties);
			Environment.registerDestinationDataProvider(destDataProvider);
		}
	}
}
