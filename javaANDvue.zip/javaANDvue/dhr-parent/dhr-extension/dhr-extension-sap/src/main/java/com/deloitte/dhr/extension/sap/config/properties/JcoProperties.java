package com.deloitte.dhr.extension.sap.config.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "jco")
public class JcoProperties {

	@Value("${jco.client.ashost}")
	private String ashost;

	@Value("${jco.client.sysnr}")
	private String sysnr;

	@Value("${jco.client.client}")
	private String client;

	@Value("${jco.client.user}")
	private String user;

	@Value("${jco.client.passwd}")
	private String passwd;

	@Value("${jco.client.lang}")
	private String lang;

	@Value("${jco.destination.pool_capacity}")
	private String pool_capacity;

	@Value("${jco.destination.peak_limit}")
	private String peak_limit;

	@Value("${jco.destination.expiration_time}")
	private String expiration_time;

	@Value("${jco.destination.max_get_client_time}")
	private String max_get_client_time;

	@Value("${jco.destination.expiration_check_period}")
	private String expiration_check_period;

}
