package com.deloitte.dhr.extension.mongodb.schema;

/**
 * HR服务使用到的mongodb的collection
 * <br/>27/08/2019 15:11
 *
 * @author lshao
 */
public class HRCollection {

    public static final String HR_STAFF_INFO = "staff_info";
    public static final String HR_STAFF_EMAIL_STATUS = "staff_email_status";
    /**
     * 上传文件表
     */
    public static final String STAFF_BATCH_UPLOAD = "staff_batch_upload";
    /**
     * 员工信息填写校验结果表
     */
    public static final String HR_STAFF_INFO_CHECK = "staff_info_check";
    /**
     * 业务编号生成器表
     */
    public static final String HR_BUSNISS_NO = "busi_no_gengerator";
    /**
     * 员工信息修改变更申请
     */
    public static final String HR_STAFF_UPDATE_APPLY = "staff_info_apply";
    /**
     * 员工信息修改变更申请变化记录
     */
    public static final String HR_STAFF_UPDATE_APPLY_CHANGERD = "staff_info_update_apply_detail";

    /**
     * 审核节点信息表
     */
    public static final String HR_TASK_AUDIT_NODE = "task_audit_node";

    /**
     * 用户角色关联表
     */
    public static final String DHR_SYS_USER_ROLE_REL = "dhr_sys_user_role_rel";

    /**
     * 资源表
     */
    public static final String DHR_SYS_RESOURCE = "dhr_sys_resource";

    /**
     * 角色资源关联表
     */
    public static final String DHR_SYS_ROLE_RESOURCE_REL = "dhr_sys_role_resource_rel";

    /**
     * 角色表
     */
    public static final String DHR_SYS_ROLE = "dhr_sys_role";

    /**
     * 消息表
     */
    public static final String HR_MESSAGE = "message";

    /**
     * 离职详细表
     */
    public static final String HR_DISMISSION_DETAIL = "staff_resign_apply_detail";

    /**
     * 结束兼岗详细表
     */
    public static final String HR_END_AND_POST_DETAIL = "staff_part_time_job_end_detail";

    /**
     * 开始兼岗详细表
     */
    public static final String HR_START_AND_POST_DETAIL = "staff_part_time_job_start_detail";

    /**
     * 合同管理发起合同详细表
     */
    public static final String HR_START_CONTRACT_DETAIL = "staff_part_time_job_start_detail";

    /**
     * 合同管理续签合同详细表
     */
    public static final String HR_EXTEND_CONTRACT_DETAIL = "staff_part_time_job_start_detail";

    /**
     * 合同管理终结合同详细表
     */
    public static final String HR_END_CONTRACT_DETAIL = "staff_part_time_job_start_detail";

    /**
     * 岗位变动详细表
     */
    public static final String HR_POSITION_CHANGE_DETAIL = "staff_position_change_detail";
}
