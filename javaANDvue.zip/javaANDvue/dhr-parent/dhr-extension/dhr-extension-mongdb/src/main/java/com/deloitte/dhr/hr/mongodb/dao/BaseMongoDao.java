package com.deloitte.dhr.hr.mongodb.dao;

import com.deloitte.dhr.hr.mongodb.bean.BaseMongoPo;
import org.springframework.data.mongodb.repository.MongoRepository;


/**
 * @author chunliucq
 * @since 26/08/2019 11:28
 */
public interface BaseMongoDao<T extends BaseMongoPo>
        extends MongoRepository<T, Long> {
//    void saveData(T entity, String collectionName);
}
