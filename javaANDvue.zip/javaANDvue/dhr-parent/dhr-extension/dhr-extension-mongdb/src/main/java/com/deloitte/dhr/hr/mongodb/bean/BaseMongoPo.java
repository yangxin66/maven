package com.deloitte.dhr.hr.mongodb.bean;

import java.io.Serializable;

/**
 * @author chunliucq
 * @since 26/08/2019 11:31
 */
public class BaseMongoPo implements Serializable {
}
