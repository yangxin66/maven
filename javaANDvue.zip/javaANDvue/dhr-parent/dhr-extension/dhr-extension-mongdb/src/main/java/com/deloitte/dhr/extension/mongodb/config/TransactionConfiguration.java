package com.deloitte.dhr.extension.mongodb.config;

import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.MongoTransactionManager;

/**
 * date: 10/09/2019 15:16
 *
 * @author wgong
 * @since 0.0.1
 */
public class TransactionConfiguration {

    @Bean
    MongoTransactionManager transactionManager(MongoDbFactory dbFactory) {
        return new MongoTransactionManager(dbFactory);
    }
}
