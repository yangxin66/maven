package com.deloitte.dhr.extension.beans.sap;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

/**
 * 用于sap数据存在分页的时候的返回到前端base实体
 * <br/>23/09/2019 18:14
 *
 * @author lshao
 */
@Data
@AllArgsConstructor
public class SapDataPaginationResponse {
    /**
     * 当前页数
     */
    private int page;
    /**
     * 每页显示条数
     */
    private int size;
    /**
     * 总页数
     */
    private int total;
    /**
     * 由于查询出来的分类信息有可能是list也有可能是单个对象
     */
    private Object data;
}
