package com.deloitte.dhr.extension.beans.sap;

import lombok.Data;

/**
 * 用于sap数据存在分页的时候的base实体
 * <br/>23/09/2019 18:14
 *
 * @author lshao
 */
@Data
public class SapDataPaginationRequest {
    /**
     * 当前页数
     */
    private int page;
    /**
     * 每页显示条数
     */
    private int size;
}
