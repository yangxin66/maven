package com.deloitte.dhr.extension.beans.mongo;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;

 /**
  * 配置页面数据提交的数据结构
 * <br/>27/08/2019 10:53
 *
 * @author lshao
 */
@Data
public class PageDataRequest {
    @JsonProperty("_PAGEID")
    @JSONField(name = "_PAGEID")
    private String pageId;

    @JsonProperty("_BUSINESSID")
    @JSONField(name = "_BUSINESSID")
    private String businessId;

    @JsonProperty("_ORGID")
    @JSONField(name = "_ORGID")
    private String orgId;

    @JsonProperty("_DATATYPE")
    @JSONField(name = "_PAGEID")
    private String dataType;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonProperty("_OPTIONTIME")
    @JSONField(name = "_OPTIONTIME")
    private LocalDateTime optionTime;

    @JsonProperty("_DATA")
    @JSONField(name = "_DATA")
    private JSONObject data;
}
