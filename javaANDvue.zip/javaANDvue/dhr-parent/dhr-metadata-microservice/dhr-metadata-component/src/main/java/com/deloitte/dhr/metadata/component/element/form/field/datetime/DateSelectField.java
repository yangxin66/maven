package com.deloitte.dhr.metadata.component.element.form.field.datetime;

import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 日期选择表单字段抽象
 *
 * @author xideng
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DateSelectField extends FormField {

    public static final String TYPE_CODE = "DATE_SELECT_FIELD";

    private DateSelectValue modelValue = new DateSelectValue();

    public static DateSelectField of(String label, Model model) {
        return of(label, model, false);
    }

    public static DateSelectField of(String label, Model model, boolean required) {
        DateSelectField field = new DateSelectField();
        field.setLabel(label);
        field.setModel(model);
        field.setRequired(required);
        return field;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
