package com.deloitte.dhr.metadata.component.element.box;

import com.deloitte.dhr.metadata.component.element.button.Button;
import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.event.AjaxEvent;
import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;

/**
 * 带分页的表格盒子抽象
 *
 * @author lshao
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class PaginationTableBox extends Box {

    public static final String TYPE_CODE = "PAGINATION_TABLE_BOX";

    /**
     * 前端用于存储当前的tablebox的数据总条数
     */
    private Integer total;

    private String name;
    /**
     * 用于描述异步加载数据的事件
     */
    private AjaxEvent ajaxEvent;

    private List<FormField> fields = new ArrayList<>();
    /**
     * 右上方的按钮
     */
    private List<Button> topButtons = new ArrayList<>();

    public PaginationTableBox(String name) {
        this.name = name;
    }

    public PaginationTableBox() {
    }


    public PaginationTableBox addFields(FormField... fields) {
        this.fields.addAll(Arrays.asList(fields));
        return this;
    }

    public PaginationTableBox addTopButtons(Button... buttons) {
        this.topButtons.addAll(Arrays.asList(buttons));
        return this;
    }

    public PaginationTableBox addAjaxEvent(AjaxEvent event) {
        this.ajaxEvent = event;
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @SuppressWarnings("Duplicates")
    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        Map<String, Object> result = new HashMap<>();
        this.fields.forEach(it -> {
            Model model = it.getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), it.getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        });
        //table的model返回的是一个数组的嵌套对象
        data.forEach((k, v) -> {
            List<Object> list = new ArrayList<>();
            list.add(v);
            result.put(k, list);
        });
        return result;
    }
}
