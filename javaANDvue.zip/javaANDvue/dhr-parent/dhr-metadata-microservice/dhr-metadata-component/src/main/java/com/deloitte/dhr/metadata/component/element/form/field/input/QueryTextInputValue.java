package com.deloitte.dhr.metadata.component.element.form.field.input;

import com.deloitte.dhr.metadata.component.element.form.field.QueryOperationEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 用于查询的文本输入框值抽象
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class QueryTextInputValue extends TextInputValue {

    private QueryOperationEnum operation = QueryOperationEnum.eq;
    public static QueryTextInputValue of(QueryOperationEnum operation) {
        QueryTextInputValue value = new QueryTextInputValue();
        value.setOperation(operation);
        return value;
    }
    public static QueryTextInputValue of(QueryOperationEnum operation,Object val) {
        QueryTextInputValue value = new QueryTextInputValue();
        value.setOperation(operation);
        value.setValue(val);
        return value;
    }
}
