package com.deloitte.dhr.metadata.component.element.box.audit;

import com.deloitte.dhr.metadata.component.element.form.field.upload.PictureUploadField;
import lombok.Data;

/**
 * 用于描述在box中的图片控件布局
 * <br/>14/10/2019 13:47
 *
 * @author lshao
 */
@Data
public class PictureLayout {
    public static final String LEFT = "LEFT";
    public static final String RIGHT = "RIGHT";
    private String location = LEFT;

    private PictureUploadField pictureUploadField;

    public PictureLayout(String location, PictureUploadField pictureUploadField) {
        this.location = location;
        this.pictureUploadField = pictureUploadField;
    }
}
