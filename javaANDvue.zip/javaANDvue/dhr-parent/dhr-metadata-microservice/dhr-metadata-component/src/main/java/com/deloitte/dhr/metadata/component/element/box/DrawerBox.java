package com.deloitte.dhr.metadata.component.element.box;

import com.deloitte.dhr.metadata.component.element.button.Button;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;

/**
 * 带有页签的盒子组件
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DrawerBox extends Box {

    public static final String TYPE_CODE = "DRAWER_BOX";

    /**
     * tab的label
     */
    private String name;
    /**
     * 用于前端方便提取字段，跟字段的前缀一致（prefix属性）
     */
    private String prefix;


    /**
     * 是否已经展开
     */
    private Boolean hasOpen = false;
    /**
     * 是否是编辑状态
     */
    private Boolean hasEdit = false;


    private List<Box> children = new ArrayList<>();
    /**
     * 只能配置一个按钮，因为drawerbox在页面上的按钮逻辑时写死的，先点击修改，弹出取消和该按钮
     */
    private Button button;


    public DrawerBox setPrefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public DrawerBox(String name) {
        this.name = name;
    }

    public DrawerBox() {
    }

    public DrawerBox hasOpen(boolean hasOpen) {
        this.hasOpen = hasOpen;
        return this;
    }

    public DrawerBox hasEdit(boolean hasEdit) {
        this.hasEdit = hasEdit;
        return this;
    }

    public DrawerBox addButton(Button button) {
        this.button = button;
        return this;
    }

    public DrawerBox addBoxes(Box... boxes) {
        this.children.addAll(Arrays.asList(boxes));
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @SuppressWarnings("Duplicates")
    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        this.getChildren().forEach(it -> {
            Map<String, Object> subData = it.buildModelStruct();
            subData.forEach((k, v) -> {

                if (null == v) {
                    data.put(k, null);
                } else {
                    Map<String, Object> subMap = (Map<String, Object>) data.getOrDefault(k, new HashMap<>());
                    //在构建models的过程中，tablebox的是一个list，其他的box是map
                    if (v instanceof Map) {
                        subMap.putAll((Map<String, Object>) v);
                        data.put(k, subMap);
                    } else if (v instanceof List) {
                        if (subMap.get(k) != null) {
                            List dataList = (List) subMap.get(k);
                            dataList.addAll((List) v);
                        } else {
                            data.put(k, v);
                        }
                    }

                }
            });
        });
        return data;
    }
}
