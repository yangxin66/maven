package com.deloitte.dhr.metadata.component.element.form.field.customized;

import com.deloitte.dhr.metadata.component.context.OptionContext;
import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.element.form.field.MultiOptionFormField;
import com.deloitte.dhr.metadata.component.element.form.field.Option;
import com.deloitte.dhr.metadata.component.element.form.field.select.SelectValue;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 所属单位选择框组件
 *
 * @author lshao
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DepartmentSelectField extends FormField {

    public static final String TYPE_CODE = "DEPARTMENT_SELECT_FIELD";

    private SelectValue modelValue = new SelectValue();

    public static DepartmentSelectField of(String label, Model model, boolean required) {
        DepartmentSelectField field = new DepartmentSelectField();
        field.setLabel(label);
        field.setModel(model);
        field.setRequired(required);
        return field;
    }

    public static DepartmentSelectField of(String label, Model model) {
        return of(label, model, false);
    }


    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
