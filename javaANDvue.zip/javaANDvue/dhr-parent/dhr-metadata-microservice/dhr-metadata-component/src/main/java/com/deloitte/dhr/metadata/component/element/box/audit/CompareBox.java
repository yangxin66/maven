package com.deloitte.dhr.metadata.component.element.box.audit;

import com.deloitte.dhr.metadata.component.element.box.Box;
import com.deloitte.dhr.metadata.component.element.button.Button;
import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;

/**
 * 该box具备进行对比的功能
 * <br/>10/10/2019 10:17
 *
 * @author lshao
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class CompareBox extends Box {

    public static final String TYPE_CODE = "COMPARE_BOX";
    private String name;
    private List<FormField> fields = new ArrayList<>();
    private List<FormField> afterFields = new ArrayList<>();
    private List<FormField> beforeFields = new ArrayList<>();

    /**
     * 如果不填写formbox的name属性，则在页面上不展示form的title
     */
    public CompareBox(String name) {
        this.name = name;
    }

    public CompareBox addBeforeFields(FormField... fields) {
        this.fields.addAll(Arrays.asList(fields));
        this.beforeFields.addAll(Arrays.asList(fields));
        return this;
    }

    public CompareBox addAfterFields(FormField... fields) {
        this.fields.addAll(Arrays.asList(fields));
        this.afterFields.addAll(Arrays.asList(fields));
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @SuppressWarnings("Duplicates")
    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        this.fields.forEach(it -> {
            Model model = it.getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), it.getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        });
        return data;
    }

}
