package com.deloitte.dhr.metadata.component.element.box;

import com.deloitte.dhr.metadata.component.element.Element;
import com.deloitte.dhr.metadata.component.model.ModelContainer;
import com.deloitte.dhr.metadata.component.security.SecurityAccess;
import lombok.Data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 盒子组件抽象
 *
 * @author xideng
 */
@Data
public abstract class Box implements Element, SecurityAccess, ModelContainer {
    /**
     * tip提醒文本
     */
    private String tip;

    private List<String> permissions = new ArrayList<>();

    public Box addTip(String tip) {
        this.tip = tip;
        return this;
    }
    @Override
    public Box requirePermissions(String... permissions) {
        this.permissions.addAll(Arrays.asList(permissions));
        return this;
    }
}
