package com.deloitte.dhr.metadata.component.element.form.field;

/**
 * 查询操作枚举
 *
 * @author xideng
 */
public enum QueryOperationEnum {

    /**
     * 相等
     */
    eq,

    /**
     * 模糊查询
     */
    like,

    /**
     * 大于
     */
    gt,

    /**
     * 小于
     */
    lt,

    /**
     * 大于等于
     */
    gte,

    /**
     * 小于等于
     */
    lte
}
