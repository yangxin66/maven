package com.deloitte.dhr.metadata.component.element.form.field;

import com.deloitte.dhr.metadata.component.context.OptionContext;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * 带有多个选项的表单字段抽象
 *
 * @author xideng
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public abstract class MultiOptionFormField extends FormField {

    private String optionKey;
}
