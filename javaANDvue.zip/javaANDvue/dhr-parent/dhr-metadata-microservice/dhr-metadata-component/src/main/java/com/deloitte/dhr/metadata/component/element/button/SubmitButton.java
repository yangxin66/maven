package com.deloitte.dhr.metadata.component.element.button;

/**
 * 异步请求Button
 *
 * @author xideng
 */
public class SubmitButton extends Button {

    @Override
    public String getTypeCode() {
        return null;
    }
}
