package com.deloitte.dhr.metadata.component.element.form.field.datetime;

import com.deloitte.dhr.metadata.component.element.form.field.FormValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 日期选择值抽象
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DateSelectValue extends FormValue {

    public static final String DEFAULT_PATTERN = "yyyy-MM-dd";

    private String pattern = DEFAULT_PATTERN;
}
