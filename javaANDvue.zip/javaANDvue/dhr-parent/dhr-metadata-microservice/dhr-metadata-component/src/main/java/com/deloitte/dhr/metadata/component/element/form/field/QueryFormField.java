package com.deloitte.dhr.metadata.component.element.form.field;

import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.model.ModelValue;

/**
 * 用于查询的表单字段
 *
 * @author xideng
 */
public interface QueryFormField {

    QueryOperationEnum getOperation();

    Model getModel();

    ModelValue getModelValue();
}
