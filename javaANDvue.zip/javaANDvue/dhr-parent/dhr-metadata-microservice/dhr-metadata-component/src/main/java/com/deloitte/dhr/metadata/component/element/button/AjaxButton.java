package com.deloitte.dhr.metadata.component.element.button;

import com.deloitte.dhr.metadata.component.event.AjaxEvent;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 异步请求按钮
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class AjaxButton extends Button {

    public static final String TYPE_CODE = "AJAX_BUTTON";

    private AjaxEvent event;

    public static AjaxButton of(String text, String type, AjaxEvent event) {
        AjaxButton button = new AjaxButton();
        button.setText(text);
        button.setType(type);
        button.setEvent(event);
        return button;
    }

    public AjaxButton withIcon(String icon) {
        this.setIcon(icon);
        return this;
    }

    public static AjaxButton of(String text, AjaxEvent event) {
        return of(text, null, event);
    }

    @Override
    public String getTypeCode() {
        return null;
    }
}
