package com.deloitte.dhr.metadata.component.element.button;

import com.deloitte.dhr.metadata.component.event.AjaxEvent;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 异步请求按钮
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DialogButton extends Button {

    public static final String TYPE_CODE = "DIALOG_BUTTON";

    private AjaxEvent event;

    public static DialogButton of(String text, String type, AjaxEvent event) {
        DialogButton button = new DialogButton();
        button.setText(text);
        button.setType(type);
        button.setEvent(event);
        return button;
    }

    public DialogButton withIcon(String icon) {
        this.setIcon(icon);
        return this;
    }

    public static DialogButton of(String text, AjaxEvent event) {
        return of(text, null, event);
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
