package com.deloitte.dhr.metadata.component.element.box.audit;

import com.deloitte.dhr.metadata.component.element.box.Box;
import com.deloitte.dhr.metadata.component.element.button.Button;
import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;

/**
 * 表单盒子带有图片布局，前端是将图片和字段分布成两块div进行渲染，与入职信息的图片上传的那块formbox的实现方式不一致
 *
 * @author lshao
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class FormPictureBox extends Box {

    public static final String TYPE_CODE = "FORM_PICTURE_BOX";

    private String name;

    /**
     * 一个图片的布局
     */
    private PictureLayout pictureLayout;

    private List<FormField> fields = new ArrayList<>();

    /**
     * 可具备异步加载当前box数据的能力
     */
//    private AjaxEvent event;
    public FormPictureBox(String name) {
        this.name = name;
    }

    /**
     * 如果不填写formbox的name属性，则在页面上不展示form的title
     */
    public FormPictureBox() {

    }

    public FormPictureBox addFields(FormField... fields) {
        this.fields.addAll(Arrays.asList(fields));
        return this;
    }

    public FormPictureBox addPictureLayout(PictureLayout pictureLayout) {
        this.pictureLayout = pictureLayout;
//        this.fields.add(pictureLayout.getPictureUploadField());
        return this;
    }


    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @SuppressWarnings("Duplicates")
    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        this.fields.forEach(it -> {
            Model model = it.getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), it.getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        });
        if (this.pictureLayout != null) {
            Model model = this.pictureLayout.getPictureUploadField().getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), this.pictureLayout.getPictureUploadField().getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        }
        return data;
    }
}
