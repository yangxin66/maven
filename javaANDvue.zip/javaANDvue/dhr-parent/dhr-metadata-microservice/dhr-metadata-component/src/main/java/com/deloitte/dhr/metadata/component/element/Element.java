package com.deloitte.dhr.metadata.component.element;

/**
 * 可配置元素抽象
 *
 * @author xideng
 */
public interface Element {

    String getTypeCode();
}
