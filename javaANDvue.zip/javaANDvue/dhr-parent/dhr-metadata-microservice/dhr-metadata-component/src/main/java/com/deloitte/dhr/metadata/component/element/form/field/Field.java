package com.deloitte.dhr.metadata.component.element.form.field;

import com.deloitte.dhr.metadata.component.element.Element;
import com.deloitte.dhr.metadata.component.model.ModelContainer;
import com.deloitte.dhr.metadata.component.model.ModelValueContainer;

/**
 * 字段抽象
 *
 * @author xideng
 */
public interface Field extends Element, ModelValueContainer {
}
