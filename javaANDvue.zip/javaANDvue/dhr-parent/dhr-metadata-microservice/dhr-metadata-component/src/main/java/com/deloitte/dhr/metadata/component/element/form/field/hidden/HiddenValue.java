package com.deloitte.dhr.metadata.component.element.form.field.hidden;

import com.deloitte.dhr.metadata.component.element.form.field.FormValue;

/**
 * 隐藏组件的值抽象
 *
 * @author xideng
 */
public class HiddenValue extends FormValue {

    public static HiddenValue of(String value) {
        HiddenValue hiddenValue = new HiddenValue();
        hiddenValue.setValue(value);
        return hiddenValue;
    }
}
