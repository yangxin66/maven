package com.deloitte.dhr.metadata.component.element;

import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 客户端页面或组件间传递参数的实体
 * <br/>09/10/2019 16:02
 *
 * @author lshao
 */
@Data
@AllArgsConstructor
public class Param {
    private String key;
    private String value;
}
