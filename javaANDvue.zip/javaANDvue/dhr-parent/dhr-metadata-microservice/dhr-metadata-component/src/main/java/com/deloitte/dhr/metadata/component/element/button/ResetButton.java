package com.deloitte.dhr.metadata.component.element.button;

/**
 * 重置按钮
 *
 * @author xideng
 */
public class ResetButton extends Button {

    public static final String TYPE_CODE = "RESET_BUTTON";

    public static ResetButton of(String text, String type) {
        ResetButton button = new ResetButton();
        button.setText(text);
        button.setType(type);
        return button;
    }

    public static ResetButton of(String text) {
        return of(text, null);
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
