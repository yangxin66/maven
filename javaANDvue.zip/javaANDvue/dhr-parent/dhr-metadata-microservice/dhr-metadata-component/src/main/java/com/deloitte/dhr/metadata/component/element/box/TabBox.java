package com.deloitte.dhr.metadata.component.element.box;

import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;

/**
 * 带有页签的盒子组件
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class TabBox extends Box {

    public static final String TYPE_CODE = "TAB_BOX";

    /**
     * tab的label
     */
    private String name;

    private List<Box> children = new ArrayList<>();

    public TabBox(String name) {
        this.name = name;
    }

    public TabBox() {
    }

    public TabBox addBoxes(Box... boxes) {
        this.children.addAll(Arrays.asList(boxes));
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @SuppressWarnings("Duplicates")
    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        this.getChildren().forEach(it -> {
            Map<String, Object> subData = it.buildModelStruct();
/*            subData.forEach((k, v) -> {
                if (null == v) {
                    data.put(k, null);
                } else {
                    Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(k, new HashMap<>());
                    subMap.putAll((Map<String, ModelValue>) v);
                    data.put(k, subMap);
                }
            });*/
            data.putAll(subData);
        });
        return data;
    }
}
