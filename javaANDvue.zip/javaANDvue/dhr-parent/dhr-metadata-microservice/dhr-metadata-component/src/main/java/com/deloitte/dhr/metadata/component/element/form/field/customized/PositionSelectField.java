package com.deloitte.dhr.metadata.component.element.form.field.customized;

import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 职位选择下拉框
 *
 * @author xideng
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class PositionSelectField extends FormField {

    public static final String TYPE_CODE = "POSITION_SELECT_FIELD";

    private PositionSelectValue modelValue = new PositionSelectValue();

    public static PositionSelectField of(String label, Model model) {
        return of(label, model, false);
    }

    public static PositionSelectField of(String label, Model model, boolean required) {
        PositionSelectField field = new PositionSelectField();
        field.setLabel(label);
        field.setModel(model);
        field.setRequired(required);
        return field;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
