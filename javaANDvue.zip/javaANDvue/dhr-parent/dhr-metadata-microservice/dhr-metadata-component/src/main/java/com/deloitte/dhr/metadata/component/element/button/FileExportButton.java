package com.deloitte.dhr.metadata.component.element.button;

import com.deloitte.dhr.metadata.component.model.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 文件导出按钮
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class FileExportButton extends Button {

    public static final String TYPE_CODE = "FILE_EXPORT_BUTTON";

    private String url;

    private String method = "get";

    private List<Model> params = new ArrayList<>();

    public static FileExportButton of(String text, String type) {
        FileExportButton button = new FileExportButton();
        button.setText(text);
        button.setType(type);
        return button;
    }

    public static FileExportButton of(String text) {
        return of(text, null);
    }

    public FileExportButton requestWhileClicked(String url, String method) {
        this.setUrl(url);
        this.setMethod(method);
        return this;
    }

    public FileExportButton requestWhileClicked(String url) {
        return this.requestWhileClicked(url, "get");
    }

    public FileExportButton addParams(Model... params) {
        this.params.addAll(Arrays.asList(params));
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}

