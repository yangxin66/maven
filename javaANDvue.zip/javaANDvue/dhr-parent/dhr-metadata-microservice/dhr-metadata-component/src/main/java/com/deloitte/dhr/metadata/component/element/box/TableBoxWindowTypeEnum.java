package com.deloitte.dhr.metadata.component.element.box;

/**
 *  TableBox容器中的表格的交互弹窗类型
 * <br/>28/09/2019 17:43
 *
 * @author lshao
 */
public enum TableBoxWindowTypeEnum {
    //审核弹窗
    AUDIT_WINDOW,
    //查看弹窗
    CHECK_WINDOW,
    //编辑弹窗
    EDIT_WINDOW
}
