package com.deloitte.dhr.metadata.component.element.box;

import com.deloitte.dhr.metadata.component.element.Param;
import com.deloitte.dhr.metadata.component.element.button.Button;
import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.element.form.field.QueryFormField;
import com.deloitte.dhr.metadata.component.element.form.field.table.PaginationTableField;
import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 列表盒子组件
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class ListBox extends Box {

    public static final String TYPE_CODE = "LIST_BOX";

    private String name;

    private String key;

    private List<QueryFormField> queryFields = new ArrayList<>();

    private List<Model> queryParams = new ArrayList<>();

    private List<FormField> tableParamFields = new ArrayList<>();

    private PaginationTableField table;

    /**
     * 如果有值则显示开始时间、结束时间控件并以该key为查询时的时间上限和下限参数传递到后端
     */
    private String dateFilterKey;

    public ListBox addQueryFields(QueryFormField... fields) {
        this.queryFields.addAll(Arrays.asList(fields));
        this.queryParams.addAll(Arrays.stream(fields).map(QueryFormField::getModel).collect(Collectors.toList()));
        return this;
    }

    /**
     * 添加表格查询时的一些扩展参数
     * @param fields
     * @return
     */
    public ListBox addParamFields(FormField... fields) {
        this.tableParamFields.addAll(Arrays.asList(fields));
        return this;
    }

    public static ListBox of(String name, String key) {
        ListBox box = new ListBox();
        box.setName(name);
        box.setKey(key);
        return box;
    }

    public ListBox dateFilterKey(String key) {
        this.setDateFilterKey(key);
        return this;
    }

    public String getUrl() {
        return null == this.getTable() ? null : this.getTable().getUrl();
    }

    public String getMethod() {
        return null == this.getTable() ? null : this.getTable().getMethod();
    }

    public ListBox withTable(PaginationTableField table) {
        this.table = table;
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        this.queryFields.forEach(it -> {
            Model model = it.getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), it.getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        });
        // TODO 还有table自己的
        return data;
    }
}
