package com.deloitte.dhr.metadata.component.element.form.field;

import com.deloitte.dhr.metadata.component.model.ModelValue;
import lombok.Data;

/**
 * 表单字段值抽象
 *
 * @author xideng
 */
@Data
public abstract class FormValue implements ModelValue {

    private Object value;
}
