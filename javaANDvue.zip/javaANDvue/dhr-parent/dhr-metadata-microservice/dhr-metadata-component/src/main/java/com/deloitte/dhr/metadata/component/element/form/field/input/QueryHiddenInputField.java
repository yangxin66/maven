package com.deloitte.dhr.metadata.component.element.form.field.input;

import com.deloitte.dhr.metadata.component.element.form.field.QueryFormField;
import com.deloitte.dhr.metadata.component.element.form.field.QueryOperationEnum;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 隐藏的列表查询框，用于传递注入type固定值的
 *
 * @author lshao
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class QueryHiddenInputField extends TextInputField implements QueryFormField {

    public static final String TYPE_CODE = "QUERY_Hidden_INPUT_FIELD";

    private QueryOperationEnum operation;


    public static QueryHiddenInputField of(String label, Model model, QueryOperationEnum operation) {
        return of(label, model, operation, null);
    }

    public static QueryHiddenInputField of(String label, Model model, QueryOperationEnum operation,Object value) {
        QueryHiddenInputField field = new QueryHiddenInputField();
        field.setLabel(label);
        field.setModel(model);
        field.setPlaceholder("请填写" + field.getLabel());
        field.setOperation(operation);
        field.setModelValue(QueryTextInputValue.of(operation,value));
        return field;
    }

    public QueryHiddenInputField placeholder(String placeholder) {
        this.setPlaceholder(placeholder);
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
