package com.deloitte.dhr.metadata.component.element.box;

import com.deloitte.dhr.metadata.component.element.button.Button;
import com.deloitte.dhr.metadata.component.element.form.field.Field;
import com.deloitte.dhr.metadata.component.event.AjaxEvent;
import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.model.ModelValue;
import com.deloitte.dhr.metadata.component.page.DrawerBoxPage;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.*;

/**
 * 表单盒子抽象
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class FormBox extends Box {

    public static final String TYPE_CODE = "FORM_BOX";

    private String name;

    /**
     * 为了适应右边显示一个图片的布局
     */
    private FormField singleRight;

    /**
     * 固定显示有多少列
     */
    private int cols = 2;
    /**
     * 背景色：#FFFFFF的形式
     */
    private String backgroundColor;

    private List<FormField> fields = new ArrayList<>();

    private List<Button> buttons = new ArrayList<>();
    /**
     * 可具备异步加载当前box数据的能力
     */
    private AjaxEvent ajaxEvent;

    public FormBox(String name) {
        this.name = name;
    }

    /**
     * 如果不填写formbox的name属性，则在页面上不展示form的title
     */
    public FormBox() {

    }

    public FormBox addButton(Button... buttons) {
        this.buttons.addAll(Arrays.asList(buttons));
        return this;
    }

    public FormBox addFields(FormField... fields) {
        this.fields.addAll(Arrays.asList(fields));
        return this;
    }

    public FormBox addSingleRight(FormField field) {
        this.singleRight = field;
//        this.fields.add(field);
        return this;
    }


    public FormBox addCols(int cols) {
        this.cols = cols;
        return this;
    }

    public FormBox addBackgroundColor(String backgroundColor) {
        this.backgroundColor = backgroundColor;
        return this;
    }

    public FormBox addAjaxEvent(AjaxEvent event) {
        this.ajaxEvent = event;
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

    @SuppressWarnings("Duplicates")
    @Override
    public Map<String, Object> buildModelStruct() {
        Map<String, Object> data = new HashMap<>();
        this.fields.forEach(it -> {
            Model model = it.getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), it.getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        });
        if (this.singleRight != null) {
            Model model = this.singleRight.getModel();
            if (!model.hasPrefix()) {
                data.put(model.getKey(), null);
            } else {
                Map<String, ModelValue> subMap = (Map<String, ModelValue>) data.getOrDefault(model.getPrefix(), new HashMap<>());
                subMap.put(model.getKey(), this.singleRight.getModelValue());
                data.put(model.getPrefix(), subMap);
            }
        }
        return data;
    }
}
