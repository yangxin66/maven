package com.deloitte.dhr.metadata.component.element.form.field.datetime;

import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.element.form.field.QueryFormField;
import com.deloitte.dhr.metadata.component.element.form.field.QueryOperationEnum;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 列表查询的日期选择表单字段抽象
 *
 * @author lshao
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class QueryDateSelectField extends FormField implements QueryFormField {

    public static final String TYPE_CODE = "QUERY_DATE_SELECT_FIELD";

    private DateSelectValue modelValue = new DateSelectValue();

    private QueryOperationEnum operation;

    public static QueryDateSelectField of(String label, Model model,QueryOperationEnum operation) {
        return of(label, model, operation,false);
    }

    public static QueryDateSelectField of(String label, Model model,QueryOperationEnum operation, boolean required) {
        QueryDateSelectField field = new QueryDateSelectField();
        field.setLabel(label);
        field.setModel(model);
        field.setRequired(required);
        field.setOperation(operation);
        return field;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
