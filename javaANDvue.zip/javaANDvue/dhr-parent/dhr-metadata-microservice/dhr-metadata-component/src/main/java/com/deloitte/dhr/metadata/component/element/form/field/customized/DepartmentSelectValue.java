package com.deloitte.dhr.metadata.component.element.form.field.customized;

import com.deloitte.dhr.metadata.component.element.form.field.FormValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 所属单位选择框值抽象
 *
 * @author lshao
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DepartmentSelectValue extends FormValue {

    private String text;
}
