package com.deloitte.dhr.metadata.component.element.form.field.datetime;

import com.deloitte.dhr.metadata.component.element.form.field.FormValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 列表查询的日期选择值抽象
 *
 * @author lsha
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class QueryDateSelectValue extends FormValue {

    public static final String DEFAULT_PATTERN = "yyyy-MM-dd";

    private String pattern = DEFAULT_PATTERN;
}
