package com.deloitte.dhr.metadata.component.element.button;

import com.deloitte.dhr.metadata.component.element.Element;
import com.deloitte.dhr.metadata.component.element.Param;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 *
 *
 * @author xideng
 */
@Data
public abstract class Button implements Element {

    private String text;

    private String type;

    private String icon;

    private String img;
    /**
     * 可以给按钮赋值固定参数，适用于在点击按钮传入一些固定type之类的场景
     */
    private List<Param> fixedParams = new ArrayList<>();

}
