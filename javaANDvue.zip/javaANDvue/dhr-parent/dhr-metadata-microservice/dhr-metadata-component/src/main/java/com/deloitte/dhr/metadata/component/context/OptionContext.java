package com.deloitte.dhr.metadata.component.context;

import com.deloitte.dhr.metadata.component.element.form.field.Option;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 选项集中域
 *
 * @author xideng
 */
public class OptionContext {

    public static final Map<String, List<Option>> RESOURCES = new ConcurrentHashMap<>();

    static {
        RESOURCES.put("WERKS",
                Arrays.asList(
                        new Option("人事范围1", "R01"),
                        new Option("人事范围2", "R02")
                )
        );
        RESOURCES.put("R01",
                Arrays.asList(
                        new Option("人事子范围1", "RZ01"),
                        new Option("人事子范围2", "RZ02")
                )
        );
        RESOURCES.put("R02",
                Arrays.asList(
                        new Option("人事子范围3", "RZ03"),
                        new Option("人事子范围4", "RZ04")
                )
        );
        RESOURCES.put("sex",
                Arrays.asList(
                        new Option("男", "男"),
                        new Option("女", "女")
                )
        );
        RESOURCES.put("nation",
                Arrays.asList(
                        new Option("中国", "中国"),
                        new Option("外国", "外国")
                )
        );
        RESOURCES.put("ZZSFSGGB",
                Arrays.asList(
                        new Option("是", "是"),
                        new Option("否", "否")
                )
        );
        RESOURCES.put("ZZGJRCBS",
                Arrays.asList(
                        new Option("是", "是"),
                        new Option("否", "否")
                )
        );
        RESOURCES.put("sendFlag",
                Arrays.asList(
                        new Option("待审核", "true"),
                        new Option("未发送邮件", "false")
                )
        );
        RESOURCES.put("busiType",
                Arrays.asList(
                        new Option("普通岗位变动", "001"),
                        new Option("领导岗位变动", "002")
                )
        );
        RESOURCES.put("RESAON",
                Arrays.asList(
                        new Option("岗位调整1", "001"),
                        new Option("岗位调整2", "002")
                )
        );
        RESOURCES.put("ZZGWXL",
                Arrays.asList(
                        new Option("崗位1", "001"),
                        new Option("崗位2", "002")
                )
        );
    }
}
