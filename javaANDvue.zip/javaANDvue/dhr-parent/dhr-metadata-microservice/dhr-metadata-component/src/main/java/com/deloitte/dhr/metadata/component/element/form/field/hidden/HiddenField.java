package com.deloitte.dhr.metadata.component.element.form.field.hidden;

import com.deloitte.dhr.metadata.component.element.form.field.FormField;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 表示不在前端进行展示
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class HiddenField extends FormField {

    public static final String TYPE_CODE = "HIDDEN_FIELD";

    private HiddenValue modelValue = new HiddenValue();

    public static HiddenField of(Model model) {
        HiddenField field = new HiddenField();
        field.setModel(model);
        return field;
    }
    public static HiddenField of(Model model,Object value) {
        HiddenField field = new HiddenField();
        field.setModel(model);
        field.modelValue.setValue(value);
        return field;
    }
/*    public HiddenField(Model model,Object value) {
        this.setModel(model);
        this.modelValue.setValue(value);
    }*/
    public HiddenField() {
    }
    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
