package com.deloitte.dhr.metadata.component.element.form.field.input;

import com.deloitte.dhr.metadata.component.element.form.field.QueryFormField;
import com.deloitte.dhr.metadata.component.element.form.field.QueryOperationEnum;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 用于查询的表单输入字段
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class QueryTextInputField extends TextInputField implements QueryFormField {

    public static final String TYPE_CODE = "QUERY_TEXT_INPUT_FIELD";

    private QueryOperationEnum operation;

    public static QueryTextInputField of(String label, Model model, QueryOperationEnum operation) {
        return of(label, model, operation, false);
    }

    public static QueryTextInputField of(String label, Model model, QueryOperationEnum operation, boolean required) {
        QueryTextInputField field = new QueryTextInputField();
        field.setLabel(label);
        field.setModel(model);
        field.setRequired(required);
        field.setPlaceholder("请填写" + field.getLabel());
        field.setOperation(operation);
        field.setModelValue(QueryTextInputValue.of(operation));
        return field;
    }

    public QueryTextInputField placeholder(String placeholder) {
        this.setPlaceholder(placeholder);
        return this;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
