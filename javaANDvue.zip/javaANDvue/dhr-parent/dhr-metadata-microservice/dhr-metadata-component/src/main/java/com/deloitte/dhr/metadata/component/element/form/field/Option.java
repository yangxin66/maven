package com.deloitte.dhr.metadata.component.element.form.field;

import com.deloitte.dhr.metadata.component.element.Element;
import lombok.Data;

/**
 * 选项
 *
 * @author xideng
 */
@Data
public class Option implements Element {

    public static final String TYPE_CODE = "OPTION";

    private String text;

    private String value;

    public Option(String text, String value) {
        this.text = text;
        this.value = value;
    }

    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }
}
