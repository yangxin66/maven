package com.deloitte.dhr.metadata.component.element.form.field;

import com.deloitte.dhr.metadata.component.model.Model;
import com.deloitte.dhr.metadata.component.security.SecurityAccess;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 表单字段抽象
 *
 * @author xideng
 */
@Getter
@Setter
@EqualsAndHashCode
@ToString
public abstract class FormField implements Field, SecurityAccess {

    private String label;
    /**
     * label字体加粗
     */
    private Boolean labelBold = false;

    private Model model;
    /**
     * 是否只读
     */
    private Boolean disabled = false;
    /**
     * 是否将控件显示成文本模式
     */
    private Boolean onlyShow = false;
    /**
     * 是否必填
     */
    private Boolean required = false;
    /**
     * 是否整行显示控件
     */
    private Boolean fullRow = false;
    /**
     * 引用的model，下拉框的显示文本和实际code为两个值，该model指向的字段为下拉框的code实际存储字段
     */
    private Model refModel;

    private List<String> permissions = new ArrayList<>();

    public FormField onlyShow(boolean flag){
        this.onlyShow = flag;
        return this;
    }
    public FormField disabled(boolean flag){
        this.disabled = flag;
        return this;
    }
    public FormField addFullRow(boolean flag){
        this.fullRow = flag;
        return this;
    }
    @Override
    public FormField requirePermissions(String... permissions) {
        this.permissions.addAll(Arrays.asList(permissions));
        return this;
    }
}
