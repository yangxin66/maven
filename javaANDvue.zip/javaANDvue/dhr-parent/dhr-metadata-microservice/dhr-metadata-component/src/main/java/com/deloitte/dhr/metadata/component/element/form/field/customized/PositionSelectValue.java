package com.deloitte.dhr.metadata.component.element.form.field.customized;

import com.deloitte.dhr.metadata.component.element.form.field.FormValue;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 职位选择值抽象
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class PositionSelectValue extends FormValue {

    private String text;
}
