package com.deloitte.dhr.metadata.component.element.button;

import com.deloitte.dhr.metadata.component.element.Param;
import com.deloitte.dhr.metadata.component.model.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 跳转链接按钮
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class LinkButton extends Button {

    public static final String TYPE_CODE = "LINK_BUTTON";

    private String link;

    private List<Model> params = new ArrayList<>();

    public static LinkButton of(String text, String type, String link) {
        LinkButton button = new LinkButton();
        button.setText(text);
        button.setType(type);
        button.setLink(link);
        return button;
    }

    public LinkButton withIcon(String icon) {
        this.setIcon(icon);
        return this;
    }

    public LinkButton withImg(String img) {
        this.setImg(img);
        return this;
    }

    public LinkButton addParams(Model... p) {
        this.params.addAll(Arrays.asList(p));
        return this;
    }

    public LinkButton addFixedParams(Param... p) {
        this.setFixedParams(Arrays.asList(p));
        StringBuilder parameter = new StringBuilder("?");
        this.getFixedParams().forEach(param -> {
            if (parameter.length() == 1) {
                parameter.append(param.getKey() + "=" + param.getValue());
            } else {
                parameter.append("&" + param.getKey() + "=" + param.getValue());
            }
        });
        this.setLink(this.getLink() + parameter.toString());
        return this;
    }


    @Override
    public String getTypeCode() {
        return TYPE_CODE;
    }

}
