package com.deloitte.dhr.metadata.component.element.form.field;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * 用于查询的表单值抽象
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public abstract class QueryFormValue extends FormValue {

    abstract QueryOperationEnum getOperation();
}
