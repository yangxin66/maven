package com.deloitte.dhr.metadata.api;

import com.deloitte.dhr.metadata.api.model.ListPageDto;
import com.deloitte.infrastructure.communication.Response;

/**
 * 列表页面RESTful API
 *
 * @author xideng
 */
public interface ListPageRestInterface {

    Response<ListPageDto> getListPage(String code);
}
