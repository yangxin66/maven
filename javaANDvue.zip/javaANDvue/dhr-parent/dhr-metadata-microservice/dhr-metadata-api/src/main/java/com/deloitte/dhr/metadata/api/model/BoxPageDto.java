package com.deloitte.dhr.metadata.api.model;

import com.deloitte.dhr.metadata.component.model.ModelValue;
import com.deloitte.dhr.metadata.component.page.BoxPage;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * 盒子表单页面DTO
 *
 * @author xideng
 */
@Data
public class BoxPageDto implements Serializable {

    private static final long serialVersionUID = 8317454614958994494L;

    /**
     * 页面配置信息
     */
    private final BoxPage pageConfig;

    /**
     * 初始化数据
     */
    private final Map<String, String> initData;

    /**
     * 【页面绑定数据】结构体
     */
    private final Map<String, Object> models;

    public BoxPageDto(BoxPage pageConfig, Map<String, String> initData) {
        this.pageConfig = pageConfig;
        this.initData = initData;
        this.models = this.pageConfig.buildModelStruct();
    }
}
