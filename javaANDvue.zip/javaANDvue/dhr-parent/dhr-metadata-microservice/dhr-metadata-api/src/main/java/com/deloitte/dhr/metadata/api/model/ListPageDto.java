package com.deloitte.dhr.metadata.api.model;

import com.deloitte.dhr.metadata.component.model.ModelValue;
import com.deloitte.dhr.metadata.component.page.ListPage;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * 列表页面DTO
 *
 * @author xideng
 */
@Data
public class ListPageDto implements Serializable {

    private static final long serialVersionUID = -5196906539166400791L;

    /**
     * 页面配置信息
     */
    private final ListPage pageConfig;

    /**
     * 初始化数据
     */
    private final Map<String, String> initData;

    /**
     * 【页面绑定数据】结构体
     */
    private final Map<String, Object> models;

    public ListPageDto(ListPage pageConfig, Map<String, String> initData) {
        this.pageConfig = pageConfig;
        this.initData = initData;
        this.models = this.pageConfig.buildModelStruct();
    }
}
