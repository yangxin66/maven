package com.deloitte.dhr.metadata.api;

import com.deloitte.dhr.metadata.api.model.TabPageDto;
import com.deloitte.infrastructure.communication.Response;

/**
 * tab模板页面 RESTful 控制器 - 首次用于员工入职-员工填写页面
 *
 * @author lshao
 */
public interface TabPageRestInterface {

    Response<TabPageDto> getTabPage(String code);
}
