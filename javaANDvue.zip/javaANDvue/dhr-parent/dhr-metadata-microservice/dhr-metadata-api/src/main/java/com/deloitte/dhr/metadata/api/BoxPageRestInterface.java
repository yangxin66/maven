package com.deloitte.dhr.metadata.api;

import com.deloitte.dhr.metadata.api.model.BoxPageDto;
import com.deloitte.infrastructure.communication.Response;

/**
 * 盒子页面 RESTful API
 *
 * @author xideng
 */
public interface BoxPageRestInterface {

    Response<BoxPageDto> getBoxPage(String code);
}
