package com.deloitte.dhr.metadata.api.model;

import com.deloitte.dhr.metadata.component.page.DrawerBoxPage;
import com.deloitte.dhr.metadata.component.page.TabPage;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

/**
 * 盒子手风琴页面DTO
 *
 * @author lshao
 */
@Data
public class DrawerBoxPageDto implements Serializable {

    private static final long serialVersionUID = 8317454614958994494L;

    /**
     * 页面配置信息
     */
    private final DrawerBoxPage pageConfig;

    /**
     * 初始化数据
     */
    private final Map<String, String> initData;

    /**
     * 【页面绑定数据】结构体
     */
    private final Map<String, Object> models;

    public DrawerBoxPageDto(DrawerBoxPage pageConfig, Map<String, String> initData) {
        this.pageConfig = pageConfig;
        this.initData = initData;
        this.models = this.pageConfig.buildModelStruct();
    }
}
