package com.deloitte.dhr.file.provider.gateway.rest.v1;

import com.deloitte.dhr.common.exception.FileMateInfo;
import com.deloitte.dhr.file.api.FileOperInterface;
import com.deloitte.dhr.file.api.dto.FilePreviewRequestDto;
import com.deloitte.dhr.file.api.dto.FileRequestDto;
import com.deloitte.dhr.file.api.dto.FileResponseDto;
import com.deloitte.dhr.file.provider.config.FastDFSConnectionPool;
import com.deloitte.dhr.file.provider.util.FileUtil;
import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.csource.common.MyException;
import org.csource.fastdfs.StorageClient1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/v1/file")
public class FileOperProvider implements FileOperInterface {
    /**
     * FastDFS 连接池
     */
    @Autowired
    private FastDFSConnectionPool fastDFSConnectionPool = null;

    @ApiOperation(value = "上传文件")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "fileName",value="文件名",required = true,dataType = "String",paramType = "body"),
            @ApiImplicitParam(name = "fileBytes",value="文件流",required = true,dataType = "String",paramType = "body")
    })
    @Override
    public Response<FileResponseDto> uploadFile(@RequestBody FileRequestDto fileRequestDto) {
        String result = null;
        //获取客户端
        StorageClient1 storageClient1 = null;
        try {
            //1、创建连接池
            //initFastDFSConnectionPool();
            //2、上传文件
            //获取客户端
            storageClient1 = fastDFSConnectionPool.get();
            //文件名
            String fileName = fileRequestDto.getFileName();
            //文件后缀
            String suffix = FileUtil.getSuffix(fileName);
            //上传
            result = storageClient1.upload_file1(fileRequestDto.getFileBytes(), suffix, null);
//            result = fastDFSConnectionPool.getAccessServer() + result;
            //链接放回文件连接池
            fastDFSConnectionPool.put(storageClient1);
        } catch (Exception e) {
            log.error("上传文件失败", e);
            throw new BusinessException(FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getCode(),FileMateInfo.UPLOAD_FILE_FAILURE_ERR.getMessage(), e);
        } finally {
            try {
                fastDFSConnectionPool.drop(storageClient1);
            } catch (Exception e1) {
                log.error("上传文件-关闭文件连接池失败", e1);
            }
        }
        FileResponseDto fileResponseDto = new FileResponseDto();
        fileResponseDto.setUrl(result);
        return new Response(LanguageEnum.getDefault(),Response.SUCCESS_CODE,"Success",fileResponseDto);
    }

    @ApiOperation(value = "删除文件")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "url",value="文件url",required = true,dataType = "String",paramType = "body")
    })
    @Override
    public Response<Boolean> deleteFile(String url) {
        boolean result = false;
        //获取客户端
        StorageClient1 storageClient1 = null;
        try {
            //1、创建连接池
            //initFastDFSConnectionPool();
            //2、删除文件
            //获取客户端
            storageClient1 = fastDFSConnectionPool.get();
            //删除文件
            int delNum = storageClient1.delete_file1(url);
            if (delNum == 0) {
                result = true;
            }
            //链接放回文件连接池
            fastDFSConnectionPool.put(storageClient1);
        } catch (Exception e) {
            log.error("删除文件", e);
            throw new BusinessException(FileMateInfo.DELETE_FILE_FAILURE_ERR.getCode(),FileMateInfo.DELETE_FILE_FAILURE_ERR.getMessage(), e);
        } finally {
            try {
                fastDFSConnectionPool.drop(storageClient1);
            } catch (Exception e1) {
                log.error("删除文件-关闭文件连接池失败", e1);
            }
        }
        return new Response(LanguageEnum.getDefault(),Response.SUCCESS_CODE,"Success",result);
    }

    /**
     * 文件预览，带有业务性质，仅供参考
     * @param filePreviewRequestDto
     * @param response
     */
    @PostMapping("/preview")
    public void preview(@RequestBody FilePreviewRequestDto filePreviewRequestDto, HttpServletResponse response) {
        //参数
        Map params = (Map) filePreviewRequestDto.getParam();

        ByteArrayOutputStream out = null;
        StorageClient1 storageClient = null;
        try {
            storageClient = fastDFSConnectionPool.get();
            // 下载
            byte[] fileByte = storageClient.download_file1(filePreviewRequestDto.getTemplateUrl());

            XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(fileByte));

            //替换段落里面的变量
            FileUtil.replaceInPara(doc, params);

            PdfOptions options = PdfOptions.create();
            out = new ByteArrayOutputStream();
            PdfConverter.getInstance().convert(doc, out, options);

            OutputStream os = response.getOutputStream();
            byte[] buffer = out.toByteArray();
            os.write(buffer, 0, buffer.length);
            os.flush();

        } catch (Exception e) {
            throw new BusinessException(FileMateInfo.PREVIEW_FILE_FAILURE_ERR.getCode(), FileMateInfo.PREVIEW_FILE_FAILURE_ERR.getMessage(), e);
        } finally {
            FileUtil.close(out);
        }

    }

    @ApiOperation(value = "下载文件")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "url",value="文件url",required = true,dataType = "String",paramType = "body")
    })
    @GetMapping("/download")
    public void download(String url, HttpServletResponse response){
        StorageClient1 storageClient = null;
        InputStream is = null;
        OutputStream os = null;
        try {
            storageClient = fastDFSConnectionPool.get();
            // 下载
            byte[] fileByte = storageClient.download_file1(url);

            if(fileByte != null){

                os = response.getOutputStream();

                is = new ByteArrayInputStream(fileByte);
                byte[] buffer = new byte[1024 * 5];
                int len = 0;
                while ((len = is.read(buffer)) > 0) {
                    os.write(buffer, 0, len);
                }
                os.flush();
            }
            //链接放回文件连接池
            fastDFSConnectionPool.put(storageClient);
        } catch (IOException | MyException e) {
            throw new BusinessException(FileMateInfo.DOWNLOAD_FILE_FAILURE_ERR.getCode(), FileMateInfo.DOWNLOAD_FILE_FAILURE_ERR.getMessage(), e);
        } finally {
            // 关闭流
            try {
                if(is != null){
                    is.close();
                }
                if(os != null){
                    os.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
