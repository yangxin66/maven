package com.deloitte.dhr.file.provider.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xwpf.usermodel.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description
 * @Author 程杰 | Cheng, Jie J (CN - Chongqing)
 * @Email jiecheng@deloitte.com.cn
 * @phone +86 15921445651
 * @CreatDate 2019/06/03
 */
@Slf4j
public class FileUtil {
    //根据当前的系统都识别 / 系统统一使用 、
    public final static String file_separator = "/";

    /**
     * 默认的字符集
     */
    public final static String DEFAULT_CHARSET = "UTF-8";

    /**
     * 简单获取后缀名
     *
     * @param fileName 文件
     * @return 文件格式
     * @throws Exception
     */
    public static String getSuffix(String fileName) {
        if (fileName == null || fileName.indexOf(".") == -1) {
            return ""; //如果图片地址为null或者地址中没有"."就返回""
        }
        return fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());
    }

    /**
     * 建立文件(可以同时建立文件需要的文件夹)
     * <功能详细描述>
     *
     * @param path
     * @return File [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static File createFile(String path) {
        // 先格式化路径
        if (path == null || "".equals(path)) {
            return null;
        }

        path = getPath(path);
        String mdr = path.substring(0, path.lastIndexOf(file_separator));

        File file = new File(mdr);

        if (!file.exists()) {
            try {
                // 建立路径
                file.mkdirs();
            } catch (Exception e) {
                return null;
            }

        }

        return new File(path);
    }

    /**
     * 创建文件夹
     * <功能详细描述>
     *
     * @param path
     * @return boolean [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean createFolders(String path) {
        // 先格式化路径
        if (path == null || "".equals(path)) {
            return false;
        }

        path = getPath(path);

        File file = new File(path);

        if (!file.exists()) {
            try {
                // 建立路径
                file.mkdirs();
            } catch (Exception e) {
                return false;
            }
        }
        return true;
    }

    /**
     * 从全部路径里面获得文件名称(GBK名称)
     * <功能详细描述>
     *
     * @param path
     * @return String [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static String getFileName(String path) {
        path = path.replaceAll("\\\\", file_separator);
        return path.substring(path.lastIndexOf(file_separator) + 1,
                path.length());
    }

    /**
     * 文件是否存在(如果是文件夹返回false)
     * <功能详细描述>
     *
     * @param filePath
     * @return boolean [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean isFileExist(String filePath) {
        File file = new File(filePath);
        return file.exists() && file.isFile();
    }

    /**
     * 拷贝文件
     * <功能详细描述>
     *
     * @param in
     * @param out
     * @return boolean [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean copyFile(InputStream in, OutputStream out)
            throws IOException {
        if (in == null || out == null) {
            return false;
        }
        try {
            int bytesRead = 0;
            final int length = 8192;
            byte[] buffer = new byte[length];

            while ((bytesRead = in.read(buffer, 0, length)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        return true;
    }

    /**
     * 复制文件
     * <功能详细描述>
     *
     * @param srcFile
     * @param dirFile
     * @return boolean [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean copyFile(String srcFile, String dirFile)
            throws IOException {
        FileOutputStream out = null;
        FileInputStream in = null;
        try {
            out = new FileOutputStream(getPath(dirFile));
            in = new FileInputStream(getPath(srcFile));
            copyFile(in, out);
        } catch (FileNotFoundException e) {
            throw e;
        } catch (IOException e) {
            throw e;
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {

            }
        }

        return true;
    }

    /**
     * 剪切文件
     * <功能详细描述>
     *
     * @param srcFile
     * @param dirFile
     * @return boolean [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean cutFile(String srcFile, String dirFile)
            throws IOException {
        copyFile(srcFile, dirFile);

        File file = new File(srcFile);

        if (file != null) {
            try {
                file.delete();
            } catch (Exception e) {

            }
        }
        return true;
    }

    /**
     * 获得本地认识的path(屏蔽平台之间的字符集设置)
     * <功能详细描述>
     *
     * @param path
     * @return String [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static String getPath(String path) {
        path = path.replaceAll("\\\\", file_separator);
        try {
            path = new String(path.getBytes(DEFAULT_CHARSET));
        } catch (UnsupportedEncodingException e) {
        }
        return path;
    }

    /**
     * 生成类似于xml的list
     * <功能详细描述>
     *
     * @param path
     * @return List [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static List searchAll(String path) throws IOException {
        List list = new ArrayList();
        File file = new File(getPath(path));
        File[] f = file.listFiles();

        if (f == null) {
            return list;
        }

        if (f.length == 0) {
            return list;
        }

        list.add("<floder path =\"" + path + "\">");

        for (int i = 0; i < f.length; i++) {
            if (f[i].isFile()) {
                list.add("<file>" + new String(f[i].getName().getBytes(),
                        DEFAULT_CHARSET) + "</file>");
            } else {
                list.addAll(searchAll(f[i].getPath()));
            }
        }
        list.add("</floder>");

        return list;
    }

    /**
     * 查询目录下的文件
     * <功能详细描述>
     *
     * @param path
     * @return List [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static List searchAllFile(String path) throws IOException {
        List list = new ArrayList();
        File file = new File(getPath(path));

        File[] f = file.listFiles();

        if (f == null) {
            return list;
        }

        if (f.length == 0) {
            return list;
        }

        for (int i = 0; i < f.length; i++) {
            if (f[i].isFile()) {
                //这里获得GBK的路径
                list.add(new String(f[i].getAbsolutePath().getBytes(),
                        DEFAULT_CHARSET));
            } else {
                list.addAll(searchAllFile(f[i].getPath()));
            }
        }

        return list;
    }

    /**
     * 删除文件以及文件夹
     * <功能详细描述>
     *
     * @param floderPath
     * @return int [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static int delFloder(String floderPath) {
        int result = 0;
        File file = new File(getPath(floderPath));

        File[] files = file.listFiles();

        if (files == null) {
            return result;
        }

        if (files.length == 0) {
            return result;
        }

        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                result += files[i].delete() == true ? 1 : 0;
            } else {
                result += delFloder(files[i].getPath());
                try {
                    files[i].delete();
                } catch (Exception e) {

                }
            }
        }

        return result;
    }

    /**
     * 复制文件
     * <功能详细描述>
     *
     * @param srcFile
     * @param dirFile
     * @return boolean [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean copyFile(File srcFile, File dirFile)
            throws IOException {
        // 防止没有路径
        if (!srcFile.exists()) {
            return false;
        }

        FileOutputStream out = null;
        FileInputStream in = null;
        try {
            out = new FileOutputStream(dirFile);
            in = new FileInputStream(srcFile);

            copyFile(in, out);
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {

            }
        }

        return true;
    }

    /**
     * 把srcFloder下面的文件夹以及子文件拷贝到dirFloder目录下
     * <功能详细描述>
     *
     * @param srcFloder
     * @param dirFloder
     * @return int [返回类型说明]
     * @throws IOException [参数说明]
     * @throws throws      [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static int copyFloder(String srcFloder, String dirFloder)
            throws IOException {
        int copyCount = 0;
        File file = new File(getPath(srcFloder));
        File[] f = file.listFiles();

        // 格式化path
        dirFloder = getFormatPath(dirFloder);

        if (f == null) {
            return 0;
        }

        if (f.length == 0) {
            return 0;
        }

        for (int i = 0; i < f.length; i++) {
            if (f[i].isFile()) {
                // 拷贝文件到目标目录 这里的f[i].getName()根据操作系统字符编码是根据操作系统决定的
                //但是拷贝到本机就无所谓的，这里不需要在转码
                boolean bb = copyFile(f[i],
                        createFile(dirFloder + f[i].getName()));
                copyCount += (bb == true ? 1 : 0);
            } else {
                createFolders(dirFloder + f[i].getName());
                copyCount += copyFloder(f[i].getPath(),
                        dirFloder + f[i].getName());
            }
        }

        return copyCount;
    }

    /**
     * (GBK编码的路径)格式化路径，使得路径后面是/或者\
     * <功能详细描述>
     *
     * @param path
     * @return String [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static String getFormatPath(String path) {
        if (path == null) {
            return null;
        }

        // 替换文件路径，使用windows和aix，unix
        path = path.replaceAll("\\\\", file_separator);

        if (!path.substring(path.length() - 1).equals(file_separator)) {
            path = path + file_separator;
        }

        try {
            path = new String(path.getBytes(DEFAULT_CHARSET));
        } catch (UnsupportedEncodingException e) {
        }

        return path;
    }

    /**
     * 将内容写入文件中
     * <功能详细描述>
     *
     * @param filePath
     * @param content
     * @return String [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static void writeFile(String filePath, String content) {
        writeFile(filePath, content, false, null);
    }

    /**
     * 将内容写入文件中
     * <功能详细描述>
     *
     * @param filePath
     * @param content
     * @return String [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static void writeFile(String filePath, String content,
                                 boolean isNotOverride) {
        writeFile(filePath, content, isNotOverride, null);
    }

    /**
     * 将内容写入文件中
     * <功能详细描述>
     *
     * @param filePath
     * @param content
     * @return String [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static void writeFile(String filePath, String content,
                                 boolean isNotOverride, String encoding) {
        if (StringUtils.isNoneBlank(filePath) || content == null) {
            return;
        }
        File file = createFile(filePath);
        FileOutputStream outSTr = null;
        OutputStreamWriter osw = null;
        BufferedWriter writer = null;
        try {

            outSTr = new FileOutputStream(file, isNotOverride);
            if (StringUtils.isNoneBlank(encoding)) {
                osw = new OutputStreamWriter(outSTr);
            } else {
                osw = new OutputStreamWriter(outSTr, encoding);
            }
            writer = new BufferedWriter(osw);
            writer.write(content);
            writer.flush();
            writer.close();
        } catch (Exception e) {
            log.error("写入文件失败", e);
        } finally {
            try {
                writer.close();
                outSTr.close();
            } catch (Exception e) {
                log.error("写入文件失败", e);
            }
        }

    }

    /**
     * 写入文件
     * <功能详细描述>
     *
     * @param filePath   文件路径
     * @param contents   内容
     * @param isOverride 是否覆盖
     * @return void [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static void writeFile(String filePath, List<String> contents,
                                 boolean isOverride) {
        writeFile(filePath, contents, isOverride, null);
    }

    /**
     * 写入文件
     * <功能详细描述>
     *
     * @param filePath      文件路径
     * @param contents      内容
     * @param isNotOverride 是否不覆盖
     * @param encoding      编码
     * @return void [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static void writeFile(String filePath, List<String> contents,
                                 boolean isNotOverride, String encoding) {

        if (StringUtils.isNoneBlank(filePath) || contents == null) {
            return;
        }
        File file = createFile(filePath);
        FileOutputStream outSTr = null;
        OutputStreamWriter osw = null;
        BufferedWriter writer = null;
        try {

            outSTr = new FileOutputStream(file, isNotOverride);
            if (StringUtils.isNoneBlank(encoding)) {
                osw = new OutputStreamWriter(outSTr);
            } else {
                osw = new OutputStreamWriter(outSTr, encoding);
            }
            writer = new BufferedWriter(osw);
            for (String content : contents) {
                content = content + "\r\n";
                writer.write(content);
            }
            writer.flush();
            writer.close();
        } catch (Exception e) {
            log.error("写入文件失败", e);
        } finally {
            try {
                writer.close();
                osw.close();
                outSTr.close();
            } catch (Exception e) {
                log.error("写入文件失败", e);
            }
        }

    }

    /**
     * 读取文件
     * <功能详细描述>
     *
     * @param file
     * @return String [返回类型说明]
     * @throws FileNotFoundException [参数说明]
     * @throws throws                [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static String readFile(File file) throws FileNotFoundException {
        BufferedReader br = null;
        StringBuffer sb = new StringBuffer();
        try {
            br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), "GBK"));
            String temp = br.readLine();
            while (temp != null) {
                sb.append(temp);
                sb.append("\r\n");
                temp = br.readLine();
            }
        } catch (IOException e) {
            log.error("读取文件失败", e);
            throw new FileNotFoundException();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                log.error("读取文件失败", e);
                throw new FileNotFoundException();
            }
        }
        return sb.toString();
    }

    /**
     * 读取文本文件
     * <功能详细描述>
     *
     * @param file
     * @return String[] [返回类型说明]
     * @throws FileNotFoundException [参数说明]
     * @throws throws                [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static String[] readLineFile(File file) throws FileNotFoundException {
        BufferedReader br = null;
        StringBuffer sb = new StringBuffer();
        try {
            br = new BufferedReader(
                    new InputStreamReader(new FileInputStream(file), "GBK"));
            String temp = br.readLine();
            while (temp != null) {
                sb.append(temp + "\n");
                temp = br.readLine();
            }
        } catch (IOException e) {
            throw new FileNotFoundException();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                throw new FileNotFoundException();
            }
        }
        return sb.toString().split("\n");
    }

    /**
     * 创建文件目录
     * <功能详细描述>
     *
     * @param fileDir
     * @return boolean [返回类型说明]
     * @throws throws [异常类型] [异常说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean createDir(String fileDir) {
        // 如果不为空，创建文件目录
        if (null != fileDir) {
            File dir = new File(fileDir);
            if (!dir.exists() || !dir.isDirectory()) {
                try {
                    // 创建新的文件目录
                    return dir.mkdirs();
                } catch (Exception e) {
                    log.error("创建文件目录失败", e);
                }
            }
        }
        return true;
    }

    /**
     * 删除文件
     * <功能详细描述>
     *
     * @param filePath
     * @return boolean [返回类型说明]
     * @throws throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    public static boolean delFile(String filePath) {
        File file = new File(getPath(filePath));

        if (!file.exists()) {
            return false;
        }

        boolean r = file.delete();
        return r;
    }

    /**
     * 替换段落里面的变量
     *
     * @param doc    要替换的文档
     * @param params 参数
     */
    public static void replaceInPara(XWPFDocument doc, Map<String, Object> params) {
        Iterator<XWPFParagraph> iterator = doc.getParagraphsIterator();
        XWPFParagraph para;

        while (iterator.hasNext()) {
            para = iterator.next();
            replaceInPara(para, params);
        }
    }

    /**
     * 替换段落里面的变量
     *
     * @param para   要替换的段落
     * @param params 参数
     */
    public static void replaceInPara(XWPFParagraph para, Map<String, Object> params) {
        List<XWPFRun> runs;
        Matcher matcher;
        if (matcher(para.getText()).find()) {
            runs = para.getRuns();
            for (int i = 0; i < runs.size(); i++) {
                XWPFRun run = runs.get(i);
                String runText = run.toString();
                matcher = matcher(runText);
                if (matcher.find()) {
                    while ((matcher = matcher(runText)).find()) {
                        runText = matcher.replaceFirst(String.valueOf(params.get(matcher.group(1))));
                    }
                    //直接调用XWPFRun的setText()方法设置文本时，在底层会重新创建一个XWPFRun，把文本附加在当前文本后面，
                    //所以我们不能直接设值，需要先删除当前run,然后再自己手动插入一个新的run。
                    run.setText(runText, 0);
                }
            }
        }
    }

    /**
     * 替换表格里面的变量
     *
     * @param doc    要替换的文档
     * @param params 参数
     */
    private void replaceInTable(XWPFDocument doc, Map<String, Object> params) {
        Iterator<XWPFTable> iterator = doc.getTablesIterator();
        XWPFTable table;
        List<XWPFTableRow> rows;
        List<XWPFTableCell> cells;
        List<XWPFParagraph> paras;
        while (iterator.hasNext()) {
            table = iterator.next();
            rows = table.getRows();
            for (XWPFTableRow row : rows) {
                cells = row.getTableCells();
                for (XWPFTableCell cell : cells) {
                    paras = cell.getParagraphs();
                    for (XWPFParagraph para : paras) {
                        replaceInPara(para, params);
                    }
                }
            }
        }
    }

    /**
     * 正则匹配字符串
     *
     * @param str
     * @return
     */
    public static Matcher matcher(String str) {
        Pattern pattern = Pattern.compile("\\{(.+?)\\}", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(str);
        return matcher;
    }

    /**
     * 关闭输入流
     *
     * @param is
     */
    public static void close(InputStream is) {
        if (is != null) {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 关闭输出流
     *
     * @param os
     */
    public static void close(OutputStream os) {
        if (os != null) {
            try {
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 获得指定文件的byte数组
     *
     * @param file 文件
     * @return 文件的byte数组
     */
    private byte[] getBytes(File file) throws Exception {
        FileInputStream fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
        byte[] b = new byte[1024];
        int n;
        while ((n = fis.read(b)) != -1) {
            bos.write(b, 0, n);
        }
        fis.close();
        bos.close();
        return bos.toByteArray();
    }
}
