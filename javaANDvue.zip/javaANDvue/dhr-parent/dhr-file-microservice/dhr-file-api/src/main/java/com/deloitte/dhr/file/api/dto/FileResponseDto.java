package com.deloitte.dhr.file.api.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class FileResponseDto implements Serializable {
    private String url;
}
