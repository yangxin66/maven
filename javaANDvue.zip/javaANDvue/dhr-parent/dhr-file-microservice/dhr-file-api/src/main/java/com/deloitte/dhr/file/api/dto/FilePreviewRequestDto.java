package com.deloitte.dhr.file.api.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class FilePreviewRequestDto implements Serializable {
    /***
     * 模板名(路径)
     */
    private String fileName;

    /***
     * 模板参数
     */
    private Object param;

    /***
     * 模板地址
     */
    private String templateUrl;
}
