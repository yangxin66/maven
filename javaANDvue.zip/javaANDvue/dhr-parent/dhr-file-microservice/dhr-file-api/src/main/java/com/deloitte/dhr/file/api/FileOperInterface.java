package com.deloitte.dhr.file.api;

import com.deloitte.dhr.file.api.dto.FileRequestDto;
import com.deloitte.dhr.file.api.dto.FileResponseDto;
import com.deloitte.infrastructure.communication.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(value = "dhr-file-microservice", path = "/api/v1/file")
public interface FileOperInterface {

    /***
     * 上传文件
     *
     * @title 上传文件
     * @param fileRequestDto 文件信息
     * @return 上传文件地址
     * @author chengjie
     * @since v1.0.0
     */
    @PostMapping("/uploadFile")
    Response<FileResponseDto> uploadFile(@RequestBody FileRequestDto fileRequestDto);

    /***
     *  删除文件
     *
     * @title 删除文件
     * @param url 文件地址
     * @return 是否删除成功
     * @author chengjie
     * @since v1.0.0
     */
    @PostMapping("/deleteFile")
    Response<Boolean> deleteFile(@RequestBody String url);
}
