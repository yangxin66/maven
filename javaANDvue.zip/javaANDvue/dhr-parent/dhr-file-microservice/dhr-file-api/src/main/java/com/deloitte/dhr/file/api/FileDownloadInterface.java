package com.deloitte.dhr.file.api;

import com.deloitte.dhr.file.api.dto.FilePreviewRequestDto;
import feign.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "dhr-file-microservice", path = "/api/v1/file")
public interface FileDownloadInterface {

    @GetMapping("/download")
    Response download(@RequestParam(name = "url") String url);

    @GetMapping("/preview")
    Response preview(@RequestBody FilePreviewRequestDto filePreviewRequestDto);
}
