package com.deloitte.dhr.common.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JSON,MAP值获取工具
 * JSON 基本fastjson
 * @author chunliucq
 * @since 20/09/2019 14:39
 */
public class ValueGetTool {

    /**
     * 根据Key值获取json对应的字符串值
     * 多层次json，key以'.'分隔
     * 数组以[N]指定数据定位
     * @param json
     * @param key
     * @return
     */
    public static String getStringFromJsonByKey(JSONObject json,String key){
        return (String)getObjectFromJsonByKey(json,key);
    }

    /**
     * 根据Key值获取json对应的JSONObject
     * 多层次json，key以'.'分隔
     * 数组以[N]指定数据定位
     * @param json
     * @param key
     * @return
     */
    public static JSONObject getJSONObjectFromJsonByKey(JSONObject json,String key){
        JSONObject jsonObject = (JSONObject)getObjectFromJsonByKey(json, key);
        return new JSONObject(jsonObject);
    }

    /**
     * 根据Key值获取json对应的JSONArray
     * 多层次json，key以'.'分隔
     * 数组以[N]指定数据定位
     * @param json
     * @param key
     * @return
     */
    public static JSONArray getJSONArrayFromJsonByKey(JSONObject json,String key){
        JSONArray jsonArr = (JSONArray)getObjectFromJsonByKey(json, key);
        return new JSONArray(jsonArr);
    }


    private static Object getObjectFromJsonByKey(JSONObject json,String key){
        if (key == null){
            return null;
        }
        String curKey = new StringBuffer(key).toString();
        JSONObject target = json;
        while(curKey != null){
            if (target == null){
                return null;
            }
            int dotIndex = curKey.indexOf(".");
            if (dotIndex < 0){
                boolean isValueArray = curKey.endsWith("]");
                if (isValueArray){
                    int leftIndex = curKey.indexOf("[");
                    String tempKey = curKey.substring(0,leftIndex);
                    String positionStr = curKey.substring(leftIndex + 1,curKey.length() - 1);
                    JSONArray jsonArray = target.getJSONArray(tempKey);
                    int position = Integer.parseInt(positionStr);
                    Object[] objArr = jsonArray.toArray();
                    if (position >=  objArr.length){
                        return null;
                    }
                    return  objArr[position];
                }else {
                    return target.get(curKey);
                }
            }
            String preKey = curKey.substring(0,dotIndex).trim();
            boolean isValueArray = preKey.endsWith("]");
            if (isValueArray){
                int leftIndex = preKey.indexOf("[");
                String tempKey = preKey.substring(0,leftIndex);
                String positionStr = preKey.substring(leftIndex + 1,preKey.length() - 1);
                int position = Integer.parseInt(positionStr);
                JSONArray jsonArray = target.getJSONArray(tempKey);
                Object[] objArr = jsonArray.toArray();
                target = (JSONObject) objArr[position];
            }else {
                target = target.getJSONObject(preKey);
            }
            curKey = curKey.substring(dotIndex + 1);
        }
        return null;
    }

    /**
     * 根据Key值获取Map对应的字符串值
     * 多层次Map，key以'.'分隔
     * @param map
     * @param key
     * @return
     */
    public static String getStringFromMap(Map map,String key){
        Object obj = getObjectFromMap(map,key);
        if (obj != null){
            return (String)obj;
        }
        return null;
    }

    /**
     * 根据Key值获取Map对应的字符串值
     * 多层次Map，key以'.'分隔
     * @param map
     * @param key
     * @return
     */
    public static Map getSubMapFromMap(Map map,String key){
        Object obj = getObjectFromMap(map,key);
        if (obj != null){
            HashMap hashMap = new HashMap();
            hashMap.putAll((Map)obj);
            return hashMap;
        }
        return null;
    }

    private static Object getObjectFromMap(Map map,String key){
        if (key == null || map == null){
            return null;
        }
        String[] keySplit = key.split("\\.");
        Map currentMap = map;
        for (int i = 0,len = keySplit.length; i < len; i++){
            String tmpKey = keySplit[i].trim();

            Object tmpObj = null;
            if (tmpKey.endsWith("]")){
                int dox = tmpKey.indexOf("[");
                String curKey = tmpKey.substring(0,dox);
                String positionStr = tmpKey.substring(dox + 1,tmpKey.length() - 1);
                int position = Integer.parseInt(positionStr);
                List<Object> objList = ( List<Object>)currentMap.get(curKey);
                if (objList != null && position >= 0 && position < objList.size()){
                    tmpObj = objList.get(position);
                }
            }else {
                tmpObj =  currentMap.get(tmpKey);
            }
            if (i == len - 1){
                return tmpObj;
            }
            if (tmpObj instanceof Map){
                currentMap = (Map)tmpObj;
            }else {
                return null;
            }
        }
        return null;
    }

    /**
     * 根据key，value 合并成map
     * Key Demo格式1：key1.key2.key3.k34
     * Key Demo格式2：key1.key2[2].key3[3].k34.key
     * @param keyArr
     * @param valueArr
     * @return
     */
    public static Map<String,Object> combinationKeyValueArrForMap(List<String> keyArr,List<Object> valueArr){
        if (keyArr == null || valueArr == null){
            return null;
        }
        Map<String,Object> result = new HashMap<>();
        int keyArrLen = keyArr.size();
        int valueArrLen = valueArr.size();
        for (int i = 0; i < keyArrLen; i++){
            String key = keyArr.get(i);
            Object value = null;
            if (i < valueArrLen){
                value = valueArr.get(i);
            }
            pushValueToMap(result,key,value);
        }
        return result;
    }

    /**
     * 向Map中指定key  push数据，若没有对应的key,增加对应的key值
     * Key Demo格式1：key1.key2.key3.k34
     * Key Demo格式2：key1.key2[2].key3[3].k34.key
     * @param map
     * @param key
     * @param value
     */
    public static void pushValueToMap(Map<String,Object> map,String key,Object value){
        if (map == null || key == null){
            return;
        }
        Map<String,Object> tmpMap = map;
        String[] keySplit = key.split("\\.");
        for (int i = 0,len = keySplit.length; i < len; i++){
            boolean isEnd = (i == len - 1);

            String tmpSubKey = keySplit[i].trim();
            if (tmpSubKey != null && tmpSubKey.endsWith("]")){
                int dotIndex = tmpSubKey.indexOf("[");
                String curKey = tmpSubKey.substring(0,dotIndex);
                String indexStr = tmpSubKey.substring(dotIndex + 1,tmpSubKey.length() - 1);
                int index = Integer.parseInt(indexStr);
                if (!tmpMap.containsKey(curKey)){
                    List<Map<String,Object>> mapList = new ArrayList<>();
                    tmpMap.put(curKey,mapList);
                }
                if (isEnd){
                    List<Object> objList = (List<Object>)tmpMap.get(curKey);
                    if (objList.size() > index){
                        objList.set(index,value);
                    }else {
                        for (int tmp_i = 0,difflen = index - objList.size();tmp_i < difflen; tmp_i++){
                            objList.add(null);
                        }
                        objList.add(value);
                    }
                    tmpMap = null;
                }else {
                    List<Map<String,Object>> mapList = (List<Map<String,Object>>)tmpMap.get(curKey);
                    if (mapList.size() >= index){
                        Map tmp = mapList.get(index -1);
                        if (tmp == null){
                            tmp = new HashMap();
                        }
                        mapList.set(index,tmp);
                        tmpMap = tmp;
                    }else {
                        for (int tmp_i = 0,difflen = index - mapList.size();tmp_i < difflen; tmp_i++){
                            mapList.add(null);
                        }
                        Map tmp = new HashMap();
                        mapList.add(tmp);
                        tmpMap = tmp;
                    }
                }
            }else {
                if (isEnd){
                    tmpMap.put(tmpSubKey,value);
                }else {
                    if (!tmpMap.containsKey(tmpSubKey)){
                        tmpMap.put(tmpSubKey,new HashMap<>());
                    }
                    tmpMap = (Map<String,Object>)tmpMap.get(tmpSubKey);
                }
            }
        }
    }

    public static void main(String[] args) {
        Map map = new HashMap();
        List<String> keyList = new ArrayList<>();
        List<Object> valueList = new ArrayList<>();

        keyList.add("aa.bb.cc.dd");
        valueList.add("abc");

        keyList.add("aa.bb.cx[2].xx[4]");
        valueList.add("abc");

        keyList.add("aa.bb.cx[2].xx[2].xxabc");
        valueList.add("ss");

        keyList.add("tt.ss.cc.d");
        valueList.add("dssdddsdsd");

        keyList.add("tx[1].ds");
        valueList.add("ds1sdddsdsd");

        map = combinationKeyValueArrForMap(keyList,valueList);
        System.out.println(map);
        System.out.println(Instant.now());

        Map tmp  = ValueGetTool.getSubMapFromMap(map,"tx[1]");
        System.out.println(tmp);
    }

}
