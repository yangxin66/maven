package com.deloitte.dhr.common.global.session;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户登录权限信息
 * 主要包括：用户登录ID，员工编号、部门ID、角色列表、权限列表
 * @author chunliucq
 * @since 25/09/2019 15:31
 */
@Data
public class CurrentLoginUserInfo {
    /**
     * 登录鉴权ClientID
     */
    private String clientID;
    /**
     * 登录用户名
     */
    private String loginUserName;

    /**
     * 登录员工编号
     */
    private String staffNo;

    /**
     * 员工姓名-姓
     */
    private String surName;

    /**
     * 员工姓名-名
     */
    private String preName;

    /**
     * 员工姓名
     */
    private String StaffName;

    /**
     * 员工部门ID
     */
    private String departmentId;
    /**
     * 部门名称
     */
    private String departmentName;

    /**
     * 角色列表
     */
    private List<Role> roleList;
    /**
     * 角色编码列表
     */
    private List<String> roleCodeList;

    /**
     * 资源列表
     */
    private List<Resource> resourceList;

    /**
     * 登录时间  yyyy-MM-dd HH:mm:ss:SSS
     */
    private String loginTime;

    @Data
    public static class Role{

        /**
         * 角名ID
         */
        private Long id;
        /**
         *
         */
        private String orgId;

        /**
         *
         */
        private String grantOrgs;
        /**
         * 角色Code
         */
        private String roleCode;

        /**
         * 角色名称
         */
        private String roleName;
    }

    @Data
    public static class Resource{
        /**
         * 资源ID
         */
        private Long id;
        /**
         * 部门ID
         */
        private String orgId;
        /**
         * 资源父ID
         */
        private Long parentId;
        /**
         * 资源名称
         */
        private String name;
        /**
         * 资源COde
         */
        private String code;
        /**
         * 资源URL
         */
        private String Uri;
        /**
         * 菜单级别
         */
        private Integer level;
        /**
         * 资源类型
         */
        private String type;


    }
}
