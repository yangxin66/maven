package com.deloitte.dhr.common.export;

import com.alibaba.fastjson.JSONArray;
import com.deloitte.dhr.common.export.model.ExportTitle;
import com.deloitte.dhr.common.export.model.SheetList;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;


/**
 * <br/>26/08/2019 17:26
 *
 * @author lshao
 */
public interface Exports {

    /**
     * 生成文档到指定的输出流
     * @param response HttpServletResponse对象
     * @param title 表格title
     * @param data 列表展示数据
     * @param fileName 文件名称
     */
    void generateDoucment(HttpServletResponse response, List<ExportTitle> title, JSONArray data, String fileName, List<Boolean> sendFlags) throws IOException,
            ParseException;


    HttpServletResponse generateDoucmentSheets(HttpServletResponse response,
                                List<SheetList> sheetLists,String fileName) throws IOException,
            ParseException;
}
