package com.deloitte.dhr.common.exception;

/**
 * 文件系统异常code
 * <br/>27/08/2019 15:45
 *
 * @author lshao
 */
public enum FileMateInfo {

    /**
     * 上传文件失败
     */
    UPLOAD_FILE_FAILURE_ERR("001-02-10000", "上传文件异常"),

    /**
     * 删除文件失败
     */
    DELETE_FILE_FAILURE_ERR("001-02-10001", "删除文件异常"),

    /**
     * 预览文件失败
     */
    PREVIEW_FILE_FAILURE_ERR("001-02-10002", "预览文件异常"),

    /**
     * 下载文件失败
     */
    DOWNLOAD_FILE_FAILURE_ERR("001-02-10003", "下载文件异常");

    private String code;
    private String message;

    FileMateInfo(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

}
