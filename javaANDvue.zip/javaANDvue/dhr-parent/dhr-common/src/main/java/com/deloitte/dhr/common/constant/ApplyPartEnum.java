package com.deloitte.dhr.common.constant;

public enum ApplyPartEnum {


    _BASE("基本信息"),

    _PARTY("党务信息"),

    _BANK("银行信息"),

    _HOME("家庭成员"),

    _ADDRESS("地址信息"),

    _URGENCY("紧急联系人"),

    _EDUCATION("学历信息"),

    _WORK("工作经历"),

    _TRAIN("培训信息"),

    _CAREER("职业资格"),

    _POSITION("职位信息"),

    _LANGUAGE("语言能力"),

    _AWARD("奖励情况"),

    _JIANZHI("外部兼职");

    private String value;

    ApplyPartEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
