package com.deloitte.dhr.common.global.session;


import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.constant.CommonConstant;
import com.deloitte.dhr.common.exception.HRMateInfo;
import com.deloitte.infrastructure.ex.BusinessException;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 * @author amzheng
 * @disc
 * @type
 * @creatTime 26/04/2019
 */
public class ContextSession {


    /**
     * 获取请求对象
     * @return
     */
    public static HttpServletRequest getHttpServletRequest(){
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (Objects.isNull(requestAttributes)) {
            return null;
        }
        return requestAttributes.getRequest();
    }

    /**
     * 获取用户登录JWT
     * @return
     */
    public static String getLoginUseToken() {
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (Objects.isNull(requestAttributes)) {
            return null;
        }
        HttpServletRequest request = requestAttributes.getRequest();
        String authToken = null;
        String headerAuthorization = "Authorization";
        String headerBearer = "Bearer";
        String authHeader = request.getHeader(headerAuthorization);
        if (!StringUtils.isEmpty(authHeader) && authHeader.startsWith(headerBearer)) {
            authToken = authHeader.substring(headerBearer.length()).trim();
        }
        if ("undefined".equals(authToken)){
            // 前端浏览器未获取到JWT时，JWT值为 undefined  ,此时为无效Token
            authToken = null;
        }
        return authToken;
    }

    /**
     * 获取JWT中的负载信息JWT.Payload
     * @return
     */
    public static JSONObject getTokenPayload(){
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (Objects.isNull(requestAttributes)) {
            return null;
        }
        HttpServletRequest request = requestAttributes.getRequest();
        String jwt = request.getHeader(CommonConstant.TOKEN_JWT);
        if (jwt == null){
            jwt = getLoginUseToken();
        }
        if (jwt == null){
            throw new BusinessException(HRMateInfo.STAFF_NO_NOT_LOGIN.getCode(),HRMateInfo.STAFF_NO_NOT_LOGIN.getMessage());
        }
        return getTokenPayload(jwt);
    }

    /**
     * 获取JWT中的负载信息JWT.Payload
     * @param jwtToken
     * @return
     */
    public static JSONObject getTokenPayload(String jwtToken){
        String[] jwtOriMsgArr = jwtToken.split("\\.");
        if(jwtOriMsgArr.length != 3){
            throw new BusinessException(HRMateInfo.STAFF_NO_SESSION_EXCEPTION.getCode(),HRMateInfo.STAFF_NO_SESSION_EXCEPTION.getMessage());
        }
        String payloadBase = jwtOriMsgArr[1];
        String payloadJson = new String(Base64.getUrlDecoder().decode(payloadBase));
        return JSONObject.parseObject(payloadJson);
    }

    /**
     * 从JWT中员工编号
     * @param jwt
     * @return
     */
    public static String getStaffFromJwt(String jwt){
        JSONObject payload = getTokenPayload(jwt);
        return payload.getString("staff_no");
    }

    /**
     * 从JWT中员工编号
     * @return
     */
    public static String getStaffNoFromJwt(){
        JSONObject payload = getTokenPayload();
        return payload == null ? null : payload.getString("staff_no");
    }

    /**
     * 获取当前登录用户权限信息
     * @return
     */
    public static CurrentLoginUserInfo getCurrentLoginUserInfo(){
        //设置登陆用户
//        if (1 == 1) {
//            CurrentLoginUserInfo cu = new CurrentLoginUserInfo();
//            cu.setStaffNo("1569325685456");
//            cu.setStaffName("cvd");
//            cu.setDepartmentName("xxxxxx");
//            cu.setRoleCodeList(Arrays.asList(new String[]{"hr"}));
//
//            return cu;
//        }

        HttpServletRequest request = getHttpServletRequest();
        if (request == null) {
            throw new BusinessException(HRMateInfo.SYSTEM_EXCETION.getCode(), HRMateInfo.SYSTEM_EXCETION.getMessage());
        }
        String loginInfoBase = request.getHeader(CommonConstant.LOGIN_USER_INFO);
        if (loginInfoBase == null) {
            throw new BusinessException(HRMateInfo.STAFF_NO_NOT_LOGIN.getCode(), HRMateInfo.STAFF_NO_NOT_LOGIN.getMessage());
        }
        byte[] loginInfoJsonBytes = Base64.getUrlDecoder().decode(loginInfoBase);
        CurrentLoginUserInfo loginInfo = null;
        try {
            String loginInfoJson = new String(loginInfoJsonBytes, "UTF-8");
            loginInfo = JSONObject.parseObject(loginInfoJson, CurrentLoginUserInfo.class);
        } catch (UnsupportedEncodingException e) {
            throw new BusinessException(HRMateInfo.SYSTEM_EXCETION.getCode(), HRMateInfo.SYSTEM_EXCETION.getMessage(), e);
        }
//        return loginInfo;
//        CurrentLoginUserInfo loginInfo = new CurrentLoginUserInfo();
//        loginInfo.setDepartmentId("1");
//        loginInfo.setDepartmentName("测试");
//        loginInfo.setStaffNo("1569325685456");
//        loginInfo.setStaffName("1111");
//        loginInfo.setRoleCodeList(Collections.singletonList("hr"));
//
//        loginInfo.setStaffNo("1569582477626");
//        loginInfo.setStaffName("1111");
//        loginInfo.setRoleCodeList(Collections.singletonList("1569582477626"));
        return loginInfo;
    }

    public static List<String> getCurrentLoginUserRoleCodes(){
        CurrentLoginUserInfo currentLoginUserInfo = getCurrentLoginUserInfo();
        return currentLoginUserInfo.getRoleCodeList();
    }
}
