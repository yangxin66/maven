package com.deloitte.dhr.common.constant;

/**
 * 常量字符串
 *
 * @author chunliucq
 * @since 18/09/2019 14:10
 */
public class CommonStringConstant {
    public final static String  BUSINESSNO_RID_KEY = "staff_info_record_id";
    public final static String  BUSINESSNO_APPLY_KEY = "staff_info_apply_no";
}
