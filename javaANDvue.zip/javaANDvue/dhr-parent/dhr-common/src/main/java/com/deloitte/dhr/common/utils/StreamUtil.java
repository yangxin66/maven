package com.deloitte.dhr.common.utils;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

/**
 * @author amzheng
 * 处理流相关的工具
 */
@Slf4j
public class StreamUtil {

    public static void writeExcel(HttpServletResponse response, InputStream inputStream) {

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "*");
        response.setContentType("application/octet_stream;charset=utf-8");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type,XFILENAME,XFILECATEGORY,XFILESIZE");
        write(response, inputStream);
    }

    public static void write(HttpServletResponse response, InputStream inputStream) {
        OutputStream out = null;
        try {
            out = response.getOutputStream();
            byte[] b = new byte[1024];
            int len;
            while ((len = inputStream.read(b, 0, 1024)) != -1) {
                response.getOutputStream().write(b, 0, len);
            }
            response.getOutputStream().flush();
        } catch (IOException e) {
            log.error("关闭流错误：{}", e.getMessage());
//            throw new BusinessException(WorkflowMateInfo.DEPLOY_STREAM_ERR.getCode(), WorkflowMateInfo.DEPLOY_STREAM_ERR.getMessage(), e);
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                log.error("关闭流错误：{}", e.getMessage());
            }
        }
    }

}
