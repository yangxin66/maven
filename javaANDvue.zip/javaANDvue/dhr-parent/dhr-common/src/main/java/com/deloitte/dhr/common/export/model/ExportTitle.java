package com.deloitte.dhr.common.export.model;

import lombok.Data;

/**
 * 表头实体
 * <br/>26/08/2019 18:21
 *
 * @author lshao
 */
@Data
public class ExportTitle {
    
    private String name;

    private String field;
}
