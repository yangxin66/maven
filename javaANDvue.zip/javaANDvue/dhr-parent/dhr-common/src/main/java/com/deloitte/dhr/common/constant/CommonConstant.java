package com.deloitte.dhr.common.constant;

/**
 * @author amzheng
 * @disc
 * @type
 * @creatTime 26/04/2019
 */
public class CommonConstant {
    /**
     * jwt
     */
    public static final String TOKEN_JWT = "token-jwt";

    /**
     * jwt存储对象主键
     */
    public static final String LOGIN_USER_ID = "loginUserId";
    public static final String LOGIN_USER_INFO= "loginUserInfo";

    /**
     * jwt存储对象主键
     */
    public static final String LOGIN_USER_OID = "loginUserOid";
    public static final String LOGIN_USER_DEPARTMENT_ID = "loginUserDepartmentId";

    public static final String LOING_USER_REDIS_JWT_ID = "LOGIN:SESSION:USERINFO:JWT";
    public static final String LOING_USER_REDIS_INFO_ID = "LOGIN:SESSION:USERINFO:INFO:";
}
