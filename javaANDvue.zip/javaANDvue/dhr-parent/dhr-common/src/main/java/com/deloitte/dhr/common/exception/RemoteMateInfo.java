package com.deloitte.dhr.common.exception;

/**
 * 调用第三方的异常code
 * <br/>27/08/2019 15:45
 *
 * @author lshao
 */
public enum RemoteMateInfo {

    SAP_INVOKE_ERR("001-00-10000", "sap的RFC调用失败");

    private String code;
    private String message;

    RemoteMateInfo(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
