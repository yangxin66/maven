package com.deloitte.dhr.common.export;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.deloitte.dhr.common.export.model.*;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;


import javax.servlet.http.HttpServletResponse;

import java.io.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <br/>26/08/2019 18:20
 *
 * @author lshao
 */
public class ExcelExportImpl implements Exports {


    /**
     * 生成一个sheet的excel
     *
     * @param response  HttpServletResponse对象
     * @param title     表格title
     * @param data      列表展示数据
     * @param fileName  文件名称
     * @param sendFlags
     * @throws IOException
     * @throws ParseException
     */
    @Override
    public void generateDoucment(HttpServletResponse response, List<ExportTitle> title, JSONArray data, String fileName, List<Boolean> sendFlags) throws IOException, ParseException {

//        fileName=fileName+".xls";

//        ReadyOutputStream(response,fileName);
//        response.reset();// 清空输出流
////        String filename = response.encodeURL(new String((fileName + ".xls").getBytes(StandardCharsets.UTF_8)));
//        response.setHeader("Access-Control-Allow-Origin", "*");
//        response.setHeader("Access-Control-Allow-Methods", "*");
//        response.setHeader("Content-Disposition", "attachment;filename=utf-8'zh_cn'" + fileName + ".xls");
//        response.setContentType("application/octet_stream;charset=utf-8");
//        response.setHeader("Access-Control-Allow-Headers", "Content-Type,XFILENAME,XFILECATEGORY,XFILESIZE");
//        //  response.setContentType("application/vnd.ms-excel;charset=UTF-8");// 定义输出类型
//
//        response.setCharacterEncoding("UTF-8");
        //fileName = URLEncoder.encode(fileName, "UTF-8");


        //  创建一个工作簿
        HSSFWorkbook wb = new HSSFWorkbook();
        ReadyStream(response, fileName);
        //  创建一个工作表
        HSSFSheet sheet = wb.createSheet("sheet1");
        sheet.setDefaultRowHeightInPoints(20);

        OutputStream os = response.getOutputStream();
        //设置日期格式
        HSSFCellStyle cellStyle = wb.createCellStyle();
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        // HSSFDataFormat format= wb.createDataFormat();
        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
        //创建表格的title
        HSSFRow titleRow = sheet.createRow(0);

        for (int i = 0; i < title.size(); i++) {
            //ExportTitle exportTitle=title[i];
            HSSFCell cell = titleRow.createCell(i);
            cell.setCellValue(title.get(i).getName());
            sheet.setColumnWidth(cell.getColumnIndex(), 256 * 30);
            //把格式写入单元格
            cell.setCellStyle(cellStyle);

        }

        //插入表格中的数据
        //  创建行
        for (int i = 0; i < data.size(); i++) {
            HSSFRow row = sheet.createRow(i + 1);
            //JSONObject object = data.getJSONObject(i);
            for (int j = 0; j < title.size(); j++) {

                JSONObject object = data.getJSONObject(i);
                ExportTitle exportTitle1 = title.get(j);
                String[] titles = exportTitle1.getField().split("\\.");

                //如果第一层没有
                if (titles.length > 1) {
                    LayerOneNotData(sheet, cellStyle, row, j, object, titles);
                } else {
                    HSSFCell cell = row.createCell(j);
                    // ExportTitle exportTitle=title.get(j);
                    if (titles[0].equals("sendFlag")) {
                        if (sendFlags.get(i)) {
                            cell.setCellValue("待审核");
                        } else {
                            cell.setCellValue("未发送邮件");
                        }
                    } else if (titles[0].equals("reviewFlag  ")) {
                        cell.setCellValue("已审核");
                    } else if (titles[0].equals("_OPTIONTIME")) {
                        String string = object.getString(titles[0]);
                        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        Date date = sDateFormat.parse(string);
                        cell.setCellValue(date);
                    } else {
                        if (object.getString(titles[0]) == null || StringUtils.isEmpty(object.getString(titles[0]))) {
                            cell.setCellValue("暂无数据");
                        } else {
                            cell.setCellValue(object.getString(titles[0]));
                        }
                    }
                    cell.setCellStyle(cellStyle);
                    sheet.setColumnWidth(cell.getColumnIndex(), 256 * 50);
                }
            }
        }
        wb.write(os); // 写入文件
        os.flush();
        os.close();
    }

    /**
     * 生成多个sheet的excel文件
     *
     * @param response
     * @param sheetLists sheet的list
     * @throws IOException
     * @throws ParseException
     */
    @Override
    public HttpServletResponse generateDoucmentSheets(HttpServletResponse response, List<SheetList> sheetLists, String fileName) throws IOException, ParseException {

        ResponseEntity responseEntity = null;
        HttpHeaders headers = new HttpHeaders();

        ReadyStream(response, fileName);
        HSSFWorkbook wb = new HSSFWorkbook();
        OutputStream os = response.getOutputStream();
        InputStream is = null;
        //  创建一个工作表
        for (SheetList sheetList : sheetLists) {
            try {
                HSSFSheet sheet = wb.createSheet(sheetList.getSheetName());
                JSONArray data = sheetList.getData();
                List<ExportTitle> title = sheetList.getTitle();
                List<Boolean> sendFlags = sheetList.getSendFlags();
                CreateTitle(wb,title,sheet);//写入表头
                WriteCellValue(data,title,sheet,wb,sendFlags);//写入数据
                wb.write(os); // 写入文件
                os.flush();
            } finally {
                os.close();
            }
        }
        return response;
    }

    public void ReadyStream(HttpServletResponse response, String fileName) throws UnsupportedEncodingException {
        response.reset();// 清空输出流
//        String filename = URLEncoder.encode(fileName,"utf-8") + ".xls";
//        String filename = HttpUtility.UrlEncode(fileName, System.Text.Encoding.GetEncoding("UTF-8"));
        String filename = response.encodeURL(new String((fileName + ".xls").getBytes("UTF-8"), "ISO-8859-1"));
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "*");
        response.setHeader("Content-Disposition", "attachment;filename=" + filename);
        response.setContentType("application/octet_stream;charset=utf-8");
//        response.setHeader("Access-Control-Allow-Headers", "Content-Type,XFILENAME,XFILECATEGORY,XFILESIZE");
        response.setCharacterEncoding("UTF-8");
    }

    /**
     * 如果数据不是在第一层时
     * @param sheet  sheet
     * @param cellStyle  单元格格式
     * @param row 行数
     * @param j  第几条
     * @param object 数据
     * @param titles  表头数据
     */
    private void LayerOneNotData(HSSFSheet sheet, HSSFCellStyle cellStyle, HSSFRow row, int j, JSONObject object, String[] titles) {
        for (int k = 0; k < titles.length - 1; k++) {
            object = object.getJSONObject(titles[k]);
            if (k == titles.length - 2) {
                HSSFCell cell = row.createCell(j);
                if (object.getString(titles[k + 1]) == null || StringUtils.isEmpty(object.getString(titles[k + 1]))) {
                    cell.setCellValue("暂无数据");
                } else {
                    cell.setCellValue(object.getString(titles[k + 1]));
                }
                //把格式写入单元格
                cell.setCellStyle(cellStyle);
                sheet.setColumnWidth(cell.getColumnIndex(), 256 * 20);
            }
        }
    }

    /**
     * 创建表头
     * @param wb  工作簿
     * @param title   表头数据
     * @param sheet   工作表
     */
    public void CreateTitle(HSSFWorkbook wb, List<ExportTitle> title, HSSFSheet sheet){
        HSSFRow titleRow = sheet.createRow(0);
        HSSFCellStyle cellStyle = wb.createCellStyle();
        sheet.setDefaultRowHeightInPoints(20);
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        // HSSFDataFormat format= wb.createDataFormat();
        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));

        for (int i = 0; i < title.size(); i++) {
            //ExportTitle exportTitle=title[i];
            HSSFCell cell = titleRow.createCell(i);
            cell.setCellValue(title.get(i).getName());
            sheet.setColumnWidth(cell.getColumnIndex(), 200 * 20);
            //把格式写入单元格
            cell.setCellStyle(cellStyle);

        }
    }

    /**
     *    添加单元格数据
     * @param data  数据
     * @param title  表头
     * @param sheet  工作表
     * @param wb  工作簿
     * @param sendFlags  一些参数
     * @throws ParseException
     */
    private void WriteCellValue(JSONArray data,List<ExportTitle> title,HSSFSheet sheet,HSSFWorkbook wb,List<Boolean> sendFlags) throws ParseException {
        HSSFCellStyle cellStyle = wb.createCellStyle();
        sheet.setDefaultRowHeightInPoints(20);
        cellStyle.setAlignment(HorizontalAlignment.CENTER);//水平居中
        cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);//垂直居中
        // HSSFDataFormat format= wb.createDataFormat();
        cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
        for (int i = 0; i < data.size(); i++) {
            HSSFRow row = sheet.createRow(i + 1);
            //JSONObject object = data.getJSONObject(i);
            for (int j = 0; j < title.size(); j++) {

                JSONObject object = data.getJSONObject(i);
                ExportTitle exportTitle1 = title.get(j);
                String[] titles = exportTitle1.getField().split("\\.");

                //如果第一层没有
                if (titles.length > 1) {
                    LayerOneNotData(sheet, cellStyle, row, j, object, titles);
                } else {
                    HSSFCell cell = row.createCell(j);
                    // ExportTitle exportTitle=title.get(j);
//                            if (titles[0].equals("_DATA_PART_NAME")) {
//                                cell.setCellValue(ApplyPartEnum.valueOf(object.getString("_DATA_PART")).getValue());
//                            }
//                            else if (titles[0].equals("_APPLY_STATUS")) {
//                                if (object.getString("_APPLY_STATUS").equals(ApproveStatusEnum.APPROVAL_PENDING.toString())) {
//                                    cell.setCellValue(ApproveStatusEnum.APPROVAL_PENDING.getValue());
//                                } else if (object.getString("_APPLY_STATUS").equals(ApproveStatusEnum.APPROVED.toString())) {
//                                    cell.setCellValue(ApproveStatusEnum.APPROVED.getValue());
//                                } else if (object.getString("_APPLY_STATUS").equals(ApproveStatusEnum.REJECT.toString())) {
//                                    cell.setCellValue(ApproveStatusEnum.REJECT.getValue());
//                                } else if (object.getString("_APPLY_STATUS").equals(ApproveStatusEnum.CLOSE.toString())) {
//                                    cell.setCellValue(ApproveStatusEnum.CLOSE.getValue());
//                                }else if (object.getString("_APPLY_STATUS").equals(ApproveStatusEnum.UNAPPROVED.toString())) {
//                                    cell.setCellValue(ApproveStatusEnum.UNAPPROVED.getValue());
//                                }else {
//                                    cell.setCellValue(ApproveStatusEnum.SUBMITTED.getValue());
//                                }
//                            }
//                            else
                    if (titles[0].equals("sendFlag")) {
                        if (sendFlags.get(i)) {
                            cell.setCellValue("待审核");
                        } else {
                            cell.setCellValue("未发送邮件");
                        }
                    } else if (titles[0].equals("reviewFlag")) {
                        cell.setCellValue("已审核");
                    } else if (titles[0].equals("_OPTIONTIME") || titles[0].equals("_APPLY_TIME") || titles[0].equals("_AUDIT_TIME")) {
                        String string = object.getString(titles[0]);
                        if (string != null) {
                            SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                            Date date = sDateFormat.parse(string);
                            cell.setCellValue(date);
                        } else {
                            cell.setCellValue("暂无数据");
                        }
                        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        Date date = sDateFormat.parse(string);
                        cell.setCellValue(date);
                    } else {
                        if (object.getString(titles[0]) == null || StringUtils.isEmpty(object.getString(titles[0]))) {
                            cell.setCellValue("暂无数据");
                        } else {
                            cell.setCellValue(object.getString(titles[0]));
                        }
                    }
                    cell.setCellStyle(cellStyle);
                    sheet.setColumnWidth(cell.getColumnIndex(), 200 * 20);
                }
            }
        }
    }

}
