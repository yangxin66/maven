package com.deloitte.dhr.common.utils;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * JWT工具类
 */
public class JwtUtil {
  private static final Logger log = LoggerFactory.getLogger(JwtUtil.class);

  /**
   * token密钥
   */
  private static String SECRET_KEY = "psc@deloitte.com.cn-DHR-common-jwt-cq-cn-2019-09-27-20-50-00";

  /**
   * 生成token的方法，参数组装成一个JSONObject
   * @param jsonObject
   * @return
   * @throws JOSEException
   */
  public static String createToken(JSONObject jsonObject){
    Payload payload = new Payload(jsonObject);
    JWSHeader header = new JWSHeader(JWSAlgorithm.HS256);
    JWSObject jwsObject = new JWSObject(header,payload);
    try {
      jwsObject.sign(new MACSigner(SECRET_KEY));
    } catch (JOSEException e) {
      throw new RuntimeException("创建token错误");
    }
    return jwsObject.serialize();
  }

  /**
   * 解析token 返回空即可认为是错误token
   * @param token
   * @return
   */
  public static JSONObject verifyToken(String token){
    try{
      JWSObject object = JWSObject.parse(token);
      Payload payload = object.getPayload();
      JWSVerifier verifier = new MACVerifier(SECRET_KEY);
      if(object.verify(verifier)){
        return payload.toJSONObject();
      }
    }catch (Exception e){
      log.error(e.getMessage());
    }
    return null;
  }

}
