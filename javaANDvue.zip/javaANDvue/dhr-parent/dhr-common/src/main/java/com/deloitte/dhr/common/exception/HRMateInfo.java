package com.deloitte.dhr.common.exception;

/**
 * HR异常code、message
 * <br/>27/08/2019 15:44
 *
 * @author lshao
 */
public enum HRMateInfo {
    SYSTEM_EXCETION("001-00-00000","系统异常,请联系管理员处理"),
    STAFF_NO_NOT_LOGIN("001-00-00001", "用户未登录,请重新登录"),
    STAFF_NO_SESSION_EXCEPTION("001-00-00002", "用户会话异常,请重新登录"),
    STAFF_NO_FORBIDDEN_EXCEPTION("001-00-00003", "用户权限不足,无法访问"),
    STAFF_NO_LOGIN_EXCEPTION("001-00-00004", "用户登录异常,无法访问"),

    VERIFY_NOT_EQUAL_ERR("001-01-10000", "用户不匹配"),

    VERIFY_UNKNOW_ERR("001-01-10001", "身份证或姓名有误"),

    VERIFY_PARAMETER_ERR("001-01-10002", "参数错误"),

    APPROVE_UNKNOW_ERR("001-01-10003", "审核出现错误"),

    STAFF_CODE_REPEAT_ERR("001-01-10004", "员工编码重复"),

    STAFF_NOT_FOUND_ERR("001-01-10005", "员工编号错误，未找到该员工"),

    STAFF_INFO_IN_COMPLETE_ERR("001-01-10006", "该员工信息不完整"),

    UPLOAD_ERR("001-01-10007", "上传失败"),

    DOWNLOAD_ERR("001-01-10008", "下载失败"),

    STAFF_INFO_NONE_ERR("001-01-10009", "缺失员工编号列表参数"),

    STAFF_CODE_IS_EMPTY_ERR("001-01-10010", "员工编码不能为空"),

    HR_BATCH_APPROVE_RNTRY_DATA_IS_EMPTY_ERR("001-01-10011", "HR批量审核数据不能为空"),

    STAFF_SEARCH_IS_EMPTY_ERR("001-01-10012", "搜索项不能为空"),

    SEND_REJECT_EMAIL_IS_EMPTY_ERR("001-01-10013", "缺失驳回参数"),

    DATA_NONULL_IS_EMPTY_ERR("001-01-10014", "选择不能为空"),

    DOWNLOAD_IS_NULL_IS_EMPTY_ERR("001-01-10015", "下载内容为空"),

    EXPORT_STAFF_INFO_ERR("001-01-10016", "员工信息导出异常"),

    EXPORT_STAFF_INFO_TRANS_ERR("001-01-10017", "员工信息参数转换异常"),

    STAFF_INFO_UPDATE_APPLY_ERR_APPNO_NONE("001-01-10018", "员工信息修改申请记录未找到"),

    STAFF_INFO_UPDATE_APPLY_ERR_RID_NONE("001-01-10019", "员工信息修改申请变化记录未找到"),

    STAFF_INFO_UPDATE_APPLY_REQUEST_ERR("001-01-10020", "请求参数格式错误"),

    APPLYNO_ISNULL("001-01-10021", "申请编号为空"),

    AUDIT_PARAMETER_IS_NULL("001-01-10022", "缺失审批参数"),

    CURRENT_LOGIN_STAFF_NO_ERR("001-01-10023", "当前登录用户员工编号有误"),

    AUDIT_PARAMETER_INSTANT_ID_IS_ERR("001-01-10024", "审核参数的流程实例id或任务id有误"),

    STAFF_UPDATE_APPLY_NO_IS_ERR("001-01-10025", "员工信息修改申请的业务编号有误"),

    STAFF_INFO_APPLY_NOT_FOUND_ERR("001-01-10026", "未找到员工信息修改申请数据"),
    STAFF_INFO_REGISTER_USER_ERR("001-01-10027", "员工同步注册登录用户失败"),

    SEARCH_STAFF_INFO_KEYWORD_IS_EMPTY("001-01-10027", "员工信息搜索关键字不能为空"),

    STAFF_INFO_EMAIL_OR_NAME_IS_EMPTY_ERR("001-01-10028", "该员工的邮箱或姓名缺失"),

    STAFF_INFO_MODIFY_DATA_IS_EMPTY_ERR("001-01-10029", "员工信息修改数据不能为空"),

    STAFF_INFO_MODIFY_RID_ERR("001-01-10030", "员工信息修改数据中的_RID不能为空"),

    STAFF_INFO_MODIFY_STAFF_NO_ERR("001-01-10031", "员工信息修改数据中的员工编号不能为空"),

    STAFF_INFO_MODIFY_ADD_IS_ERR("001-01-10032", "该员工信息模块不允许新增多条数据"),

    STAFF_INFO_MODIFY_UPDATE_IS_ERR("001-01-10032", "该员工信息模块修改数据失败，未找到该数据"),

    APPLY_REMARK_LONG_OVER_LONG_ERR("001-01-10033", "申请备注长度过长"),

    PROCESSINSTANCE_ID_ISNULL_ERR("001-01-10034", "流程实例id不能为空"),

    STAFF_INFO_MODIFY_STATUS_IS_ERR("001-01-10035", "员工信息更新异常，暂不支持该状态"),

    SEARCH_TYPE_IS_UNSUPPORT_ERR("001-01-10036", "不支持该搜索类型"),
    STAFF_LOGIN_QUERY_STAFF_INFO_ERR("001-01-10037", "获取员工信息失败"),
    STAFF_LOGIN_QUERY_ROLE_ERR("001-01-10038", "获取员工角色信息失败"),
    STAFF_LOGIN_QUERY_RESOURCES_ERR("001-01-10039", "获取员工资源信息失败"),

    AUDIT_PARAMETER_APPLYNO_ERR("001-01-10040", "审核参数异常，业务编号不存在"),

    SEARCH_CONDITION_ERR("001-01-10041", "搜索待办已办列表条件错误，条件必须包含申请时间并且只能搜索一年内的数据"),

    TIME_TRANS_ERR("001-01-10042", "时间格式转换错误"),

    ADD_MESSAGE_DATA_IS_NULL_ERR("001-01-10043", "新增消息数据不能为空"),

    MODIFY_STAFF_INFO_OP_IS_ERR("001-01-10044", "修改的数据无操作类型或操作类型有误, 信息更新失败"),

    QUERY_MESSAGE_TYPE_IS_ERR("001-01-10045", "查询消息类型有误"),

    CURRENT_NODE_NOT_SUPPORT_REJECT("001-01-10046", "当前节点状态不支持驳回至上一级"),

    BUSINESS_TYPE_IS_ERR("001-01-10047", "业务类型有误"),
    APPLY_START_PROCESS_ERR("001-01-10048", "申请启动流程异常,处理失败"),
    APPLY_MODIFY_BUSIDATA_ERR("001-01-10049", "修改业务数据失败"),
    ;

    /**
     * 异常编码
     */
    private String code;

    /**
     * 异常信息
     */
    private String message;

    HRMateInfo(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public String getCode() {
        return code;
    }
}
