package com.deloitte.dhr.common.utils;

import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.communication.pagination.PaginationResponse;
import com.deloitte.infrastructure.communication.pagination.SortPair;
import com.deloitte.infrastructure.ex.BusinessException;

import java.util.List;

/**
 * Response对象生成器
 *
 * @author chunliucq
 * @since 03/09/2019 11:04
 */
public class ResponseUtil<T> {

    private static ResponseUtil instance = new ResponseUtil();

    private ResponseUtil() {
    }

    public static ResponseUtil build() {
        return instance;
    }

    public Response<T> creatDeaultOkResponse(T data) {
        return new Response<>(LanguageEnum.ZH_CN, Response.SUCCESS_CODE, "success", data);
    }

    public Response<T> creatDeaultOkResponse(LanguageEnum lang, T data) {
        return new Response<>(lang, Response.SUCCESS_CODE, "success", data);
    }

    public Response<T> createBadResponse(BusinessException e) {
        return new Response<>(LanguageEnum.ZH_CN, e.getCode(), e.getMessage(), null);
    }

    public Response<T> createBadResponse(BusinessException e, T data) {
        return new Response<>(LanguageEnum.ZH_CN, e.getCode(), e.getMessage(), data);
    }

    public Response<T> createBadResponse(LanguageEnum lang, BusinessException e, T data) {
        return new Response<>(lang, e.getCode(), e.getMessage(), data);
    }

    public Response<T> createBadResponse(LanguageEnum lang, BusinessException e) {
        return new Response<>(lang, e.getCode(), e.getMessage(), null);
    }

    public Response<T> createBadResponse(String code, String message, T data) {
        return new Response<>(LanguageEnum.ZH_CN, code, message, data);
    }

    public Response<T> createBadResponse(String code, String message) {
        return new Response<>(LanguageEnum.ZH_CN, code, message, null);
    }

    public Response<T> createBadResponse(LanguageEnum lang, String code, String message, T data) {
        return new Response<>(lang, code, message, data);
    }

    public PaginationResponse<T> creatDeaultOkPaginationResponse(LanguageEnum language, int page, int size, int total,
                                                                 List<SortPair> sortBy, T data) {
        return new PaginationResponse(language,
                page,
                size,
                total,
                sortBy,
                Response.SUCCESS_CODE, "success", data);
    }

    public PaginationResponse<T> creatBadPaginationResponse(LanguageEnum language, String code, String message) {
        return new PaginationResponse(language,
                0,
                0,
                0,
                null,
                code, message, null);
    }

}
