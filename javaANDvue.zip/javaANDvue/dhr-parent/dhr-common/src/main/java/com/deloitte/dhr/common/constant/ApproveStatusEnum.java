package com.deloitte.dhr.common.constant;

/**
 * date: 17/09/2019 20:14
 *
 * @author wgong
 * @since 0.0.1
 */
public enum ApproveStatusEnum {
    /**
     * 待审批
     */
    APPROVAL_PENDING("待审批"),

    /**
     * 审核通过
     */
    APPROVED("审核通过"),
    /**
     * 审核不通过
     */
    UNAPPROVED("审核不通过"),

    /**
     * 关闭流程
     */
    CLOSE("已关闭流程"),

    /**
     * 驳回
     */
    REJECT("已驳回"),

    /**
     * 提交
     */
    SUBMITTED("已提交"),

    /**
     * 已删除流程
     */
    DELETE("已删除流程"),

    /**
     * 待提交
     */
    PRE_SUBMIT("待提交");

    private String value;

    ApproveStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
