package com.deloitte.dhr.common.export.model;

import com.alibaba.fastjson.JSONArray;
import lombok.Data;

import java.util.List;


@Data
public class SheetList {
    //sheet名字
    private String sheetName;
    //这个sheet的表头
    private List<ExportTitle> title;
    //这个sheet的数据
    private JSONArray data;
    //这个sheet中数据为特殊的字段
    private List<Boolean> sendFlags;
}
