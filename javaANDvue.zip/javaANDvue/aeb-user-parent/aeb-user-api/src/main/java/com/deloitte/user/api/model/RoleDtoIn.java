package com.deloitte.user.api.model;



import lombok.Data;


@Data
public class RoleDtoIn {


    private String roleName;

    private String orgId;

    private String grantOrgs;

    private String code;

}
