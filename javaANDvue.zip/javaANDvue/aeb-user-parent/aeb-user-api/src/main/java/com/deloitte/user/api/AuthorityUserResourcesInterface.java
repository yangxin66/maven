package com.deloitte.user.api;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.user.api.model.*;
import org.bouncycastle.i18n.LocaleString;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Set;


@FeignClient(value = "AEB-USER", path = "/api/v1/hr/authority")
public interface AuthorityUserResourcesInterface {

    @PostMapping("/role/info")
    Response<List<RoleDtoOut>> queryRole(@RequestBody Request<String> roleName);

    @PostMapping("/role/save")
    Response<Void> saveRole(@RequestBody Request<RoleDtoIn> roleDtoInRequest);

    @PostMapping("/role/update")
    Response<RoleDtoOut> updateRole(@RequestBody Request<RoleDtoOut> roleDtoOutRequest);

    @PostMapping("/role/remove")
    Response<Void> removeRole(@RequestBody Request<Long> requestId);



    @PostMapping("/roleuser/info")
    Response<List<RoleUserRelDto>> queryRoleUser(@RequestBody Request<String> pernr);

    @PostMapping("/roleuser/update")
    Response<Void> UpdateRoleUser(@RequestBody Request<UpdateRoleUser> updateRoleUserRequest);

    @PostMapping("/roleuser/remove")
    Response<Void> removeRoleUser(@RequestBody Request<String> request);

    @PostMapping("/roleuser/save")
    Response<Void> saveRoleUserRel(@RequestBody Request<RoleUserRelDto> roleUserRelDtoRequest);



    @PostMapping("/resources/save")
    Response<Void> saveResources(@RequestBody Request<ResourcesDto> resourcesDtoRequest);

    @PostMapping("/resources/remove")
    Response<Void> removeResources(@RequestBody Request<Long> request);

    @PostMapping("/resources/query")
    Response<List<ResourcesDto>> queryResourcesList(@RequestBody Request<String> request);

    @PostMapping("/resources/queryidlist")
    Response<List<ResourcesDto>> queryResourcesId(@RequestBody Request<List<Long>> listRequest);

    @PostMapping("/resources/queryid/")
    Response<ResourcesDto> queryResources(@RequestBody Request<Long> longRequest);

    @PostMapping("/resources/update")
    Response<ResourcesDto> updateResources(@RequestBody Request<ResourcesDto> resourcesDtoRequest);



    @PostMapping("/roleresources/save")
    Response<Void> saveRoleResources(@RequestBody Request<RoleResourcesDto> roleResourcesDtoRequest);

    @PostMapping("/roleresources/queryres")
    Response<List<RoleResourcesDto>> queryRoleResourcesRes(@RequestBody Request<Long> request);

    @PostMapping("/roleresources/queryro")
    Response<List<RoleResourcesDto>> queryRoleResourcesRo(@RequestBody Request<Long> request);

    @PostMapping("/roleresources/querylist")
    Response<Set<RoleResourcesDto>> queryRoleResourcesList(@RequestBody Request<List<Long>> listRequest);

    @PostMapping("/roleresources/update")
    Response<RoleResourcesDto> updateRoleResources(@RequestBody Request<RoleResourcesDto> roleResourcesDtoRequest);

    @PostMapping("/roleresources/remove")
    Response<Void> removeRoleResources(@RequestBody Request<Long> longRequest);


    @PostMapping("/power/user")
    Response<List<ResourcesDto>> queryUserResources(@RequestBody Request<String> pernrRequest);


    @PostMapping("/power/userandtype")
    Response<List<ResourcesDto>> queryUserResourcesByType(@RequestBody Request<String> pernrRequest);

    @PostMapping("/authority/usertorole")
    Response<List<RoleDtoOut>> queryUserRoleInfo(@RequestBody Request<String> pernrRequest);

//    @PostMapping("/authority/roletoresources")
//    Response<List<ResourcesDto>> queryRoleResourcesInfoByRoleType(@RequestBody Request<String> roleTypeRequest);

    @PostMapping("/authority/roletoresources")
    Response<List<ResourcesDto>> queryRoleResourcesInfo(@RequestBody Request<Long> longRequest);

    @PostMapping("/authority/roleresources/byidtype")
    Response<List<ResourcesDto>> queryRoleResourcesInfoByTypeAndId(@RequestBody Request<ResourcesByTypeAndId> longRequest);

    @PostMapping("/authority/roleresources/byPernrtype")
    Response<List<ResourcesDto>> queryUserResourcesInfoByPernrAndCode(@RequestBody Request<ResourcesByTypeAndPernr> resourcesByTypeAndPernrRequest);

    @PostMapping("/authority/roleresources/byrolecode")
    Response<List<ResourcesDto>> queryRoleResourcesInfoAndCode(@RequestBody Request<String> request);


}
