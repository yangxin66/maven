package com.deloitte.user.api.model;

import lombok.Data;

@Data
public class UpdatePower {

    Long id;
    UpdateRole updateRole;
}
