package com.deloitte.user.api.model;



import lombok.Data;


@Data
public class RoleUserRelDto {

    private Long id;

    private String pernr;

    private String orgId;

    private Long RoleId;

}
