package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 邮箱验证，用于发送邮件前的校验
 *
 * @author lshao
 */
@Data
public class EmailVerifyDto implements Serializable {

    private static final long serialVersionUID = 7771107405602336419L;

    @Length(max = 30, message = "邮箱总长度不能超过30位")
    @NotBlank(message = "邮箱不能为空")
    @Email(message = "邮箱格式错误")
    private String email;

    @Length(max = 10, message = "图形验证码长度不能超过10位")
    @NotBlank(message = "图形验证码不能为空")
    private String imgCode;
}
