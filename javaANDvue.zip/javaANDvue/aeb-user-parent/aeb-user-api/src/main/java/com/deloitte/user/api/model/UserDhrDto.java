package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * @author chunliucq
 * @since 24/09/2019 11:49
 */
@Data
public class UserDhrDto implements Serializable {
    @Length(max = 11, message = "手机号码必须为11位")
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^[1]([3-9])[0-9]{9}$", message = "手机号码错误，请使用中国大陆11位手机号注册")
    private String mobile;

    @NotBlank(message = "邮箱不能为空")
    private String email;

    @NotBlank(message = "员工编号不能为空")
    private String staffNo;

    /**
     * 密码
     */
    @Length(max = 30, message = "密码总长度不能超过30位")
    @NotBlank(message = "密码不能为空")
    private String password;
}
