package com.deloitte.user.api;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用于获取图形验证码
 */
@FeignClient(value = "AEB-USER", path = "/api/v1/users/img_verify")
public interface ImgVerifyRestInterface {
    /**
     * 默认以验证码为键进行缓存的图形验证码
     */
    @GetMapping("getCodeImg")
    void getCodeImg(HttpServletRequest request, HttpServletResponse response) throws IOException;
    /**
     * 自定义键进行缓存的图形验证码
     */
    @GetMapping("getCodeImg")
    void getCodeImg(HttpServletRequest request, HttpServletResponse response,String key) throws IOException;
}
