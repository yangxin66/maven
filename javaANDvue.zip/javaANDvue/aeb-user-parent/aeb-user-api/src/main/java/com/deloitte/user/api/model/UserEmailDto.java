package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * 邮箱注册\密码更新 传输实体
 *
 * @author lshao
 */
@Data
public class UserEmailDto implements Serializable {

    private static final long serialVersionUID = 422840971761414941L;


    @Length(max = 100, message = "token不超过100位")
    @NotBlank(message = "token不能为空")
    private String token;

    @Length(max = 100, message = "密码长度不能超过100位")
    @NotBlank(message = "密码不能为空")
    @Pattern(regexp = "^(?=.*[0-9].*)(?=.*[A-Z].*)(?=.*[a-z].*)(?=.*[^A-Za-z0-9].*).{10,15}$",
            message = "密码长度应为10-15位，必须包含大写字母、小写字母、数字、特殊字符")
    private String password;

}
