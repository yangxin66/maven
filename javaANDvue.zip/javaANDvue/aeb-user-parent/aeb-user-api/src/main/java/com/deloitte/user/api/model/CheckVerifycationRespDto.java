package com.deloitte.user.api.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class CheckVerifycationRespDto implements Serializable {
    /*
     * 验证码验证结果
     */

    @ApiModelProperty
    private boolean checkResult;
}
