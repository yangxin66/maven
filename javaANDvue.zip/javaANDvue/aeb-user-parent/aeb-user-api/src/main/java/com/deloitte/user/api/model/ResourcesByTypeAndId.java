package com.deloitte.user.api.model;

import lombok.Data;

@Data
public class ResourcesByTypeAndId {
    Long id;
    String type;

}
