package com.deloitte.user.api.model;



import lombok.Data;


@Data
public class RoleResourcesDto {

    private Long id;

    private Long roleId;

    private Long resourceId;

}
