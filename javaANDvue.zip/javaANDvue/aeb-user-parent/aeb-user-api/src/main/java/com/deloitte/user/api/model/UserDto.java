package com.deloitte.user.api.model;

import lombok.Data;

import java.io.Serializable;
import java.util.UUID;

/**
 * TODO 类注释
 *
 * @author xideng
 */
@Data
public class UserDto implements Serializable {

    private static final long serialVersionUID = 5042601427244489962L;
    
    private Long id;

    private UUID oid;

    private String email;

    private String mobile;

    private Boolean enabled;

    private String staffNo;

    /*
     * 图片验证码
     */
    private String verificationCode;

}
