package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * 用户短信验证码 传输实体
 *
 * @author wgong
 */
@Data
public class UserSmsDto implements Serializable {

    private static final long serialVersionUID = 4202819453462982043L;

    @Length(max = 11, message = "手机号码必须为11位")
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^[1]([3-9])[0-9]{9}$", message = "手机号码错误，请使用中国大陆11位手机号注册")
    private String mobile;

    @Length(max = 10, message = "验证码长度不能超过10位")
    @NotBlank(message = "验证码不能为空")
    @Pattern(regexp = "^\\d+$", message = "手机验证码错误，只能包含数字")
    private String code;

}
