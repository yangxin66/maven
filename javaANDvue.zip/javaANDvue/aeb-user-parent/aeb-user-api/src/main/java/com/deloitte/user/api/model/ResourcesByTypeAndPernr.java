package com.deloitte.user.api.model;

import lombok.Data;

@Data
public class ResourcesByTypeAndPernr {
    String pernr;
    String type;

}
