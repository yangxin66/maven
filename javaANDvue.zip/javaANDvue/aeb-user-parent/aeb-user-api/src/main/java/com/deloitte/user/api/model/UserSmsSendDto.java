package com.deloitte.user.api.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author chunliucq
 * @since 03/09/2019 15:05
 */
@Data
public class UserSmsSendDto implements Serializable {

    private String mobile;
    private SmsOriginEnum smsOriginEnum;
}
