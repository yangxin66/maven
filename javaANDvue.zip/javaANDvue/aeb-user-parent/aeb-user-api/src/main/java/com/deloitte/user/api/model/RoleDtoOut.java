package com.deloitte.user.api.model;



import lombok.Data;


@Data
public class RoleDtoOut {


    private String roleName;

    private Long id;

    private String orgId;

    private String grantOrgs;

    private String code;

}
