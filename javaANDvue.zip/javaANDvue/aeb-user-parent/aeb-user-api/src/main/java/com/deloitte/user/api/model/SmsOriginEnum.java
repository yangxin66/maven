package com.deloitte.user.api.model;

/**
 * 发送手机验证码来源 枚举
 * date: 24/07/2019 11:16
 *
 * @author wgong
 * @since 0.0.1
 */
public enum SmsOriginEnum {
    /**
     * 登录
     */
    LOGIN,

    /**
     * 注册
     */
    REGISTER,

    /**
     * 重置密码
     */
    RESET_PWD
}
