package com.deloitte.user.api;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.user.api.model.*;
import com.deloitte.user.api.model.UserSmsDto;
import com.deloitte.user.api.model.UserSmsResetPwdDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "AEB-USER", path = "/api/v1/users")
public interface UserRestInterface {

    @GetMapping("/{id:^\\d+$}")
    Response<UserDto> get(@PathVariable("id") long id);

    @PostMapping("/sms")
    Response<String> registerUser(@Validated @RequestBody Request<UserSmsAddDto> userSmsAddDtoRequest);

    @PostMapping("/login/check_verification_code")
    Response<String> checkVerificationCodeFromLogin(@Validated @RequestBody Request<UserSmsDto> userSmsDtoRequest);

    @PostMapping("/verification_code")
    Response<String> sendVerificationCode( Request<UserSmsSendDto> userSmsSendDtoRequest);

    @PostMapping("/reset_password/check_verification_code")
    Response<String> checkVerificationCodeFromResetPwd(@Validated @RequestBody Request<UserSmsDto> userSmsDtoRequest);

    @PostMapping("/reset_password/verification_code")
    Response<String> resetPassword(@Validated @RequestBody Request<UserSmsResetPwdDto> userSmsResetPwdDtoRequest);

    @PostMapping("/reset_password/verify_token")
    Response<String> verifyToken(@Validated @RequestBody Request<UserSmsVerifyToken> userSmsVerifyTokenRequest);

    @PostMapping(value = "/login/acct",produces = "application/json;charset=UTF-8")
    Response<String> loginByAccount(@RequestBody Request<UserLoginDto> loginInfoRequest) ;

    @PostMapping(value = "/login/is_dispalay_verifycation_code")
    Response<CheckVerifycationRespDto> isCheckVerifycationCode(Request<UserLoginDto> accountRequest);

    @PostMapping("/email_verify")
    Response<String> emailVerify(Request<EmailVerifyDto> dtoRequest);
    /**
     * 发送重置密码的邮件
     * @param dtoRequest
     * @return
     */
    @PostMapping("/email_repass")
    Response<String> sendEmailRepass(Request<EmailVerifyDto> dtoRequest);

    /**
     * 根据加密字符串获取对应的注册邮箱地址
     * @param tokenRequest
     * @return
     */
    @PostMapping("/get_email")
    Response<String> getEmailByToken(Request<String> tokenRequest);
    /**
     * 根据加密字符串获取对应的找回密码的邮箱地址
     * @param tokenRequest
     * @return
     */
    @PostMapping("/get_repass_email")
    Response<String> getRepassEmailByToken(Request<String> tokenRequest);

    /**
     * 根据邮箱进行注册
     * @param dtoRequest
     * @return
     */
    @PostMapping("/email_register")
    Response<String> registerByEmail(@RequestBody Request<UserEmailDto> dtoRequest);

    /**
     * 根据邮箱修改密码
     * @param dtoRequest
     * @return
     */
    @PostMapping("/email_update_password")
    Response<String> updatePasswordByEmail(@RequestBody Request<UserEmailDto> dtoRequest);

    @PostMapping(value = "/syn_register")
    public Response<String> registerUserByOtherSystem(@Validated @RequestBody Request<UserDhrDto> userDhrDtoRequest);

    @PostMapping(value = "/user/query")
    Response<UserDto> queryUserInfoByAccount(@RequestBody Request<String> loginAccountRequest);
}
