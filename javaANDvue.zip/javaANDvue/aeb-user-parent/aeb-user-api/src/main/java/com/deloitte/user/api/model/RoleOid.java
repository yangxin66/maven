package com.deloitte.user.api.model;

import lombok.Data;

import java.util.UUID;

@Data
public class RoleOid {
    private UUID oid;
}
