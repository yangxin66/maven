package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * 重置密码 传输实体
 *
 * @author wgong
 */
@Data
public class UserSmsResetPwdDto implements Serializable {

    private static final long serialVersionUID = 7710023534103912142L;

    @Length(max = 11, message = "手机号码必须为11位")
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^[1]([3-9])[0-9]{9}$", message = "手机号码错误，请使用中国大陆11位手机号注册")
    private String mobile;

    @Length(max = 100, message = "密码长度不能超过100位")
    @NotBlank(message = "密码不能为空")
    @Pattern(regexp = "^(?=.*[0-9].*)(?=.*[A-Z].*)(?=.*[a-z].*)(?=.*[^A-Za-z0-9].*).{10,15}$",
            message = "密码长度应为10-15位，必须包含大写字母、小写字母、数字、特殊字符")
    private String password;

    @Length(min = 32, max = 32, message = "token长度必须为32位")
    @NotBlank(message = "token不能为空")
    private String token;

}
