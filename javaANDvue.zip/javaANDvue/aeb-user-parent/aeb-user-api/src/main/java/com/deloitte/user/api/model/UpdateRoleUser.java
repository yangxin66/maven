package com.deloitte.user.api.model;

import lombok.Data;

@Data
public class UpdateRoleUser {

//    private Long id;
    private String pernr;
    private Long roleId;
}
