package com.deloitte.user.api.model;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class UpdateRole {

    @NotNull(message = "字段名称不允许为空")
    @NotBlank(message = "字段名称不允许为空")
    String key;
    String value;
}
