package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * 修改密码校验token 类
 * date: 25/07/2019 15:03
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class UserSmsVerifyToken implements Serializable {

    private static final long serialVersionUID = 6944390042005385339L;

    @Length(max = 11, message = "手机号码必须为11位")
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^[1]([3-9])[0-9]{9}$", message = "手机号码错误，请使用中国大陆11位手机号注册")
    private String mobile;

    @Length(min = 32, max = 32, message = "token长度必须为32位")
    @NotBlank(message = "token不能为空")
    private String token;
}
