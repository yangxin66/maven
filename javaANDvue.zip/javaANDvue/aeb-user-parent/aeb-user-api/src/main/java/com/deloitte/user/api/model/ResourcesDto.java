package com.deloitte.user.api.model;

import lombok.Data;

@Data
public class ResourcesDto {

    private Long id;

    private String orgId;

    private Long parentId;

    private String name;

    private String Uri;

    private Integer level;

    private String code;

    private String type;
}
