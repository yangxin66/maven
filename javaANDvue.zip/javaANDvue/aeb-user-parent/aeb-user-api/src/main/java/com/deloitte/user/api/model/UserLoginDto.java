package com.deloitte.user.api.model;

import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.UUID;

@Data
public class UserLoginDto implements Serializable {
    /**
     * 手机号或邮箱
     */
    @Length(max = 30, message = "手机号或邮箱总长度不能超过30位")
    @NotBlank(message = "手机号或邮箱地址不能为空")
    private String account;

    /**
     * 密码
     */
    @Length(max = 30, message = "密码总长度不能超过30位")
    @NotBlank(message = "密码不能为空")
    private String password;
    /*
     * 图片验证码
     */
    private String verificationCode;
}
