-----------------------------------------------------
-- Export file for user DUSER_USER                 --
-- Created by chunliucq on 17/09/2019, 10:03:46 AM --
-----------------------------------------------------

create table D_USER
(
  ID                NUMBER(19) not null,
  CREATED_DATE      TIMESTAMP(6) not null,
  CREATED_USER_OID  RAW(16) not null,
  DELETED           NUMBER(1) not null,
  MODIFIED_DATE     TIMESTAMP(6) not null,
  MODIFIED_USER_OID RAW(16) not null,
  OID               RAW(16),
  EMAIL             VARCHAR2(100 CHAR),
  ENABLED           NUMBER(1) not null,
  MOBILE            VARCHAR2(20 CHAR),
  PASSWORD          VARCHAR2(100 CHAR) not null,
  USERNAME          VARCHAR2(100 CHAR)
)
;
alter table D_USER
  add primary key (ID);
alter table D_USER
  add constraint UK_CM2C2EHP2UAAGEKSNVLTNJO02 unique (EMAIL);
alter table D_USER
  add constraint UK_CQ097DAS2QLT4FGL6UUKQ9N8O unique (OID);
alter table D_USER
  add constraint UK_D75KS84KC9MWWOK87RSVH9BC7 unique (MOBILE);

create sequence HIBERNATE_SEQUENCE
minvalue 1
maxvalue 9999999999999999999999999999
start with 41
increment by 1
cache 20;

