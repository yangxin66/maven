package com.deloitte.com.user.provider.test;

import com.deloitte.user.api.model.UserLoginDto;
import com.deloitte.user.provider.UserProviderApplication;
import com.deloitte.user.provider.service.UserService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(MockitoJUnitRunner.class)
@SpringBootTest(classes = UserProviderApplication.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT) // 指定启动类
public class UserProviderApplicationTest {

    @Autowired
    private UserService userService;

    //@Test
    public void loginByAcctTest() throws Exception {
        UserLoginDto dto = new UserLoginDto();
        dto.setAccount("aaxd");
        dto.setPassword("Zs!234567890");
        dto.setVerificationCode("1212");

    }

    @Before
    public void setUp() throws Exception {

    }
    @Test
    public void mockTest(){

    }
}
