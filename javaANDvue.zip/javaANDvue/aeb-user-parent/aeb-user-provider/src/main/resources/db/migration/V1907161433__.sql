# 2019-07-16 14:33
# Author Deng, Xiao
# 工程初始化，添加"创建用户信息表"SQL

CREATE TABLE IF NOT EXISTS user(

    # 通用字段
    id BIGINT(20) PRIMARY KEY AUTO_INCREMENT COMMENT '自增主键',
    oid BINARY(16) NOT NULL COMMENT '数据全局唯一id',
    created_user_oid BINARY(16) NOT NULL COMMENT '数据创建者oid',
    created_date DATETIME NOT NULL COMMENT '数据创建时间',
    modified_user_oid BINARY(16) NOT NULL COMMENT '数据上一次修改人oid',
    modified_date DATETIME NOT NULL COMMENT '数据上一次修改时间',
    deleted TINYINT(1) NOT NULL DEFAULT 0 COMMENT '逻辑删除标识符 true --> 已删除 | false --> 未删除',

    # 业务字段
    username VARCHAR(100) COMMENT '用户名，属于预留字段',
    email VARCHAR(100) UNIQUE COMMENT '用户邮箱地址',
    mobile VARCHAR(20) UNIQUE COMMENT '用户手机号码',
    password VARCHAR(100) NOT NULL COMMENT '用户登录密码',
    enabled TINYINT(1) NOT NULL DEFAULT 1 COMMENT '用户启用标识符 true --> 启用 | false --> 禁用',

    # 索引
    INDEX idx_user_email_deleted(email, deleted) COMMENT '邮箱地址&逻辑删除标识符 联合索引',
    INDEX idx_user_mobile_deleted(mobile, deleted) COMMENT '手机号码&逻辑删除标识符 联合索引'

) DEFAULT CHARSET = UTF8 COLLATE = UTF8_UNICODE_CI ENGINE = INNODB;
