package com.deloitte.user.provider.service;

import com.deloitte.infrastructure.jpa.service.BaseService;
import com.deloitte.user.api.model.UserLoginDto;
import com.deloitte.user.api.model.UserSmsAddDto;
import com.deloitte.user.api.model.UserDto;
import com.deloitte.user.provider.repository.model.UserPo;

public interface UserService extends BaseService<UserPo> {

    UserDto findById(long id);

    /**
     * 发送短信验证码
     *
     * @param mobile 手机号
     */
    void sendVerificationCode(String mobile);

    /**
     * 校验短信验证码
     *
     * @param mobile 手机号
     */
    void checkVerificationCode(String mobile, String code);

    /**
     * 添加用户
     *
     * @param userSmsAddDto 新增用户实体
     */
    void addUser(UserSmsAddDto userSmsAddDto);

    /**
     * 判断手机号是否存在
     *
     * @param mobile 手机号
     */
    boolean existsByMobile(String mobile);

    /**
     * 通过账号或邮箱查询出用户信息
     * @param accountOrEmail
     * @return
     */
    UserPo findUserByAccountOrEmail(String accountOrEmail);

    /**
     * 判断是否需要进行图片验证码验证
     * @param account 账号或邮箱地址
     */
    boolean isCheckVerifycationCode(String account);

    /**
     * 用户使用手机号或邮箱登录
     * @param loginInfo 登录请求信息
     */
    void loginByAcct(UserLoginDto loginInfo);

    /**
     * 检查手机号或邮箱是否被锁住
     * @param account
     */
    void checkAccountLocked(String account);
}
