package com.deloitte.user.provider.service.impl;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.jpa.service.BaseServiceImpl;
import com.deloitte.notification.provider.api.SmsRestInterface;
import com.deloitte.notification.provider.api.model.AliyunSmsDto;
import com.deloitte.notification.provider.api.model.AliyunSmsParamDto;
import com.deloitte.user.api.model.SmsOriginEnum;
import com.deloitte.user.api.model.UserSmsAddDto;
import com.deloitte.user.api.model.UserSmsResetPwdDto;
import com.deloitte.user.provider.exception.DUserException;
import com.deloitte.user.provider.properties.SmsProperties;
import com.deloitte.user.provider.repository.CommonRedisRepository;
import com.deloitte.user.provider.repository.UserRepository;
import com.deloitte.user.provider.repository.model.MobileValidateCodePo;
import com.deloitte.user.provider.repository.model.ResetPasswordValidatePo;
import com.deloitte.user.provider.repository.model.UserPo;
import com.deloitte.user.provider.service.UserMobileSmsService;
import com.deloitte.user.provider.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 手机相关的用户服务层
 *
 * @author wgong
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class UserMobileSmsServiceImpl extends BaseServiceImpl<UserPo> implements UserMobileSmsService {

    private final UserRepository repository;

    private final SmsProperties smsProperties;

    private final CommonRedisRepository commonRedisRepository;

    private final UserService userService;

    // 注册手机验证码的存储前缀
    private final String REGISTER_MOBILE_VALIDATE_PREFIX = "SMS:MOBILE_VALIDATE:REGISTER_MOBILE_VALIDATE:";

    // 注册手机验证码的存储前缀
    private final String LOGIN_MOBILE_VALIDATE_PREFIX = "SMS:MOBILE_VALIDATE:LOGIN_MOBILE_VALIDATE:";

    // 注册手机验证码的存储前缀
    private final String RESET_PWD_MOBILE_VALIDATE_PREFIX = "SMS:MOBILE_VALIDATE:RESET_PWD_MOBILE_VALIDATE:";

    // 同一个手机号码，24小时内，连续验证失败次数的存储前缀
    private final String CUMULATIVE_FAILURE_NUMBER_PREFIX = "SMS:CUMULATIVE_FAILURE_NUMBER:";

    // 同一个手机号码，24小时内，获取验证码的次数的前缀
    private final String SEND_NUMBER_PREFIX = "SMS:SEND_NUMBER:";

    // 重置密码的token信息前缀
    private final String RESET_PWD_PREFIX = "RESET_PWD_TOKEN:";

    private final long STEP = 1;

    private ObjectMapper objectMapper;

    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    private SmsRestInterface smsRestInterface;

    public UserMobileSmsServiceImpl(UserRepository repository, SmsProperties smsProperties,
                                    CommonRedisRepository commonRedisRepository, ObjectMapper objectMapper,
                                    UserService userService, SmsRestInterface smsRestInterface) {
        super(repository);
        this.repository = repository;
        this.smsProperties = smsProperties;
        this.commonRedisRepository = commonRedisRepository;
        this.objectMapper = objectMapper;
        this.userService = userService;
        this.smsRestInterface = smsRestInterface;
    }

    /**
     * 保存短信验证码的信息
     *
     * @param key  redis中的key
     * @param data 数据
     */
    private void saveMobileValidateCode(String key, Object data) {
        // 保存验证码 默认该验证码被验证的次数为0 设置发送时间就是为了后续判断发送时间的有效期
        commonRedisRepository.set(key, data,
                smsProperties.getMobileValidateLimitTime(), TimeUnit.MINUTES);
    }

    /**
     * 保存发送短信验证码的次数
     *
     * @param mobile 手机号
     */
    private void saveSendNumber(String mobile) {
        // 保存发送验证码的次数 每次加1
        commonRedisRepository.increment(SEND_NUMBER_PREFIX + mobile, STEP,
                smsProperties.getMobileValidateLimitTime(), TimeUnit.HOURS);
    }

    /**
     * 登录-校验短信验证码
     *
     * @param mobile 手机号
     */
    @Override
    public boolean checkVerificationCodeFromLogin(String mobile, String code) {
        return commonCheckVerificationCode(LOGIN_MOBILE_VALIDATE_PREFIX + mobile, mobile, code);
    }

    /**
     * 重置密码时验证码的校验
     *
     * @param mobile 手机号
     */
    @Override
    public String checkVerificationCodeFromResetPwd(String mobile, String code) {
        // 校验短信验证码
        boolean b = commonCheckVerificationCode(RESET_PWD_MOBILE_VALIDATE_PREFIX + mobile, mobile, code);
        if (!b) {//如果校验不成功
            throw new BusinessException(DUserException.CHECK_VALID_CODE_FAIL.getCode(),DUserException.CHECK_VALID_CODE_FAIL.getMessage());
        }
        String token = UUID.randomUUID().toString().replace("-", "");
        long deadTime = System.currentTimeMillis() + smsProperties.getDeadVerifyMinute() * 60 * 1000;
        // 生成校验对象
        ResetPasswordValidatePo resetPasswordValidatePo =
                ResetPasswordValidatePo.builder()
                        .mobile(mobile)
                        .expiredMillis(deadTime).build();
        String resetPasswordValidateStr;
        try {
            resetPasswordValidateStr = objectMapper.writeValueAsString(resetPasswordValidatePo);
        } catch (JsonProcessingException e) {
            throw new BusinessException(DUserException.SERIALIZE_VALID_CODE_FAIL.getCode(),DUserException.SERIALIZE_VALID_CODE_FAIL.getMessage(),e);
        }
        commonRedisRepository.set(RESET_PWD_PREFIX + token, resetPasswordValidateStr);
        return token;
    }

    /**
     * 发送手机验证码
     *
     * @param mobile        手机号
     * @param smsOriginEnum 发送手机号来源
     */
    @Override
    public void sendVerificationCode(String mobile, SmsOriginEnum smsOriginEnum) {
        if (SmsOriginEnum.REGISTER.equals(smsOriginEnum)) { // 如果是注册
            commonSendVerificationCode(REGISTER_MOBILE_VALIDATE_PREFIX + mobile, mobile);
        } else if (SmsOriginEnum.LOGIN.equals(smsOriginEnum)) { // 如果是登录
            // 检查手机号是否被锁
            userService.checkAccountLocked(mobile);
            commonSendVerificationCode(LOGIN_MOBILE_VALIDATE_PREFIX + mobile, mobile);
        } else {// 如果是重置密码
            // 检查手机号是否被锁
            userService.checkAccountLocked(mobile);
            commonSendVerificationCode(RESET_PWD_MOBILE_VALIDATE_PREFIX + mobile, mobile);
        }

    }

    /**
     * 添加用户
     *
     * @param userSmsAddDto 新增用户实体
     */
    @Override
    public void registerUser(UserSmsAddDto userSmsAddDto) {
        // 校验短信验证码
        if (commonCheckVerificationCode(REGISTER_MOBILE_VALIDATE_PREFIX + userSmsAddDto.getMobile(),
                userSmsAddDto.getMobile(), userSmsAddDto.getCode())) { // 如果输入的验证码正确
            UserPo userPo = new UserPo();
            userPo.setMobile(userSmsAddDto.getMobile());
            userPo.setPassword(passwordEncoder.encode(userSmsAddDto.getPassword()));
            userPo.setEnabled(true);
            create(userPo);
        } else { // 输入错误的验证码
            throw new BusinessException(DUserException.CHECK_VALID_CODE_FAIL.getCode(),DUserException.CHECK_VALID_CODE_FAIL.getMessage());
        }
    }

    /**
     * 重置密码
     *
     * @param userSmsResetPwdDto 重置密码实体
     */
    @Override
    public void resetPassword(UserSmsResetPwdDto userSmsResetPwdDto) {
        UserPo userPo = repository.findByMobileAndDeletedIsFalse(userSmsResetPwdDto.getMobile()).orElse(null);
        if (userPo == null) {
            throw new BusinessException(DUserException.ACCOUNT_NOT_REGISTER.getCode(),DUserException.ACCOUNT_NOT_REGISTER.getMessage());
        }

        verifyTokenFromResetPwd(userSmsResetPwdDto.getMobile(), userSmsResetPwdDto.getToken());

        userPo.setPassword(passwordEncoder.encode(userSmsResetPwdDto.getPassword()));
        repository.saveAndFlush(userPo);
        // 修改密码成功后 删除该token信息
        commonRedisRepository.remove(RESET_PWD_PREFIX + userSmsResetPwdDto.getToken());
    }

    @Override
    public void verifyTokenFromResetPwd(String mobile, String token) {
        Object str = commonRedisRepository.get(RESET_PWD_PREFIX + token);
        if (str == null) {
            throw new BusinessException(DUserException.SMS_CHECK_FAIL.getCode(),DUserException.SMS_CHECK_FAIL.getMessage());
        }
        ResetPasswordValidatePo resetPasswordValidatePo;
        try {
            resetPasswordValidatePo = objectMapper.readValue((String) str, ResetPasswordValidatePo.class);
        } catch (IOException e) {
            throw new BusinessException(DUserException.RESET_PASSWORD_SERIALIZE.getCode(),DUserException.RESET_PASSWORD_SERIALIZE.getMessage());
        }
        // 如果已经过期了
        if (resetPasswordValidatePo.isExpired()) {
            //过期就删除信息
            commonRedisRepository.remove(RESET_PWD_PREFIX + token);
            throw new BusinessException(DUserException.SMS_CHECK_EXPIRED_FAIL.getCode(),DUserException.SMS_CHECK_EXPIRED_FAIL.getMessage());
        }
        if (!resetPasswordValidatePo.getMobile().equals(mobile)) {
            throw new BusinessException(DUserException.ACCOUNT_TOKEN_CHECK_NOT_MATCHES.getCode(),DUserException.ACCOUNT_TOKEN_CHECK_NOT_MATCHES.getMessage());
        }
    }

    /**
     * 更新验证码次数整个实体
     *
     * @param key                  验证码前缀
     * @param mobileValidateCodePo 验证码次数实体
     */
    private void updateSameCodeMaxVerifyNumber(String key, MobileValidateCodePo mobileValidateCodePo) {
        // 将输入错误数据的次数存入Redis
        mobileValidateCodePo.setVerifyNumber(mobileValidateCodePo.getVerifyNumber() + 1);
        String codeStr;
        try {
            codeStr = objectMapper.writeValueAsString(mobileValidateCodePo);
        } catch (JsonProcessingException e) {
            throw new BusinessException(DUserException.SERIALIZE_VALID_CODE_FAIL.getCode(),DUserException.SERIALIZE_VALID_CODE_FAIL.getMessage());
        }

        // 保存验证码 默认该验证码被验证的次数为0 设置发送时间就是为了让发送有效期为1分钟
        commonRedisRepository.set(key, codeStr,
                smsProperties.getMobileValidateLimitTime(), TimeUnit.MINUTES);
    }

    /**
     * 获取短信验证码实体
     *
     * @param key 短信验证码key
     */
    private MobileValidateCodePo getMobileValidateCodePo(String key) {
        // 根据手机号获取redis中的验证码
        Object mobileCodeStr = commonRedisRepository.get(key);

        if (mobileCodeStr == null) {
            return null;
        }
        MobileValidateCodePo mobileValidateCodePo;
        try {
            mobileValidateCodePo = objectMapper.readValue((String) mobileCodeStr, MobileValidateCodePo.class);
        } catch (IOException e) {
            throw new BusinessException(DUserException.SERIALIZE_VALID_CODE_FAIL.getCode(),DUserException.SERIALIZE_VALID_CODE_FAIL.getMessage(),e);
        }
        return mobileValidateCodePo;
    }

    /**
     * 判断获取验证码次数是否超过阈值 如果超过则不允许获取
     *
     * @param mobile 手机号
     */
    private void judgeMaxSendNumber(String mobile) {
        Object sendNumber = commonRedisRepository.get(SEND_NUMBER_PREFIX + mobile);
        if (sendNumber != null && Integer.parseInt(String.valueOf(sendNumber)) >= smsProperties.getMaxSendNumber()) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_GET_TOO_MANY_TIMES.getCode(),
                    String.format(DUserException.SMS_VALIDCODE_GET_TOO_MANY_TIMES.getMessage(),smsProperties.getMobileValidateLimitTime()));
        }
    }

    /**
     * 判断24小时内连续验证失败的次数是否超过阈值 如果超过则不允许获取
     *
     * @param mobile 手机号
     */
    private void judgeCumulativeFailureNumber(String mobile) {
        Object cumulativeFailureNumber = commonRedisRepository.get(CUMULATIVE_FAILURE_NUMBER_PREFIX + mobile);
        if (cumulativeFailureNumber != null && (Integer.parseInt(String.valueOf(cumulativeFailureNumber))) >= smsProperties.getCumulativeFailureNumber()) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES.getCode(),
                    String.format(DUserException.SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES.getMessage(),smsProperties.getMobileValidateLimitTime()));
        }
    }

    /**
     * 判断连续输入的次数是否超过阈值 如果超过则不允许输入
     *
     * @param mobile 手机号
     */
    private void judgeCumulativeFailureNum(String mobile) {
        Object cumulativeFailureNum = commonRedisRepository.get(CUMULATIVE_FAILURE_NUMBER_PREFIX + mobile);
        if (cumulativeFailureNum != null && Integer.parseInt(String.valueOf(cumulativeFailureNum)) >= smsProperties.getCumulativeFailureNumber()) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES.getCode(),
                    String.format(DUserException.SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES.getMessage(),smsProperties.getMobileValidateLimitTime()));
        }
    }

    /**
     * 判断同一验证码连续输入的次数是否超过阈值 如果超过则不允许输入
     *
     * @param verifyNumber 手机号验证码输入失败的次数
     */
    private void judgeSameCodeMaxVerifyNumber(int verifyNumber) {
        // 对于同一验证码 如果连续输错的次数达到阈值 则返回错误信息
        if (verifyNumber >= smsProperties.getSameCodeMaxVerifyNumber()) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_CHECKFAILT_GET_NEW.getCode(),
                    String.format(DUserException.SMS_VALIDCODE_CHECKFAILT_GET_NEW.getMessage(),smsProperties.getMobileValidateLimitTime()));
        }
    }

    /**
     * 判断手机号是否存在
     *
     * @param mobile 手机号
     */
    @Override
    public boolean existsByMobile(String mobile) {
        Optional<UserPo> userPoOptional = repository.findByMobileAndDeletedIsFalse(mobile);
        return userPoOptional.isPresent();
    }

    /**
     * 发送验证码的通用方法
     *
     * @param key    验证码前缀
     * @param mobile 手机号
     */
    private void commonSendVerificationCode(String key, String mobile) {
        // 判断获取验证码次数是否超过阈值 如果超过则不允许获取
        judgeMaxSendNumber(mobile);
        // 判断24小时内连续验证失败的次数是否超过阈值 如果超过则不允许获取
        judgeCumulativeFailureNumber(mobile);
        // 生成验证码
        String code = createRandomNum(smsProperties.getCodeSize());
        boolean b = sendSms(mobile, code);
        if (!b) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_SEND_FAIL.getCode(),DUserException.SMS_VALIDCODE_SEND_FAIL.getMessage());
        }
        MobileValidateCodePo mobileValidateCodePo = new MobileValidateCodePo();
        mobileValidateCodePo.setCode(code);
        long deadTime = System.currentTimeMillis() + smsProperties.getDeadVerifyMinute() * 60 * 1000;
        mobileValidateCodePo.setExpiredMillis(deadTime);
        String codeStr;
        try {
            codeStr = objectMapper.writeValueAsString(mobileValidateCodePo);
        } catch (JsonProcessingException e) {
            throw new BusinessException(DUserException.SERIALIZE_VALID_CODE_FAIL.getCode(),DUserException.SERIALIZE_VALID_CODE_FAIL.getMessage(),e);
        }
        saveMobileValidateCode(key, codeStr);
        saveSendNumber(mobile);
    }

    public boolean sendSms(String mobile, String code) {
        String codeJsonStr = "{\"code\":\"" + code + "\"}";
        AliyunSmsParamDto aliyunSmsParamDto =
                AliyunSmsParamDto.builder()
                        .phoneNumbers(mobile)
                        .signName(smsProperties.getSignName())
                        .templateCode(smsProperties.getTemplateCode())
                        .templateParam(codeJsonStr)
                        .build();
        Response<AliyunSmsDto> aliyunSmsDtoJsonResult = smsRestInterface.sendSms(aliyunSmsParamDto);
        return aliyunSmsDtoJsonResult != null;
    }

    /**
     * 通用短信验证码校验方法
     *
     * @param key    短信验证码key
     * @param mobile 手机号
     * @param code   验证码
     */
    public boolean commonCheckVerificationCode(String key, String mobile, String code) {
        // 先判断连续输入的次数是否超过阈值 如果超过则不允许输入
        judgeCumulativeFailureNum(mobile);

        // 获取redis中的验证码信息
        MobileValidateCodePo mobileValidateCodePo = getMobileValidateCodePo(key);
        // 如果验证码不存在 直接返回错误信息 并且输入错误验证码次数自增1
        if (mobileValidateCodePo == null) {
            // 每次连续输入错误的验证码 次数自增1
            commonRedisRepository.increment(CUMULATIVE_FAILURE_NUMBER_PREFIX + mobile, STEP,
                    smsProperties.getMobileValidateLimitTime(), TimeUnit.HOURS);
            throw new BusinessException(DUserException.CHECK_VALID_CODE_FAIL.getCode(),DUserException.CHECK_VALID_CODE_FAIL.getMessage());
        }
        if (mobileValidateCodePo.isExpired()) { //如果超过有效期
            // 过期后删除信息
            commonRedisRepository.remove(key);
            // 每次连续输入错误的验证码 次数自增1
            commonRedisRepository.increment(CUMULATIVE_FAILURE_NUMBER_PREFIX + mobile, STEP,
                    smsProperties.getMobileValidateLimitTime(), TimeUnit.HOURS);
            throw new BusinessException(DUserException.SMS_VALIDCODE_EXPIRE.getCode(),DUserException.SMS_VALIDCODE_EXPIRE.getMessage());
        }
        // 对于同一验证码 如果连续输错的次数达到阈值 则返回错误信息
        judgeSameCodeMaxVerifyNumber(mobileValidateCodePo.getVerifyNumber());

        // 如果输入的验证码正确
        if (code.equals(mobileValidateCodePo.getCode())) {
            // 添加用户成功后 将redis里面验证码、连续验证错误的次数清除
            commonRedisRepository.remove(key);
            // 清除连续输入验证码错误的次数
            commonRedisRepository.remove(CUMULATIVE_FAILURE_NUMBER_PREFIX + mobile);
            return true;
        }
        // 更新验证错误的次数
        updateSameCodeMaxVerifyNumber(key, mobileValidateCodePo);
        return false;
    }

    /**
     * 生成指定位数的随机验证码
     *
     * @param codeSize 随机验证码的位数
     */
    private String createRandomNum(int codeSize) {
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < codeSize; i++) {
            stringBuilder.append(random.nextInt(10));
        }
        return stringBuilder.toString();
    }
}
