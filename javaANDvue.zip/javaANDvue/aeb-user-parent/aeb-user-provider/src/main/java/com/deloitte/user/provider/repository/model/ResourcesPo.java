package com.deloitte.user.provider.repository.model;


import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "dhr_sys_resource")
@Entity(name = "Resources")
@SQLDelete(sql = "update Resources set Resources.deleted = 1 where Resources.id = ?")
@Where(clause = "deleted = 0")
public class ResourcesPo extends BasePo {

    private static final long serialVersionUID = 6766218395560419282L;

    @Column(name = "org_id",length = 50)
    private String orgId;

    @Column(name = "parent_id",length = 50)
    private Long parentId;

    @Column(name = "name",length = 50)
    private String name;

    @Column(name = "Uri",length = 50)
    private String Uri;

    @Column(name = "res_level",length = 50)
    private Integer level;

    @Column(name = "code",length = 50)
    private String code;

    @Column(name = "type",length = 50)
    private String type;

}
