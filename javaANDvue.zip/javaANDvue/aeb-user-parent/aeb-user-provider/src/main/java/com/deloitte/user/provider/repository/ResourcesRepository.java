package com.deloitte.user.provider.repository;


import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.user.provider.repository.model.ResourcesPo;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;


@Repository
public interface ResourcesRepository extends BaseRepository<ResourcesPo> {

    List<ResourcesPo> findByName(String name);

//    Optional<ResourcesPo> findById(Long id);

//    List<ResourcesPo> findByIdIn(List<Long> idList);

    @Transactional
    @Modifying
    @Query("update  Resources r set r.orgId = ?2,r.parentId = ?3,r.name = ?4,r.Uri = ?5,r.level = ?6,r.code = ?7,r.type = ?8 where id=?1")
    Integer updateCode(Long id, String orgId, Long parentId, String name, String Uri, Integer level, String code, String type);

    List<ResourcesPo> findByTypeAndIdIn(String type,List<Long> id);

}
