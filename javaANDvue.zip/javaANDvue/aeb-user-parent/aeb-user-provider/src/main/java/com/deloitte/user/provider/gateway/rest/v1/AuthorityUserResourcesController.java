package com.deloitte.user.provider.gateway.rest.v1;


import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.user.api.AuthorityUserResourcesInterface;
import com.deloitte.user.api.model.*;
import com.deloitte.user.provider.service.RoleUserPowerService;
import com.deloitte.user.provider.utils.ResponseUtil;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;


@Slf4j
@RestController
@RequestMapping(value = "/api/v1/hr/authority", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class AuthorityUserResourcesController implements AuthorityUserResourcesInterface {

    @Autowired
    RoleUserPowerService roleUserPowerService;


    @Override
    @PostMapping("/role/info")
    @ApiOperation(value = "角色名查看角色数据")
    @ApiImplicitParam(name = "request", value = "角色名", required = true, dataType = "Request«string»")
    public Response<List<RoleDtoOut>> queryRole(@RequestBody Request<String> request) {
        List<RoleDtoOut> roleDtoList = roleUserPowerService.queryRole(request.getData());
        return new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, null, roleDtoList);
    }

    @Override
    @PostMapping("/role/save")
    @ApiOperation(value = "保存角色")
    @ApiImplicitParam(name = "roleDtoInRequest", value = "角色数据", required = true, dataType = "Request«RoleDtoIn»")
    public Response<Void> saveRole(@RequestBody Request<RoleDtoIn> roleDtoInRequest) {
        roleUserPowerService.saveRole(roleDtoInRequest.getData());
        return new Response<>(roleDtoInRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/role/update")
    @ApiOperation(value = "修改角色数据")
    @ApiImplicitParam(name = "roleDtoOutRequest", value = "修改数据", required = true, dataType = "Request«RoleDtoOut»")
    public Response<RoleDtoOut> updateRole(@RequestBody Request<RoleDtoOut> roleDtoOutRequest) {
        roleUserPowerService.updateRole(roleDtoOutRequest.getData());
        Long id = roleDtoOutRequest.getData().getId();
        RoleDtoOut roleDto = roleUserPowerService.queryById(id);
        return new Response<>(roleDtoOutRequest.getLanguage(),
                Response.SUCCESS_CODE, null, roleDto);
    }

    @Override
    @PostMapping("/role/remove")
    @ApiOperation(value = "删除角色")
    @ApiImplicitParam(name = "requestId", value = "角色code", required = true, dataType = "Request«long»")
    public Response<Void> removeRole(@RequestBody Request<Long> requestId) {
//        roleUserPower.removeRole(request.getData());
        roleUserPowerService.removeRole(requestId.getData());
        return new Response<>(requestId.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/roleuser/info")
    @ApiOperation(value = "根据用户查询角色id")
    @ApiImplicitParam(name = "requestPernrr", value = "员工编号", required = true, dataType = "Request«string»")
    public Response<List<RoleUserRelDto>> queryRoleUser(@RequestBody Request<String> requestPernrr) {
        List<RoleUserRelDto> roleUserRelDtos = roleUserPowerService.queryRoleUserRel(requestPernrr.getData());
        return new Response<>(requestPernrr.getLanguage(),
                Response.SUCCESS_CODE, null, roleUserRelDtos);
    }

    @Override
    @PostMapping("/roleuser/update")
    @ApiOperation(value = "修改角色用户关联")
    @ApiImplicitParam(name = "updateRoleUserRequest", value = "员工编号", required = true, dataType = "Request«UpdateRoleUser»")
    public Response<Void> UpdateRoleUser(@RequestBody Request<UpdateRoleUser> updateRoleUserRequest) {
        roleUserPowerService.updateRoleUserRel(updateRoleUserRequest.getData());
//        RoleResourcesDto roleResourcesDto = roleUserPowerService.queryRoleResourcesId(updateRoleUserRequest.getData().getId());
        return new Response<>(updateRoleUserRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/roleuser/remove")
    @ApiOperation(value = "删除角色用户关联")
    @ApiImplicitParam(name = "pernrRequest", value = "员工编号", required = true, dataType = "Request«string»")
    public Response<Void> removeRoleUser(@RequestBody Request<String> pernrRequest) {
        roleUserPowerService.removeRoleUserRel(pernrRequest.getData());
        return new Response<>(pernrRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/roleuser/save")
    @ApiOperation(value = "保存角色与用户关系")
    @ApiImplicitParam(name = "roleUserRelDtoRequest", value = "", required = true, dataType = "Request«RoleUserRelDto»")
    public Response<Void> saveRoleUserRel(@RequestBody Request<RoleUserRelDto> roleUserRelDtoRequest) {
        roleUserPowerService.saveRoleUserRel(roleUserRelDtoRequest.getData());
        return new Response<>(roleUserRelDtoRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }


    @Override
    @PostMapping("/resources/save")
    @ApiOperation(value = "保存资源")
    @ApiImplicitParam(name = "resourcesDtoRequest", value = "", required = true, dataType = "Request«ResourcesDto»")
    public Response<Void> saveResources(@RequestBody Request<ResourcesDto> resourcesDtoRequest) {
        roleUserPowerService.saveResources(resourcesDtoRequest.getData());
        return new Response<>(resourcesDtoRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/resources/remove")
    @ApiOperation(value = "删除资源")
    @ApiImplicitParam(name = "request", value = "", required = true, dataType = "Request«long»")
    public Response<Void> removeResources(@RequestBody Request<Long> request) {
        roleUserPowerService.removeResources(request.getData());
        return new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/resources/query")
    @ApiOperation(value = "查询资源资源名称")
    @ApiImplicitParam(name = "request", value = "", required = true, dataType = "Request«string»")
    public Response<List<ResourcesDto>> queryResourcesList(@RequestBody Request<String> request) {
        List<ResourcesDto> resourcesDtoList = roleUserPowerService.queryResources(request.getData());//
        return   new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtoList);
    }

    @Override
    @PostMapping("/resources/queryidlist")
    @ApiOperation(value = "根据多个id查询资源")
    @ApiImplicitParam(name = "listRequest", value = "", required = true, dataType = "Request«List«long»»")
    public Response<List<ResourcesDto>> queryResourcesId(@RequestBody Request<List<Long>> listRequest) {
        List<ResourcesDto> resourcesDtos = roleUserPowerService.queryResources(listRequest.getData());
        return  new Response<>(listRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtos);
    }

    @Override
    @PostMapping("/resources/queryid/")
    @ApiOperation(value = "查询资源id")
    @ApiImplicitParam(name = "longRequest", value = "", required = true, dataType = "Request«long»")
    public Response<ResourcesDto> queryResources(@RequestBody Request<Long> longRequest) {
        ResourcesDto resourcesDto = roleUserPowerService.queryResources(longRequest.getData());//
        return  new Response<>(longRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDto);
    }

    @Override
    @PostMapping("/resources/update")
    @ApiOperation(value = "更改查询资源")
    @ApiImplicitParam(name = "resourcesDtoRequest", value = "", required = true, dataType = "Request«ResourcesDto»")
    public Response<ResourcesDto> updateResources(@RequestBody Request<ResourcesDto> resourcesDtoRequest) {
        roleUserPowerService.updateResources(resourcesDtoRequest.getData());
        ResourcesDto resourcesDto = roleUserPowerService.queryResources(resourcesDtoRequest.getData().getId());
        return  new Response<>(resourcesDtoRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDto);
    }


    @Override
    @PostMapping("/roleresources/save")
    @ApiOperation(value = "保存角色与资源关系")
    @ApiImplicitParam(name = "roleResourcesDtoRequest", value = "", required = true, dataType = "Request«RoleResourcesDto»")
    public Response<Void> saveRoleResources(@RequestBody Request<RoleResourcesDto> roleResourcesDtoRequest) {
        roleUserPowerService.saveRoleResources(roleResourcesDtoRequest.getData());
        return new Response<>(roleResourcesDtoRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/roleresources/queryres")
    @ApiOperation(value = "查询角色与资源关系按资源id")
    @ApiImplicitParam(name = "request", value = "", required = true, dataType = "Request«long»")
    public Response<List<RoleResourcesDto>> queryRoleResourcesRes(@RequestBody Request<Long> request) {
        List<RoleResourcesDto> roleResourcesDtos = roleUserPowerService.queryRoleResourcesRes(request.getData());
        return new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, null, roleResourcesDtos);
    }

    @Override
    @PostMapping("/roleresources/queryro")
    @ApiOperation(value = "查询角色与资源关系角色id")
    @ApiImplicitParam(name = "request", value = "", required = true, dataType = "Request«long»")
    public Response<List<RoleResourcesDto>> queryRoleResourcesRo(@RequestBody Request<Long> request) {
        List<RoleResourcesDto> roleResourcesDtos = roleUserPowerService.queryRoleResourcesRo(request.getData());
        return new Response<>(request.getLanguage(),
                Response.SUCCESS_CODE, null, roleResourcesDtos);
    }

    @Override
    @PostMapping("/roleresources/querylist")
    @ApiOperation(value = "通过多个角色id查询资源")
    @ApiImplicitParam(name = "listRequest", value = "", required = true, dataType = "Request«List«long»»")
    public Response<Set<RoleResourcesDto>> queryRoleResourcesList(@RequestBody Request<List<Long>> listRequest) {
        Set<RoleResourcesDto> roleResourcesDtos = roleUserPowerService.queryRoleResourcesList(listRequest.getData());
        return new Response<>(listRequest.getLanguage(),
                Response.SUCCESS_CODE, null, roleResourcesDtos);
    }

    @Override
    @PostMapping("/roleresources/update")
    @ApiOperation(value = "更改角色与资源关系角色")
    @ApiImplicitParam(name = "roleResourcesDtoRequest", value = "", required = true, dataType = "Request«RoleResourcesDto»")
    public  Response<RoleResourcesDto> updateRoleResources(@RequestBody Request<RoleResourcesDto> roleResourcesDtoRequest) {
        roleUserPowerService.updateRoleResources(roleResourcesDtoRequest.getData());
        RoleResourcesDto roleResourcesDto = roleUserPowerService.queryRoleResourcesId(roleResourcesDtoRequest.getData().getId());
        return  new Response<>(roleResourcesDtoRequest.getLanguage(),
                Response.SUCCESS_CODE, null, roleResourcesDto);
    }

    @Override
    @PostMapping("/roleresources/remove")
    @ApiOperation(value = "删除角色与资源关系角色id")
    @ApiImplicitParam(name = "longRequest", value = "", required = true, dataType = "Request«long»")
    public Response<Void> removeRoleResources(@RequestBody Request<Long> longRequest) {
        roleUserPowerService.removeRoleResources(longRequest.getData());
        return new Response<>(longRequest.getLanguage(),
                Response.SUCCESS_CODE, null, null);
    }

    @Override
    @PostMapping("/power/user")
    @ApiOperation(value = "查询用户的资源")
    @ApiImplicitParam(name = "pernrRequest", value = "", required = true, dataType = "Request«string»")
    public Response<List<ResourcesDto>> queryUserResources(@RequestBody Request<String> pernrRequest) {
        List<ResourcesDto> resourcesDtos = roleUserPowerService.queryUserResources(pernrRequest.getData());
        return new Response<>(pernrRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtos);
    }

    @Override
    public Response<List<ResourcesDto>> queryUserResourcesByType(Request<String> pernrRequest) {
        return null;
    }

    @Override
    @PostMapping("/authority/usertorole")
    @ApiOperation(value = "查询用户的角色")
    @ApiImplicitParam(name = "pernrRequest", value = "", required = true, dataType = "Request«string»")
    public Response<List<RoleDtoOut>> queryUserRoleInfo(@RequestBody Request<String> pernrRequest) {

        List<RoleDtoOut> roleDtoOutList = roleUserPowerService.queryUserRoleInfo(pernrRequest.getData());
        return new Response<>(pernrRequest.getLanguage(),
                Response.SUCCESS_CODE, null, roleDtoOutList);
    }

//    @Override
//    public Response<List<ResourcesDto>> queryRoleResourcesInfoByRoleType(Request<String> roleTypeRequest) {
//        return null;
//    }

    @Override
    @PostMapping("/authority/roletoresources")
    @ApiOperation(value = "查询角色对应的资源")
    @ApiImplicitParam(name = "longRequest", value = "", required = true, dataType = "Request«long»")
    public Response<List<ResourcesDto>> queryRoleResourcesInfo(@RequestBody Request<Long> longRequest) {
        List<ResourcesDto> resourcesDtoList = roleUserPowerService.queryRoleResourcesInfo(longRequest.getData());
        return new Response<>(longRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtoList);
    }

    @Override
    @PostMapping("/authority/roleresources/byidtype")
    @ApiOperation(value = "查询角色对应的Type资源")
    @ApiImplicitParam(name = "resourcesByTypeAndIdRequest", value = "", required = true, dataType = "Request«ResourcesByTypeAndId»")
    public Response<List<ResourcesDto>> queryRoleResourcesInfoByTypeAndId(@RequestBody Request<ResourcesByTypeAndId> resourcesByTypeAndIdRequest) {
        List<ResourcesDto> resourcesDtos = roleUserPowerService.queryRoleResourcesInfoByIdAndType(resourcesByTypeAndIdRequest);
        return new Response<>(resourcesByTypeAndIdRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtos);
    }

    @Override
    @PostMapping("/authority/roleresources/byPernrtype")
    @ApiOperation(value = "查询User对应的Type资源")
    @ApiImplicitParam(name = "resourcesByTypeAndPernrRequest", value = "", required = true, dataType = "Request«ResourcesByTypeAndPernr»")
    public Response<List<ResourcesDto>> queryUserResourcesInfoByPernrAndCode(@RequestBody Request<ResourcesByTypeAndPernr> resourcesByTypeAndPernrRequest) {
        String pernr = resourcesByTypeAndPernrRequest.getData().getPernr();
        String type = resourcesByTypeAndPernrRequest.getData().getType();
        List<ResourcesDto> resourcesDtos = roleUserPowerService.queryUserResourcesByTypeAndPernr(pernr, type);
        return new Response<>(resourcesByTypeAndPernrRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtos);
    }


    @Override
    @PostMapping("/authority/roleresources/byrolecode")
    @ApiOperation(value = "查询角色Code对应的资源")
    @ApiImplicitParam(name = "request", value = "", required = true, dataType = "Request«string»")
    public Response<List<ResourcesDto>> queryRoleResourcesInfoAndCode(@RequestBody Request<String> roleTypeRequest) {
        List<ResourcesDto> resourcesDtos = roleUserPowerService.queryRoleResourcesByRoleCode(roleTypeRequest.getData());
        return new Response<>(roleTypeRequest.getLanguage(),
                Response.SUCCESS_CODE, null, resourcesDtos);
    }


}
