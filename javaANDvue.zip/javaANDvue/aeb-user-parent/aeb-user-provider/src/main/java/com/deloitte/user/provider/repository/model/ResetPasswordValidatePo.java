package com.deloitte.user.provider.repository.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 重置密码的校验 Persistent Object
 * date: 21/07/2019 11:59
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@Builder
public class ResetPasswordValidatePo {

    /**
     * 手机号
     */
    private String mobile;


    /**
     * 过期时间的毫秒数
     */
    private long expiredMillis;

    public boolean isExpired() {
        return expiredMillis < System.currentTimeMillis();
    }

}
