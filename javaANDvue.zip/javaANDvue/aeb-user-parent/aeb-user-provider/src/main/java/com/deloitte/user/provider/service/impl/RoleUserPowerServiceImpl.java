package com.deloitte.user.provider.service.impl;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.user.api.model.*;
import com.deloitte.user.provider.repository.ResourcesRepository;
import com.deloitte.user.provider.repository.RoleRepository;
import com.deloitte.user.provider.repository.RoleResourcesRepository;
import com.deloitte.user.provider.repository.RoleUserRelRepository;
import com.deloitte.user.provider.repository.model.ResourcesPo;
import com.deloitte.user.provider.repository.model.RolePo;
import com.deloitte.user.provider.repository.model.RoleResourcesPo;
import com.deloitte.user.provider.repository.model.RoleUserRelPo;
import com.deloitte.user.provider.service.RoleUserPowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RoleUserPowerServiceImpl implements RoleUserPowerService {

    @Autowired
    ResourcesRepository resourcesRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    RoleResourcesRepository roleResourcesRepository;

    @Autowired
    RoleUserRelRepository roleUserRelRepository;

//    protected RoleUserPowerServiceImpl(BaseRepository repository) {
//        super(repository);
//    }

    /**
     * 根据角色名查询
     * @param roleName  角色名
     * @return 角色数据
     */
    @Override
    public List<RoleDtoOut> queryRole(String roleName) {
        List<RoleDtoOut> roleDtoList=new ArrayList<>();
        List<RolePo> byRoleName = roleRepository.findByRoleName(roleName);
        byRoleName.forEach(m->{
            RoleDtoOut roleDto=new RoleDtoOut();
            roleDto.setId(m.getId());
            roleDto.setCode(m.getCode());
            roleDto.setGrantOrgs(m.getGrantOrgs());
            roleDto.setOrgId(m.getOrgId());
            roleDto.setRoleName(m.getRoleName());
            roleDtoList.add(roleDto);
        });
        return roleDtoList;
    }


    @Override
    public RoleDtoOut queryByCode(String code) {
        RolePo rolePo = roleRepository.findByCode(code);
        RoleDtoOut roleDtoOut = new RoleDtoOut();
        roleDtoOut.setCode(rolePo.getCode());
        roleDtoOut.setGrantOrgs(rolePo.getGrantOrgs());
        roleDtoOut.setId(rolePo.getId());
        roleDtoOut.setOrgId(rolePo.getOrgId());
        roleDtoOut.setRoleName(rolePo.getRoleName());
        return roleDtoOut;
    }

    /**
     * 根据id查询
     * @param id  id
     * @return  一个角色对象
     */
    @Override
    public RoleDtoOut queryById(Long id) {
        Optional<RolePo> byId = roleRepository.findById(id);
        RoleDtoOut roleDto=new RoleDtoOut();
        roleDto.setId(byId.get().getId());
        roleDto.setCode(byId.get().getCode());
        roleDto.setGrantOrgs(byId.get().getGrantOrgs());
        roleDto.setOrgId(byId.get().getOrgId());
        roleDto.setRoleName(byId.get().getRoleName());
        return roleDto;
    }

    @Override
    public void updateRole(RoleDtoOut roleDtoOut) {
//        roleRepository.updateByRoleName(roleName,code);
        String code = roleDtoOut.getCode();
        String grantOrgs = roleDtoOut.getGrantOrgs();
        long id = roleDtoOut.getId();
        String orgId = roleDtoOut.getOrgId();
        String roleName = roleDtoOut.getRoleName();
        roleRepository.updateById(id,orgId,grantOrgs,code,roleName);
    }

    /**
     * 逻辑删除角色
     * @param id  id
     *
     */
    @Override
    public void removeRole(Long id) {
        roleRepository.deleteByIdLogically(id);

    }

    /**
     * 实际删除角色
     * @param oid 全局id
     */
    @Override
    public void deleteRole(UUID oid) {
        roleRepository.deleteByOid(oid);
    }

    /**
     * 添加角色
     * @param roleDtoIn
     */
    public void saveRole(RoleDtoIn roleDtoIn) {
        RolePo role=new RolePo();
        role.setCode(roleDtoIn.getCode());
        role.setGrantOrgs(roleDtoIn.getGrantOrgs());
        role.setOrgId(roleDtoIn.getOrgId());
        role.setRoleName(roleDtoIn.getRoleName());
        roleRepository.save(role);
    }

    /**
     * 回复逻辑删除角色
     * @param id
     */
    @Override
    public void recoverById(long id) {
        roleRepository.recoverById(id);
    }

    @Override
    public  List<ResourcesDto> queryResources(String name) {
        List<ResourcesDto> resourcesDtoList = new ArrayList<>();
        List<ResourcesPo> resourcesPoList= resourcesRepository.findByName(name);
        resourcesPoList.forEach(resourcesPo -> {
            ResourcesDto resourcesDto =new ResourcesDto();
            getRes(resourcesDtoList, resourcesPo, resourcesDto);
        });
        return resourcesDtoList;
    }

    @Override
    public List<ResourcesDto> queryResources(List<Long> idList) {
        List list = new ArrayList();
        List<ResourcesPo> allById = resourcesRepository.findAllById(idList);
        return getResourcesDtos(allById, list);
    }

    @Override
    public ResourcesDto queryResources(Long id) {
        Optional<ResourcesPo> resourcesPo = resourcesRepository.findById(id);
        ResourcesDto resourcesDto =new ResourcesDto();
        resourcesDto.setId(resourcesPo.get().getId());
        resourcesDto.setCode(resourcesPo.get().getCode());
        resourcesDto.setLevel(resourcesPo.get().getLevel());
        resourcesDto.setName(resourcesPo.get().getName());
        resourcesDto.setOrgId(resourcesPo.get().getOrgId());
        resourcesDto.setParentId(resourcesPo.get().getParentId());
        resourcesDto.setType(resourcesPo.get().getType());
        resourcesDto.setUri(resourcesPo.get().getUri());
        return resourcesDto;
    }

    @Override
    public Integer updateResources(ResourcesDto resourcesDto) {
        String code = resourcesDto.getCode();
        Integer level = resourcesDto.getLevel();
        String name = resourcesDto.getName();
        String orgId = resourcesDto.getOrgId();
        Long parentId = resourcesDto.getParentId();
        String type = resourcesDto.getType();
        String uri = resourcesDto.getUri();
        Long id = resourcesDto.getId();
        return resourcesRepository.updateCode(id,orgId,parentId,name,uri,level,code,type);
    }

    @Override
    public void removeResources(Long id) {
        resourcesRepository.deleteByIdLogically(id);
    }

    /**
     * 保存资源
     * @param resourcesDto
     */
    @Override
    public void saveResources(ResourcesDto resourcesDto) {
        ResourcesPo resourcesPo = new ResourcesPo();
        resourcesPo.setCode(resourcesDto.getCode());
        resourcesPo.setLevel(resourcesDto.getLevel());
        resourcesPo.setName(resourcesDto.getName());
        resourcesPo.setOrgId(resourcesDto.getOrgId());
        resourcesPo.setParentId(resourcesDto.getParentId());
        resourcesPo.setType(resourcesDto.getType());
        resourcesPo.setUri(resourcesDto.getUri());
        resourcesRepository.save(resourcesPo);

    }

    @Override
    public List<RoleUserRelDto> queryRoleUserRel(String pernr) {
        List list =new ArrayList();

        List<RoleUserRelPo> roleUserRelList = roleUserRelRepository.findByPernr(pernr);
        roleUserRelList.forEach(m->{
            RoleUserRelDto roleUserRelDto = new RoleUserRelDto();
            roleUserRelDto.setOrgId(m.getOrgId());
            roleUserRelDto.setPernr(m.getPernr());
            roleUserRelDto.setRoleId(m.getRoleId());
            list.add(roleUserRelDto);
        });

        return list;
    }

    @Override
    public Integer updateRoleUserRel(UpdateRoleUser updateRoleUser) {
        String pernr = updateRoleUser.getPernr();
        Long roleId = updateRoleUser.getRoleId();
        return roleUserRelRepository.updateRoleId(pernr,roleId);
    }

    @Override
    public void removeRoleUserRel(String pernr) {
        roleUserRelRepository.removeByPernr(pernr);
    }

    /**
     * 保存角色与用户的关联
     * @param roleUserRelDto
     */
    @Override
    public void saveRoleUserRel(RoleUserRelDto roleUserRelDto) {
        RoleUserRelPo roleUserRelPo=new RoleUserRelPo();
        roleUserRelPo.setOrgId(roleUserRelDto.getOrgId());
        roleUserRelPo.setPernr(roleUserRelDto.getPernr());
        roleUserRelPo.setRoleId(roleUserRelDto.getRoleId());
        roleUserRelRepository.save(roleUserRelPo);
    }

    @Override
    public List<RoleResourcesDto> queryRoleResourcesRes(Long resourceId) {
        List<RoleResourcesPo> roleResourcesList = roleResourcesRepository.findByResourceId(resourceId);
        return getRoleResourcesDtos(roleResourcesList);
    }

    @Override
    public List<RoleResourcesDto> queryRoleResourcesRo(Long roleId) {
        List<RoleResourcesPo> roleResourcesList = roleResourcesRepository.findByRoleId(roleId);
        return getRoleResourcesDtos(roleResourcesList);
    }

    @Override
    public Set<RoleResourcesDto> queryRoleResourcesList(List<Long> roleIdList) {
        Set set =new HashSet();
        List<RoleResourcesPo> byRoleIdIn = roleResourcesRepository.findByRoleIdIn(roleIdList);
        byRoleIdIn.forEach(roleResourcesPo -> {
            RoleResourcesDto roleResourcesDto = new RoleResourcesDto();
            roleResourcesDto.setResourceId(roleResourcesPo.getResourceId());
            roleResourcesDto.setRoleId(roleResourcesPo.getRoleId());
            roleResourcesDto.setId(roleResourcesPo.getId());
            set.add(roleResourcesDto);
        });
        return set;
    }

    @Override
    public RoleResourcesDto queryRoleResourcesId(Long id) {
        Optional<RoleResourcesPo> roleResourcesPo = roleResourcesRepository.findById(id);
        RoleResourcesDto roleResourcesDto =new RoleResourcesDto();
        roleResourcesDto.setRoleId(roleResourcesPo.get().getRoleId());
        roleResourcesDto.setResourceId(roleResourcesPo.get().getResourceId());
        roleResourcesDto.setId(roleResourcesPo.get().getId());
        return roleResourcesDto;
    }

    @Override
    public void updateRoleResources(RoleResourcesDto roleResourcesDto) {
        roleResourcesRepository.updateById(roleResourcesDto.getId(),roleResourcesDto.getRoleId(),roleResourcesDto.getResourceId());
    }

    @Override
    public void removeRoleResources(Long id) {
        roleResourcesRepository.recoverById(id);
    }

    private List<RoleResourcesDto> getRoleResourcesDtos(List<RoleResourcesPo> roleResourcesList) {
        List<RoleResourcesDto> list = new ArrayList<>();
        roleResourcesList.forEach(roleResourcesPo -> {
            RoleResourcesDto roleResourcesDto =new RoleResourcesDto();
            roleResourcesDto.setResourceId(roleResourcesPo.getResourceId());
            roleResourcesDto.setRoleId(roleResourcesPo.getRoleId());
            list.add(roleResourcesDto);
        });


        return list;
    }




    /**
     * 保存角色与资源的关系
     * @param roleResourcesDto
     */
    @Override
    public void saveRoleResources(RoleResourcesDto roleResourcesDto) {
        RoleResourcesPo roleResourcesPo = new RoleResourcesPo();
        roleResourcesPo.setResourceId(roleResourcesDto.getResourceId());
        roleResourcesPo.setRoleId(roleResourcesDto.getRoleId());
        roleResourcesRepository.save(roleResourcesPo);
    }

    @Override
    public List<ResourcesDto> queryUserResources(String pernr) {
        List<Long> roleIdList=new ArrayList<>();
        List<RoleUserRelPo> roleUserRelPoList = roleUserRelRepository.findByPernr(pernr);
        roleUserRelPoList.forEach(roleUserRelPo -> {
            Long roleId = roleUserRelPo.getRoleId();
            roleIdList.add(roleId);
        });
        List<RoleResourcesPo> roleResourcesPoList = roleResourcesRepository.findByRoleIdIn(roleIdList);
        List<Long> resourcesId =new ArrayList<>();
        roleResourcesPoList.forEach(roleResourcesPo -> {
            Long resourceId = roleResourcesPo.getResourceId();
            resourcesId.add(resourceId);
        });
        List<ResourcesPo> resourcesPoList = resourcesRepository.findAllById(resourcesId);
        List list = new ArrayList();
        return getResourcesDtos(resourcesPoList, list);
    }

    @Override
    public List<RoleDtoOut> queryUserRoleInfo(String pernr) {
        List<RoleUserRelPo> roleUserRelPoList = roleUserRelRepository.findByPernr(pernr);
        List<Long>  roleIdList=new ArrayList<>();
        roleUserRelPoList.forEach(roleUserRelPo -> {
            Long roleId = roleUserRelPo.getRoleId();
            roleIdList.add(roleId);
        });
        List<RolePo> roleList = roleRepository.findAllById(roleIdList);
        List<RoleDtoOut> resourcesDtoList=new ArrayList<>();
        roleList.forEach(rolePo -> {
            RoleDtoOut roleDtoOut =new RoleDtoOut();
            roleDtoOut.setCode(rolePo.getCode());
            roleDtoOut.setGrantOrgs(rolePo.getGrantOrgs());
            roleDtoOut.setId(rolePo.getId());
            roleDtoOut.setOrgId(rolePo.getOrgId());
            roleDtoOut.setRoleName(rolePo.getRoleName());
            resourcesDtoList.add(roleDtoOut);
        });
        return resourcesDtoList;
    }

    @Override
    public List<ResourcesDto> queryRoleResourcesInfo(Long roleId) {
        List<RoleResourcesPo> roleResourcesPoList = roleResourcesRepository.findByRoleId(roleId);
        List<Long> resourcesIdList =new ArrayList<>();
        roleResourcesPoList.forEach(roleResourcesPo -> resourcesIdList.add(roleResourcesPo.getResourceId()));
        List<ResourcesPo> resourcesPoList = resourcesRepository.findAllById(resourcesIdList);
        List<ResourcesDto> resourcesDtoList = new ArrayList<>();
        resourcesPoList.forEach(resourcesPo -> {
            ResourcesDto resourcesDto = new ResourcesDto();
            resourcesDto.setUri(resourcesPo.getUri());
            resourcesDto.setType(resourcesPo.getType());
            resourcesDto.setOrgId(resourcesPo.getOrgId());
            resourcesDto.setName(resourcesPo.getName());
            resourcesDto.setCode(resourcesPo.getCode());
            resourcesDto.setId(resourcesPo.getId());
            resourcesDto.setLevel(resourcesPo.getLevel());
            resourcesDto.setParentId(resourcesPo.getParentId());
            resourcesDtoList.add(resourcesDto);
        });
        return resourcesDtoList;
    }

    @Override
    public List<ResourcesDto> queryRoleResourcesInfoByIdAndType(Request<ResourcesByTypeAndId> resourcesByTypeAndIdRequest) {
        Long roleId = resourcesByTypeAndIdRequest.getData().getId();
        String type = resourcesByTypeAndIdRequest.getData().getType();
        List<RoleResourcesPo> roleResourcesPoList = roleResourcesRepository.findByRoleId(roleId);
        List<Long> resourcesIdList =new ArrayList<>();
        roleResourcesPoList.forEach(roleResourcesPo -> resourcesIdList.add(roleResourcesPo.getResourceId()));
        List<ResourcesPo> resourcesPoList = resourcesRepository.findByTypeAndIdIn(type,resourcesIdList);
        List<ResourcesDto> resourcesDtoList = new ArrayList<>();
        resourcesPoList.forEach(resourcesPo -> {
            ResourcesDto resourcesDto = new ResourcesDto();
            resourcesDto.setUri(resourcesPo.getUri());
            resourcesDto.setType(resourcesPo.getType());
            resourcesDto.setOrgId(resourcesPo.getOrgId());
            resourcesDto.setName(resourcesPo.getName());
            resourcesDto.setCode(resourcesPo.getCode());
            resourcesDto.setId(resourcesPo.getId());
            resourcesDto.setLevel(resourcesPo.getLevel());
            resourcesDto.setParentId(resourcesPo.getParentId());
            resourcesDtoList.add(resourcesDto);
        });
        return resourcesDtoList;
    }

    @Override
    public List<ResourcesDto> queryUserResourcesByTypeAndPernr(String pernr, String type) {
        List<Long> roleIdList=new ArrayList<>();
        List<RoleUserRelPo> roleUserRelPoList = roleUserRelRepository.findByPernr(pernr);
        roleUserRelPoList.forEach(roleUserRelPo -> {
            Long roleId = roleUserRelPo.getRoleId();
            roleIdList.add(roleId);
        });
        List<RoleResourcesPo> roleResourcesPoList = roleResourcesRepository.findByRoleIdIn(roleIdList);
        List<Long> resourcesId =new ArrayList<>();
        roleResourcesPoList.forEach(roleResourcesPo -> {
            Long resourceId = roleResourcesPo.getResourceId();
            resourcesId.add(resourceId);
        });
        List<ResourcesPo> resourcesPoList = resourcesRepository.findByTypeAndIdIn(type,resourcesId);
        List list = new ArrayList();
        return getResourcesDtos(resourcesPoList, list);
    }

    @Override
    public List<ResourcesDto> queryRoleResourcesByRoleCode(String code) {
        RolePo rolePo = roleRepository.findByCode(code);
        Long roleId=rolePo.getId();
        List<RoleResourcesPo> roleResourcesPoList = roleResourcesRepository.findByRoleId(roleId);
        List<Long> resourcesIdList=new ArrayList<>();
        roleResourcesPoList.forEach(roleResourcesPo -> {
            resourcesIdList.add(roleResourcesPo.getResourceId());
        });
        List<ResourcesPo> resourcesPoList = resourcesRepository.findAllById(resourcesIdList);
        List list = new ArrayList();
        return getResourcesDtos(resourcesPoList, list);
    }

    private List<ResourcesDto> getResourcesDtos(List<ResourcesPo> allById, List list) {
        allById.forEach(resourcesPo -> {
            ResourcesDto resourcesDto = new ResourcesDto();
            resourcesDto.setId(resourcesPo.getId());
            getRes(list, resourcesPo, resourcesDto);
        });
        return list;
    }

    private void getRes(List list, ResourcesPo resourcesPo, ResourcesDto resourcesDto) {
        resourcesDto.setCode(resourcesPo.getCode());
        resourcesDto.setLevel(resourcesPo.getLevel());
        resourcesDto.setName(resourcesPo.getName());
        resourcesDto.setOrgId(resourcesPo.getOrgId());
        resourcesDto.setParentId(resourcesPo.getParentId());
        resourcesDto.setType(resourcesPo.getType());
        resourcesDto.setUri(resourcesPo.getUri());
        list.add(resourcesDto);
    }
}
