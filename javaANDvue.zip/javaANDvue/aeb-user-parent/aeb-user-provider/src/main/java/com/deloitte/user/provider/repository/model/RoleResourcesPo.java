package com.deloitte.user.provider.repository.model;


import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "dhr_sys_role_resource_rel")
@Entity(name = "RoleResources")
@SQLDelete(sql = "update RoleResources set RoleResources.deleted = 1 where RoleResources.id = ?")
@Where(clause = "deleted = 0")
public class RoleResourcesPo extends BasePo {


    private static final long serialVersionUID = -4601666480056188250L;

    @Column(name = "role_id",length = 50)
    private Long roleId;

    @Column(name = "Resource_id",length = 50)
    private Long resourceId;

}
