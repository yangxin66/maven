package com.deloitte.user.provider.repository;



import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.user.provider.repository.model.RoleResourcesPo;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;


@Repository
public interface RoleResourcesRepository extends BaseRepository<RoleResourcesPo> {



    @Transactional
    @Modifying
    @Query("update RoleResources r set r.roleId=?2,r.resourceId=?3 where  r.id=?1" )
    Integer updateById(Long id, Long roleId, Long resourceId);

    List<RoleResourcesPo> findByResourceId(Long resourceId);

    List<RoleResourcesPo> findByRoleId(Long roleId);


    List<RoleResourcesPo> findByRoleIdIn(List roleList);

    @Transactional
    @Modifying
    @Query("update RoleResources r set r.deleted=true where  r.resourceId=?1" )
    Boolean removeByResourceId(String resourceId);


    @Transactional
    @Modifying
    @Query("update RoleResources r set deleted=true where  r.id=?1" )
    Boolean removeById(Long id);

    @Transactional
    @Modifying
    @Query("update RoleResources r set deleted=true where r.roleId=?1" )
    Boolean removeByRoleId(String roleId);
}
