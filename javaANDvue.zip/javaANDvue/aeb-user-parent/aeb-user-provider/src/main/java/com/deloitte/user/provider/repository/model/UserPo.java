package com.deloitte.user.provider.repository.model;

import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 用户 Persistent Object
 *
 * @author xideng
 */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "d_user")
@Entity(name = "user")
@SQLDelete(sql = "update user set deleted = 1 where id = ?")
@Where(clause = "deleted = 0")
public class UserPo extends BasePo {

    private static final long serialVersionUID = -3762972068277820498L;

    /**
     * 用户名
     */
    @Column(name = "username", length = 100)
    private String username;

    /**
     * 用户邮箱
     */
    @Column(name = "email", length = 100, unique = true)
    private String email;

    /**
     * 员工编号-关联DHR员工编号
     */
    @Column(name = "staff_no", length = 100,nullable = true)
    private String staffNo;

    /**
     * 用户手机号码
     */
    @Column(name = "mobile", length = 20, unique = true)
    private String mobile;

    /**
     * 用户密码
     */
    @Column(name = "password", length = 100, nullable = false)
    private String password;

    /**
     * 用户启用标识符
     */
    @Column(name = "enabled", nullable = false)
    private Boolean enabled;
}
