package com.deloitte.user.provider.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author chunliucq
 * @since 28/09/2019 14:46
 */
@Data
@Component
@ConfigurationProperties(prefix = "com.deloitte.user")
public class UserProperties {
    private String defalutRole = "staff";
}
