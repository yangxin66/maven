package com.deloitte.user.provider.repository;

import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.user.provider.repository.model.UserPo;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserFromEmailRepository extends BaseRepository<UserPo> {

    Optional<UserPo> findByEmailAndDeletedIsFalse(String email);

    // 通过员工编号查询用户信息
    UserPo findByStaffNoAndDeletedFalseAndEnabledTrue(String username);

}
