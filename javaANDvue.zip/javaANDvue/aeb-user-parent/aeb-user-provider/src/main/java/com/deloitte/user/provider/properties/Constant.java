package com.deloitte.user.provider.properties;

/**
 * 常量字符串
 */
public class Constant {


    /**
     * Redis Key 前缀
     */
    // 图片验证码KEY
    public static String LOGIN_IMAGE_CODE_KEY_PREFIX = "LOGIN:IMAGE_RANDOM_CODE_";
    // 账号被锁标志  0-未锁  1-被锁定
    public static String LOGIN_ACOUNT_LOCKED_KEY_PREFIX = "LOGIN:ACCOUNT_LOCKED_FLAG_";
    // 账号被锁时间 时间格式:yyyy-MM-dd HH:mm:ss
    public static String LOGIN_ACOUNT_LOCKED_TIME_KEY_PREFIX = "LOGIN:ACCOUNT_LOCKED_TIME_";
    // 账号连续登录失败次数
    public static String LOGIN_ACOUNT_CONTINUITY_FAIL_CUNT_KEY_PREFIX = "LOGIN:ACCOUNT_CONTINUITY_FAIL_COUNT_";

}
