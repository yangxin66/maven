package com.deloitte.user.provider.exception;

/**
 * 调用第三方的异常code
 * <br/>27/08/2019 15:45
 *
 * @author lshao
 */
public enum DUserException {
    CHECK_VALID_CODE_FAIL("001-00-10000", "验证码错误"),
    SERIALIZE_VALID_CODE_FAIL("001-00-10001", "验证码校验信息反序列化异常"),
    ACCOUNT_NOT_REGISTER("001-00-10002", "该手机号未注册"),
    SMS_CHECK_FAIL("001-00-10003","验证信息错误，请重新发送短信验证码并校验"),
    RESET_PASSWORD_SERIALIZE("001-00-10004","重置密码实体序列化异常"),
    SMS_CHECK_EXPIRED_FAIL("001-00-10005","验证信息已过期，请重新发送短信验证码并校验"),
    ACCOUNT_TOKEN_CHECK_NOT_MATCHES("001-00-10006","手机号信息与验证信息不匹配"),
    SMS_VALIDCODE_GET_TOO_MANY_TIMES("001-00-10007","该号码获取验证码次数过多,请%s小时后再试"),
    SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES("001-00-10008","该号码获取验证码次数过多,请%s小时后再试"),
    SMS_VALIDCODE_CHECKFAILT_GET_NEW("001-00-10009","验证码错误超过%d次，请重新获取验证码"),
    SMS_VALIDCODE_SEND_FAIL("001-00-10010","短信发送失败,请稍后重试"),
    SMS_VALIDCODE_EXPIRE("001-00-10011","短信发送失败,请稍后重试"),
    SMS_VALIDCODE_NULL("001-00-10013","验证码不能为空"),
    SMS_VALIDCODE_ERROR("001-00-10013","验证码不正确"),
    ACCOUNT_LOCKED("001-00-10014","您的帐户已锁定，请%d分钟后再操作"),
    ACCOUNT_LOGIN_FAILT("001-00-10015","登录失败"),
    EMAIL_REGISTER_REPEAT("001-00-10016","该邮箱已注册"),
    EMAIL_REGISTER_NOT("001-00-10017","该邮箱未注册"),
    EMAIL_SEND_TOO_MANY_TIME("001-00-10018","该邮箱已超过发送次数，请于24小时之后重试"),
    EMAIL_TOKEN_EXPIRED("001-00-10019","token已失效，请重新通过邮箱注册"),
    TOKEN_EXPIRED("001-00-10020","token缓存已失效"),
    EAMIL_TOKEN_USER_NOT_FOUND("001-00-10021","无法找到该邮箱对应的用户信息"),
    ACCOUNT_REGISTERED("001-00-10022","该手机号已注册"),
    ACCOUNT_PASSWORD_NOT_BLANK("001-00-10023","密码不允许出现空格"),
    ACCOUNT_PASSWORD_CONFIRM_NOT_BLANK("001-00-100024","确认密码不允许出现空格"),
    ACCOUNT_PASSWORD_DIS_MATCH("001-00-100025","两次输入的密码不一致"),
    TELPHONE_FORMAT_ERROR("001-00-10026","手机号码错误，请使用中国大陆11位手机号注册"),
    IMAGE_CODE_EXCEPTION("001-00-100027","图形验证码获取异常"),
    SMS_PARAMS_ERROR("001-00-10028","参数错误，smsOriginEnum只允许为LOGIN/REGISTER/RESET_PWD"),
    SYS_PRAMA_ERROR("001-00-10029","参数不合法"),
    USER_NOT_REGISTER("001-00-10030","该用户未注册"),
    USER_STAFFNO_REGISTERED("001-00-10031","该员工编号已注册"),
    USER_NOT_FOUND("001-00-10032","该登录账户未查询到用户信息"),


    ;

    private String code;
    private String message;

    DUserException(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
