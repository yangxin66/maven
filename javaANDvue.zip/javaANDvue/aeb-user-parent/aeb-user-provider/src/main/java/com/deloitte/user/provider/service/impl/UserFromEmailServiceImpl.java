package com.deloitte.user.provider.service.impl;

import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.jpa.service.BaseServiceImpl;
import com.deloitte.notification.provider.api.EmailRestInterface;
import com.deloitte.notification.provider.api.model.EmailParamDto;
import com.deloitte.user.api.model.*;
import com.deloitte.user.provider.exception.DUserException;
import com.deloitte.user.provider.properties.EmailProperties;
import com.deloitte.user.provider.properties.UserProperties;
import com.deloitte.user.provider.repository.CommonRedisRepository;
import com.deloitte.user.provider.repository.UserFromEmailRepository;
import com.deloitte.user.provider.repository.UserRepository;
import com.deloitte.user.provider.repository.model.UserPo;
import com.deloitte.user.provider.service.ImgVerifyService;
import com.deloitte.user.provider.service.RoleUserPowerService;
import com.deloitte.user.provider.service.UserFromEmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;


@Service
@Transactional(rollbackFor = Exception.class)
public class UserFromEmailServiceImpl extends BaseServiceImpl<UserPo> implements UserFromEmailService {
    //邮箱缓存信息前缀
    private static final String EMAIL_CACHE_PREFIX = "EMAIL:";
    //邮箱缓存-用于实现同一个邮箱的间隔时间内发送相同密钥
    private static final String EMAIL_CACHE_COUNT_DOWN = EMAIL_CACHE_PREFIX + "COUNT_DOWN:";
    //邮箱缓存-用于实现同一个邮箱的一天只能发送二十次
    private static final String EMAIL_CACHE_SEND_TIMES = EMAIL_CACHE_PREFIX + "SEND_TIMES:";
    //邮箱缓存-以加密code为键存储邮箱信息
    private static final String EMAIL_CACHE_SECURITY_CODE = EMAIL_CACHE_PREFIX + "SECURITY_CODE:";
    //验证链接的后的token参数名称
    private static final String VERIFY_TOKEN_PARAMETER = "token";
    //邮件注册主题
    private static final String EMAIL_REGISTER_SUBJECT = "德勤用户系统注册确认邮件";
    //邮件注册主题
    private static final String EMAIL_REPASS_SUBJECT = "德勤用户系统密码找回确认邮件";
    private final CommonRedisRepository commonRedisRepository;
    private final UserFromEmailRepository repository;
    private final ImgVerifyService imgVerifyService;
    private final EmailProperties emailProperties;

    @Autowired
    private UserRepository userRepository;


    private final EmailRestInterface emailRestInterface;

    @Autowired
    RoleUserPowerService roleUserPowerService;

    @Autowired
    private UserProperties userProperties;

    protected UserFromEmailServiceImpl(UserFromEmailRepository repository, CommonRedisRepository commonRedisRepository, ImgVerifyService imgVerifyService, EmailProperties emailProperties, EmailRestInterface emailRestInterface) {
        super(repository);
        this.repository = repository;
        this.commonRedisRepository = commonRedisRepository;
        this.imgVerifyService = imgVerifyService;
        this.emailProperties = emailProperties;
        this.emailRestInterface = emailRestInterface;
    }

    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public String generateEmailVerify(EmailVerifyDto dto, SendEmailEnum sendType) {
        String md5Code;
        String email = dto.getEmail();
        String imgCode = dto.getImgCode();
        //验证图形验证码是否正确
        if (!this.imgVerifyService.verifyImgCode(imgCode.toUpperCase(), imgCode)) {
            throw new BusinessException(DUserException.CHECK_VALID_CODE_FAIL.getCode(),DUserException.CHECK_VALID_CODE_FAIL.getMessage());
        }
        //验证邮箱是否具备注册条件(当前必须是注册方式下才进行判断)
        if (this.verifyIsRegister(email) && sendType == SendEmailEnum.REGISTER_INFO) {
            throw new BusinessException(DUserException.EMAIL_REGISTER_REPEAT.getCode(),DUserException.EMAIL_REGISTER_REPEAT.getMessage());
        }
        //验证邮箱是否已经注册（当前必须是密码找回方式下才进行判断）
        if (!this.verifyIsRegister(email) && sendType == SendEmailEnum.FIND_PASSWORD) {
            throw new BusinessException(DUserException.EMAIL_REGISTER_NOT.getCode(),DUserException.EMAIL_REGISTER_NOT.getMessage());
        }
        //验证邮箱是否已达到规定时间内的发送次数
        if (this.verifyIsOutOfSendCount(email, sendType)) {
            throw new BusinessException(DUserException.EMAIL_SEND_TOO_MANY_TIME.getCode(),DUserException.EMAIL_SEND_TOO_MANY_TIME.getMessage());
        }
        //验证redis中该地址是否具备重新生成随机码的条件
        if (this.verifyIsOverdue(email, sendType)) {
            //生成md5随机码
            md5Code = this.encodeByMd5(this.generateRandom());
            //更新到redis缓存
            this.setEmailOverdueCaheInfo(email, md5Code, sendType);
        } else {
            md5Code = this.getEmailOverdueCaheInfo(email, sendType);
        }
        //将邮箱存到缓存中，用于后续注册提交后通过加密串获取正在注册的邮箱
        this.setEmailSecurityCode(md5Code, email, sendType);

        //拼装地址
        String assemblyUrl = this.assemblyVerifyUrl(md5Code, sendType);
        //发送邮件
        this.sendEmail(email, assemblyUrl, sendType);
        return assemblyUrl;
    }


    @Override
    public boolean verifyIsOutOfSendCount(String email, SendEmailEnum sendType) {
        if (commonRedisRepository.hasKey(EMAIL_CACHE_SEND_TIMES + sendType.getName() + email)) {
            int count = (int) commonRedisRepository.get(EMAIL_CACHE_SEND_TIMES + sendType.getName() + email);
            long expire = commonRedisRepository.getExpire(EMAIL_CACHE_SEND_TIMES + sendType.getName() + email, TimeUnit.SECONDS);
            count--;
            if (count > 0) {
                commonRedisRepository.set(EMAIL_CACHE_SEND_TIMES + sendType.getName() + email, count, expire, TimeUnit.SECONDS);
                return false;
            } else {
                return true;
            }
        } else {
            commonRedisRepository.set(EMAIL_CACHE_SEND_TIMES + sendType.getName() + email, emailProperties.getLimitSendCount(), emailProperties.getLimitSendTime(), TimeUnit.SECONDS);
            return false;
        }
    }

    @Override
    public boolean verifyIsOverdue(String email, SendEmailEnum sendType) {
        Object e = commonRedisRepository.get(EMAIL_CACHE_COUNT_DOWN + sendType.getName() + email);
        return Objects.isNull(e);
    }

    @Override
    public boolean verifyIsRegister(String email) {
        Optional<UserPo> userPoOptional = repository.findByEmailAndDeletedIsFalse(email);
        return userPoOptional.isPresent();
    }

    @Override
    public void sendEmail(String email, String verifyUrl, SendEmailEnum sendType) {
        String emailContent;
        EmailParamDto dto = EmailParamDto.builder().build();
        dto.setReceivers(email);
        //注册
        if (sendType == SendEmailEnum.REGISTER_INFO) {
            emailContent = this.getEmailRegisterContent(verifyUrl);
            dto.setContent(emailContent);
            dto.setSubject(EMAIL_REGISTER_SUBJECT);
            //找回密码
        } else if (sendType == SendEmailEnum.FIND_PASSWORD) {
            emailContent = this.getEmailRepassContent(verifyUrl);
            dto.setContent(emailContent);
            dto.setSubject(EMAIL_REPASS_SUBJECT);
        }

        this.emailRestInterface.sendEmailWithNoAttachment(dto);
        //this.emailRestInterface.sendEmail(dto,null);

    }

    private String getEmailRegisterContent(String verifyUrl) {
        return "<p>尊敬的用户:</p><br /><p>欢迎您注册使用德勤产品，请点击以下链接完成注册验证，验证链接三十分钟内有效，请勿泄露！请点击以下链接激活此账号：</p><p><a href='" + verifyUrl + "'>" + verifyUrl + "</a></p>";
    }

    private String getEmailRepassContent(String verifyUrl) {
        return "<p>尊敬的用户:</p><br /><p>欢迎您使用德勤产品，请点击以下链接完成密码找回，验证链接三十分钟内有效，请勿泄露！请点击以下链接进行密码找回：</p><p><a href='" + verifyUrl + "'>" + verifyUrl + "</a></p>";
    }

    private void setEmailOverdueCaheInfo(String email, String md5Code, SendEmailEnum sendType) {
        commonRedisRepository.set(EMAIL_CACHE_COUNT_DOWN + sendType.getName() + email, md5Code, emailProperties.getIntervalTime(), TimeUnit.SECONDS);
    }

    /**
     * 以加密code为键，以邮箱为值
     *
     * @param email   用户邮箱
     * @param md5Code 加密code
     */
    private void setEmailSecurityCode(String md5Code, String email, SendEmailEnum sendType) {
        commonRedisRepository.set(EMAIL_CACHE_SECURITY_CODE + sendType.getName() + md5Code, email, emailProperties.getIntervalTime(), TimeUnit.SECONDS);
    }

    /**
     * 获取md5对应的邮箱地址，如果获取不到则说明md5Code已经失效
     *
     * @param md5Code 加密code
     */
    @Override
    public String getEmailSecurityCode(String md5Code, SendEmailEnum sendType) {
        Object code = commonRedisRepository.get(EMAIL_CACHE_SECURITY_CODE + sendType.getName() + md5Code);
        if (Objects.isNull(code)) {
            throw new BusinessException(DUserException.EMAIL_TOKEN_EXPIRED.getCode(),DUserException.EMAIL_TOKEN_EXPIRED.getMessage());
        }
        return (String) code;
    }

    @Override
    public void removeEmailSecurityCode(String md5Code, SendEmailEnum sendType) {
        commonRedisRepository.remove(EMAIL_CACHE_SECURITY_CODE + sendType.getName() + md5Code);
    }

    @Override
    public void registerUserByEmail(UserEmailDto dto) {
        this.create(this.generateAddUser(dto));
    }

    @Override
    public void registerUserByDhr(UserDhrDto dto){
        UserPo userPo = repository.findByStaffNoAndDeletedFalseAndEnabledTrue(dto.getStaffNo());
        if (userPo != null){
            throw new BusinessException(DUserException.USER_STAFFNO_REGISTERED.getCode(),DUserException.USER_STAFFNO_REGISTERED.getMessage());
        }
        UserPo mobileTmpUser = userRepository.findByMobileAndDeletedFalseAndEnabledTrue(dto.getMobile());
        UserPo emailTmpUser = userRepository.findByEmailAndDeletedFalseAndEnabledTrue(dto.getEmail());

        userPo = new UserPo();
        userPo.setStaffNo(dto.getStaffNo());
        if (mobileTmpUser == null){
            userPo.setMobile(dto.getMobile());
        }
        if (emailTmpUser == null){
            userPo.setEmail(dto.getEmail());
        }
        userPo.setPassword(passwordEncoder.encode(dto.getPassword()));
        userPo.setEnabled(true);
        this.create(userPo);

        // 新建用户默认 员工角色
        String defaultRoleCode = userProperties.getDefalutRole();
        RoleDtoOut roleDtoOut = roleUserPowerService.queryByCode(defaultRoleCode);
        RoleUserRelDto roleUserRelDto = new RoleUserRelDto();
        roleUserRelDto.setOrgId("");
        roleUserRelDto.setPernr(dto.getStaffNo());
        roleUserRelDto.setRoleId(roleDtoOut.getId());
        roleUserPowerService.saveRoleUserRel(roleUserRelDto);
    }


    @Override
    public void updatePasswordByEmail(UserEmailDto dto) {
        this.update(this.generateUpdateUser(dto));
    }

    private String getEmailOverdueCaheInfo(String email, SendEmailEnum sendType) {
        Object e = commonRedisRepository.get(EMAIL_CACHE_COUNT_DOWN + sendType.getName() + email);
        if (Objects.isNull(e)) {
            throw new BusinessException(DUserException.TOKEN_EXPIRED.getCode(),DUserException.TOKEN_EXPIRED.getMessage());
        } else {
            return (String) commonRedisRepository.get(EMAIL_CACHE_COUNT_DOWN + sendType.getName() + email);
        }

    }

    /**
     * 拼接邮箱中反馈给用户的注册地址
     *
     * @param md5Code 加密code
     */
    private String assemblyVerifyUrl(String md5Code, SendEmailEnum sendType) {
        String propertiesUrl;
        if (sendType == SendEmailEnum.REGISTER_INFO) {
            propertiesUrl = emailProperties.getRegisterUrl();
        } else {
            propertiesUrl = emailProperties.getRepassUrl();
        }
        return propertiesUrl + "?" + VERIFY_TOKEN_PARAMETER + "=" + md5Code;
    }

    /**
     * 生成32位md5加密串
     *
     * @param code code
     */
    private String encodeByMd5(String code) {
        return DigestUtils.md5DigestAsHex(code.getBytes());
    }

    /**
     * 生成随机字符串
     */
    private String generateRandom() {
        return Math.random() + "";
    }

    /**
     * 生成注册的持久层实体
     */
    private UserPo generateAddUser(UserEmailDto dto) {
        String email = this.getEmailSecurityCode(dto.getToken(), SendEmailEnum.REGISTER_INFO);
        if (this.verifyIsRegister(email)) {
            throw new BusinessException(DUserException.EMAIL_REGISTER_REPEAT.getCode(),DUserException.EMAIL_REGISTER_REPEAT.getMessage());
        }
        UserPo userPo = new UserPo();
        userPo.setEmail(email);
        userPo.setPassword(passwordEncoder.encode(dto.getPassword()));
        userPo.setEnabled(true);
        return userPo;
    }

    /**
     * 生成持久层实体
     */
    private UserPo generateUpdateUser(UserEmailDto dto) {
        String email = this.getEmailSecurityCode(dto.getToken(), SendEmailEnum.FIND_PASSWORD);
        Optional<UserPo> userPoOptional = repository.findByEmailAndDeletedIsFalse(email);
        if (!userPoOptional.isPresent()) {
            throw new BusinessException(DUserException.EAMIL_TOKEN_USER_NOT_FOUND.getCode(),DUserException.EAMIL_TOKEN_USER_NOT_FOUND.getMessage());
        }
        UserPo userPo = userPoOptional.get();
        userPo.setEmail(email);
        userPo.setPassword(passwordEncoder.encode(dto.getPassword()));
        return userPo;
    }
}
