package com.deloitte.user.provider.service;


import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.jpa.service.BaseService;
import com.deloitte.user.api.model.EmailVerifyDto;
import com.deloitte.user.api.model.UserDhrDto;
import com.deloitte.user.api.model.UserDto;
import com.deloitte.user.api.model.UserEmailDto;
import com.deloitte.user.provider.repository.model.UserPo;

/**
 * 通过email进行注册登录的服务层
 * <br/>21/07/2019 17:38
 *
 * @author lshao
 */
public interface UserFromEmailService extends BaseService<UserPo> {
    /**
     * 区分发送的验证邮件是注册还是找回密码
     */
    enum SendEmailEnum {
        REGISTER_INFO("REGISTER_INFO:"),
        FIND_PASSWORD("FIND_PASSWORD:");

        private String name;

        SendEmailEnum(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }


    }

    /**
     * 指定邮箱地址发送注册验证邮件
     */
    String generateEmailVerify(EmailVerifyDto dto, SendEmailEnum sendType);

    /**
     * 验证邮箱是否超过当天发送次数
     *
     * @param email：邮箱
     */
    boolean verifyIsOutOfSendCount(String email, SendEmailEnum sendType);

    /**
     * 验证邮箱是否距离上次发送超过预设的间隔时间
     *
     * @param email：邮箱
     */
    boolean verifyIsOverdue(String email, SendEmailEnum sendType);

    /**
     * 验证邮箱是否已经被注册
     *
     * @param email：邮箱
     */
    boolean verifyIsRegister(String email);

    /**
     * 发送注册验证的邮件
     *
     * @param email       接收者邮箱地址
     * @param verifyUrl  验证链接
     * @param sendType    {@link UserFromEmailService.SendEmailEnum}
     */
    void sendEmail(String email, String verifyUrl, SendEmailEnum sendType);

    /**
     * 根据token获取缓存中的用户邮箱
     *
     * @param md5Code
     * @return
     */
    String getEmailSecurityCode(String md5Code, SendEmailEnum sendType);

    /**
     * 移除对应的token在缓存中的记录
     *
     * @param md5Code
     */
    void removeEmailSecurityCode(String md5Code, SendEmailEnum sendType);

    /**
     * 通过邮箱注册
     *
     * @param dto
     */
    void registerUserByEmail(UserEmailDto dto);

    /**
     * 通过邮箱进行密码修改
     * @param dto
     */
    void updatePasswordByEmail(UserEmailDto dto);

    /**
     * 通过员工编号注册
     * @param dto
     */
    void registerUserByDhr(UserDhrDto dto);

}
