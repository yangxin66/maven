package com.deloitte.user.provider.web.converter;

import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.user.api.model.SmsOriginEnum;
import com.deloitte.user.provider.exception.DUserException;
import org.springframework.core.convert.converter.Converter;

/**
 * SmsOriginEnum 转换器
 * date: 24/07/2019 13:54
 *
 * @author wgong
 * @since 0.0.1
 */
public class SmsOriginConverter implements Converter<String, SmsOriginEnum> {
    @Override
    public SmsOriginEnum convert(String source) {
        if (!source.equals(SmsOriginEnum.LOGIN.toString()) && !source.equals(SmsOriginEnum.REGISTER.toString())
                && !source.equals(SmsOriginEnum.RESET_PWD.toString())) {
            throw new BusinessException(DUserException.SMS_PARAMS_ERROR.getCode(),
                    DUserException.SMS_PARAMS_ERROR.getMessage());
        }
        return SmsOriginEnum.valueOf(source);
    }
}
