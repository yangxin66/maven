package com.deloitte.user.provider.service;

import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.jpa.service.BaseService;
import com.deloitte.user.api.model.*;

import java.util.List;
import java.util.Set;
import java.util.UUID;

public interface RoleUserPowerService extends BaseService {

    List<RoleDtoOut> queryRole(String roleName);
    RoleDtoOut queryById(Long id);
    RoleDtoOut queryByCode(String code);
    void updateRole(RoleDtoOut roleDtoOut);
    void removeRole(Long id);
    void deleteRole(UUID oid);
    void saveRole(RoleDtoIn roleDtoIn);
    void recoverById(long id);


    List<ResourcesDto> queryResources(String name);
    List<ResourcesDto> queryResources(List<Long> idList);
    ResourcesDto queryResources(Long id);
    Integer updateResources(ResourcesDto resourcesDto);
    void removeResources(Long id);
    void saveResources(ResourcesDto resourcesDto);


    List<RoleUserRelDto> queryRoleUserRel(String pernr);
    Integer updateRoleUserRel(UpdateRoleUser updateRoleUser);
    void removeRoleUserRel(String pernr);
    void saveRoleUserRel(RoleUserRelDto roleUserRelDto);


    List<RoleResourcesDto> queryRoleResourcesRes(Long resourceId);
    List<RoleResourcesDto> queryRoleResourcesRo(Long roleId);
    Set<RoleResourcesDto> queryRoleResourcesList(List<Long> roleIdList);
    RoleResourcesDto queryRoleResourcesId(Long id);
    void updateRoleResources(RoleResourcesDto roleResourcesDto);
    void removeRoleResources(Long id);
    void saveRoleResources(RoleResourcesDto roleResourcesDto);





    List<ResourcesDto> queryUserResources(String pernr);




    List<RoleDtoOut> queryUserRoleInfo(String pernr);


    List<ResourcesDto> queryRoleResourcesInfo(Long roleId);

    List<ResourcesDto> queryRoleResourcesInfoByIdAndType(Request<ResourcesByTypeAndId> resourcesByTypeAndIdRequest);

    List<ResourcesDto> queryUserResourcesByTypeAndPernr(String pernr,String type);

    List<ResourcesDto> queryRoleResourcesByRoleCode(String code);

}
