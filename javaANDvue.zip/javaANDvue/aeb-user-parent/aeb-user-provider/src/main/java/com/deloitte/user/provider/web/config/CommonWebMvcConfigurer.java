package com.deloitte.user.provider.web.config;

import com.deloitte.user.provider.web.converter.SmsOriginConverter;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


/**
 * 跨域配置类
 *
 * @author wgong
 * @since 0.0.1
 */
@Configuration
public class CommonWebMvcConfigurer implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("*")
                .allowedMethods("GET", "POST", "PUT", "HEAD", "DELETE", "OPTIONS") // 允许请求方式  必填OPTIONS
                .allowCredentials(true) // 允许cookie
                .maxAge(3600);// 30分钟
    }

    @Override
    public void addFormatters(FormatterRegistry registry) {
        registry.addConverter(new SmsOriginConverter());
    }

}
