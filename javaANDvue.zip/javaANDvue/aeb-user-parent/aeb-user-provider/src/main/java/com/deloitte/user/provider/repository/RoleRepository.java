package com.deloitte.user.provider.repository;


import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.user.provider.repository.model.RolePo;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;


@Repository
public interface RoleRepository extends BaseRepository<RolePo> {
    /**
     * 根据角色名查询角色
     *
     * @param roleName
     * @return
     */
    List<RolePo> findByRoleName(String roleName);

//    @Query("select from Role r where r.id=?1")
//    Optional<RolePo> findById(Long id);

    @Transactional
    @Modifying
    @Query("update Role r set r.orgId=?2,r.grantOrgs=?3,r.code=?4,r.roleName=?5 where  r.id=?1" )
    void updateById(Long id, String orgId, String grantOrgs, String code, String roleName);

    @Transactional
    @Modifying
    @Query("update Role r set r.deleted=true where  r.code=?1" )
    Integer delByCode(String code);

    RolePo findByCode(String code);
}
