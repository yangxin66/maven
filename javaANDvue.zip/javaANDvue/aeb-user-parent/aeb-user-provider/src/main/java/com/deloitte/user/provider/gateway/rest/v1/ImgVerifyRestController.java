package com.deloitte.user.provider.gateway.rest.v1;

import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.user.api.ImgVerifyRestInterface;
import com.deloitte.user.provider.exception.DUserException;
import com.deloitte.user.provider.service.ImgVerifyService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 图形验证码
 *
 * @author lshao
 */
@RestController
@RequestMapping(value = "/api/v1/users/img_verify", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
public class ImgVerifyRestController implements ImgVerifyRestInterface {

    private final ImgVerifyService imgVerifyService;

    public ImgVerifyRestController(ImgVerifyService imgVerifyService) {
        this.imgVerifyService = imgVerifyService;
    }


    @Override
    @GetMapping("/getCodeImg")
    public void getCodeImg(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("image/png");
        OutputStream os = null;
        try {
            os = response.getOutputStream();
            Object[] obj = imgVerifyService.createImage();
            os.write((byte[]) obj[0]);
        } catch(Exception e){
            throw new BusinessException(DUserException.IMAGE_CODE_EXCEPTION.getCode(),
                    DUserException.IMAGE_CODE_EXCEPTION.getMessage(),e);
        } finally {
            if (os != null ){
                os.flush();
                os.close();
            }

        }
    }

    @Override
    @GetMapping("/getCustomCodeImg")
    public void getCodeImg(HttpServletRequest request, HttpServletResponse response, String key) throws IOException {
        response.setContentType("image/png");
        OutputStream os = response.getOutputStream();
        try {
            Object[] obj = imgVerifyService.createImage(key);
            os.write((byte[]) obj[0]);
        } catch (Exception e) {
            throw new BusinessException(DUserException.IMAGE_CODE_EXCEPTION.getCode(),
                    DUserException.IMAGE_CODE_EXCEPTION.getMessage(),e);
        } finally {
            os.flush();
            os.close();
        }
    }
}
