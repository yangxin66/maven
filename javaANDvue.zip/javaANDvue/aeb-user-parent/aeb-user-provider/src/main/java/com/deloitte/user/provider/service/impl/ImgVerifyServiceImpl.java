package com.deloitte.user.provider.service.impl;

import com.deloitte.user.provider.repository.CommonRedisRepository;
import com.deloitte.user.provider.service.ImgVerifyService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * @author lshao
 * <br/>19/07/2019 18:16
 * <br/>
 */
@Service
public class ImgVerifyServiceImpl implements ImgVerifyService {

    private final CommonRedisRepository commonRedisRepository;

    //验证码在缓存中失效秒数
    private final static long EXPIRE_TIME = 300L;

    private final static String img_verify_prefix = "IMAGE_CODE:";

    public ImgVerifyServiceImpl(CommonRedisRepository commonRedisRepository) {
        this.commonRedisRepository = commonRedisRepository;
    }

    // 验证码字符集
    private static final char[] chars = {
            '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
            'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
            'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
            'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    // 字符数量
    private static final int SIZE = 4;
    // 干扰线数量
    private static final int LINES = 10;
    // 宽度
    private static final int WIDTH = 230;
    // 高度
    private static final int HEIGHT = 50;
    // 字体大小
    private static final int FONT_SIZE = 30;

    @Override
    public Object[] createImage() {
        Object[] objs = this.generateImage();
        // 存储验证码
        this.setCache(objs[1].toString().toUpperCase(), objs[1].toString());
        return objs;
    }

    @Override
    public Object[] createImage(String key) {
        Object[] objs = this.generateImage();
        // 存储验证码
        this.setCache(key, objs[1].toString());
        return objs;
    }

    @Override
    public boolean verifyImgCode(String key, String imgCode) {
        String cacheImgCode = (String) commonRedisRepository.get(img_verify_prefix + key);
        if (!Objects.isNull(cacheImgCode) && !Objects.isNull(imgCode)) {
            if (StringUtils.equals(cacheImgCode.toUpperCase(), imgCode.toUpperCase())) {
                commonRedisRepository.remove(img_verify_prefix + key);
                return true;
            }
        }
        return false;
    }

    /**
     * 随机取色
     */
    private static Color getRandomColor() {
        Random ran = new Random();
        return new Color(ran.nextInt(256),
                ran.nextInt(256), ran.nextInt(256));
    }

    /**
     * 生成图片验证码
     *
     * @return object[0]图形验证码的数组，可直接返回到前端,object[1]验证码字符串
     */
    private Object[] generateImage() {
        StringBuilder sb = new StringBuilder();
        // 1.创建空白图片
        BufferedImage image = new BufferedImage(
                WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        // 2.获取图片画笔
        Graphics graphic = image.getGraphics();
        // 3.设置画笔颜色
        graphic.setColor(Color.LIGHT_GRAY);
        // 4.绘制矩形背景
        graphic.fillRect(0, 0, WIDTH, HEIGHT);
        // 5.画随机字符
        Random ran = new Random();
        for (int i = 0; i < SIZE; i++) {
            // 取随机字符索引
            int n = ran.nextInt(chars.length);
            // 设置随机颜色
            graphic.setColor(getRandomColor());
            // 设置字体大小
            graphic.setFont(new Font(
                    null, Font.BOLD + Font.ITALIC, FONT_SIZE));
            // 画字符
            graphic.drawString(
                    chars[n] + "", i * WIDTH / SIZE, HEIGHT * 2 / 3);
            // 记录字符
            sb.append(chars[n]);
        }
        // 6.画干扰线
        for (int i = 0; i < LINES; i++) {
            // 设置随机颜色
            graphic.setColor(getRandomColor());
            // 随机画线
            graphic.drawLine(ran.nextInt(WIDTH), ran.nextInt(HEIGHT),
                    ran.nextInt(WIDTH), ran.nextInt(HEIGHT));
        }
        // 7.返回图片
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, "jpeg", baos);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new Object[]{baos.toByteArray(), sb.toString()};
    }

    private void setCache(String key, String imgCode) {
        commonRedisRepository.set(img_verify_prefix + key, imgCode, EXPIRE_TIME, TimeUnit.SECONDS);

    }
}
