package com.deloitte.user.provider.web.handler;

import com.deloitte.infrastructure.communication.Response;
import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.user.provider.exception.DUserException;
import com.deloitte.user.provider.utils.ResponseUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 同一异常处理
 * date: 24/07/2019 9:46
 *
 * @author wgong
 * @since 0.0.1
 */
@Slf4j
@RestControllerAdvice
public class ExceptionHandlerAdvice {

    /**
     * 方法参数验证不合法的异常处理
     *
     * @param ex 异常
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public Response<String> methodArgumentValidationHandler(MethodArgumentNotValidException ex) {
        List<ObjectError> errors = ex.getBindingResult().getAllErrors();
        String defaultMessage = "参数不合法";
        if (errors.size() > 0) {
            defaultMessage = errors.get(0).getDefaultMessage();
        }
//        log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
        log.error(ex.getMessage(), ex);
        return ResponseUtil.build().createBadResponse(DUserException.SYS_PRAMA_ERROR.getCode(),defaultMessage);
    }

    /**
     * 参数约束异常
     *
     * @param ex 异常
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseBody
    public Response<String> handleValidationException(ConstraintViolationException ex) {
        String message = ex.getConstraintViolations().stream().filter(Objects::nonNull)
                .map(cv -> cv.getPropertyPath() + ": " + cv.getMessage())
                .collect(Collectors.joining(", "));
//        log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
        log.error(ex.getMessage(), ex);
        return ResponseUtil.build().createBadResponse(DUserException.SYS_PRAMA_ERROR.getCode(),message);
    }

    /**
     * 请求方式不支持异常
     *
     * @param ex 异常信息
     */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseBody
    public Response<String> httpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException ex) {
//        log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
        log.error(ex.getMessage(), ex);
        return ResponseUtil.build().createBadResponse(String.valueOf(HttpStatus.METHOD_NOT_ALLOWED.value()),ex.getMessage());
    }

    /**
     * 访问接口参数不全
     *
     * @param ex 异常信息
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseBody
    public Response<String> missingServletRequestParameterException(MissingServletRequestParameterException ex) {
//        log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
        log.error(ex.getMessage(), ex);
        return ResponseUtil.build().createBadResponse(DUserException.SYS_PRAMA_ERROR.getCode(),ex.getMessage());
    }

    /**
     * 绑定异常
     *
     * @param ex 异常信息
     */
    @ExceptionHandler(BindException.class)
    @ResponseBody
    public Response<Map<String, String>> bindException(BindException ex) {
        Map<String, String> map = new HashMap<>();
        List<ObjectError> allErrors = ex.getBindingResult().getAllErrors();
        allErrors.stream()
                .filter(Objects::nonNull)
                .forEach(objectError ->
                        map.put(((FieldError)allErrors.get(0)).getField(), objectError.getDefaultMessage())
                );
//        log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
        log.error(ex.getMessage(), ex);
        return ResponseUtil.build().createBadResponse(DUserException.SYS_PRAMA_ERROR.getCode(),"请求参数绑定失败",map);
    }

    /**
     * 捕获未指定处理的所有的异常
     *
     * @param ex 异常
     */
    @ExceptionHandler(Exception.class)
    public Response handleException(Exception ex) {
        final String DEFAULT_MESSAGE = "发生意外的错误，请稍后重试或联系管理员";
        if(ex instanceof BusinessException) {
            BusinessException userFriendlyException = (BusinessException) ex;
//            log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
            log.error(ex.getMessage(), ex);
            return ResponseUtil.build().createBadResponse(userFriendlyException);
        }
//        log.error(ex.getMessage(), ExceptionUtils.getStackTrace(ex.getCause()));
        log.error(ex.getMessage(), ex);
        return ResponseUtil.build().createBadResponse(DUserException.SYS_PRAMA_ERROR.getCode(),DEFAULT_MESSAGE);
    }

}
