package com.deloitte.user.provider.utils;

import java.util.regex.Pattern;

/**
 * 校验相关的工具类
 * date: 19/07/2019 11:20
 *
 * @author wgong
 * @since 0.0.1
 */
public class ValidateUtils {

    public static boolean isLegalMobile(String mobile) {
        if (mobile == null) {
            return false;
        }
        final String MOBILE_REGEX = "^[1]([3-9])[0-9]{9}$";
        return Pattern.matches(MOBILE_REGEX, mobile);
    }

}
