package com.deloitte.user.provider.service;

import com.deloitte.infrastructure.jpa.service.BaseService;
import com.deloitte.user.api.model.SmsOriginEnum;
import com.deloitte.user.api.model.UserSmsAddDto;
import com.deloitte.user.api.model.UserSmsResetPwdDto;
import com.deloitte.user.provider.repository.model.UserPo;

public interface UserMobileSmsService extends BaseService<UserPo> {

    /**
     * 注册用户
     *
     * @param userSmsAddDto 新增用户实体
     */
    void registerUser(UserSmsAddDto userSmsAddDto);

    /**
     * 登录-校验短信验证码
     *
     * @param mobile 手机号
     */
    boolean checkVerificationCodeFromLogin(String mobile, String code);

    /**
     * 忘记密码-短信验证码校验
     *
     * @param mobile 手机号
     */
    String checkVerificationCodeFromResetPwd(String mobile, String code);

    /**
     * 发送短信验证码
     *
     * @param mobile        手机号
     * @param smsOriginEnum 发送手机号来源
     */
    void sendVerificationCode(String mobile, SmsOriginEnum smsOriginEnum);

    /**
     * 重置密码
     *
     * @param userSmsResetPwdDto 重置密码实体
     */
    void resetPassword(UserSmsResetPwdDto userSmsResetPwdDto);

    /**
     * 重置密码前验证token
     *
     * @param mobile 手机号
     * @param token token
     */
    void verifyTokenFromResetPwd(String mobile, String token);

    /**
     * 判断手机号是否存在
     *
     * @param mobile 手机号
     */
    boolean existsByMobile(String mobile);
}
