package com.deloitte.user.provider.gateway.rest.v1;

import com.deloitte.infrastructure.communication.LanguageEnum;
import com.deloitte.infrastructure.communication.Request;
import com.deloitte.infrastructure.communication.Response;
import com.deloitte.user.api.UserRestInterface;
import com.deloitte.user.api.model.*;
import com.deloitte.user.api.model.UserLoginDto;
import com.deloitte.user.api.model.EmailVerifyDto;
import com.deloitte.user.api.model.UserSmsAddDto;
import com.deloitte.user.api.model.UserDto;
import com.deloitte.user.provider.exception.DUserException;
import com.deloitte.user.provider.repository.model.UserPo;
import com.deloitte.user.provider.service.UserFromEmailService;
import com.deloitte.user.provider.service.UserService;
import com.deloitte.user.provider.utils.ResponseUtil;
import com.deloitte.user.provider.utils.ValidateUtils;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.deloitte.user.provider.service.UserMobileSmsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

/**
 * 用户相关的Rest API
 *
 * @author xideng
 */
@RestController
@RequestMapping(value = "/api/v1/users", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
@Api(value = "用户相关接口", tags = {"UserApi"}, produces = MediaType.APPLICATION_JSON_VALUE)
public class UserRestController implements UserRestInterface {

    private final UserService userService;

    private final UserFromEmailService userFromEmailService;

    private final UserMobileSmsService userMobileSmsService;

    public UserRestController(UserService userService, UserMobileSmsService userMobileSmsService,
                              UserFromEmailService userFromEmailService) {
        this.userService = userService;
        this.userMobileSmsService = userMobileSmsService;
        this.userFromEmailService = userFromEmailService;
    }


    @Override
    @GetMapping(value = "/{id:^\\d+$}")
    public Response<UserDto> get(@PathVariable("id") long id) {
        return new Response<>(LanguageEnum.ZH_CN,Response.SUCCESS_CODE,"success",userService.findById(id));
    }

    @Override
    @PostMapping("/sms")
    @ApiOperation("注册用户")
    @ApiImplicitParam(name = "userSmsAddDtoRequest", value = "用户实体", required = true, dataType = "Request«UserSmsAddDto»")
    public Response<String> registerUser(@Validated @RequestBody Request<UserSmsAddDto> userSmsAddDtoRequest) {
        UserSmsAddDto userSmsAddDto = userSmsAddDtoRequest.getData();
        boolean b = userMobileSmsService.existsByMobile(userSmsAddDto.getMobile());
        if (b) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_REGISTERED.getCode(),
                    DUserException.ACCOUNT_REGISTERED.getMessage());
        }
        if (userSmsAddDto.getPassword().contains(" ")) {

            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_PASSWORD_NOT_BLANK.getCode(),
                    DUserException.ACCOUNT_PASSWORD_NOT_BLANK.getMessage());
        }
        if (userSmsAddDto.getRePassword().contains(" ")) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_PASSWORD_CONFIRM_NOT_BLANK.getCode(),
                    DUserException.ACCOUNT_PASSWORD_CONFIRM_NOT_BLANK.getMessage());
        }
        if (!userSmsAddDto.getPassword().equals(userSmsAddDto.getRePassword())) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_PASSWORD_DIS_MATCH.getCode(),
                    DUserException.ACCOUNT_PASSWORD_DIS_MATCH.getMessage());
        }
        userMobileSmsService.registerUser(userSmsAddDto);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }


    @Override
    @PostMapping("/login/check_verification_code")
    @ApiOperation("登录-校验短信验证码")
    @ApiImplicitParam(name = "userSmsDtoRequest", value = "验证码校验实体", required = true, dataType = "Request«UserSmsDto»")
    public Response<String> checkVerificationCodeFromLogin(@Validated @RequestBody Request<UserSmsDto> userSmsDtoRequest) {
        UserSmsDto userSmsDto = userSmsDtoRequest.getData();
        boolean b = userMobileSmsService.existsByMobile(userSmsDto.getMobile());
        if (!b) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_NOT_REGISTER.getCode(),
                    DUserException.ACCOUNT_NOT_REGISTER.getMessage());
        }
        boolean b1 = userMobileSmsService.checkVerificationCodeFromLogin(userSmsDto.getMobile(), userSmsDto.getCode());
        if (b1) {
            return ResponseUtil.build().creatDeaultOkResponse(null);
        }
        return ResponseUtil.build().createBadResponse(DUserException.CHECK_VALID_CODE_FAIL.getCode(),
                DUserException.CHECK_VALID_CODE_FAIL.getMessage());
    }

    @Override
    @PostMapping("/verification_code")
    @ApiOperation("发送短信验证码")
    @ApiImplicitParam(name = "userSmsSendDtoRequest", value = "手机号和发送短信验证码的来源，包括LOGIN/REGISTER/RESET_PWD",
            required = true, dataType = "Request«UserSmsSendDto»")
    public Response<String> sendVerificationCode(@RequestBody Request<UserSmsSendDto> userSmsSendDtoRequest) {

        String mobile = userSmsSendDtoRequest.getData().getMobile();
        SmsOriginEnum smsOriginEnum = userSmsSendDtoRequest.getData().getSmsOriginEnum();
        if (!ValidateUtils.isLegalMobile(mobile)) {
            return ResponseUtil.build().createBadResponse(DUserException.TELPHONE_FORMAT_ERROR.getCode(),
                    DUserException.TELPHONE_FORMAT_ERROR.getMessage());
        }
        boolean b = userMobileSmsService.existsByMobile(mobile);
        // 如果是注册  若手机号已存在 则不允许注册
        if (SmsOriginEnum.REGISTER.equals(smsOriginEnum)) {
            if (b) {
                return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_REGISTERED.getCode(),
                        DUserException.ACCOUNT_REGISTERED.getMessage());
            }
        } else {
            if (!b) {
                return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_NOT_REGISTER.getCode(),
                        DUserException.ACCOUNT_NOT_REGISTER.getMessage());
            }
        }
        userMobileSmsService.sendVerificationCode(mobile, smsOriginEnum);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @Override
    @PostMapping("/reset_password/check_verification_code")
    @ApiOperation("忘记密码-校验短信验证码")
    @ApiImplicitParam(name = "userSmsDtoRequest", value = "验证码校验实体", required = true, dataType = "Request«UserSmsDto»")
    public Response<String> checkVerificationCodeFromResetPwd(@Validated @RequestBody Request<UserSmsDto> userSmsDtoRequest) {
        UserSmsDto userSmsDto = userSmsDtoRequest.getData();
        boolean b = userMobileSmsService.existsByMobile(userSmsDto.getMobile());
        if (!b) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_NOT_REGISTER.getCode(),
                    DUserException.ACCOUNT_NOT_REGISTER.getMessage());
        }
        String token = userMobileSmsService.checkVerificationCodeFromResetPwd(userSmsDto.getMobile(), userSmsDto.getCode());
        return ResponseUtil.build().creatDeaultOkResponse(token);
    }


    @Override
    @PostMapping("/reset_password/verification_code")
    @ApiOperation("忘记密码-重置密码")
    @ApiImplicitParam(name = "userSmsResetPwdDtoRequest", value = "重置密码实体", required = true, dataType = "Request«UserSmsResetPwdDto»")
    public Response<String> resetPassword(@Validated @RequestBody Request<UserSmsResetPwdDto> userSmsResetPwdDtoRequest) {
        UserSmsResetPwdDto userSmsResetPwdDto = userSmsResetPwdDtoRequest.getData();
        boolean b = userMobileSmsService.existsByMobile(userSmsResetPwdDto.getMobile());
        if (!b) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_NOT_REGISTER.getCode(),
                    DUserException.ACCOUNT_NOT_REGISTER.getMessage());
        }
        if (userSmsResetPwdDto.getPassword().contains(" ")) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_PASSWORD_NOT_BLANK.getCode(),
                    DUserException.ACCOUNT_PASSWORD_NOT_BLANK.getMessage());
        }
        userMobileSmsService.resetPassword(userSmsResetPwdDto);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @Override
    @PostMapping("/reset_password/verify_token")
    @ApiOperation("忘记密码-校验token")
    @ApiImplicitParam(name = "userSmsVerifyTokenRequest", value = "校验token实体", required = true, dataType = "Request«UserSmsVerifyToken»")
    public Response<String> verifyToken(@Validated @RequestBody Request<UserSmsVerifyToken> userSmsVerifyTokenRequest) {
        UserSmsVerifyToken userSmsVerifyToken = userSmsVerifyTokenRequest.getData();
        boolean b = userMobileSmsService.existsByMobile(userSmsVerifyToken.getMobile());
        if (!b) {
            return ResponseUtil.build().createBadResponse(DUserException.ACCOUNT_NOT_REGISTER.getCode(),
                    DUserException.ACCOUNT_NOT_REGISTER.getMessage());
        }
        userMobileSmsService.verifyTokenFromResetPwd(userSmsVerifyToken.getMobile(), userSmsVerifyToken.getToken());
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @ApiOperation(value = "发送注册链接的邮件", notes = "发送注册链接的邮件")
    @ApiImplicitParam(name = "dtoRequest", value = "邮箱和图片验证码", required = true, dataType = "Request«EmailVerifyDto»")
    @Override
    @PostMapping("/email_verify")
    public Response<String> emailVerify(@Validated @RequestBody Request<EmailVerifyDto> dtoRequest) {
        EmailVerifyDto dto = dtoRequest.getData();
        userFromEmailService.generateEmailVerify(dto, UserFromEmailService.SendEmailEnum.REGISTER_INFO);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @Override
    @ApiOperation(value = "发送重置密码的邮件", notes = "发送重置密码的邮件")
    @ApiImplicitParam(name = "dtoRequest", value = "邮箱和验证码", required = true, dataType = "Request«EmailVerifyDto»")
    @PostMapping("/email_repass")
    public Response<String> sendEmailRepass(@RequestBody Request<EmailVerifyDto> dtoRequest) {
        EmailVerifyDto dto = dtoRequest.getData();
        userFromEmailService.generateEmailVerify(dto, UserFromEmailService.SendEmailEnum.FIND_PASSWORD);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @ApiOperation(value = "根据token获取邮箱", notes = "如果获取不到则会出现异常提示")
    @Override
    @PostMapping("/get_email")
    @ApiImplicitParam(name = "tokenRequest", value = "注册链接后面的token值", required = true, dataType = "Request«string»")
    public Response<String> getEmailByToken(@RequestBody  Request<String> tokenRequest) {
        String token = tokenRequest.getData();
        String emailSecurityCode = this.userFromEmailService.getEmailSecurityCode(token, UserFromEmailService.SendEmailEnum.REGISTER_INFO);
        return ResponseUtil.build().creatDeaultOkResponse(emailSecurityCode);
    }

    @Override
    @ApiOperation(value = "获取找回密码的邮箱", notes = "获取找回密码的邮箱")
    @PostMapping("/get_repass_email")
    @ApiImplicitParam(name = "tokenRequest", value = "获取找回密码的邮箱", required = true, dataType = "Request«string»")
    public Response<String> getRepassEmailByToken(@RequestBody  Request<String> tokenRequest) {
        String token = tokenRequest.getData();
        String emailSecurityCode = this.userFromEmailService.getEmailSecurityCode(token, UserFromEmailService.SendEmailEnum.FIND_PASSWORD);
        return ResponseUtil.build().creatDeaultOkResponse(emailSecurityCode);
    }

    @ApiOperation(value = "邮箱的方式注册", notes = "邮箱的方式注册")
    @Override
    @PostMapping("/email_register")
    @ApiImplicitParam(name = "dtoRequest", value = "token", required = true, dataType = "Request«UserEmailDto»")
    public Response<String> registerByEmail(@RequestBody Request<UserEmailDto> dtoRequest) {
        UserEmailDto userEmailDto = dtoRequest.getData();
        this.userFromEmailService.registerUserByEmail(userEmailDto);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @Override
    @PostMapping("/email_update_password")
    @ApiImplicitParam(name = "dtoRequest", value = "token和密码", required = true, dataType = "Request«UserEmailDto»")
    public Response<String> updatePasswordByEmail(@RequestBody Request<UserEmailDto> dtoRequest) {
        UserEmailDto userEmailDto = dtoRequest.getData();
        this.userFromEmailService.updatePasswordByEmail(userEmailDto);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    /**
     * 用户登录-账号密码登陆接口
     *
     * @param loginInfoRequest 用户登录信息实体
     */
    @Override
    @ApiOperation(value = "用户登录-账号密码登陆接口", notes = "用户登录-账号或邮箱密码登陆接口")
    @ApiImplicitParam(name = "loginInfoRequest", value = "用户名登录信息", required = true, dataType = "Request«UserLoginDto»")
    @PostMapping(value = "/login/acct")
    public Response<String> loginByAccount(@RequestBody Request<UserLoginDto> loginInfoRequest){
        UserLoginDto userLoginDto = loginInfoRequest.getData();
        userService.loginByAcct(userLoginDto);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    /**
     * 用户登录-判断是否需要进行图片验证码验证
     *
     * @param accountRequest 账号或邮箱信息
     */
    @Override
    @ApiOperation(value = "用户登录-判断是否需要进行图片验证码验证", notes = "用户登录-判断是否需要进行图片验证码验证")
    @ApiImplicitParam(name = "accountRequest", value = "手机号或邮箱", required = true, dataType = "Request«UserLoginDto»")
    @PostMapping(value = "/login/is_dispalay_verifycation_code")
    public Response<CheckVerifycationRespDto> isCheckVerifycationCode(@RequestBody Request<UserLoginDto> accountRequest) {
        String account = accountRequest.getData().getAccount();
        boolean isDisplayVerifycationCode = userService.isCheckVerifycationCode(account);
        CheckVerifycationRespDto resp = new CheckVerifycationRespDto();
        resp.setCheckResult(isDisplayVerifycationCode);
        return ResponseUtil.build().creatDeaultOkResponse(resp);
    }


    @ApiOperation(value = "注册用户,注该注册仅其它系统调用,非用户直接注册")
    @ApiImplicitParam(name = "userDhrDtoRequest", value = "用户实体", required = true, dataType = "Request«UserDhrDto»")
    @Override
    @PostMapping(value = "/syn_register")
    public Response<String> registerUserByOtherSystem(@Validated @RequestBody Request<UserDhrDto> userDhrDtoRequest) {
        UserDhrDto userDhrDto = userDhrDtoRequest.getData();
        this.userFromEmailService.registerUserByDhr(userDhrDto);
        return ResponseUtil.build().creatDeaultOkResponse(null);
    }

    @ApiOperation(value = "查询用户信息")
    @ApiImplicitParam(name = "loginAccountRequest", value = "登录账户，可以是手机号、邮箱、员工编号", required = true, dataType = "Request«string»")
    @Override
    @PostMapping(value = "/user/query")
    public Response<UserDto> queryUserInfoByAccount(@RequestBody Request<String> loginAccountRequest){
        String loginAcct = loginAccountRequest.getData();
        UserPo userPo = userService.findUserByAccountOrEmail(loginAcct);
        if (userPo == null){
            return ResponseUtil.build().createBadResponse(DUserException.USER_NOT_FOUND.getCode(),
                    DUserException.USER_NOT_FOUND.getMessage());
        }else {
            userPo.setPassword(null);
            return ResponseUtil.build().creatDeaultOkResponse(userPo);
        }
    }
}
