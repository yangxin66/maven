package com.deloitte.user.provider.repository.model;


import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "dhr_sys_user_role_rel")
@Entity(name = "RoleUserRel")
@SQLDelete(sql = "update RoleUserRel set RoleUserRel.deleted = 1 where RoleUserRel.id = ?")
@Where(clause = "deleted = 0")
public class RoleUserRelPo extends BasePo {

    private static final long serialVersionUID = -7875776844176219712L;

    @Column(name = "pernr",length = 50)
    private String pernr;

    @Column(name = "org_id",length = 50)
    private String orgId;

    @Column(name = "role_id",length = 50)
    private Long roleId;

}
