package com.deloitte.user.provider.service;

/**
 * @author lshao
 * <br/>19/07/2019 18:11
 * <br/>
 */
public interface ImgVerifyService {
    /**
     * 生成随机图片验证码
     * @param key 生成的验证码会存储到该redis键之中
     * @return object[0]图形验证码的数组，可直接返回到前端,object[1]验证码字符串
     */
    Object[] createImage(String key);

    /**
     * 生成随机图片验证码，默认将验证码为键值进行缓存
     * @return object[0]图形验证码的数组，可直接返回到前端,object[1]验证码字符串
     */
    Object[] createImage();

    /**
     * 验证图形验证码
     * @param key 验证该键对应的图形验证码
     * @param imgCode 需要验证的图形验证码
     * @return 验证通过返回true，否则false
     */
    boolean verifyImgCode(String key,String imgCode);
}
