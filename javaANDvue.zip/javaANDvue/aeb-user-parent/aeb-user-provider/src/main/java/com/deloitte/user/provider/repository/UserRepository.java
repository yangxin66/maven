package com.deloitte.user.provider.repository;

import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.user.provider.repository.model.UserPo;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends BaseRepository<UserPo> {

    Optional<UserPo> findByMobileAndDeletedIsFalse(String mobile);

    // 通过用户名查询用户信息
    UserPo findByMobileAndDeletedFalseAndEnabledTrue(String username);

    // 通过邮箱查询用户信息
    UserPo findByEmailAndDeletedFalseAndEnabledTrue(String username);

    // 通过员工编号查询用户信息
    UserPo findByStaffNoAndDeletedFalseAndEnabledTrue(String username);

}
