package com.deloitte.user.provider.repository.model;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 手机短信验证码Persistent Object
 * <p>
 * date: 21/07/2019 11:59
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
public class MobileValidateCodePo {

    /**
     * 手机验证码
     */
    private String code;

    /**
     * 同一验证码校验的次数
     */
    private int verifyNumber;

    /**
     * 过期时间的毫秒数
     */
    private long expiredMillis;

    public boolean isExpired() {
        return expiredMillis < System.currentTimeMillis();
    }
}
