package com.deloitte.user.provider.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * <br/>23/07/2019 17:16
 *
 * @author lshao
 */
@Data
@Component
@ConfigurationProperties(prefix = EmailProperties.PREFIX)
public class EmailProperties {
    public static final String PREFIX = "com.deloitte.email";
    //邮件中的注册地址
    public String registerUrl = "http://localhost:3000/#/email-register";
    //邮件中的找回密码地址
    public String repassUrl = "http://localhost:3000/#/forget-forward";
    //每两封邮件间隔的阈值内，发送的code相同
    private long intervalTime = 1800L;
    //此阈值过后解除email的限制发送次数的限制
    private long limitSendTime = 86400L;
    //每个email在限制时间内最多只能发送的次数
    private int limitSendCount = 20;
}
