package com.deloitte.user.provider.repository;


import com.deloitte.infrastructure.jpa.repository.BaseRepository;
import com.deloitte.user.provider.repository.model.RoleUserRelPo;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;


@Repository
public interface RoleUserRelRepository extends BaseRepository<RoleUserRelPo> {

    @Transactional
    @Modifying
    @Query("update RoleUserRel r set r.roleId=?2 where r.pernr=?1" )
    Integer updateRoleId(String pernr, Long roleId);

    List<RoleUserRelPo> findByPernr(String pernr);

    @Transactional
    @Modifying
    @Query("update RoleUserRel r set r.deleted=true where  r.pernr=?1" )
    void removeByPernr(String pernr);


    List<RoleUserRelPo> findByPernrIn(List<String> pernrList);
}
