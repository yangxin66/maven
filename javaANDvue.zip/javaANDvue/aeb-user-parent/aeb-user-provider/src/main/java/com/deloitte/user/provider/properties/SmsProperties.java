package com.deloitte.user.provider.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 短信验证码配置文件
 *
 * @author wgong
 * @since 0.0.1
 */
@Data
@Component
@ConfigurationProperties(prefix = SmsProperties.PREFIX)
public class SmsProperties {

    public static final String PREFIX = "com.deloitte.sms";

    /**
     * 短信模板
     */
    private String templateCode;

    /**
     * 短信签名
     */
    private String signName;

    /**
     * 验证码长度
     */
    private int codeSize = 6;

    /**
     * 验证码过期时间（分钟） 初始是1分钟
     */
    private int deadVerifyMinute = 1;

    /**
     * 同一验证码允许验证的最大次数 初始是3次
     */
    private int sameCodeMaxVerifyNumber = 3;

    /**
     * 同一个手机号码，24小时内，连续验证失败的最大次数，初始是10次
     */
    private int cumulativeFailureNumber = 10;

    /**
     * 同一个手机号码，24小时内，最多可以获取验证码的次数，初始是20次
     */
    private int maxSendNumber = 20;

    /**
     * 判断连续失败或者获取验证码次数的时间,默认为24小时
     */
    private int mobileValidateLimitTime = 24;

}
