package com.deloitte.user.provider.service.impl;

import com.deloitte.infrastructure.ex.BusinessException;
import com.deloitte.infrastructure.jpa.service.BaseServiceImpl;
import com.deloitte.user.api.model.UserLoginDto;
import com.deloitte.user.api.model.UserSmsAddDto;
import com.deloitte.user.api.model.UserDto;
import com.deloitte.user.provider.exception.DUserException;
import com.deloitte.user.provider.properties.Constant;
import com.deloitte.user.provider.properties.SmsProperties;
import com.deloitte.user.provider.repository.CommonRedisRepository;
import com.deloitte.user.provider.repository.UserRepository;
import com.deloitte.user.provider.repository.model.UserPo;
import com.deloitte.user.provider.service.ImgVerifyService;
import com.deloitte.user.provider.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * 用户服务层
 *
 * @author xideng
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class UserServiceImpl extends BaseServiceImpl<UserPo> implements UserService {
    private Logger log = LoggerFactory.getLogger(this.getClass());

    private final UserRepository repository;

    private final SmsProperties smsProperties;

    private final CommonRedisRepository commonRedisRepository;

    @Autowired
    private ImgVerifyService imgVerifyService;
    // 手机验证码的存储前缀
    private final String MOBILE_VALIDATE_PREFIX = "SMS:MOBILE_VALIDATE:";

    // 同一个手机号码，24小时内，连续验证失败次数的存储前缀
    private final String CUMULATIVE_FAILURE_NUMBER_PREFIX = "SMS:CUMULATIVE_FAILURE_NUMBER:";

    // 同一个手机号码，24小时内，最多可以获取验证码的次数的前缀
    private final String SEND_NUMBER_PREFIX = "SMS:SEND_NUMBER:";

    // 发送短信限制时间 24小时
    private final long MOBILE_VALIDATE_LIMIT_TIME = 24;



    // 账户被锁最长时间，需配置到配置文件或配置中心
    /**
     * @author liuchun
     */
    private final int accountLockedMaxMinutes = 30;
    private final String accountLockedExpireTimeFormate = "yyyy-MM-dd:HH:mm:ss";
    private final int accountLoginFaileMaxCount = 5;
    private final int redisExpireMinutes = 30;

    public UserServiceImpl(UserRepository repository, SmsProperties smsProperties, CommonRedisRepository commonRedisRepository) {
        super(repository);
        this.repository = repository;
        this.smsProperties = smsProperties;
        this.commonRedisRepository = commonRedisRepository;
    }

    @Override
    public UserDto findById(long id) {
        return repository.findById(id).map(po -> {
            UserDto dto = new UserDto();
            dto.setId(po.getId());
            dto.setOid(po.getOid());
            dto.setEmail(po.getEmail());
            dto.setMobile(po.getMobile());
            dto.setEnabled(po.getEnabled());
            return dto;
        }).orElse(null);
    }

    @Override
    public void sendVerificationCode(String mobile) {
        final long STEP = 1;
        Object sendNumber = commonRedisRepository.get(SEND_NUMBER_PREFIX + mobile);
        Object cumulativeFailureNumber = commonRedisRepository.get(CUMULATIVE_FAILURE_NUMBER_PREFIX + mobile);
        if (sendNumber != null && (int)sendNumber >= 20) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_GET_TOO_MANY_TIMES.getCode(),
                    String.format(DUserException.SMS_VALIDCODE_GET_TOO_MANY_TIMES.getMessage(),24));
        }
        if (cumulativeFailureNumber != null && (int)cumulativeFailureNumber >= 10) {
            throw new BusinessException(DUserException.SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES.getCode(),
                    String.format(DUserException.SMS_VALIDCODE_CHECKFAILT_TOO_MANY_TIMES.getMessage(),24));
        }
        String code = createRandomNum(smsProperties.getCodeSize());
        // 如果验证码已存在
//        boolean b = standardRedisRepository.hasKey(MOBILE_VALIDATE_PREFIX + mobile);
        // 这里发送手机验证码
        // send()
        // 保存验证码 默认配置的有效期为1分钟
        commonRedisRepository.set(MOBILE_VALIDATE_PREFIX + mobile, code, smsProperties.getDeadVerifyMinute(), TimeUnit.MINUTES);

        // 保存发送验证码的次数 每次加1
        commonRedisRepository.increment(SEND_NUMBER_PREFIX + mobile, STEP, MOBILE_VALIDATE_LIMIT_TIME, TimeUnit.HOURS);
    }

    @Override
    public void checkVerificationCode(String mobile, String code) {

    }

    @Override
    public void addUser(UserSmsAddDto userSmsAddDto) {
        final String SAME_CODE_VERIFY_NUMBER_PREFIX = "SMS:SAME_CODE_VERIFY_NUMBER:";

//        Object sameCodeVerifyNumber = commonRedisRepository.get(SAME_CODE_VERIFY_NUMBER_PREFIX + userSmsAddDto.getMobile() + "-" + userSmsAddDto.getCode());
        // 根据手机号获取redis中的验证码
        Object code = commonRedisRepository.get(MOBILE_VALIDATE_PREFIX + userSmsAddDto.getMobile());
        // 如果验证码不存在
        if(code == null) {
            throw new BusinessException(DUserException.CHECK_VALID_CODE_FAIL.getCode(),DUserException.CHECK_VALID_CODE_FAIL.getMessage());
        }



    }

    /**
     * 判断手机号是否存在
     *
     * @param mobile 手机号
     */
    @Override
    public boolean existsByMobile(String mobile) {
        Optional<UserPo> userPoOptional = repository.findByMobileAndDeletedIsFalse(mobile);
        return userPoOptional.isPresent();
    }

    /**
     *
     * @param accountOrEmail
     * @return
     */
    @Override
    public UserPo findUserByAccountOrEmail(String accountOrEmail) {
        // todo  2019/07/22   用户信息查询结果缓存处理

        UserPo userPo = repository.findByMobileAndDeletedFalseAndEnabledTrue(accountOrEmail);
        if (userPo == null){
            userPo = repository.findByEmailAndDeletedFalseAndEnabledTrue(accountOrEmail);
        }
        if (userPo == null){
            userPo = repository.findByStaffNoAndDeletedFalseAndEnabledTrue(accountOrEmail);
        }

        return userPo;
    }

    @Override
    public boolean isCheckVerifycationCode(String account) {
        // 账号连续登录失败次数
        String loginAcountContinuityFailCuntKey = Constant.LOGIN_ACOUNT_CONTINUITY_FAIL_CUNT_KEY_PREFIX + account;
        // 账号连续登录失败次数
        boolean isCheckVerificationCode = false;
        String loginAcountContinuityFailCuntStr =  (String) commonRedisRepository.get(loginAcountContinuityFailCuntKey);
        if (loginAcountContinuityFailCuntStr != null){
            int loginAcountContinuityFailCunt = Integer.parseInt(loginAcountContinuityFailCuntStr);
            isCheckVerificationCode = loginAcountContinuityFailCunt >= 3 ;
        }
        return isCheckVerificationCode;
    }

    @Override
    public void loginByAcct(UserLoginDto loginInfo) {
        // redis变量   变量名待定
        // 图片验证码KEY
        //String loginImageCodeKey = Constant.LOGIN_IMAGE_CODE_KEY_PREFIX + loginInfo.getAccount();
        // 账号被锁标志  0-未锁  1-被锁定
        String loginAcountLockedKey = Constant.LOGIN_ACOUNT_LOCKED_KEY_PREFIX + loginInfo.getAccount();
        // 账号被锁时间 时间格式:yyyy-MM-dd HH:mm:ss
        String loginAcountLockedTimeKey = Constant.LOGIN_ACOUNT_LOCKED_TIME_KEY_PREFIX + loginInfo.getAccount();
        // 账号连续登录失败次数
        String loginAcountContinuityFailCuntKey = Constant.LOGIN_ACOUNT_CONTINUITY_FAIL_CUNT_KEY_PREFIX + loginInfo.getAccount();

        // 检查账户是否被锁
        this.checkAccountLocked(loginInfo.getAccount());

        // 账号连续登录失败次数
        boolean isCheckVerificationCode = this.isCheckVerifycationCode(loginInfo.getAccount());
        int loginAcountContinuityFailCunt = 0;
        String loginAcountContinuityFailCuntStr =  (String) commonRedisRepository.get(loginAcountContinuityFailCuntKey);
        if (loginAcountContinuityFailCuntStr != null){
            loginAcountContinuityFailCunt = Integer.parseInt(loginAcountContinuityFailCuntStr);
        }
        if (isCheckVerificationCode){
            // 校验验证码
            if (StringUtils.isEmpty(loginInfo.getVerificationCode())){
                throw new BusinessException(DUserException.SMS_VALIDCODE_NULL.getCode(),DUserException.SMS_VALIDCODE_NULL.getMessage());
            }
            boolean verifiCheckResult = imgVerifyService.verifyImgCode(loginInfo.getAccount(),loginInfo.getVerificationCode());
            if (!verifiCheckResult) {
                // 验证码校验未通过
                loginFailHandle(loginInfo.getAccount(),loginAcountContinuityFailCunt,"验证码不正确");
            }
        }

        UserPo userPo = this.findUserByAccountOrEmail(loginInfo.getAccount());
        if (userPo == null){
            // 用户不存在
            throw new BusinessException(DUserException.USER_NOT_REGISTER.getCode(),DUserException.USER_NOT_REGISTER.getMessage());
        }
        // 密码校验
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        boolean checkPassword = passwordEncoder.matches(loginInfo.getPassword(),userPo.getPassword());
        if (!checkPassword){
            // 密码校验失败后控制处理
            loginFailHandle(loginInfo.getAccount(),loginAcountContinuityFailCunt,"账号或密码错误");
        }else {
            // 登录成功，连续失败次数变量缓存删除
            commonRedisRepository.remove(loginAcountContinuityFailCuntKey);
        }
    }

    @Override
    public void checkAccountLocked(String account){
        // 账号被锁标志  0-未锁  1-被锁定
        String loginAcountLockedKey = Constant.LOGIN_ACOUNT_LOCKED_KEY_PREFIX + account;
        // 账号被锁时间 时间格式:yyyy-MM-dd HH:mm:ss
        String loginAcountLockedTimeKey = Constant.LOGIN_ACOUNT_LOCKED_TIME_KEY_PREFIX + account;
        String loginAcountLockedStr = (String)commonRedisRepository.get(loginAcountLockedKey);
        if(loginAcountLockedStr != null && !"0".equals(loginAcountLockedStr)){
            // 账号被锁定
            String loginAcountLockedTimeStr = (String)commonRedisRepository.get(loginAcountLockedTimeKey);
            if (loginAcountLockedTimeStr != null){
                long diffMinute = calcDateDiffMinute(loginAcountLockedTimeStr);
                String errMsg = String.format(DUserException.ACCOUNT_LOCKED.getMessage(),diffMinute);
                throw new BusinessException(DUserException.ACCOUNT_LOCKED.getCode(),errMsg);
            }
        }
    }

    /**
     *  登录失败后台控制处理，比如连续登录失败次数，账户是否被锁，还有多久解锁等
     * @param account   账户名或邮箱
     * @param loginAcountContinuityFailCunt 连续登录失败次数
     * @param errMessage 登录失败信息
     * @return
     */
    private void loginFailHandle(String account,int loginAcountContinuityFailCunt,String errMessage){
        // 账号被锁标志  0-未锁  1-被锁定
        String loginAcountLockedKey = Constant.LOGIN_ACOUNT_LOCKED_KEY_PREFIX + account;
        // 账号被锁时间 时间格式:yyyy-MM-dd HH:mm:ss
        String loginAcountLockedTimeKey = Constant.LOGIN_ACOUNT_LOCKED_TIME_KEY_PREFIX + account;
        // 账号连续登录失败次数
        String loginAcountContinuityFailCuntKey = Constant.LOGIN_ACOUNT_CONTINUITY_FAIL_CUNT_KEY_PREFIX + account;

        if (loginAcountContinuityFailCunt >= (accountLoginFaileMaxCount - 1)){
            // 连续登录失败5次时，锁定账户
            Date lockedExpireTime = DateUtils.addMinutes(new Date(),accountLockedMaxMinutes);
            String locedExpireTime = DateFormatUtils.format(lockedExpireTime,accountLockedExpireTimeFormate);
            String loginAcountLocked = "1";
            commonRedisRepository.set(loginAcountLockedKey,loginAcountLocked,redisExpireMinutes, TimeUnit.MINUTES);
            commonRedisRepository.set(loginAcountLockedTimeKey,locedExpireTime,redisExpireMinutes, TimeUnit.MINUTES);
            String errMsg = String.format(DUserException.ACCOUNT_LOCKED.getMessage(),30);
            throw new BusinessException(DUserException.ACCOUNT_LOCKED.getCode(),errMsg);
        }

        loginAcountContinuityFailCunt += 1;
        commonRedisRepository.set(loginAcountContinuityFailCuntKey,String.valueOf(loginAcountContinuityFailCunt),redisExpireMinutes,TimeUnit.MINUTES);
        String errMsg = String.format("%s,您还可以尝试%d次",errMessage,accountLoginFaileMaxCount - loginAcountContinuityFailCunt);
        throw new BusinessException(DUserException.ACCOUNT_LOGIN_FAILT.getCode(),errMsg);
    }

    /**
     * 计算解锁到期时间，还剩多少分钟
     * @param endDate 解锁到期时间
     * @return 还剩被锁分钟数
     * @throws Exception
     */
    private long calcDateDiffMinute(String endDate){
        Date now = new Date();
        try{
            Date lockedDate = DateUtils.parseDate(endDate,accountLockedExpireTimeFormate);
            long nm = 1000 * 60;
            long diff = lockedDate.getTime() - now.getTime();
            long diffMinute = diff / nm;
            return diffMinute;
        }catch (Exception e){
            log.error("解锁到期时间解析异常",e);
        }
        return 0;
    }

    /**
     * 生成指定位数的随机验证码
     *
     * @param codeSize 随机验证码的位数
     */
    private String createRandomNum(long codeSize) {
        StringBuilder stringBuilder = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < codeSize; i++) {
            stringBuilder.append(random.nextInt(10));
        }
        return stringBuilder.toString();
    }
}
