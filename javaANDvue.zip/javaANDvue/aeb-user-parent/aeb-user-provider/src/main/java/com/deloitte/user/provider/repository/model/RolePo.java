package com.deloitte.user.provider.repository.model;


import com.deloitte.infrastructure.jpa.entity.BasePo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Table(name = "dhr_sys_role")
@Entity(name = "Role")
@SQLDelete(sql = "update Role set Role.deleted = 1 where Role.id = ?")
@Where(clause = "deleted = 0")
public class RolePo extends BasePo {

    private static final long serialVersionUID = 8372327215731661970L;

    @Column(name = "role_name",length = 50)
    private String roleName;

    @Column(name = "org_id",length = 50)
    private String orgId;

    @Column(name = "grant_orgs",length = 50)
    private String grantOrgs;

    @Column(name = "code",length = 50)
    private String code;

}
